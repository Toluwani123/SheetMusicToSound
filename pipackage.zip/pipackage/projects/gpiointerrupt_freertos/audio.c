/*
 * audio.c -- DAC8311 output, sine/pitch tables, interpolation, envelope and
 * the Timer2 sample ISR.
 *
 * Moved from gpiointerrupt.c (baseline latestb4rtos.zip); waveform math, tables,
 * envelope and ISR body are unchanged. Hardware owned here: SSI2 (PD3 clock, PD1 data),
 * PN3 DAC SYNC, PH2 amplifier shutdown (HIGH = off) and Timer2.
 *
 * RTOS integration: the Timer2 sample ISR runs at NVIC priority 0, above the
 * FreeRTOS interrupt ceiling, so it never calls the kernel and kernel critical
 * sections never delay it. Audio_startNote()/Audio_stopNote() may be called from
 * a task or from the Timer3 ISR (priority 2); each briefly masks interrupts
 * (PRIMASK) so the sample ISR cannot interleave with the SSI2/DAC transaction or
 * a half-written envelope. The masked time is one DAC word (~10 us), well under
 * the 50 us sample period, and no task lock is involved.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/*
 * Tell DriverLib exactly which MSP432E4 device
 * we are compiling for.
 *
 * This MUST appear before driverlib.h.
 */
#ifndef __MSP432E401Y__
#define __MSP432E401Y__
#endif

#include <ti/devices/msp432e4/driverlib/driverlib.h>

#include "audio.h"
#include "audio_instruments.h"   /* generated: clarinetTable, trumpetTable, marimbaTable */
#include "globals.h"


/* ============================================================
 * AUDIO CONFIGURATION
 * ============================================================
 */
#define DAC_SPI_BIT_RATE_HZ      2000000U

/*
 * DAC8311 midpoint.
 *
 * DAC range = 0 ... 16383
 */
#define DAC_IDLE_CODE            8192U


/*
 * Audio sample rate:
 *
 * 120 MHz / 6000 = 20,000 samples/second.
 */
#define AUDIO_SAMPLE_RATE_HZ     20000U
#define AUDIO_TIMER_COUNTS       6000U


#define SINE_TABLE_SIZE          256U
#define SINE_TABLE_BITS          8U

/* Highest DAC8311 code (14-bit). Every output is clamped to 0..this. */
#define DAC_MAX_CODE             16383U

/* Existing output gain applied to the table's deviation from midpoint. */
#define AUDIO_OUTPUT_GAIN        3


/* ============================================================
 * WAVEFORM QUALITY OPTIONS (Milestone: interpolation + ramps)
 * ============================================================
 *
 * Set either option to 0 and rebuild to reproduce the previous
 * nearest-entry / hard-switched output for before/after recordings.
 * With both set to 0 the DAC codes equal the pre-milestone firmware.
 */
#ifndef AUDIO_USE_INTERPOLATION
#define AUDIO_USE_INTERPOLATION  1
#endif
#ifndef AUDIO_USE_ENVELOPE
#define AUDIO_USE_ENVELOPE       1
#endif

/* Fraction bits kept between adjacent table entries (Q16). The lowest
 * 8 phase bits are dropped: they are far below one DAC code step.
 */
#define INTERP_FRACTION_BITS     16U

/* Linear attack/release length. 5 ms = 100 samples at 20 kHz. */
#define ENV_RAMP_MS              5U
#define ENV_RAMP_SAMPLES         ((AUDIO_SAMPLE_RATE_HZ / 1000U) * ENV_RAMP_MS)

/* The release reaches zero this many samples before the scheduled Note Off,
 * absorbing the small start offset between Timer2 and Timer3.
 */
#define ENV_END_GUARD_SAMPLES    2U

/* Q15 gain: 0 = silence, ENV_GAIN_ONE = existing normal amplitude. */
#define ENV_GAIN_ONE             32768U

/* Record audio-ISR execution time with the Cortex-M4 cycle counter. */
#define AUDIO_ISR_PROFILE        1

/* Bit-mask wraparound below is only valid for a power-of-two table. */
typedef char sineTableSizeIsPowerOfTwo[
    ((SINE_TABLE_SIZE == (1U << SINE_TABLE_BITS)) &&
     ((SINE_TABLE_SIZE & (SINE_TABLE_SIZE - 1U)) == 0U)) ? 1 : -1];


/* ============================================================
 * SINE-WAVE TABLE
 * ============================================================
 */

/* 256 samples of one cycle: round(8192 + 2500*sin(2*pi*i/256)).
 * Precomputed constants: no runtime floating-point sine calculation.
 * The audio ISR retains its existing x3 gain and 20 kHz update rate.
 */
static const uint16_t sineTable[SINE_TABLE_SIZE] =
{
    8192, 8253, 8315, 8376, 8437, 8498, 8559, 8619,
    8680, 8740, 8799, 8859, 8918, 8976, 9034, 9092,
    9149, 9205, 9261, 9316, 9370, 9424, 9477, 9529,
    9581, 9632, 9681, 9730, 9778, 9825, 9871, 9916,
    9960, 10003, 10044, 10085, 10125, 10163, 10200, 10236,
    10271, 10304, 10336, 10367, 10397, 10425, 10452, 10478,
    10502, 10524, 10546, 10566, 10584, 10601, 10617, 10631,
    10644, 10655, 10665, 10673, 10680, 10685, 10689, 10691,
    10692, 10691, 10689, 10685, 10680, 10673, 10665, 10655,
    10644, 10631, 10617, 10601, 10584, 10566, 10546, 10524,
    10502, 10478, 10452, 10425, 10397, 10367, 10336, 10304,
    10271, 10236, 10200, 10163, 10125, 10085, 10044, 10003,
    9960, 9916, 9871, 9825, 9778, 9730, 9681, 9632,
    9581, 9529, 9477, 9424, 9370, 9316, 9261, 9205,
    9149, 9092, 9034, 8976, 8918, 8859, 8799, 8740,
    8680, 8619, 8559, 8498, 8437, 8376, 8315, 8253,
    8192, 8131, 8069, 8008, 7947, 7886, 7825, 7765,
    7704, 7644, 7585, 7525, 7466, 7408, 7350, 7292,
    7235, 7179, 7123, 7068, 7014, 6960, 6907, 6855,
    6803, 6752, 6703, 6654, 6606, 6559, 6513, 6468,
    6424, 6381, 6340, 6299, 6259, 6221, 6184, 6148,
    6113, 6080, 6048, 6017, 5987, 5959, 5932, 5906,
    5882, 5860, 5838, 5818, 5800, 5783, 5767, 5753,
    5740, 5729, 5719, 5711, 5704, 5699, 5695, 5693,
    5692, 5693, 5695, 5699, 5704, 5711, 5719, 5729,
    5740, 5753, 5767, 5783, 5800, 5818, 5838, 5860,
    5882, 5906, 5932, 5959, 5987, 6017, 6048, 6080,
    6113, 6148, 6184, 6221, 6259, 6299, 6340, 6381,
    6424, 6468, 6513, 6559, 6606, 6654, 6703, 6752,
    6803, 6855, 6907, 6960, 7014, 7068, 7123, 7179,
    7235, 7292, 7350, 7408, 7466, 7525, 7585, 7644,
    7704, 7765, 7825, 7886, 7947, 8008, 8069, 8131
};


/* ============================================================
 * INSTRUMENT PRESETS
 * ============================================================
 *
 * An instrument is a wave table plus an attack/release length. The sample ISR is
 * unchanged apart from reading the table through a pointer.
 *
 *   SINE      the original sound; the default after reset, so earlier tests behave
 *             exactly as before (5 ms ramps).
 *   CLARINET  odd harmonics only (hollow, reedy), slower attack.
 *   TRUMPET   broad spectrum, strongest 2nd to 5th harmonics (bright, brassy), slow attack.
 *   MARIMBA   fundamental plus the 4th and 10th harmonics (the marimba's woody overtones),
 *             quick attack, then a fade after the strike (the only preset with a decay stage).
 *   (ORGAN and GUITAR presets were scrapped for now; their measured spectra are archived in
 *   test_tools/instrument_spectra.json.)
 *
 * The shapes were fitted to oscilloscope captures of virtual instruments (waveforms/,
 * test_tools/analyze_scope_waveforms.py). Tables for CLARINET, TRUMPET and MARIMBA come
 * from audio_instruments.h (generated by test_tools/generate_instrument_tables.py, which
 * also reads the *_ATTACK_MS / *_RELEASE_MS / *_DECAY_* #defines below to render its .wav previews --
 * keep them plain numbers). The clarinet ramps were chosen by ear; the trumpet and marimba
 * ramps and the marimba decay are judgement values (the 20 ms captures do not show a note
 * start, end or fade), so tune them by listening.
 *
 * An instrument chosen with Audio_setInstrument() is latched when a note starts
 * (audioStartVoiceLocked), so a change can never alter a note that is already sounding.
 */
#define CLARINET_ATTACK_MS       25U
#define CLARINET_RELEASE_MS      20U
#define TRUMPET_ATTACK_MS        30U
#define TRUMPET_RELEASE_MS       25U
#define MARIMBA_ATTACK_MS         2U
#define MARIMBA_RELEASE_MS       15U
#define MARIMBA_DECAY_MS        350U     /* fade from full level to the floor after the attack */
#define MARIMBA_DECAY_FLOOR_PERCENT 8U   /* level the fade settles at, in percent */

#define AUDIO_MS_TO_SAMPLES(ms)  ((AUDIO_SAMPLE_RATE_HZ / 1000U) * (ms))
#define AUDIO_PERCENT_TO_Q15(p)  (((p) * ENV_GAIN_ONE) / 100U)

/* The decay arithmetic multiplies a decay length by 2^15 in 32 bits: at most 100,000 samples (5 s). */
typedef char decayLengthFits[(AUDIO_MS_TO_SAMPLES(MARIMBA_DECAY_MS) <= 100000U) ? 1 : -1];

typedef struct
{
    const uint16_t *table;          /* SINE_TABLE_SIZE entries, DAC codes around DAC_IDLE_CODE */
    uint32_t attackSamples;
    uint32_t releaseSamples;
    uint32_t decaySamples;          /* 0 = no decay stage (hold at full level) */
    uint32_t decayFloorQ15;         /* level the decay settles at (Q15); unused when decaySamples = 0 */
} Instrument;

/* Indexed by AUDIO_INSTRUMENT_* (audio.h). Instruments without a decay stage behave exactly
 * as before the decay stage existed. */
static const Instrument g_instruments[AUDIO_INSTRUMENT_COUNT] =
{
    { sineTable,     AUDIO_MS_TO_SAMPLES(ENV_RAMP_MS),        AUDIO_MS_TO_SAMPLES(ENV_RAMP_MS),        0U, 0U },
    { clarinetTable, AUDIO_MS_TO_SAMPLES(CLARINET_ATTACK_MS), AUDIO_MS_TO_SAMPLES(CLARINET_RELEASE_MS), 0U, 0U },
    { trumpetTable,  AUDIO_MS_TO_SAMPLES(TRUMPET_ATTACK_MS),  AUDIO_MS_TO_SAMPLES(TRUMPET_RELEASE_MS),  0U, 0U },
    { marimbaTable,  AUDIO_MS_TO_SAMPLES(MARIMBA_ATTACK_MS),  AUDIO_MS_TO_SAMPLES(MARIMBA_RELEASE_MS),
      AUDIO_MS_TO_SAMPLES(MARIMBA_DECAY_MS), AUDIO_PERCENT_TO_Q15(MARIMBA_DECAY_FLOOR_PERCENT) }
};


/* ============================================================
 * MIDI NOTE FREQUENCY TABLE
 * ============================================================
 *
 * Frequencies are stored in milli-Hz.
 *
 * Example:
 *
 * MIDI 60:
 * 261.626 Hz
 * =
 * 261626 milli-Hz
 *
 * This avoids using floating point.
 */

static const uint32_t midiFrequencyMilliHz[] =
{
    130813,     /* 48 C3  */
    138591,     /* 49 C#3 */
    146832,     /* 50 D3  */
    155563,     /* 51 D#3 */
    164814,     /* 52 E3  */
    174614,     /* 53 F3  */
    184997,     /* 54 F#3 */
    195998,     /* 55 G3  */
    207652,     /* 56 G#3 */
    220000,     /* 57 A3  */
    233082,     /* 58 A#3 */
    246942,     /* 59 B3  */

    261626,     /* 60 C4  */
    277183,     /* 61 C#4 */
    293665,     /* 62 D4  */
    311127,     /* 63 D#4 */
    329628,     /* 64 E4  */
    349228,     /* 65 F4  */
    369994,     /* 66 F#4 */
    391995,     /* 67 G4  */
    415305,     /* 68 G#4 */
    440000,     /* 69 A4  */
    466164,     /* 70 A#4 */
    493883,     /* 71 B4  */

    523251,     /* 72 C5  */
    554365,     /* 73 C#5 */
    587330,     /* 74 D5  */
    622254,     /* 75 D#5 */
    659255,     /* 76 E5  */
    698456,     /* 77 F5  */
    739989,     /* 78 F#5 */
    783991,     /* 79 G5  */
    830609,     /* 80 G#5 */
    880000,     /* 81 A5  */
    932328,     /* 82 A#5 */
    987767,     /* 83 B5  */

    1046502     /* 84 C6  */
};

/* ============================================================
 * AUDIO STATE: VOICES
 * ============================================================
 *
 * Polyphony: AUDIO_MAX_VOICES independent voices share the one DAC. Each voice has its own pitch
 * (phase accumulator), wave table, and envelope, started and stopped by Audio_startVoice() /
 * Audio_stopVoice(). The sample ISR adds the voices that are sounding and AVERAGES them (divides by
 * how many are sounding, with the divisor smoothed so voices joining or leaving cause no click and a
 * single note is exactly as loud as before polyphony).
 *
 * Voice state is written only with interrupts masked (the Audio_* entry points), and read by timer2ISR.
 */

/* Diagnostics live in Glo.Diagnostics: LastDacCode, AudioInterruptCount,
 * AudioIsrLastCycles, AudioIsrMaxCycles (single writer: the audio paths). */

/* Instrument chosen by Audio_setInstrument() (task context, one byte, atomic). It is latched into a
 * voice when that voice's note starts, so a change can never alter a note that is already sounding. */
static volatile uint8_t g_selectedInstrument = AUDIO_INSTRUMENT_SINE;

/* POLY-CORE-TYPES BEGIN (extracted by test_tools/check_poly_audio.py; keep the markers) */
/* Per-note envelope of one voice, in audio samples since that voice's Note On. Release ends at
 * releaseEnd, before the scheduled Note Off. */
typedef struct
{
    uint32_t attack;
    uint32_t releaseStart;
    uint32_t releaseSamples;
    uint32_t releaseEnd;
    uint32_t decay;                 /* 0 = no decay stage */
    uint32_t decayFloor;            /* Q15 level the decay settles at */
} VoiceEnvelope;

typedef struct
{
    bool active;
    uint8_t midiNote;
    uint32_t phase;                 /* DDS phase accumulator */
    uint32_t increment;
    uint32_t sampleIndex;           /* samples since this note began */
    const uint16_t *table;          /* wave table of the instrument chosen when the note began */
    VoiceEnvelope env;
} Voice;

static volatile Voice g_voices[AUDIO_MAX_VOICES];
static volatile uint32_t g_mixGain = ENV_GAIN_ONE;     /* smoothed 1/(sounding voices), Q15 */
static volatile bool g_voicesRunning = false;          /* at least one voice sounding */
/* POLY-CORE-TYPES END */

/* CCS watch values: audio ISR duration in CPU cycles (120 cycles = 1 us).
 * Max is cleared when each melody starts; write 0 in CCS to clear manually.
 */

#if AUDIO_ISR_PROFILE
#define CORE_DEMCR               (*(volatile uint32_t *)0xE000EDFCU)
#define CORE_DWT_CTRL            (*(volatile uint32_t *)0xE0001000U)
#define CORE_DWT_CYCCNT          (*(volatile uint32_t *)0xE0001004U)
#define CORE_DEMCR_TRCENA        (1U << 24)
#define CORE_DWT_CYCCNTENA       (1U << 0)
#endif


/* ============================================================
 * MIDI NOTE -> FREQUENCY
 * ============================================================
 */

static uint32_t midiNoteToFrequencyMilliHz(
    uint8_t midiNote
)
{
    if ((midiNote < AUDIO_NOTE_MIN) ||
        (midiNote > AUDIO_NOTE_MAX))
    {
        return 0;
    }


    return midiFrequencyMilliHz[
        midiNote - AUDIO_NOTE_MIN
    ];
}

/* ============================================================
 * DAC8311 WRITE
 * ============================================================
 */

static void DAC8311_write(
    uint16_t sample
)
{
    uint32_t dummyData;


    /*
     * DAC8311 is 14-bit.
     */
    sample &= 0x3FFFU;


    /*
     * Begin transaction.
     *
     * DAC SYNC is active LOW.
     *
     * Your working jumper setup uses PN3.
     */
    GPIOPinWrite(
        GPIO_PORTN_BASE,
        GPIO_PIN_3,
        0
    );


    /*
     * Send complete 16-bit DAC word.
     */
    SSIDataPut(
        SSI2_BASE,
        (uint32_t)sample
    );


    /*
     * Wait until SPI transmission has finished.
     */
    while (SSIBusy(SSI2_BASE))
    {
    }


    /*
     * Finish DAC transaction.
     */
    GPIOPinWrite(
        GPIO_PORTN_BASE,
        GPIO_PIN_3,
        GPIO_PIN_3
    );


    /*
     * Drain dummy RX data.
     */
    while (SSIDataGetNonBlocking(
               SSI2_BASE,
               &dummyData))
    {
    }


    Glo.Diagnostics.LastDacCode =
        sample;
}

/* ============================================================
 * TIMER2 AUDIO ISR
 * ============================================================
 *
 * Timer2 has ONE job:
 *
 * generate audio samples at 20 kHz.
 */

/* POLY-CORE-FUNCS BEGIN (extracted by test_tools/check_poly_audio.py; keep the markers) */
/*
 * Linear interpolation between adjacent sine-table entries.
 *
 * 32-bit phase = [ 8-bit index | 16-bit fraction | 8 unused bits ].
 * Position 20.25 -> index 20, next 21, fraction 0.25 (16384/65536).
 *
 *     sample = first + fraction * (next - first)
 *
 * next wraps 255 -> 0 by mask (table length is a power of two), so the
 * last entry interpolates toward entry 0 and never reads past the table.
 * The difference is signed (falling half of the sine). The scaled sum
 * first*2^16 + difference*fraction lies between first and next scaled,
 * so it is never negative: it is shifted as unsigned, rounding half up.
 * Maximum 10692*2^16 + 2^15 < 2^32, so no overflow. The instrument tables keep
 * the same +-2500 peak limit, so the bound holds for every table.
 */
static inline uint32_t sineTableInterpolate(
    uint32_t phase,
    const uint16_t *table
)
{
    uint32_t index =
        phase >> (32U - SINE_TABLE_BITS);

    uint32_t nextIndex =
        (index + 1U) & (SINE_TABLE_SIZE - 1U);

    uint32_t fraction =
        (phase >> (32U - SINE_TABLE_BITS - INTERP_FRACTION_BITS)) &
        ((1U << INTERP_FRACTION_BITS) - 1U);

    int32_t first =
        (int32_t)table[index];

    int32_t difference =
        (int32_t)table[nextIndex] - first;

    uint32_t scaled =
        ((uint32_t)first << INTERP_FRACTION_BITS) +
        (uint32_t)(difference * (int32_t)fraction) +
        (1U << (INTERP_FRACTION_BITS - 1U));

    return scaled >> INTERP_FRACTION_BITS;
}


/*
 * Attack / (optional decay) / sustain / release gain in Q15 for the n-th sample of one voice's note.
 * Attack: 0 -> ONE over e->attack. Release: the current level -> 0, reaching
 * exactly 0 at e->releaseEnd and staying 0 until the note is stopped.
 * Each divide uses an exact ratio, so no step truncation can leave a
 * residual level; operands are at most (ramp or decay length) * 2^15.
 *
 * Decay (e->decay != 0): after the attack the level falls from ONE to
 * e->decayFloor over the decay length along a quadratic curve (steep at first, like a
 * struck bar), then stays at the floor. With no decay stage the level is ONE and the
 * release factor is multiplied by ONE (2^15), so the result is exactly the original
 * attack/sustain/release envelope.
 */
static inline uint32_t envelopeGainQ15(
    const volatile VoiceEnvelope *e,
    uint32_t n
)
{
    uint32_t attack = e->attack;
    uint32_t releaseStart = e->releaseStart;
    uint32_t releaseEnd = e->releaseEnd;
    uint32_t decay = e->decay;
    uint32_t level = ENV_GAIN_ONE;

    if (n < attack)
    {
        return (n * ENV_GAIN_ONE) / attack;
    }

    if (decay != 0U)
    {
        uint32_t into = n - attack;
        uint32_t floorLevel = e->decayFloor;

        if (into < decay)
        {
            /* left: Q15 1 -> 0 across the decay; gain = floor + (ONE - floor) * left^2. */
            uint32_t left = ((decay - into) * ENV_GAIN_ONE) / decay;
            uint32_t span = ((ENV_GAIN_ONE - floorLevel) * left) >> 15;

            level = floorLevel + ((span * left) >> 15);
        }
        else
        {
            level = floorLevel;
        }
    }

    if (n < releaseStart)
    {
        return level;
    }
    if (n < releaseEnd)
    {
        return (level * (((releaseEnd - n) * ENV_GAIN_ONE) / e->releaseSamples)) >> 15;
    }
    return 0U;
}


/* The mix gain moves at most this much per sample: ONE over 10 ms (200 samples at 20 kHz). */
#define AUDIO_MIX_SLEW_Q15       (ENV_GAIN_ONE / (AUDIO_SAMPLE_RATE_HZ / 100U))

/*
 * One voice's contribution to this sample, centred on zero (DAC counts, already times the output
 * gain and the voice's envelope), and the voice advances by one sample. This is the original
 * single-note arithmetic, unchanged. Gain is applied to the deviation from the DAC midpoint;
 * signed division truncates toward zero, so positive and negative halves scale symmetrically
 * (no DC drift). |7500 * 32768| < 2^31.
 */
static inline int32_t voiceSampleCentered(volatile Voice *v)
{
    uint32_t phase = v->phase;          /* read once: index and fraction from the same value */
    uint32_t waveform;
    uint32_t gain;
    int32_t centeredSample;

#if AUDIO_USE_INTERPOLATION
    waveform = sineTableInterpolate(phase, v->table);
#else
    waveform = v->table[phase >> (32U - SINE_TABLE_BITS)];
#endif

#if AUDIO_USE_ENVELOPE
    gain = envelopeGainQ15(&v->env, v->sampleIndex);
    if (v->sampleIndex != UINT32_MAX)
    {
        v->sampleIndex++;
    }
#else
    gain = ENV_GAIN_ONE;
#endif

    centeredSample =
        ((int32_t)waveform - (int32_t)DAC_IDLE_CODE) *
        AUDIO_OUTPUT_GAIN;

    centeredSample =
        (centeredSample * (int32_t)gain) /
        (int32_t)ENV_GAIN_ONE;

    /* Unsigned 32-bit wraparound is the intended cycle wrap. */
    v->phase = phase + v->increment;

    return centeredSample;
}

/* Gain that averages the sounding voices: 1, 1, 1/2, 1/3 for 0, 1, 2, 3 voices (Q15). */
static inline uint32_t mixTargetQ15(uint32_t soundingVoices)
{
    if (soundingVoices <= 1U)
    {
        return ENV_GAIN_ONE;
    }
    if (soundingVoices == 2U)
    {
        return ENV_GAIN_ONE / 2U;
    }
    return ENV_GAIN_ONE / 3U;
}

/*
 * The next mixed sample, centred on zero: every sounding voice added, times the smoothed average
 * gain. With one voice the gain is exactly ONE, so the result is bit-for-bit the single-note
 * output. The sum of three voices is at most 3 * 7500 = 22500, and 22500 * 32768 < 2^31.
 */
static inline int32_t mixNextSampleCentered(void)
{
    int32_t sum = 0;
    uint32_t sounding = 0U;
    uint32_t i;
    uint32_t target;
    uint32_t gain;

    for (i = 0U; i < AUDIO_MAX_VOICES; i++)
    {
        if (g_voices[i].active)
        {
            sum += voiceSampleCentered(&g_voices[i]);
            sounding++;
        }
    }

    target = mixTargetQ15(sounding);
    gain = g_mixGain;
    if (gain > target)
    {
        gain = ((gain - target) > AUDIO_MIX_SLEW_Q15) ? (gain - AUDIO_MIX_SLEW_Q15) : target;
    }
    else if (gain < target)
    {
        gain = ((target - gain) > AUDIO_MIX_SLEW_Q15) ? (gain + AUDIO_MIX_SLEW_Q15) : target;
    }
    g_mixGain = gain;

    return (sum * (int32_t)gain) / (int32_t)ENV_GAIN_ONE;
}
/* POLY-CORE-FUNCS END */



/* Reset one voice to "not sounding" (interrupts masked, or before Timer2 runs). */
static void audioClearVoice(uint32_t i)
{
    g_voices[i].active = false;
    g_voices[i].midiNote = AUDIO_NOTE_NONE;
    g_voices[i].phase = 0U;
    g_voices[i].increment = 0U;
    g_voices[i].sampleIndex = 0U;
    g_voices[i].table = sineTable;
    g_voices[i].env.attack = 0U;
    g_voices[i].env.releaseStart = 0U;
    g_voices[i].env.releaseSamples = 0U;
    g_voices[i].env.releaseEnd = 0U;
    g_voices[i].env.decay = 0U;
    g_voices[i].env.decayFloor = 0U;
}

static void audioClearAllVoices(void)
{
    uint32_t i;

    for (i = 0U; i < AUDIO_MAX_VOICES; i++)
    {
        audioClearVoice(i);
    }
    g_voicesRunning = false;
    g_mixGain = ENV_GAIN_ONE;
}


static void timer2ISR(void)
{
    int32_t output;

#if AUDIO_ISR_PROFILE
    uint32_t startCycles = CORE_DWT_CYCCNT;
    uint32_t elapsedCycles;
#endif


    TimerIntClear(
        TIMER2_BASE,
        TIMER_TIMA_TIMEOUT
    );


    if (g_voicesRunning)
    {
        output =
            (int32_t)DAC_IDLE_CODE + mixNextSampleCentered();

        if (output < 0)
        {
            output = 0;
        }
        else if (output > (int32_t)DAC_MAX_CODE)
        {
            output = (int32_t)DAC_MAX_CODE;
        }


        DAC8311_write(
            (uint16_t)output
        );
    }


    Glo.Diagnostics.AudioInterruptCount++;

#if AUDIO_ISR_PROFILE
    elapsedCycles = CORE_DWT_CYCCNT - startCycles;
    Glo.Diagnostics.AudioIsrLastCycles = elapsedCycles;
    if (elapsedCycles > Glo.Diagnostics.AudioIsrMaxCycles)
    {
        Glo.Diagnostics.AudioIsrMaxCycles = elapsedCycles;
    }
#endif
}

/* ============================================================
 * AUDIO HARDWARE INITIALIZATION
 * ============================================================
 */

static void Audio_hardwareInit(void)
{
    uint32_t dummyData;


    /*
     * Required GPIO / SSI hardware.
     */
    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_GPIOD
    );

    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_GPION
    );

    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_GPIOH
    );

    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_SSI2
    );


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_GPIOD))
    {
    }


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_GPION))
    {
    }


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_GPIOH))
    {
    }


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_SSI2))
    {
    }


    /*
     * PD3 = SSI2CLK
     */
    GPIOPinConfigure(
        GPIO_PD3_SSI2CLK
    );


    /*
     * PD1 = SSI2XDAT0 / MOSI
     */
    GPIOPinConfigure(
        GPIO_PD1_SSI2XDAT0
    );


    GPIOPinTypeSSI(
        GPIO_PORTD_BASE,
        GPIO_PIN_1 |
        GPIO_PIN_3
    );


    /*
     * PN3 = DAC SYNC.
     */
    GPIOPinTypeGPIOOutput(
        GPIO_PORTN_BASE,
        GPIO_PIN_3
    );


    /*
     * PH2 = amplifier shutdown control.
     *
     * This is the corrected pin that removed
     * the static in your setup.
     */
    GPIOPinTypeGPIOOutput(
        GPIO_PORTH_BASE,
        GPIO_PIN_2
    );


    /*
     * DAC SYNC idles HIGH.
     */
    GPIOPinWrite(
        GPIO_PORTN_BASE,
        GPIO_PIN_3,
        GPIO_PIN_3
    );


    /*
     * Amplifier starts OFF.
     *
     * TPA301 shutdown is active HIGH.
     */
    GPIOPinWrite(
        GPIO_PORTH_BASE,
        GPIO_PIN_2,
        GPIO_PIN_2
    );


    /*
     * Configure SSI2.
     */
    SSIDisable(
        SSI2_BASE
    );


    SSIConfigSetExpClk(
        SSI2_BASE,
        SYSTEM_CLOCK_HZ,
        SSI_FRF_MOTO_MODE_1,
        SSI_MODE_MASTER,
        DAC_SPI_BIT_RATE_HZ,
        16
    );


    /*
     * Clear receive FIFO.
     */
    while (SSIDataGetNonBlocking(
               SSI2_BASE,
               &dummyData))
    {
    }


    SSIEnable(
        SSI2_BASE
    );


    /*
     * Start DAC at midpoint / silence.
     */
    DAC8311_write(
        DAC_IDLE_CODE
    );
}

/* ============================================================
 * TIMER2 INITIALIZATION
 * ============================================================
 */

static void Audio_timerInit(void)
{
    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_TIMER2
    );


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_TIMER2))
    {
    }


    TimerDisable(
        TIMER2_BASE,
        TIMER_A
    );


    TimerConfigure(
        TIMER2_BASE,
        TIMER_CFG_PERIODIC
    );


    /*
     * 120 MHz / 6000 =
     * 20,000 samples/sec.
     */
    TimerLoadSet(
        TIMER2_BASE,
        TIMER_A,
        AUDIO_TIMER_COUNTS - 1U
    );


    TimerIntRegister(
        TIMER2_BASE,
        TIMER_A,
        timer2ISR
    );


    /* Above the FreeRTOS ceiling: this ISR makes no kernel calls. */
    IntPrioritySet(
        INT_TIMER2A,
        IRQ_PRIO_AUDIO_SAMPLE
    );


    TimerIntClear(
        TIMER2_BASE,
        TIMER_TIMA_TIMEOUT
    );


    TimerIntEnable(
        TIMER2_BASE,
        TIMER_TIMA_TIMEOUT
    );


    /*
     * Audio starts silent.
     *
     * Timer2 does NOT start yet.
     */
    audioClearAllVoices();

#if AUDIO_ISR_PROFILE
    /* Usually already enabled by the debugger; harmless if repeated. */
    CORE_DEMCR |= CORE_DEMCR_TRCENA;
    CORE_DWT_CYCCNT = 0U;
    CORE_DWT_CTRL |= CORE_DWT_CYCCNTENA;
#endif
}

/* ============================================================
 * NOTE OFF
 * ============================================================
 */

static void audioSilenceLocked(void)
{
    /*
     * Everything silent. The voices must already be cleared.
     *
     * Stop waveform generation first.
     */
    TimerDisable(
        TIMER2_BASE,
        TIMER_A
    );


    TimerIntClear(
        TIMER2_BASE,
        TIMER_TIMA_TIMEOUT
    );


    g_voicesRunning = false;

    g_mixGain = ENV_GAIN_ONE;


    /*
     * Return DAC to midpoint.
     */
    DAC8311_write(
        DAC_IDLE_CODE
    );


    /*
     * Shut down amplifier.
     *
     * HIGH = amplifier OFF.
     */
    GPIOPinWrite(
        GPIO_PORTH_BASE,
        GPIO_PIN_2,
        GPIO_PIN_2
    );
}

/* Hard silence for every voice (STOP, errors, end of melody): envelopes cancelled, Timer2 off. */
static void audioStopAllLocked(void)
{
    audioClearAllVoices();

    audioSilenceLocked();
}

/* Stop one voice. When it was the last one sounding, everything goes silent as above. */
static void audioStopVoiceLocked(uint8_t voice)
{
    uint32_t i;
    bool anySounding = false;

    if (voice >= AUDIO_MAX_VOICES)
    {
        return;
    }

    audioClearVoice(voice);

    for (i = 0U; i < AUDIO_MAX_VOICES; i++)
    {
        if (g_voices[i].active)
        {
            anySounding = true;
        }
    }

    if (!anySounding)
    {
        audioSilenceLocked();
    }
}

/* ============================================================
 * NOTE ON
 * ============================================================
 */

/* Milliseconds -> Timer3 counts, clamped to the 32-bit load register.
 * Shared by the scheduler and the envelope so both use the same note end.
 */
uint32_t Audio_msToCpuCounts(
    uint32_t milliseconds
)
{
    uint64_t timerCounts;

    if (milliseconds == 0U)
    {
        milliseconds = 1U;
    }

    timerCounts =
        ((uint64_t)SYSTEM_CLOCK_HZ * milliseconds) / 1000ULL;

    if (timerCounts > 0xFFFFFFFFULL)
    {
        timerCounts = 0xFFFFFFFFULL;
    }

    return (uint32_t)timerCounts;
}

/*
 * Fit attack + release inside the scheduled note.
 *
 * usable = note samples - guard. Normal notes: 5 ms attack, 5 ms release
 * ending 'guard' samples before Note Off. If usable < 2 ramps (notes under
 * ~10 ms), both ramps shrink to usable/2 so the note still rises and falls
 * inside its own duration. A 0 ms note is scheduled as 1 ms (20 samples),
 * like before. Timing of Note Off, rests and the next onset is unchanged.
 */
static void audioConfigureEnvelope(
    uint32_t durationMs,
    const Instrument *instrument,
    volatile VoiceEnvelope *env
)
{
    uint32_t noteSamples =
        Audio_msToCpuCounts(durationMs) / AUDIO_TIMER_COUNTS;

    uint32_t usable = 0U;

    uint32_t attack = instrument->attackSamples;

    uint32_t release = instrument->releaseSamples;

    if (noteSamples > ENV_END_GUARD_SAMPLES)
    {
        usable = noteSamples - ENV_END_GUARD_SAMPLES;
    }

    /* Too short for both ramps: both shrink to half of the usable length. With the
     * SINE preset (equal ramps) this is the original rule, sample for sample. */
    if ((attack + release) > usable)
    {
        attack = usable / 2U;
        release = usable / 2U;
    }

    env->attack = attack;
    env->releaseSamples = release;
    env->releaseEnd = usable;
    env->releaseStart = usable - release;
    env->decay = instrument->decaySamples;
    env->decayFloor = instrument->decayFloorQ15;
}


static void audioStartVoiceLocked(
    uint8_t voice,
    uint8_t midiNote,
    uint32_t durationMs
)
{
    uint32_t frequencyMilliHz;

    const Instrument *instrument;

    uint8_t instrumentId;

    bool firstVoice;

    volatile Voice *v;


    if (voice >= AUDIO_MAX_VOICES)
    {
        return;
    }


    frequencyMilliHz =
        midiNoteToFrequencyMilliHz(
            midiNote
        );


    /*
     * Unsupported note.
     */
    if (frequencyMilliHz == 0U)
    {
        audioStopVoiceLocked(voice);

        return;
    }


    /* The first voice of a sound switches the audio hardware on; later voices just join. */
    firstVoice = !g_voicesRunning;

    v = &g_voices[voice];


    /*
     * Latch the selected instrument for this whole note: wave table and
     * envelope lengths. Read the selection once; an out-of-range value
     * (cannot happen, Audio_setInstrument validates) falls back to SINE.
     */
    instrumentId = g_selectedInstrument;

    if (instrumentId >= AUDIO_INSTRUMENT_COUNT)
    {
        instrumentId = AUDIO_INSTRUMENT_SINE;
    }

    instrument = &g_instruments[instrumentId];


    /*
     * Interrupts are masked, so the sample ISR cannot see this voice half-written.
     * Restarting a voice that is already sounding simply replaces its note.
     */
    v->active = false;

    v->phase = 0U;

    /*
     * DDS phase increment:
     *
     * frequency * 2^32
     * ----------------
     * sample rate
     *
     * Frequency is stored in milli-Hz,
     * therefore sample rate is multiplied
     * by 1000.
     */
    v->increment =
        (uint32_t)(
            ((uint64_t)frequencyMilliHz << 32)
            /
            (
                (uint64_t)AUDIO_SAMPLE_RATE_HZ *
                1000ULL
            )
        );

    v->sampleIndex = 0U;

    v->table = instrument->table;

    v->midiNote = midiNote;

    audioConfigureEnvelope(
        durationMs,
        instrument,
        &v->env
    );

    v->active = true;


    if (firstVoice)
    {
        g_mixGain = ENV_GAIN_ONE;


        TimerDisable(
            TIMER2_BASE,
            TIMER_A
        );


        /*
         * Start from silent DAC level.
         */
        DAC8311_write(
            DAC_IDLE_CODE
        );


        /*
         * Enable amplifier.
         *
         * LOW = amplifier ON.
         */
        GPIOPinWrite(
            GPIO_PORTH_BASE,
            GPIO_PIN_2,
            0
        );


        TimerIntClear(
            TIMER2_BASE,
            TIMER_TIMA_TIMEOUT
        );


        g_voicesRunning = true;


        /*
         * Begin generating samples.
         */
        TimerEnable(
            TIMER2_BASE,
            TIMER_A
        );
    }
}



/* ============================================================
 * PUBLIC INTERFACE (declared in audio.h)
 * ============================================================
 */

/* Mask interrupts around audio state/DAC changes. Preserves the caller's
 * mask state, so it nests (PRIMASK is also taken by Playback_start/stop). */
void Audio_stopNote(void)
{
    bool interruptsWereDisabled = IntMasterDisable();

    audioStopAllLocked();

    if (!interruptsWereDisabled)
    {
        IntMasterEnable();
    }
}

void Audio_startVoice(
    uint8_t voice,
    uint8_t midiNote,
    uint32_t durationMs
)
{
    bool interruptsWereDisabled = IntMasterDisable();

    audioStartVoiceLocked(voice, midiNote, durationMs);

    if (!interruptsWereDisabled)
    {
        IntMasterEnable();
    }
}

void Audio_stopVoice(uint8_t voice)
{
    bool interruptsWereDisabled = IntMasterDisable();

    audioStopVoiceLocked(voice);

    if (!interruptsWereDisabled)
    {
        IntMasterEnable();
    }
}

void Audio_startNote(
    uint8_t midiNote,
    uint32_t durationMs
)
{
    Audio_startVoice(0U, midiNote, durationMs);
}

/* DAC/SSI/GPIO hardware, then Timer2 (not started). Order as in the baseline. */
void Audio_init(void)
{
    Audio_hardwareInit();
    Audio_timerInit();
}

bool Audio_isNoteActive(void)
{
    return g_voicesRunning;
}

uint8_t Audio_activeVoices(void)
{
    uint32_t i;
    uint8_t count = 0U;

    for (i = 0U; i < AUDIO_MAX_VOICES; i++)
    {
        if (g_voices[i].active)
        {
            count++;
        }
    }
    return count;
}

/* Takes effect at the next Audio_startVoice()/Audio_startNote(). One byte store: no lock needed. */
bool Audio_setInstrument(uint8_t instrument)
{
    if (instrument >= AUDIO_INSTRUMENT_COUNT)
    {
        return false;
    }

    g_selectedInstrument = instrument;
    return true;
}

uint8_t Audio_getInstrument(void)
{
    return g_selectedInstrument;
}

/* The profiler maximum is cleared when each melody starts. */
void Audio_clearIsrMax(void)
{
    Glo.Diagnostics.AudioIsrMaxCycles = 0U;
}
