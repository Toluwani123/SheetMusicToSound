/*
 * midi.h -- supported-subset MIDI parser interface (midi.c).
 *
 * Contract: one Type-0 track, PPQN, channel 0, notes 48..84, at most MIDI_MAX_VOICES (3)
 * sounding at the same time (chords of up to three notes, overlapping melodies).
 * The parser never sends UART output, starts timers or touches the RTOS.
 */
#ifndef MIDI_H
#define MIDI_H

#include <stdint.h>
#include <stdbool.h>

/* MIDI 48 = C3 through 84 = C6 (kept equal to the audio table; playback.c
 * checks the two ranges agree at compile time). */
#define MIDI_NOTE_MIN      48U
#define MIDI_NOTE_MAX      84U
#define MIDI_NOTE_NONE     0xFFU

#define MAX_PARSED_NOTES   1024U

/* Most notes that may sound at once. The audio module has the same number of voices
 * (playback.c checks the two agree at compile time). */
#define MIDI_MAX_VOICES    3U

/* One parsed note. startMs counts from the first note (which is 0: leading silence is not
 * played); notes are stored in the order they start. A note sounds from startMs for durationMs
 * (at least 1). Rests are simply the gaps between notes. */
typedef struct
{
    uint8_t midiNote;
    uint32_t startMs;
    uint32_t durationMs;
} MelodyEvent;

typedef enum
{
    MIDI_PARSE_OK = 0,
    MIDI_PARSE_MALFORMED,       /* not valid under the supported subset */
    MIDI_PARSE_NOTE_CAPACITY,   /* valid so far, but more than 'capacity' notes */
    MIDI_PARSE_TOO_MANY_VOICES  /* valid so far, but more than MIDI_MAX_VOICES notes sound at once */
} MidiParseResult;

/*
 * Parse a complete file into out[0..capacity-1]; *outCount receives the number
 * of events written (valid only for MIDI_PARSE_OK). 'out' may be partly
 * overwritten on failure, so do not parse into storage that is being played.
 */
MidiParseResult Midi_parse(const uint8_t *data,
                           uint32_t fileLength,
                           MelodyEvent *out,
                           uint32_t capacity,
                           uint32_t *outCount);

#endif /* MIDI_H */
