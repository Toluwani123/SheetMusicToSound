/*
 * voice_sched.h -- polyphonic note scheduler (header only, pure computation).
 *
 * Takes the parsed note list (midi.h: start time and length of each note, in start order) and decides,
 * at each moment, which of the MIDI_MAX_VOICES voice lanes starts or stops a note and how long to wait
 * until the next change. It touches no hardware and no RTOS, so the real code is compiled and tested on
 * a PC (test_tools/check_voice_sched.py); playback.c applies its decisions to the audio module.
 *
 * Use: Sched_init(); then loop { delta = Sched_advance(...); if (delta == 0) done; wait delta ms;
 * sched.nowMs += delta; }. The first Sched_advance() runs at nowMs = 0 and starts the first note(s).
 *
 * Lane choice: the lowest free lane. If every lane is busy (only possible when rounding to whole
 * milliseconds makes a 4th note overlap a note that is about to end) the lane whose note ends soonest
 * is taken over, so the music never stalls and never uses more than the available voices.
 */
#ifndef VOICE_SCHED_H
#define VOICE_SCHED_H

#include <stdint.h>
#include <stdbool.h>

#include "midi.h"

typedef struct
{
    const MelodyEvent *notes;                  /* parsed notes in start order (read only) */
    uint32_t count;
    uint32_t next;                             /* index of the next note that has not started */
    uint32_t nowMs;                            /* current time; the caller advances it */
    bool laneActive[MIDI_MAX_VOICES];
    uint32_t laneEndMs[MIDI_MAX_VOICES];       /* absolute end time of the note in each busy lane */
} VoiceSched;

/* Called to start / stop a lane. 'remainingMs' is how long the note still has to sound from now (>= 1). */
typedef void (*SchedVoiceOn)(void *ctx, uint8_t lane, uint8_t midiNote, uint32_t remainingMs);
typedef void (*SchedVoiceOff)(void *ctx, uint8_t lane);

static inline void Sched_init(VoiceSched *s, const MelodyEvent *notes, uint32_t count)
{
    uint32_t i;

    s->notes = notes;
    s->count = count;
    s->next = 0U;
    s->nowMs = 0U;
    for (i = 0U; i < MIDI_MAX_VOICES; i++)
    {
        s->laneActive[i] = false;
        s->laneEndMs[i] = 0U;
    }
}

/* Is any lane still sounding, or any note still to come? */
static inline bool Sched_busy(const VoiceSched *s)
{
    uint32_t i;

    if (s->next < s->count)
    {
        return true;
    }
    for (i = 0U; i < MIDI_MAX_VOICES; i++)
    {
        if (s->laneActive[i])
        {
            return true;
        }
    }
    return false;
}

/* Process everything due at s->nowMs. Returns the milliseconds to wait until the next change (>= 1),
 * or 0 when the song is finished (all notes started and every lane ended). */
static inline uint32_t Sched_advance(VoiceSched *s, SchedVoiceOn on, SchedVoiceOff off, void *ctx)
{
    uint32_t lane;
    uint32_t wake;
    bool haveWake = false;

    /* 1. notes that have run their length stop first, so a note ending exactly when another begins
     *    frees its lane for it. */
    for (lane = 0U; lane < MIDI_MAX_VOICES; lane++)
    {
        if (s->laneActive[lane] && (s->laneEndMs[lane] <= s->nowMs))
        {
            off(ctx, (uint8_t)lane);
            s->laneActive[lane] = false;
        }
    }

    /* 2. notes whose start time has come */
    while ((s->next < s->count) && (s->notes[s->next].startMs <= s->nowMs))
    {
        const MelodyEvent *note = &s->notes[s->next];
        uint32_t endMs = note->startMs + note->durationMs;
        uint32_t chosen = MIDI_MAX_VOICES;
        uint32_t remaining;

        for (lane = 0U; lane < MIDI_MAX_VOICES; lane++)
        {
            if (!s->laneActive[lane])
            {
                chosen = lane;
                break;
            }
        }
        if (chosen == MIDI_MAX_VOICES)              /* all busy: take over the lane that ends soonest */
        {
            chosen = 0U;
            for (lane = 1U; lane < MIDI_MAX_VOICES; lane++)
            {
                if (s->laneEndMs[lane] < s->laneEndMs[chosen])
                {
                    chosen = lane;
                }
            }
        }
        remaining = (endMs > s->nowMs) ? (endMs - s->nowMs) : 1U;   /* running late: play what is left */
        on(ctx, (uint8_t)chosen, note->midiNote, remaining);
        s->laneActive[chosen] = true;
        s->laneEndMs[chosen] = endMs;
        s->next++;
    }

    /* 3. when does anything change next? */
    wake = 0U;
    if (s->next < s->count)
    {
        wake = s->notes[s->next].startMs;
        haveWake = true;
    }
    for (lane = 0U; lane < MIDI_MAX_VOICES; lane++)
    {
        if (s->laneActive[lane] && (!haveWake || (s->laneEndMs[lane] < wake)))
        {
            wake = s->laneEndMs[lane];
            haveWake = true;
        }
    }
    if (!haveWake)
    {
        return 0U;
    }
    return (wake > s->nowMs) ? (wake - s->nowMs) : 1U;
}

#endif /* VOICE_SCHED_H */
