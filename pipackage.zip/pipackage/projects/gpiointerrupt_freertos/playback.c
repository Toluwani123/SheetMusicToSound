/*
 * playback.c -- polyphonic playback: Timer3 wake-ups, voice hand-out, completion state.
 *
 * The note list from the parser holds a start time and a length for every note, with up to
 * MIDI_MAX_VOICES notes sounding at once. voice_sched.h (pure computation, tested on a PC) decides
 * which voice lane starts or stops a note at each moment; this file runs it from the Timer3 one-shot
 * timer and applies its decisions through the public audio API (Audio_startVoice/Audio_stopVoice).
 * It never parses MIDI or touches the UART.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#ifndef __MSP432E401Y__
#define __MSP432E401Y__
#endif

#include <ti/devices/msp432e4/driverlib/driverlib.h>

#include "playback.h"
#include "audio.h"
#include "midi.h"
#include "voice_sched.h"
#include "globals.h"

/* Audio and MIDI describe the same pitch range and the same number of voices; keep them in step. */
typedef char playbackNoteRangesAgree[
    ((AUDIO_NOTE_MIN == MIDI_NOTE_MIN) &&
     (AUDIO_NOTE_MAX == MIDI_NOTE_MAX) &&
     (AUDIO_NOTE_NONE == MIDI_NOTE_NONE)) ? 1 : -1];

typedef char playbackVoiceCountsAgree[
    (AUDIO_MAX_VOICES == MIDI_MAX_VOICES) ? 1 : -1];

/* Longest single Timer3 wait: the 32-bit load register holds this many milliseconds at the CPU clock
 * (about 35.8 s). A longer gap between two changes is waited out in several shots. */
#define PLAYBACK_MAX_WAIT_MS     (0xFFFFFFFFU / (SYSTEM_CLOCK_HZ / 1000U))


/* ============================================================
 * PLAYBACK SCHEDULER STATE
 * ============================================================
 */

typedef enum
{
    PLAYBACK_IDLE = 0,

    PLAYBACK_PLAYING,

    PLAYBACK_COMPLETE

} PlaybackState;


static volatile PlaybackState g_playbackState =
    PLAYBACK_IDLE;

static volatile bool g_playbackActive = false;

/* The scheduler (borrowed, read-only view of the melody inside it). Written by Playback_start/stop and
 * the Timer3 ISR, always with interrupts masked or from the ISR itself. */
static VoiceSched s_sched;

/* How long the Timer3 shot now running was armed for; the ISR adds it to the song clock. */
static volatile uint32_t s_armedMs = 0U;

/* Set when a melody has been started; cleared by completion reporting or by
 * Playback_stop. Lets the task layer print DONE only for a natural finish. */
static volatile bool s_completionPending = false;

/* Called from the Timer3 ISR when the melody finishes naturally (after the
 * hard silence). Must be ISR-safe; it may only signal work. May be NULL. */
static PlaybackCompletionHook s_completionHook = NULL;

static void PlaybackTimer_armMs(
    uint32_t milliseconds
);

static void playbackStep(void);


/* Cancel the entire song, including notes still to come. Preserve the caller's
 * interrupt-mask state; ACK_STOPPED is sent only after this function returns.
 * Timer4 remains running so transfer timeouts continue to work in silence.
 */
void Playback_stop(void)
{
    bool interruptsWereDisabled = IntMasterDisable();

    TimerDisable(TIMER3_BASE, TIMER_A);
    TimerIntClear(TIMER3_BASE, TIMER_TIMA_TIMEOUT);
    g_playbackActive = false;
    g_playbackState = PLAYBACK_IDLE;
    Sched_init(&s_sched, NULL, 0U);
    s_armedMs = 0U;
    s_completionPending = false;
    Audio_stopNote();

    /* Read back the peripheral clears before clearing latched NVIC requests. */
    (void)TimerIntStatus(TIMER3_BASE, false);
    (void)TimerIntStatus(TIMER2_BASE, false);
    IntPendClear(INT_TIMER3A);
    IntPendClear(INT_TIMER2A);

    if (!interruptsWereDisabled)
    {
        IntMasterEnable();
    }
}

/* ============================================================
 * TIMER3 PLAYBACK TIMER
 * ============================================================
 *
 * Timer3 has ONE job:
 *
 * musical/event timing: it fires when the next voice has to start or stop.
 */

static void PlaybackTimer_armMs(
    uint32_t milliseconds
)
{
    /*
     * Convert milliseconds to timer counts
     * (0 ms -> 1 ms, clamped to 32 bits).
     */
    uint32_t timerCounts =
        Audio_msToCpuCounts(
            milliseconds
        );


    TimerDisable(
        TIMER3_BASE,
        TIMER_A
    );


    TimerIntClear(
        TIMER3_BASE,
        TIMER_TIMA_TIMEOUT
    );


    TimerLoadSet(
        TIMER3_BASE,
        TIMER_A,
        timerCounts - 1U
    );


    TimerEnable(
        TIMER3_BASE,
        TIMER_A
    );
}

/* ============================================================
 * VOICE HAND-OUT (callbacks for voice_sched.h)
 * ============================================================
 */

static void playbackVoiceOn(void *ctx, uint8_t lane, uint8_t midiNote, uint32_t remainingMs)
{
    (void)ctx;
    Audio_startVoice(lane, midiNote, remainingMs);
}

static void playbackVoiceOff(void *ctx, uint8_t lane)
{
    (void)ctx;
    Audio_stopVoice(lane);
}

/* ============================================================
 * ONE SCHEDULER STEP
 * ============================================================
 *
 * Runs everything due at the song clock (voices stop, voices start), then either arms Timer3 for the
 * next change or, when nothing is left, finishes the song. Called from Playback_start() (interrupts
 * masked) and from the Timer3 ISR.
 */

static void playbackStep(void)
{
    uint32_t delta = Sched_advance(&s_sched, playbackVoiceOn, playbackVoiceOff, NULL);

    if (delta == 0U)
    {
        /*
         * End of parsed melody: every note has started and ended.
         * Extra safety hard silence.
         */
        Audio_stopNote();


        g_playbackActive =
            false;


        g_playbackState =
            PLAYBACK_COMPLETE;


        if (s_completionHook != NULL)
        {
            s_completionHook();
        }


        return;
    }


    g_playbackState =
        PLAYBACK_PLAYING;


    if (delta > PLAYBACK_MAX_WAIT_MS)
    {
        delta = PLAYBACK_MAX_WAIT_MS;
    }

    s_armedMs = delta;

    PlaybackTimer_armMs(
        delta
    );
}

/* ============================================================
 * TIMER3 ISR
 * ============================================================
 */

static void timer3ISR(void)
{
    TimerIntClear(
        TIMER3_BASE,
        TIMER_TIMA_TIMEOUT
    );


    /* A late interrupt after STOP must not advance/restart the melody. */
    if (!g_playbackActive)
    {
        TimerDisable(TIMER3_BASE, TIMER_A);
        return;
    }
    if (s_sched.count > MAX_PARSED_NOTES)
    {
        Playback_stop();
        return;
    }

    /* The wait we armed has elapsed: move the song clock to the moment that was scheduled. */
    s_sched.nowMs += s_armedMs;

    playbackStep();
}

/* ============================================================
 * TIMER3 INITIALIZATION
 * ============================================================
 */

static void PlaybackTimer_init(void)
{
    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_TIMER3
    );


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_TIMER3))
    {
    }


    TimerDisable(
        TIMER3_BASE,
        TIMER_A
    );


    /*
     * One-shot because the gap to the next change differs every time.
     */
    TimerConfigure(
        TIMER3_BASE,
        TIMER_CFG_ONE_SHOT
    );


    TimerIntRegister(
        TIMER3_BASE,
        TIMER_A,
        timer3ISR
    );


    /* Calls FreeRTOS *FromISR through the completion hook, so it must sit at
     * or below the kernel ceiling (and below the audio sample ISR). */
    IntPrioritySet(
        INT_TIMER3A,
        IRQ_PRIO_PLAYBACK
    );


    TimerIntClear(
        TIMER3_BASE,
        TIMER_TIMA_TIMEOUT
    );


    TimerIntEnable(
        TIMER3_BASE,
        TIMER_TIMA_TIMEOUT
    );


    g_playbackState =
        PLAYBACK_IDLE;


    g_playbackActive =
        false;


    Sched_init(&s_sched, NULL, 0U);
}

/* ============================================================
 * START PARSED MELODY
 * ============================================================
 */

bool Playback_start(const MelodyEvent *events, uint32_t count)
{
    bool started = false;
    bool interruptsWereDisabled = IntMasterDisable();

    TimerDisable(TIMER3_BASE, TIMER_A);
    TimerIntClear(TIMER3_BASE, TIMER_TIMA_TIMEOUT);
    Audio_stopNote();
    (void)TimerIntStatus(TIMER3_BASE, false);
    (void)TimerIntStatus(TIMER2_BASE, false);
    IntPendClear(INT_TIMER3A);
    IntPendClear(INT_TIMER2A);

    g_playbackState = PLAYBACK_IDLE;
    g_playbackActive = false;
    Audio_clearIsrMax();
    Sched_init(&s_sched, NULL, 0U);
    s_armedMs = 0U;
    s_completionPending = false;
    if ((events != NULL) && (count > 0U) && (count <= MAX_PARSED_NOTES))
    {
        Sched_init(&s_sched, events, count);
        s_completionPending = true;
        g_playbackActive = true;
        playbackStep();                 /* the first note(s) start now, at song time 0 */
        started = true;
    }

    if (!interruptsWereDisabled)
    {
        IntMasterEnable();
    }

    return started;
}


/* ============================================================
 * PUBLIC INTERFACE (declared in playback.h)
 * ============================================================
 */

void Playback_init(PlaybackCompletionHook completionHook)
{
    s_completionHook = completionHook;
    PlaybackTimer_init();
}

bool Playback_isActive(void)
{
    return g_playbackActive;
}

/* True exactly once after a natural finish. Reproduces the baseline test
 * "completion pending && playback no longer active". */
bool Playback_completionReady(void)
{
    return s_completionPending && !g_playbackActive;
}

bool Playback_takeCompletion(void)
{
    bool finished = false;
    bool interruptsWereDisabled = IntMasterDisable();

    if (s_completionPending && !g_playbackActive)
    {
        s_completionPending = false;
        finished = true;
    }

    if (!interruptsWereDisabled)
    {
        IntMasterEnable();
    }

    return finished;
}
