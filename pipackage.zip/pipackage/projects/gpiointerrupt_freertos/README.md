# gpiointerrupt_freertos

FreeRTOS polyphonic (up to 3 notes at once) MIDI player for the MSP-EXP432E401Y (120 MHz Cortex-M4F), built with
GNU Arm 9.2.1 in CCS 21 / Theia and SimpleLink MSP432E4 SDK 4.20.00.12. It references the
kernel library project `../freertos_kernel_glo` (FreeRTOS V10.2.1).

| File | Role |
|---|---|
| `main_freertos.c` | The only `main()`: board init, `Control_init()`, scheduler start; kernel fault hooks |
| `globals.h` / `globals.c` | `extern Globals Glo` / its single definition: `Glo.Bios` handles, `Glo.Diagnostics` counters, NVIC priority plan |
| `audio.h` / `audio.c` | DAC8311 on SSI2, sine table, interpolation, per-voice envelope, pitch to phase, three voices averaged in the Timer2 sample ISR; instrument presets (sine default, clarinet, trumpet, marimba; the marimba adds an optional decay stage to the envelope) selected with `Audio_setInstrument()` |
| `audio_instruments.h` | generated clarinet, trumpet and marimba wave tables (`test_tools/generate_instrument_tables.py`); included by `audio.c` only |
| `midi.h` / `midi.c` | Type-0 MIDI parser (`Midi_parse`): notes with start time and length, up to 3 at once, `MelodyEvent`; no hardware, no RTOS |
| `voice_sched.h` | header-only polyphonic scheduler: which voice starts/stops when; pure computation, tested on a PC |
| `playback.h` / `playback.c` | runs the scheduler from Timer3 (one shot per change), applies it with `Audio_startVoice/stopVoice`, start/stop, completion hook |
| `uart_task.h` / `uart_task.c` | UART0 RX ISR + ring, SMID framing/timeouts/recovery, CRC, `Uart_readTask`; submits replies to the TX queue (never writes the UART) |
| `uart_tx.h` / `uart_tx.c` | reply queue (`Glo.Bios.UARTTxQueue`, 8 x 41 B), `UartTx_send*`, `UartTx_task` = sole owner of the UART transmitter, Tx diagnostics |
| `control_task.h` / `control_task.c` | RTOS object/queue/task creation, `PayloadTask` (replies, DONE critical section), `MonitorTask`, STOP/BUSY hooks |
| `gpiointerrupt.syscfg` | SysConfig: `RTOS = FreeRTOS`, GPIO (LEDs/buttons) |
| `MSP_EXP432E401Y_FREERTOS.lds` | SDK linker script for FreeRTOS (unchanged) |

The old monolithic `gpiointerrupt.c` and `main_nortos.c` are not part of this project.
See `../../IMPLEMENTATION_SUMMARY.md` for design and `../../HARDWARE_TEST_GUIDE.md` to build, flash and test.
`uart_tx_test.h` (saturation test only) is intentionally absent; see `../../test_tools/saturation/`.
