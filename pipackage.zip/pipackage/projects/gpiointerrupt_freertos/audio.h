/*
 * audio.h -- public interface of the audio module (audio.c).
 *
 * Owns the DAC8311 on SSI2, the PN3 SYNC and PH2 amplifier pins, Timer2 and
 * the 20 kHz sample ISR. Playback code must use only these functions; it never
 * edits phase/envelope state directly.
 */
#ifndef AUDIO_H
#define AUDIO_H

#include <stdint.h>
#include <stdbool.h>

/* Pitch range of the frequency table (MIDI 48 = C3 .. 84 = C6). */
#define AUDIO_NOTE_MIN   48U
#define AUDIO_NOTE_MAX   84U
#define AUDIO_NOTE_NONE  0xFFU

/* Polyphony: this many notes can sound at once (voices 0 .. AUDIO_MAX_VOICES-1). The sample interrupt
 * averages the voices that are sounding. playback.c checks this equals MIDI_MAX_VOICES (midi.h). */
#define AUDIO_MAX_VOICES 3U

/* Configure DAC, amplifier (off) and Timer2 (stopped). Call once at startup. */
void Audio_init(void);

/* Start a note on one voice; the instrument ramps (attack/release, and decay for the marimba) fit
 * inside durationMs. Starting a voice that is already sounding replaces its note. An unsupported note
 * number, or a voice number >= AUDIO_MAX_VOICES, stops/ignores that voice instead. The first voice
 * to start switches the amplifier and Timer2 on. */
void Audio_startVoice(uint8_t voice, uint8_t midiNote, uint32_t durationMs);

/* Stop one voice. When it was the last voice sounding, everything goes silent (see Audio_stopNote). */
void Audio_stopVoice(uint8_t voice);

/* Start one note on voice 0 (the single-voice entry point used before polyphony). */
void Audio_startNote(uint8_t midiNote, uint32_t durationMs);

/* Hard silence for ALL voices: stop Timer2, clear envelopes, DAC to midpoint, amplifier off. */
void Audio_stopNote(void);

/* Read-only status for the scheduler/diagnostics. */
bool Audio_isNoteActive(void);          /* true while at least one voice is sounding */
uint8_t Audio_activeVoices(void);       /* how many voices are sounding right now (0..AUDIO_MAX_VOICES) */

/* Instrument presets. SINE is the original sound and the default after reset. */
#define AUDIO_INSTRUMENT_SINE      0U
#define AUDIO_INSTRUMENT_CLARINET  1U
#define AUDIO_INSTRUMENT_TRUMPET   2U
#define AUDIO_INSTRUMENT_MARIMBA   3U
#define AUDIO_INSTRUMENT_COUNT     4U

/* Choose the instrument for notes that START after this call (a note already
 * sounding is not changed). Returns false and changes nothing if 'instrument'
 * is not a valid AUDIO_INSTRUMENT_* value. Safe from any task. */
bool Audio_setInstrument(uint8_t instrument);

/* Currently selected instrument (what the next note will use). */
uint8_t Audio_getInstrument(void);

/* Milliseconds -> CPU-clock counts (0 ms -> 1 ms, clamped to 32 bits). Shared
 * by the Timer3 scheduler and the envelope so both use the same note end. */
uint32_t Audio_msToCpuCounts(uint32_t milliseconds);

/* Clear the audio-ISR maximum-cycles profiler value. */
void Audio_clearIsrMax(void);

#endif /* AUDIO_H */
