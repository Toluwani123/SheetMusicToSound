# Queue-based UART transmission: implementation summary

Milestone: replace the shared `UARTTxMutex` with **a reply queue and one transmit task** (`UARTTxTask`) in the
existing monophonic MSP432E401Y player. Built offline with the CCS 21 headless toolchain; **not yet run on the
board** (section 12 lists what only hardware can show).

Baseline: `checkpoints/05_baseline_before_uart_tx_queue/` (sources, build log, SHA-256) — the previous milestone's
final sources, copied before any edit.

---

## 1. What changed and why

| Before | After |
|---|---|
| Any task with a reply took `UARTTxMutex` and called blocking `UARTCharPut()` for every byte, holding the mutex for the whole message (~87 µs per byte). | A task copies its **complete reply** into `Glo.Bios.UARTTxQueue` and continues. `UARTTxTask` is the **only** application code that writes UART0 data. |
| A producer's time on the wire was spent at the producer's priority. | The wire time is spent in `UARTTxTask`, which sleeps one tick whenever the 16-byte FIFO is full, so other tasks keep running. |
| `UARTTxMutex` (priority-inheriting mutex) | Removed. No mutex remains in the image (checked in the link output). |

Unchanged: UART protocol (SMID v2, v1 MIDI accepted), reply text, limits (16,384-byte file, 1,024 notes), audio path,
sample rate, pins, receive ISR + 1,024-byte ring + `UARTReadSem`, `PayloadSem`, Timer2/3/4 roles, STOP semantics,
`Audio_*`, `Midi_*` (files `audio.c/h`, `midi.c/h`, `globals.c`, `FreeRTOSConfig.h`, `.syscfg`, linker script are
**byte-identical** to the baseline: `evidence/files_changed_vs_baseline.txt`). No polyphony, DMA or unrelated refactoring.

### File ownership

| File | Responsibility |
|---|---|
| `uart_tx.h/.c` **(new)** | Queue item type (private), `UartTx_send / sendLine / sendAck / trySend / waitForSpace`, `UartTx_task`, FIFO writing, Tx diagnostics |
| `uart_task.c/.h` | Receive ISR, ring, framing, timeouts, STOP. No longer touches the TX FIFO; formatters moved to `uart_tx.c`. `Uart_payloadRejected(NULL)` = recover without an ERR line |
| `control_task.c/.h` | Creates queue then tasks; PayloadTask replies; `Control_reportCompletion` (DONE critical section); monitor snapshots |
| `playback.c/.h` | + `Playback_completionReady()` (non-consuming peek). Nothing else changed |
| `globals.h` | `Bios.UARTTxTask`, `Bios.UARTTxQueue` (replaces `UARTTxMutex`), 12 new diagnostics |
| `main_freertos.c` | Comments only: fault hooks deliberately have **no** UART/queue use |

## 2. Tasks and synchronisation, before and after

| Task | Priority before → after | Stack (words) | Role |
|---|---|---|---|
| `UART0Tx` (`UartTx_task`) | — → **4** | — → 256 | drain `UARTTxQueue` into the UART FIFO |
| `UART0Rx` (`Uart_readTask`) | 3 → 3 | 512 | framing, timeouts, recovery, STOP |
| `Payload` (`Control_payloadTask`) | 2 → 2 | 768 | CRC, parse, start playback, DONE/IDLE |
| `Monitor` | 1 → 1 | 256 | LED, diagnostics snapshot |

| Object | Before | After |
|---|---|---|
| `UARTReadSem` | RX ISR / payload release → UART0Rx | same |
| `PayloadSem` | UART0Rx publish, Timer3 ISR → Payload | same |
| `UARTTxMutex` | every reply, held across transmission | **removed** |
| `UARTTxQueue` | — | UART0Rx and Payload (whole replies) → UARTTxTask |

**Why priority 4 (highest) for the least important work.** `UARTTxTask` is the only thing that frees queue slots, so
it must never be starved by a producer. It is cheap: per message it writes what fits in the FIFO (≤16 bytes) then
sleeps one tick, a few microseconds of CPU per millisecond. It therefore does not delay STOP (priority 3), CRC (2) or
the monitor (1). Stack 256 words: static estimate 416 B of 1,024 B (`evidence/static_stack_estimate_tx.txt`);
`Glo.Diagnostics.StackFreeMinTxWords` is the runtime proof still owed. The estimate is a compiler-frame calculation,
not a measurement.

## 3. Startup sequence

1. `main()`: `Board_init`, `GPIO_init`, `Audio_init`.
2. `Control_init()`: create `UARTReadSem`, `PayloadSem`, then `UartTx_createQueue()` — **the queue exists before any task**;
   failure → `CreateFailCount++`, `Fault_halt()`.
3. `Playback_init`, `Uart_init` (UART0, Timer4, ring; **UART interrupts still masked**).
4. `xTaskCreate` ×4: `UART0Tx`, `UART0Rx`, `Payload`, `Monitor`. Any failure → `CreateFailCount`, halt.
5. `vTaskStartScheduler()`. `UART0Tx` (highest) runs first and blocks on the empty queue.
6. `UART0Rx` arms the UART interrupts and queues the banner `\r\nSMID v2 READY\r\nIDLE\r\n` (best effort; the
   sender does not require it). A submit before the queue exists would be counted in `TxNotReadyCount` (expected 0).

## 4. One message, producer to wire (`ACK_RECEIVED`)

1. `Control_processPayload` (PayloadTask) finishes the CRC and calls `UartTx_sendAck("ACK_RECEIVED", len, crc)`.
2. `uart_tx.c` builds a local `UartTxMsg {length, text[40]}` on the **caller's stack** with bounds-checked appends
   (an overlong reply is rejected and counted in `TxFormatErrorCount`, never truncated).
3. `xQueueSend(queue, msg, 0)`; if full, `TxQueueFullCount++` and wait up to 250 ms; if still full,
   `TxSubmitTimeoutCount++` and the call returns **false**. On success `TxMsgsQueued++` and the call returns.
   `xQueueSend` has **copied the item into the queue's own storage**, so the stack buffer is dead and nothing points at it.
4. PayloadTask continues (Midi_parse). `UARTTxTask` (priority 4) is unblocked, copies the item into its own stack
   item (the slot is free again), records the occupancy, and writes characters into the FIFO — sleeping one tick when full.
5. When the last byte is in the FIFO: `TxBytesTransmitted += n; TxMsgsTransmitted++`.

**"Transmitted" means: every byte was written into the UART transmit FIFO** — the same point at which the old
`UARTCharPut()` returned. The last ≤16 bytes can still be shifting out for ~1.4 ms. **"Queued" means stored in the
queue, not sent.**

## 5. Why a queue plus an owner task replaces *this* mutex (and what it does not claim)

The old mutex blocked only tasks competing for the UART, not the whole system. Its cost was that a producer
(UART0Rx or Payload) spent the entire physical transmission inside the critical resource at its own priority, and a
second producer arriving meanwhile waited for it. The new design moves physical transmission to one task, so a
producer pays only the time to copy ~30 bytes.

Queues can also make a producer wait — when all 8 slots are full. The improvement is **single-task ownership of the
peripheral and decoupling producers from the wire**, not "queues never block". It is also not a claim that queues
beat mutexes in general: for a resource guarded for microseconds, a mutex is the simpler tool. Here the guarded
operation lasts milliseconds and has several producers with ordering requirements, which is what the queue is for.
No latency improvement is claimed; none has been measured.

## 6. Sizing, memory, wait policy, overload

| Item | Value | Derivation |
|---|---|---|
| Longest reply | **29 chars** (`ACK_RECEIVED 16384 DEADBEEF\r\n`) | computed from `MAX_MIDI_FILE_SIZE` (5 digits) by `check_uart_tx.py`, which measures all 19 reply forms |
| Item | 41 B (1 length + 40 chars) | `UART_TX_MSG_MAX_CHARS 40`; 11 chars of margin |
| Depth | **8** | One transfer produces at most ACK_RECEIVED, ACK_VALID, PLAYING close together, with a DONE possibly behind them; a ~25-char reply is ~2.2 ms on the wire. Q2 (below) exceeds even that |
| Queue storage | 8 × 41 = **328 B** + kernel queue header (≈80 B, not measured) | `xQueueCreate`, from the 32 KB FreeRTOS heap once at startup |
| Task | 1,024 B stack + TCB (≈90 B, not measured) | total ≈ 1.5 KB of heap. Verify with `HeapMinFreeBytes` before/after |
| Per-reply allocation | none | |
| Producer wait | ≤ **250 ms** (`UART_TX_SUBMIT_TIMEOUT_MS`) | a healthy drain frees a slot every ~2 ms, so 250 ms means UARTTxTask is broken or starved, not busy |
| Stuck FIFO | message abandoned after 50 ms without progress → `TxFaultCount++` | the FIFO accepts a byte every 87 µs |

Do not add optional debug output to this queue: it carries required protocol replies only.

### Failure policy (a reply that was not accepted is never reported as sent)

`UartTx_send*` returns `false` when the reply is not queued; every caller handles it:

| Producer | Reply refused → |
|---|---|
| ACK_READY (UART0Rx) | do not enter payload reception; `RECOVER` (host never told to send) |
| ACK_RECEIVED / ACK_VALID (Payload) | `Uart_payloadRejected(NULL)`: quiet recovery |
| PLAYING (Payload) | `Playback_stop()`, then quiet recovery: no unannounced playback |
| ERR_* (either) | receiver already in `RECOVER`; counted |
| ACK_STOPPED+IDLE (UART0Rx) | audio is **already silent**; receiver enters `RECOVER` so IDLE is retried |
| recovery IDLE | `UartTx_trySend` (never waits); stays in `RECOVER`, retried every 10 ms pass |
| DONE[+IDLE] (Payload) | completion is **not consumed**; Payload retries every 20 ms; counted |
| banner | counted only (best effort) |

"Quiet recovery" ends with an `IDLE` (retried until accepted), and the host's own timeouts do the rest.
There is **no second transmission path**: `UARTTxTask` is the only writer in normal operation. Fault hooks do not
use the UART at all (§9).

## 7. Ordering and state correctness

FIFO preserves the order of *accepted* replies; the rules below make the order of *publication* correct.

* **Normal transfer.** ACK_READY (UART0Rx), then ACK_RECEIVED, ACK_VALID, PLAYING, ERR_* (all Payload, in protocol order).
  While the payload is out the receiver is in `VALIDATE` and UART0Rx produces nothing, and the receiver is released
  (`Uart_payloadAccepted`) only after PLAYING is queued. So there is one producer at a time for a transfer.
* **ACK_VALID before audio, PLAYING after audio.** ACK_VALID is queued before `Playback_start`, PLAYING after it succeeds
  — the baseline order. Both lines are queued by the same task, so even a one-note song's DONE cannot overtake PLAYING.
* **Grouped replies are one item:** `ACK_STOPPED\r\nIDLE\r\n`, `DONE\r\nIDLE\r\n`, the banner.
* **STOP racing natural completion.** `UART0Rx` outranks `Payload`. Without protection a STOP could be accepted
  *between* Payload's decision "completion is ready, receiver idle" and the DONE enqueue, giving the host
  `ACK_STOPPED, IDLE, DONE, IDLE` — a DONE for a song it already cancelled. `Control_reportCompletion` therefore makes
  the decision and the enqueue **one critical section** (`taskENTER_CRITICAL`), checks that a slot is free **before**
  consuming the completion, and uses a non-blocking send. Inside it nothing can be published or cancelled. After a STOP,
  `Playback_stop()` has discarded the completion, so no DONE follows. The two legal sequences are
  `DONE, IDLE, ACK_STOPPED, IDLE` and `ACK_STOPPED, IDLE`, (and `DONE, ACK_STOPPED, IDLE` if the STOP header was
  mid-receive); this matches the baseline, where the mutex hold provided the same ordering. Section length: one
  `memcpy`-sized queue copy; Timer3/UART ISRs (priority 2) are delayed by microseconds, the audio ISR (priority 0)
  is not masked by kernel critical sections.
* **Stale completion after STOP/restart.** `Playback_stop()` clears `s_completionPending`, `Playback_start()` re-arms it for
  the new song only. Unchanged from the baseline and re-verified by reading the code; R1 and Q4 test it on the board.
* **Replies built from state that changes before transmission.** No reply holds a pointer to state. The text (including
  whether `IDLE` follows `DONE`) is fixed at publication time inside the critical section.
* **The transmit task makes no protocol decisions.** It copies bytes.
* STOP is **not** reordered ahead of queued replies.

## 8. STOP keeps its priority

On a valid STOP, `UARTReceiver_acceptHeader` calls `stopPlayback` (`Playback_stop`: timers off, audio silenced,
completion discarded) **first**; only then does it `UartTx_send("ACK_STOPPED\r\nIDLE\r\n")`. Silence never waits for
queue space or the wire. If the queue is full the send can block UART0Rx up to 250 ms — the ring buffer (89 ms at full
rate) and the receiver's recovery handle input meanwhile — but the audio is already cancelled. No STOP latency is
claimed (not measured). The audio sample ISR (Timer2, priority 0) and Timer3 ISR make no queue, mutex, format or print call
(`check_architecture.py`, `check_uart_tx.py`).

## 9. What remains interrupt driven; fault hooks

Interrupt driven: UART0 **receive** ISR → ring → `UARTReadSem`; Timer2 audio samples; Timer3 note scheduling (gives
`PayloadSem`); Timer4 1 ms transfer clock. **Transmit is not interrupt driven**: `UARTTxTask` fills the FIFO and sleeps
one tick when it is full (tick = 1 ms, FIFO = 1.39 ms). A TX-interrupt design would remove that polling; it was not
needed and is not part of this milestone.

Fault hooks (`vApplicationStackOverflowHook`, `…MallocFailedHook`, `vAssertCalled`, `Fault_halt`) are unchanged
and **intentionally have no emergency UART output**: the queue and task are not usable if the kernel failed, and a
blocking queue call must not appear in a fatal path. Faults are visible in `Glo.Diagnostics` only.

## 10. Diagnostics (inspect in CCS; no serial lines added)

| Field | Writer | Meaning |
|---|---|---|
| `TxMsgsQueued` | producers, atomic add | replies accepted into the queue |
| `TxMsgsTransmitted` | UARTTxTask | replies fully written to the UART FIFO |
| `TxBytesTransmitted` | UARTTxTask | characters written to the FIFO |
| `TxQueueFullCount` | producers, atomic | attempts that found the queue full (expected 0 in normal use) |
| `TxSubmitTimeoutCount` | producers, atomic | replies **not** accepted after the bounded wait (expected 0) |
| `TxFormatErrorCount` | producers, atomic | empty or overlong reply, rejected not truncated (expected 0) |
| `TxNotReadyCount` | producers, atomic | submit before the queue existed (expected 0) |
| `TxFaultCount` | UARTTxTask | FIFO took no byte for 50 ms; reply abandoned (expected 0) |
| `TxMaxQueueDepth` | UARTTxTask | exact peak occupancy (max 8) |
| `TxQueueDepthNow` | MonitorTask (250 ms) | replies waiting at the last snapshot |
| `TxInFlight` | UARTTxTask | 1 while a dequeued reply is being written |
| `StackFreeMinTxWords` | MonitorTask | lowest free stack ever, words |

**Drain check, system quiet:** `TxMsgsQueued == TxMsgsTransmitted`, `TxQueueDepthNow == 0`, `TxInFlight == 0`.
**During activity:** `TxMsgsQueued − TxMsgsTransmitted = replies waiting + TxInFlight` (a suspended target can sit a
few instructions between dequeue and the `TxInFlight` store). `volatile` only keeps the debugger view current; multi-writer
counters use `__atomic_fetch_add`, single-writer counters are plain.

## 11. Documented behaviour changes (none to the protocol)

1. **ACK_READY → payload-idle timer.** The host sees ACK_READY a few ms later than "queued"; `payloadStartedMs` is
   taken after queuing. Negligible against the 2 s idle limit.
2. **Sound vs ACK_VALID bytes.** Playback may begin before ACK_VALID's bytes have left the chip (they are queued, not sent).
   Line order is unchanged.
3. **`TransferSuccessCount`** is incremented after ACK_VALID is accepted (was before sending it).
4. Reply failure handling (§6) is new; in a healthy system it never runs.
5. Heap use ≈ +1.5 KB, flash +1.6 KB (`build_output/size_report.txt`).

## 12. Known limitations and unverified assumptions

* **Nothing here has run on the board.** Offline evidence is source inspection, a real CCS headless build, link
  inspection and a host *model* of the protocol (it tests the test scripts, not the firmware).
* Queue depth 8 and the 250 ms policy are justified by arithmetic; `TxMaxQueueDepth` after Q2 is the evidence to collect.
* The critical-section ordering argument depends on UART0Rx (3) outranking Payload (2) and on `taskENTER_CRITICAL` masking
  the other producers; it is reasoned from the code and exercised by Q4, but a race window of microseconds is hard to
  hit on purpose — Q4 sweeps ±100 ms around the song end and counts outcomes, it cannot prove the absence of a race.
* PLAYING refused (queue full ≥250 ms) cancels the song: acceptable only because it requires a broken `UARTTxTask`.
* If the host sends data while the queue is full, UART0Rx is blocked up to 250 ms; the 1,024-byte ring covers 89 ms at full
  rate, so a sustained flood during saturation can overflow the ring (`RxOverflowCount`) → `ERR_UART` → recovery. Q3
  exercises exactly this.
* Q2 pushes 120 STOP frames at line rate; the ring backlog it builds is ≈ 0.26 ms of data per frame (≈ 31 ms for 120). A much
  larger count would overflow the ring by design of the test, not because of a defect.
* Chioma's Raspberry Pi sender was **not** touched or tested. Existing compatibility with the PC sender is by protocol
  identity (unchanged reply text/order), to be confirmed by the board tests.

## 13. Evidence in this package

| Evidence | File | What it is |
|---|---|---|
| CCS headless build, release | `build_output/build_log_ccs_headless_release.txt` | 0 errors, 0 warnings |
| CCS headless build, saturation test image | `build_output/test_saturation/build_log_saturation.txt` | 0 errors; separate image, not for release |
| Image, map, bin, SHA-256, sizes | `build_output/` | real link output |
| Source checks | `evidence/offline_architecture.txt`, `offline_uart_tx.txt` | structure, ISR rules, reply sizes, ordering structure |
| Link inspection | `evidence/offline_link_output.txt` | one main, vectors, no mutex object linked |
| Host tooling self-test | `evidence/offline_host_tooling_selftest.txt` | tests the test scripts against a model (not firmware) |
| Baseline build and checks | `checkpoints/05_baseline_before_uart_tx_queue/` | before-edit state |
| Changed/unchanged files | `evidence/files_changed_vs_baseline.txt` | SHA-256 comparison |
| Stack estimate | `evidence/static_stack_estimate_tx.txt` | compiler frames, not a measurement |
