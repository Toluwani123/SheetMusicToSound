# Polyphony milestone: up to 3 notes at once

The player now plays **chords and overlapping melodies of up to three notes**, in every instrument preset
(sine, clarinet, trumpet, marimba). A song with one note at a time sounds exactly as it did before.

**Status, honestly.** Everything below was built and tested **on a PC** with the real firmware source files
(section 6). It has **not been flashed or heard on the board yet**: section 7 is the list of things only the board
can show, and `HARDWARE_TEST_GUIDE.md` section 12 is how to check them.

The milestone before this one is saved, untouched, as `uart_tx_queue_milestone_presets_milestone.zip` (next to the
`uart_tx_queue_milestone` folder) and as the `uart_tx_queue_milestone` folder itself.

---

## 1. What changed, in one picture

```
MIDI file -> Midi_parse -> note list -> voice_sched -> Audio_startVoice / Audio_stopVoice -> 3 voices -> average -> DAC
              (midi.c)     start+length   (voice_sched.h)        (playback.c)                 (audio.c)
```

| Step | Before | Now |
|---|---|---|
| Parser (`midi.c`) | refused any overlap; kept note + rest after it | accepts up to 3 notes sounding at once; keeps each note's **start time and length** |
| Scheduler | `playback.c` stepped note, rest, note, rest | `voice_sched.h` hands each note to a free voice; Timer3 wakes only when a voice must start or stop |
| Audio (`audio.c`) | one oscillator, one envelope | **three voices**, each with its own pitch, instrument table and envelope |
| Output | that one voice | the **average** of the voices that are sounding, smoothed so nothing clicks |

Nothing else changed: the UART protocol, the queue, the startup fix (`main_freertos.c` is byte-for-byte the same file),
the instrument tables and the instrument command are all as before. **One new reply line**: `ERR_VOICES`.

## 2. Your teacher's idea

I read "three parsers and an average" as: **split the music into three independent voice lanes and average their
outputs into the single DAC.** That is what is built: the scheduler hands each note to one of three lanes (three
copies of the old one-note player), and the sample interrupt averages the three. If your teacher meant something
different, for example running three different sheet-music recognition programs and voting/averaging their results
to make recognition more accurate, that is a separate, PC-side idea that is **not** built here; say so and I can
build a merger. The nearest thing here is `test_tools/prepare_polyphonic_midi.py`, which cleans up whatever the
recognition step produces (section 5).

## 3. Why this design (the research, briefly)

A search for how small microcontrollers mix several voices through one DAC found the same practice repeatedly:
keep an array of voice states (one phase accumulator each), add the voices in a **wider** variable, scale down so the
sum cannot overflow (attenuate by 1/N, or limit afterwards), and **saturate** at the DAC limits instead of letting
the value wrap. One source also notes that plain averaging has a cost: a quiet voice mixed with a loud one gets
quieter overall. The search did **not** cover how to stop clicks when the number of voices changes; smoothing the
gain over a few milliseconds is standard audio practice and is my own decision, tested in section 6.

Sources: [12 note polyphony on an arduino synth (Hackaday)](https://hackaday.com/2021/02/19/12-note-polyphony-on-an-arduino-synth) ·
[Fixed-Point Audio Arithmetic](https://applied-ee.github.io/embedded/docs/audio-projects/audio-dsp/fixed-point-audio-arithmetic/) ·
[Mixing down from multiple input sources (DSPRelated)](https://www.dsprelated.com/showthread/audiodsp/1116-1.php) ·
[PicoSynth wavetable synth (GitHub)](https://github.com/raybellis/PicoSynth) ·
[Audio synthesis with CircuitPython synthio (Adafruit)](https://learn.adafruit.com/audio-synthesis-with-circuitpython-synthio?view=all)

## 4. Decisions

| Decision | Choice | Why |
|---|---|---|
| Voices | **3** | your request; also what the average and the headroom are sized for |
| Mixing | **average of the voices sounding**, divisor eased over 10 ms | one note is exactly as loud as before; a 3-note chord can never clip (its peak is at most one note's peak); no click when a voice joins or leaves |
| More than 3 at once | whole file refused: **`ERR_VOICES`** | the board never silently drops notes; the PC tool does the (melody-preserving) reduction |
| Voice choice | lowest free voice; if all busy (only possible when 1 ms rounding makes a 4th note overlap one about to end), take over the one ending soonest | the music never stalls and never uses a 4th voice |
| Instrument | latched into each voice when its note starts | as before: a preset change never alters a sounding note; different voices may even use different presets |
| Timing | every note timed from the song start in whole ms; Timer3 armed once per change | no accumulated rounding (Ode to Joy: worst error 12 ms before, 0.7 ms now); waits longer than the timer's 35.8 s limit are chained instead of cut short |
| Protocol | no new commands; one new error reply | Pi and PC senders keep working; they only need to know `ERR_VOICES` |
| Test method | compile the real C files on the PC with stand-ins for the hardware | the only way to test timing-critical code without the board |

## 5. For the sheet-music (Pi) side

Real recognition output is usually **Type 1, several tracks, several channels, often 4+ notes at once**, none of which
the board accepts directly. Two PC tools in `test_tools/` (pure Python, no packages beyond `poly_midi.py`):

```
python prepare_polyphonic_midi.py score.mid playable.mid     # makes any MIDI playable
python check_poly_midi.py playable.mid                       # says what the board will do, or why it would refuse
```

`prepare` merges tracks/channels, drops percussion, merges unison doubles, shifts the piece by whole octaves into
C3..C6, and reduces to 3 notes at once **always keeping the highest note (melody) and the lowest (bass)** at every
moment. `PI_SENDER_INTEGRATION.md` is updated accordingly.

## 6. How it was tested (all on the PC; none of it needs the board)

```
cd test_tools
python run_polyphony_tests.py            # everything, one line per suite (add --quick to skip the slow old self-test)
```

| Suite | What it runs | What it proves |
|---|---|---|
| `check_poly_parser.py` | the **real `midi.c`**, compiled with `cl.exe` | matches an independent Python parser on 20 fixed cases and 600 random/damaged files; hand-worked chord, tempo and rounding cases; single-line songs have the same notes and are timed **closer to exact** than before |
| `check_voice_sched.py` | the **real `voice_sched.h`** | on 400 random songs every note starts and stops at exactly the right millisecond, never more than 3 voices; 400 overloaded songs never exceed 3; running late loses nothing |
| `check_poly_audio.py` | the **real `audio.c`**, its sample interrupt run sample by sample | **one voice equals the previous milestone bit for bit** (300 cases: 4 instruments, 5 notes, 5 lengths, 3 voices); a chord equals the average of its voices exactly; chords never clip; the mix gain moves at most 10 ms per sample; voices start, stop, restart and latch instruments correctly |
| `check_poly_playback.py` | **real `midi.c` + `playback.c` + `audio.c`** together, timer interrupts fired as the hardware would | for 9 constructed songs and all 5 reference songs, the set of notes sounding after **every** wake-up is what the file says, the song ends on time, completion is reported once; STOP silences at once and a late timer interrupt starts nothing; a 100 s gap is waited out correctly |
| `check_envelope_decay.py` | the real envelope function | without decay it equals the previous milestone's over 736,497 samples |
| `check_prepare_midi.py` | the MIDI preparation tool | output always accepted, <= 3 at once, melody and bass kept at every moment, no note moved: 1,500 random multi-track songs |
| `check_poly_board.py --selftest` | the board test script against a simulated board | it passes a correct board and fails one that plays a 4-note chord |
| existing checks | waveform maths, UART queue, architecture and ISR rules, instrument tables | still pass |

The firmware also compiles for the real MSP432 (ARM GCC 9.2.1 with `-Wall -Wextra`) with no warnings in your files.

## 7. What only the board can show (not proven yet)

* **Time in the sample interrupt.** Three voices cost more than one. The interrupt has 6,000 CPU cycles per sample;
  `Glo.Diagnostics.AudioIsrMaxCycles` must stay well under that while a chord plays (guide, test P5). I could not measure it;
  counting the instructions in the CCS build (which is unoptimized, `-O0`) gives an estimate of about 2,500 to 3,500 cycles
  for three voices.
* **How it sounds.** Chords of the clarinet, trumpet and marimba, especially the quiet trumpet and the marimba fade in a chord.
* **Speaker and amplifier** at chord level (the peak equals one note's peak, so it should be no worse than before).
* **The startup fix**: repeat the unplug/replug test on the new build.

## 8. Limits to know

* **3 notes at once.** A chord of 4 is refused (`ERR_VOICES`); `prepare_polyphonic_midi.py` reduces it.
* **Loudness.** The mix is an average, so in a 3-note chord each note is about 9.5 dB quieter than the same note alone;
  the chord as a whole is about as loud as one note. When a voice joins or leaves, the others change level over about 10 ms.
* **The marimba's top note.** Its 10th harmonic folds back for C6 only (documented in the instrument work).
* **Limits unchanged:** 1,024 notes (each chord note counts), 16,384 bytes, pitches 48 to 84, Type 0, channel 1.
* **Not built:** more than 3 voices, per-voice volume, pedal sustain, pitch bend (all still read and ignored).

## 9. Building it in CCS Theia

This folder's two projects have the **same names** as the previous milestone's (`gpiointerrupt_freertos`,
`freertos_kernel_glo`), so do not open both in one workspace.

1. Open the `polyphony_milestone` folder as its own workspace (File > Open Folder), or first remove the old projects from the current one.
2. Import both projects from `polyphony_milestone\projects` (Project > Import CCS Projects).
3. Build `freertos_kernel_glo` first, then `gpiointerrupt_freertos`. There is no SysConfig change and no new `.c` file
   (`voice_sched.h` is a header), so the project needs nothing added.
4. Flash, then follow `HARDWARE_TEST_GUIDE.md` section 12, starting with the unplug/replug check.

## 10. Files

| File | Change |
|---|---|
| `projects/.../midi.h`, `midi.c` | note list with start times; up to 3 at once; `MIDI_PARSE_TOO_MANY_VOICES` |
| `projects/.../voice_sched.h` | **new**: header-only scheduler |
| `projects/.../playback.c` | rewritten on top of the scheduler; long waits chained |
| `projects/.../audio.h`, `audio.c` | 3 voices, per-voice envelope, averaged smoothed mix; `Audio_startVoice/stopVoice/activeVoices` |
| `projects/.../control_task.c` | one line: `ERR_VOICES` |
| `test_tools/` | new: `poly_midi.py`, `check_poly_*.py`, `check_voice_sched.py`, `check_prepare_midi.py`, `prepare_polyphonic_midi.py`, `check_poly_midi.py`, `run_polyphony_tests.py`; updated: `check_envelope_decay.py` |
| `test_tools/board_tests/` | new: `generate_poly_tests.py`, `check_poly_board.py`, `poly_midi/` (13 files + `manifest.txt`) |
| docs | `HARDWARE_TEST_GUIDE.md` section 12, `PI_SENDER_INTEGRATION.md`, `README.md`, this file |
