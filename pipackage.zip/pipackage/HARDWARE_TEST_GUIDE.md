# Hardware test guide: queue-based UART transmit

Everything here needs the board. It works with your PC sender (`newmiditst.py`, SMID v2) only; **Chioma's Pi sender
is not involved.** Record results in `TEST_RESULTS_RECORD.txt`. Budget about 50 minutes.

`UM\` below = `C:\Users\iembi\workspace_ccstheia\uart_tx_queue_milestone`. COM port assumed `COM5`
(Device Manager, *XDS110 Class Application/User UART*); add `--port COMx` otherwise.

## 0. Build or load, flash, run

**Fastest (no build):** in a CCS debug session on `UM\projects\gpiointerrupt_freertos\targetConfigs\MSP432E401Y.ccxml`
load `UM\build_output\gpiointerrupt_freertos.out` and **Resume**.
(SHA-256 of the image is in `UM\build_output\SHA256.txt`.)

**Or build in CCS Theia:** *File ▸ Import Project(s)…* → browse to `UM\projects`, tick **both** `freertos_kernel_glo`
and `gpiointerrupt_freertos`, leave "copy into workspace" **unchecked**, build `gpiointerrupt_freertos` (Debug).
Expected 0 errors, 0 warnings.

**Or headless (the build used for the evidence):**

```powershell
cd UM\test_tools
powershell -ExecutionPolicy Bypass -File build_headless.ps1 -Workspace C:\temp\ws_q `
    -KernelProject ..\projects\freertos_kernel_glo -AppProject ..\projects\gpiointerrupt_freertos -LogFile C:\temp\build_q.txt
```

**Do not pause the target or set breakpoints during the test scripts** (timeouts are real time). Read counters *between* tests.
LED D1 blinks about 2 Hz (`MonitorTask`). Close any serial monitor holding the COM port.

## 1. CCS watch expressions

Expressions view → add `Glo` and expand `Diagnostics` (or add these individually). **Resume after reading.**

```
Glo.Bios.UARTTxQueue          Glo.Bios.UARTTxTask         (both non-zero)
Glo.Diagnostics.TxMsgsQueued         Glo.Diagnostics.TxMsgsTransmitted     Glo.Diagnostics.TxBytesTransmitted
Glo.Diagnostics.TxQueueFullCount     Glo.Diagnostics.TxSubmitTimeoutCount  Glo.Diagnostics.TxFormatErrorCount
Glo.Diagnostics.TxNotReadyCount      Glo.Diagnostics.TxFaultCount
Glo.Diagnostics.TxMaxQueueDepth      Glo.Diagnostics.TxQueueDepthNow       Glo.Diagnostics.TxInFlight
Glo.Diagnostics.StackFreeMinTxWords  StackFreeMinUartWords  StackFreeMinPayloadWords  StackFreeMinMonitorWords
Glo.Diagnostics.HeapMinFreeBytes     RxOverflowCount  RxErrorCount  StackOverflowCount  MallocFailCount  AssertCount  CreateFailCount
```

Definitions: `TxMsgsQueued` = replies accepted into the queue; `TxMsgsTransmitted` = replies whose last byte was written into the
UART FIFO (not necessarily shifted out yet). **Quiet system:** `Queued == Transmitted`, `TxQueueDepthNow == 0`, `TxInFlight == 0`.
During activity `Queued − Transmitted` = replies waiting + `TxInFlight`.

## 2. D0 — state after reset (before any file)

Reset (*Run ▸ Restart*/CPU reset), Resume, wait 10 s, read:

| Expression | Expected | Pass/fail |
|---|---|---|
| `UARTTxQueue`, `UARTTxTask` | non-zero | zero = FAIL |
| `TxMsgsQueued`, `TxMsgsTransmitted` | **1**, **1** (the banner) | |
| `TxBytesTransmitted` | **23** (`\r\nSMID v2 READY\r\nIDLE\r\n`) | |
| `TxMaxQueueDepth` | 1 | |
| `TxQueueDepthNow`, `TxInFlight` | 0, 0 | |
| `TxQueueFullCount`, `TxSubmitTimeoutCount`, `TxFormatErrorCount`, `TxNotReadyCount`, `TxFaultCount` | all **0** | any non-zero = FAIL |
| `StackFreeMinTxWords` | record it; static estimate ≈ 150 of 256 words free | **FAIL if < 40** |
| `HeapMinFreeBytes` | record; expect ≈ 1.5 KB **below** the previous milestone's figure | FAIL if 0 or `MallocFailCount` ≠ 0 |
| `RxOverflowCount`, `RxErrorCount`, `StackOverflowCount`, `MallocFailCount`, `AssertCount`, `CreateFailCount` | 0 | |

(If a serial program touched the port before this read, the banner is still sent once at boot, so the table holds.)

## 3. T1 — known-good playback, unchanged reply sequence

```powershell
cd UM\test_tools\board_tests
New-Item -ItemType Directory -Force -Path ..\..\evidence\board | Out-Null
python newmiditst.py --stop --port COM5
python newmiditst.py reference_midi\d5_reference.mid --wait-playback --port COM5 2>&1 | Tee-Object ..\..\evidence\board\T1_smoke.txt
```

**Expected lines, in this order:** `ACK_STOPPED`, `IDLE`; then `ACK_READY 72 A4B44DC2`, `ACK_RECEIVED 72 A4B44DC2`,
`ACK_VALID`, `PLAYING`, `DONE`, `IDLE`. **Expected sound:** four tones C4 E4 G4 C5, silence afterwards.

**Counters, quiet, if you ran D0 → T1 with no other traffic (exact):**
`TxMsgsQueued == TxMsgsTransmitted == 7` (banner, STOP pair, ACK_READY, ACK_RECEIVED, ACK_VALID, PLAYING, DONE+IDLE),
`TxBytesTransmitted == 123` (23+19+23+26+11+9+12), `TxQueueDepthNow == 0`, `TxInFlight == 0`, `TxMaxQueueDepth ≤ 4`, error counters 0.
**PASS** = exact sequence, correct sound, counters as stated.

## 4. T2 — existing audio tests (behaviour must be unchanged)

```powershell
python -u check_milestone_playback.py --port COM5 2>&1 | Tee-Object ..\..\evidence\board\T2_milestone_A-E.txt
```

Final line `PASS: milestone tests A, B, C, D, E completed without a board reset.` Listen as in
`docs_previous_milestone\START_HERE_TESTING.md` §4.1 (A four tones; B pulses/scale/blips/silence/G4; C Twinkle + Ode to Joy;
D **STOP cuts off at once**, then next phrase plays; E four-note phrase five times — repeated uploads without reset).
**FAIL** = sound after `ACK_STOPPED` or after `DONE`, new popping, a missed note, any script FAIL.
After the run: error counters 0, `Queued == Transmitted` (quiet), `TxMaxQueueDepth ≤ 4`.

## 5. T3 — error replies through the queue

```powershell
python -u check_error_paths.py --port COM5 2>&1 | Tee-Object ..\..\evidence\board\T3_error_paths.txt
```

| Test | Expected UART lines | Then |
|---|---|---|
| E1 wrong CRC | `ACK_READY…`, `ERR_CRC`, `IDLE` | normal song plays to `DONE`,`IDLE` |
| E2 not MIDI, good CRC | `ACK_READY…`, `ACK_RECEIVED…`, `ERR_MIDI`, `IDLE` | normal song |
| E3 length 0, then 16385 | `ERR_SIZE`,`IDLE` twice | normal song |
| E4 header during playback | `ERR_BUSY`, `IDLE`, `DONE`, `IDLE` (or `ERR_BUSY`,`DONE`,`IDLE`) | normal song; **the first song must not cut off** |

**PASS** = each script prints PASS; no reset needed. `TransferErrorCount` rises by 5 (E1, E2, E3×2, E4); `TxSubmitTimeoutCount == 0`.

## 6. T4 — STOP (sustained and short notes) and RTOS races

```powershell
python -u check_rtos_extra.py --port COM5 2>&1 | Tee-Object ..\..\evidence\board\T4_rtos_extra.txt
python newmiditst.py reference_midi\d4_sustained.mid --stop-after 1.5 --port COM5
python newmiditst.py midi_tests_milestone\m6_stop_ramps.mid --stop-after 0.5 --port COM5
```

R1 (20 STOP/restart cycles), R2, R3 as in the previous milestone. **LISTEN:** every STOP silences the tone immediately, nothing
restarts, no tone after any `ACK_STOPPED`. **PASS** = scripts PASS and you heard no stale tone. STOP latency is **not**
measured by these tests; do not quote a number.

## 7. T5 — natural completion racing STOP, then restart (Q4); reply bursts (Q1, Q2)

```powershell
python -u check_tx_queue.py --port COM5 2>&1 | Tee-Object ..\..\evidence\board\T5_queue_Q1_Q2_Q4.txt
```

| Test | What it does | PASS |
|---|---|---|
| Q1 | 6 STOP frames in one write | exactly 6 × (`ACK_STOPPED`,`IDLE`), then a normal song |
| Q2 | 120 STOP frames in one write; each 16-byte command arrives in 1.39 ms but its 19-character reply needs 1.65 ms to send, so the 8-slot queue fills and UART0Rx waits for space | all 120 pairs, whole lines, in order; normal song after |
| Q4 | 18 cycles: STOP at −100 … +100 ms around the song's end, immediate restart each cycle | every cycle is one of `ACK_STOPPED,IDLE` / `DONE,IDLE,ACK_STOPPED,IDLE` / `DONE,ACK_STOPPED,IDLE`; **never a `DONE` after `ACK_STOPPED`** |

**CCS after this run (quiet):**

| Expression | Expected |
|---|---|
| `TxQueueFullCount` | **> 0** (Q2 filled the queue) |
| `TxMaxQueueDepth` | **8** (or 7 if the host happened to feed slowly: record it; ≥ 6 is acceptable evidence of pressure) |
| `TxSubmitTimeoutCount`, `TxFormatErrorCount`, `TxFaultCount`, `TxNotReadyCount` | **0** — Q2 must not lose a reply |
| `TxMsgsQueued` vs `TxMsgsTransmitted` | equal |
| `RxOverflowCount` | 0 (if non-zero in Q2, lower `--count 80` and record it; it is the receive ring, not the transmit queue) |
| `StackFreeMinTxWords` | record; FAIL if < 40 |

Q4 reports how many cycles landed in the DONE-before-STOP outcomes (B/C). If all 18 are `A`, rerun `--test Q4 --cycles 40`;
a run that never hits the window still passes but proves less — say so in the record.

## 8. T6 — deliberate queue-full: the saturation image

This image has `UARTTxTask` waiting 400 ms before every reply. It exists only to fill the queue; **never leave it flashed.**

1. Flash `UM\build_output\test_saturation\gpiointerrupt_freertos_SATURATION_TEST.out`
   (or copy `UM\test_tools\saturation\uart_tx_test.h` into `projects\gpiointerrupt_freertos\`, rebuild; delete it and rebuild afterwards).
2. Resume. Run:

```powershell
python -u check_tx_queue.py --test Q3 --port COM5 2>&1 | Tee-Object ..\..\evidence\board\T6_Q3_saturation.txt
```

16 STOP frames in one write. One reply is in flight, 8 are queued, the 10th waits 250 ms and is refused.
**Expected:** whole `ACK_STOPPED`,`IDLE` pairs for the accepted replies (about 9), then a single `IDLE` from receiver recovery,
no partial line, no stray `DONE`; then a normal song plays (slowly: every reply takes 400 ms). **Sound:** the song must still play correctly.
The script prints `PASS Q3`.

**CCS afterwards (quiet; wait ~6 s after the script ends so the queue drains):**

| Expression | Expected |
|---|---|
| `TxSubmitTimeoutCount` | **≥ 1** |
| `TxQueueFullCount` | **≥ 1** |
| `TxMaxQueueDepth` | **8** |
| `TxMsgsQueued == TxMsgsTransmitted` | true, `TxQueueDepthNow == 0`, `TxInFlight == 0` — accepted replies drained; refused ones were never counted as queued |
| `TxFaultCount`, `TxFormatErrorCount`, `TxNotReadyCount` | 0 |
| `AssertCount`, `StackOverflowCount`, `MallocFailCount` | 0 |

Then **re-flash the release image** and repeat D0 (power cycle or reset) to confirm the 400 ms stall is gone
(`TxMsgsTransmitted == 1` within a second of reset; T1 sequence replies promptly).

## 9. T7 — diagnostics under representative activity

After T2–T5 on the **release** image (counters accumulate since reset; do one reset first if you want a clean slate):

| Item | Record | Pass criterion |
|---|---|---|
| `StackFreeMinTxWords` | ____ words | ≥ 40 |
| `StackFreeMinUartWords`, `…PayloadWords`, `…MonitorWords` | ____ | each ≥ 40 (previous estimate: ≥ 5× headroom) |
| `HeapMinFreeBytes` | ____ | > 10,000 |
| `TxMaxQueueDepth` | ____ | ≤ 8; typical transfers ≤ 4 |
| error counters | all 0 except `TransferErrorCount` (expected from T3) | |
| `TxMsgsQueued − TxMsgsTransmitted` after quiet | 0 | |

## 10. Pass/fail summary

Milestone is **hardware-verified** only if D0, T1–T7 pass as written. Any `TxSubmitTimeoutCount`, `TxFaultCount`,
`TxFormatErrorCount` or `TxNotReadyCount` ≠ 0 on the **release** image is a FAIL: keep the log and the `Glo.Diagnostics`
values and report them. Do not claim a STOP latency, a timing improvement, or that queues are faster than mutexes from these tests.

## 11. T8 — instrument presets (sine / clarinet / trumpet / marimba)

SMID v2 command 2 (INSTRUMENT, id in header byte 6). Ids: 0 sine (default), 1 clarinet, 2 trumpet, 3 marimba. The organ and the
guitar were scrapped for now (their measured spectra are archived in `test_tools/instrument_spectra.json`). Needs the matching
firmware **and** the updated `newmiditst.py` (`--instrument`, `--set-instrument`). `main_freertos.c` is untouched:
`Power_disablePolicy()` is still the first call after `Board_init()`, so repeat D0 (unplug/replug, no debugger) on the new build.

The marimba is the only preset with a **decay stage** (the note is struck, then fades). It is a small, optional addition to the
audio envelope; instruments without decay behave exactly as before (`test_tools\check_envelope_decay.py` proves it).

| Step | Command (from `test_tools\board_tests`) | Expected |
|---|---|---|
| I1 | reset, then `python newmiditst.py reference_midi\twinkle_simple.mid --wait-playback --port COM5` | the old **sine** sound (default = instrument 0) |
| I2 | `python newmiditst.py --set-instrument trumpet --port COM5` | `ACK_INSTRUMENT 2` then `IDLE` |
| I3 | play the file again, no `--instrument` | **trumpet**: bright and buzzy, much richer than the sine (and quieter, see below) |
| I4 | `python newmiditst.py reference_midi\twinkle_simple.mid --instrument marimba --wait-playback --port COM5` | `ACK_INSTRUMENT 3`, `IDLE`, normal transfer, `DONE`; **marimba**: a struck, woody tone that fades during each note, with a bright ring on top |
| I5 | `python newmiditst.py --set-instrument clarinet --port COM5`, then play | `ACK_INSTRUMENT 1`; clarinet exactly as before this change |
| I6 | `python newmiditst.py --set-instrument sine --port COM5` | `ACK_INSTRUMENT 0`; the original sound returns, with no fade |
| I7 | start a long song, then `--set-instrument trumpet` while it plays (single connection: use `--stop-after` instead if COM5 is busy) | `ERR_BUSY`, then `IDLE`; the song keeps its old sound |
| I8 | unknown id: `python -c "import serial,newmiditst as n; p=serial.Serial('COM5',115200,timeout=1); p.write(n.make_instrument_header(4)); print(p.read(40))"` | `ERR_INSTRUMENT`, then `IDLE` after ~250 ms; the instrument is unchanged |
| I9 | all voices in a row: `python play_instrument_samples.py reference_midi\ode_to_joy_msp.mid --port COM5` | each voice reaches `DONE`; the summary lists sine, clarinet, trumpet, marimba as OK |
| I10 | play a **long note** with the marimba, e.g. `python newmiditst.py reference_midi\d4_sustained.mid --instrument marimba --wait-playback --port COM5` | the tone dies away to a quiet level during the note, then ends cleanly; a short note fades only a little |

**PASS** = every expected line, no new popping at note starts or ends, STOP still silences at once with each instrument
(`python newmiditst.py reference_midi\d4_sustained.mid --stop-after 1.5 --port COM5` after selecting each one), and the error
counters stay as in section 9. `AudioIsrMaxCycles` must stay far below 6,000 cycles (50 µs) with each instrument, **especially the
marimba** (its decay adds a few divides to the sample interrupt); record it.

The shapes are fitted to the oscilloscope captures in `waveforms/` (`test_tools/analyze_scope_waveforms.py`; comparison plots
`test_tools/instrument_preview/match_*.png`; previews of the intended sounds `test_tools/instrument_preview/*.wav`, including the
marimba fade). Tables are regenerated by `test_tools/generate_instrument_tables.py`. Measured waveforms are peakier than a sine, so
at the same peak swing the instruments are quieter than the sine (about 3.7 dB marimba, 4.5 dB clarinet, 8 dB trumpet): raise the
volume, do not read it as a fault.

Known limits: the marimba keeps a 10th harmonic (its strongest overtone), so its top note C6 has that harmonic fold back to
9.5 kHz as a quiet, very high tone. Its attack, release, decay length (350 ms) and decay floor (8%) are judgement values, not
measured (the captures are only 20 ms long): tune them by ear in `audio.c`. A real marimba's upper overtone dies faster than its
fundamental; this preset fades everything together.
Scope check on the board: the DAC output for a held note should resemble the match plots.

## 12. T9 — polyphony (up to 3 notes at once)

New in this milestone: chords and overlapping melodies of up to three notes; a fourth note at the same moment is refused
with `ERR_VOICES`. Design and PC-side tests: `POLYPHONY.md`. **Everything here needs the board** (flash this milestone's build first).
Commands run from `test_tools\board_tests`. Test files are in `poly_midi\` and `poly_midi\manifest.txt` says what each is for.

> **`run_polyphony_tests.py` never plays anything.** It runs on the PC only and never opens the COM port. To hear the board,
> start here (20 seconds, it tells you whether silence is the software or the speaker):
> `python board_hello.py --port COM5`  and only then continue with P0 to P9 below.

| Step | Do | Expected |
|---|---|---|
| P0 | build, flash, **unplug and replug (no debugger)**, `python newmiditst.py --stop --port COM5` | `ACK_STOPPED`, `IDLE`: the startup fix is intact |
| P1 | **regression, one voice**: `python newmiditst.py reference_midi\twinkle_simple.mid --wait-playback --port COM5`, also `ode_to_joy_msp.mid` | sounds exactly as in the earlier milestones (same pitch, timing, loudness); `PLAYING`, `DONE` |
| P2 | **the wire**: `python check_poly_board.py --port COM5` | all 13 files `PASS`: 10 play to `DONE`; `p11`/`p12` are refused with `ERR_VOICES`; `p13` with `ERR_MIDI`; summary `13 of 13 files behaved correctly` |
| P3 | **listen**, each preset: `python check_poly_board.py --port COM5 --instrument clarinet --ask` (repeat `trumpet`, `marimba`, and no option for sine) | each file sounds as its `LISTEN:` line says; answer `y`/`n` |
| P4 | **STOP in a chord**: `python newmiditst.py poly_midi\p05_staggered_entries.mid --stop-after 2.0 --port COM5` | `ACK_STOPPED`, `IDLE`; **all three voices silent at once**, nothing restarts |
| P5 | **interrupt time** (CCS Expressions: `Glo.Diagnostics.AudioIsrMaxCycles`). First play ONE note (`reference_midi\d5_reference.mid`, sine) and record the value as the baseline (no earlier milestone recorded one). Then play `p07_fast_chord_stabs`, `p10_voice_reuse`, `p03_chord_progression` with the **marimba** and with the sine | record every maximum. The budget is 6,000 cycles (50 µs per sample). My limit: **PASS < 4,500** (75% of the budget); look into anything above 3,000. Expect chords to cost clearly more than the single-note baseline. (Estimate from counting instructions in the `-O0` build: about 2,500 to 3,500 cycles with three voices; measure to confirm.) |
| P6 | **refusal then recovery**: `python newmiditst.py poly_midi\p11_four_note_chord_REFUSED.mid --port COM5`, then `reference_midi\d5_reference.mid --wait-playback` | `ERR_VOICES`, `IDLE`, silence; then the next song plays normally |
| P7 | **a real score**: `python ..\prepare_polyphonic_midi.py omr_output.mid playable.mid`, `python ..\check_poly_midi.py playable.mid`, then send `playable.mid` | the report says what was simplified; the checker says ACCEPTED; chords are audible |
| P8 | error counters after all of the above (section 9 table) | unchanged from the earlier milestone (all 0 except `TransferErrorCount`, which the refusals raise) |
| P9 | **scope on the DAC** while `p02_triad_held` plays | the sum of three tones, amplitude about that of **one** note (not three times larger), no flat clipped tops |

**PASS** = P0 to P9 as written. Record results in `TEST_RESULTS_RECORD.txt`. Things to listen for specifically: no click or
pop when a voice joins or leaves (`p05`, `p06`); the marimba chord in `p09` strikes together and fades; the trumpet is
quiet (as before) but not distorted; each note of a chord is quieter than the same note alone (an average of three: about
9.5 dB per note, the whole chord is about as loud as one note); the top note of `p08` (C6) is clean.

If `AudioIsrMaxCycles` fails P5 the remedy is in `audio.c` (`mixNextSampleCentered`): tell me the number and the test that produced it.

## Rollback

The previous milestone is untouched in `C:\Users\iembi\workspace_ccstheia\globals_freertos_milestone`; its image is in
`UM\checkpoints\05_baseline_before_uart_tx_queue\evidence\gpiointerrupt_freertos.out`.

## 13. Piano songs: melody with left-hand accompaniment (homophonic)

No new instrument: these play on whichever preset you pick (default sine). Ten public-domain songs, each as a **solo** (melody
alone) and with one or more accompaniments: **bass** (1 low note, 2 voices), **block** (2-note chord, 3 voices), **oompah**
(bass / chord alternating), plus **ground / ground3** for Canon and **under** for Für Elise. The left hand is always one or
two notes and always lower than the melody, so you never exceed 3 notes at once or double a pitch.

Songs: Twinkle Twinkle, Ode to Joy (D major, as in `ode_to_joy_msp.mid`), Mary Had a Little Lamb, Jingle Bells (chorus),
Frère Jacques, Au clair de la lune, Row Row Row Your Boat (6/8), Happy Birthday (3/4 waltz), Canon in D, Für Elise (opening).

Run from `test_tools\board_tests` (files are written to `piano_midi\`, `piano_midi\manifest.txt` lists them):

| Command | What it does |
|---|---|
| `python check_piano_board.py --list` | list all 25 files |
| `python check_piano_board.py --port COM5 --quick` | per song: the solo, then one accompanied version (about 6 min) |
| `python check_piano_board.py --port COM5` | all 25 files (about 9 min) |
| `python check_piano_board.py --port COM5 --songs twinkle ode --ask` | only these songs, and it asks whether you recognised each |
| `python check_piano_board.py --port COM5 --variants solo block --instrument clarinet` | filter by style / choose the voice |

What to listen for: the solo must be recognisable; the accompanied version must have the **same melody** with a low note
or chord under it, and the melody must stay clear. Tell me the file name (e.g. `piano_02_ode_block`) and the bar if a tune
is wrong. The transcriptions are mine, cross-checked against online sources for most tunes (Canon's melody line could not be
confirmed, only its chord cycle); Twinkle matches your `twinkle_simple.mid` note for note and Ode to Joy matches the first 44
notes of `ode_to_joy_msp.mid`. PC-only check: `python check_piano_songs.py` (also part of `run_polyphony_tests.py`).
