# Pi sender integration: play processed sheet music and pick an instrument preset

For the team running the Raspberry Pi and the web app. This is **protocol and flow documentation**, not a finished
app: it tells you the exact bytes and replies so you can fit them to your own code and design. A tested reference
class is in section 7; copy it or translate it.

**Status, honestly.** The protocol below is what the PC sender (`test_tools/board_tests/newmiditst.py`) already uses
against the current firmware. The Pi has **not** been run against this firmware yet: the Pi serial wiring is still an
untested plan (section 3). Section 10 is a checklist for the first Pi test.

---

> **Updated for polyphony.** The board now plays **up to 3 notes at once** (chords, overlapping melodies). New reply line:
> `ERR_VOICES`. New tools to prepare and check files: section 6. Everything else in this guide is unchanged.

---

## 1. The whole flow in one picture

```
camera -> OMR (your side) -> .mid file -> [check it] -> Pi sender -> UART -> MSP432 -> speaker
                                                          ^
                                          web app: preset dropdown, Play, Stop
```

What the web app has to do, in order:

1. **Once, at startup:** open the serial port, wait 2.6 s for the board to settle (`sync`).
2. **When the user picks a preset:** send the *instrument command* (section 5). Only possible while nothing is playing.
3. **When the user presses Play:** send the MIDI file (section 5). The board validates it, then **starts playing by itself**.
4. **While playing:** read the board's lines. `DONE` means the song finished. The user can press Stop at any time.

The board remembers the preset until it is changed or the board is reset (after a reset it is the plain sine again).
Sending the preset command before every Play is cheap and keeps things consistent after a board reset.

---

## 2. Quick start with the existing command-line sender (no code to write)

`newmiditst.py` already does everything below and also runs on a Pi (`pip install pyserial`). Your web app can call it as a
subprocess while you build the native version. Run from `test_tools/board_tests/`:

```bash
# play a file with the default (sine) voice and wait until the board says DONE
python3 newmiditst.py reference_midi/d5_reference.mid --wait-playback --port /dev/serial0

# choose an instrument, then play (the choice stays selected afterwards)
python3 newmiditst.py song.mid --instrument trumpet --wait-playback --port /dev/serial0

# only choose an instrument, send nothing else
python3 newmiditst.py --set-instrument marimba --port /dev/serial0

# stop whatever is playing
python3 newmiditst.py --stop --port /dev/serial0
```

Exit code 0 = success, nonzero = the board refused or did not answer (the text before it says why).
Every run waits 2.6 s before sending, so for a responsive web app use the class in section 7 and keep the port open.

---

## 3. Connecting the Pi

**Serial settings (both routes):** 115200 baud, 8 data bits, no parity, 1 stop bit, no flow control.

**Route A, USB (the tested route on a PC):** plug the LaunchPad's USB into the Pi. The board's debug probe shows two
serial ports; you want the one called *Application/User UART*.
`ls /dev/serial/by-id/` lists them (typically `/dev/ttyACM0` and `/dev/ttyACM1`). If you open the wrong one you simply
see no boot banner, so try the other. Give your user access: `sudo usermod -aG dialout $USER`, then log out and in.

**Route B, GPIO UART (not demonstrated yet, treat as a plan):**

| Pi | MSP432 |
|---|---|
| GPIO14 / TXD (pin 8) | PA0 (UART0 RX) |
| GPIO15 / RXD (pin 10) | PA1 (UART0 TX) |
| GND | GND |

Both sides are 3.3 V. On the Pi: `sudo raspi-config` -> Interface Options -> Serial Port -> login shell **No**, serial hardware
**Yes**; the port is then `/dev/serial0`. Check the LaunchPad user guide on isolating the on-board USB serial from PA0/PA1 so
two transmitters never drive the same pin.

**Proof the link works:** after resetting the board you receive `SMID v2 READY` then `IDLE`.

---

## 4. Instrument presets (what to put in the dropdown)

| id | name | what it sounds like | loudness vs. sine | status |
|---|---|---|---|---|
| 0 | **Sine** (original, default after reset) | plain tone | 0 dB | proven |
| 1 | **Clarinet** | hollow, reedy | about -4.5 dB | listened to and approved |
| 2 | **Trumpet** | bright, brassy | about -8 dB (quietest) | listened to, acceptable |
| 3 | **Marimba** | struck, then fades during the note | about -4 dB | new, not yet judged by ear |

Notes for the UI:

* The ids are fixed by the firmware (`AUDIO_INSTRUMENT_*` in `audio.h`). Use the ids on the wire, names only in the UI.
* The trumpet is noticeably quieter; if you want the volume to feel even, that is a speaker-volume matter, not a fault.
* An instrument **cannot** be chosen by a MIDI "program change" inside the file: the board ignores those. The preset
  comes only from the instrument command below.
* The organ and guitar presets were scrapped for now. Ids above 3 are refused with `ERR_INSTRUMENT`.

---

## 5. Protocol reference

All frames start with a **16-byte header**, multi-byte fields **little-endian**. Python: `struct.pack("<4sBBBxII", ...)`.

| Offset | Size | Field | Value |
|---|---|---|---|
| 0 | 4 | magic | `"SMID"` |
| 4 | 1 | version | `2` |
| 5 | 1 | command | `0` = play MIDI file, `1` = STOP, `2` = choose instrument |
| 6 | 1 | argument | the instrument id for command `2`; **must be 0** for commands 0 and 1 |
| 7 | 1 | reserved | `0` |
| 8 | 4 | length | MIDI file size in bytes (command 0); `0` otherwise |
| 12 | 4 | CRC-32 | of the MIDI bytes only (`zlib.crc32(data) & 0xFFFFFFFF`); `0` otherwise |

The board answers with ASCII lines ending in CRLF.

| You send | Normal replies, in order |
|---|---|
| (board reset / power up) | `SMID v2 READY`, `IDLE` |
| **Choose instrument** (command 2) | `ACK_INSTRUMENT <id>`, `IDLE` |
| **Play MIDI** (command 0): header | `ACK_READY <length> <crc>` |
| ...then the MIDI bytes (only after `ACK_READY`) | `ACK_RECEIVED <length> <crc>`, `ACK_VALID`, `PLAYING` |
| (song ends by itself) | `DONE`, then `IDLE` |
| **STOP** (command 1), any time between frames | `ACK_STOPPED`, `IDLE` (a `DONE` can arrive just before, if the song ended at the same moment) |

Rules to build into your code:

* **Wait for `IDLE` before sending the next header** after any error. The board sends `IDLE` about 250 ms after it
  rejects something, and again when it is ready.
* **Never send a header while a song is playing**, except STOP. A new file or an instrument change during playback is
  refused with `ERR_BUSY` (the song keeps playing, unharmed).
* Send the MIDI bytes only after `ACK_READY`, in one go. Do not send them with the header.
* Time limits on the board: header must complete within 1 s, the payload may pause at most 2 s and take at most 10 s in
  total (a full 16 KB file takes about 1.4 s at 115200). Otherwise `ERR_TIMEOUT`.
* There are no automatic retries. If a reply is lost, the state is uncertain: wait for `IDLE`, or send STOP.

**Error lines and what to tell the user**

| Reply | Meaning | Suggested message |
|---|---|---|
| `ERR_BUSY` | a song is playing | "Already playing. Stop it first." |
| `ERR_VOICES` | more than 3 notes sound at the same moment | "This score has chords of more than three notes. Simplify it." (run `prepare_polyphonic_midi.py`) |
| `ERR_MIDI` | file not playable (see section 6) | "This score can't be played." (run `check_poly_midi.py` to see why) |
| `ERR_NOTE_CAPACITY` | more than 1,024 notes | "This score is too long." |
| `ERR_SIZE` | empty, or over 16,384 bytes, or extra bytes arrived | "This score is too large." |
| `ERR_CRC` | transfer corrupted | "Transfer failed. Try again." |
| `ERR_TIMEOUT`, `ERR_UART` | cable or timing problem | "Lost contact with the player. Check the connection." |
| `ERR_INSTRUMENT` | unknown preset id | (a bug in your code: only send ids 0 to 3) |
| `ERR_HEADER`, `ERR_COMMAND`, `ERR_VERSION` | malformed header, or **old firmware that has no instrument command** | "Player firmware needs updating." |

---

## 6. The MIDI file the board accepts (what your OMR output must be)

The firmware rejects anything outside this (`ERR_MIDI`, or `ERR_VOICES` for too many notes at once):

* **Standard MIDI file, Type 0, exactly one track**, ending with End Of Track as the last event.
* Time division in **ticks per quarter note**, not SMPTE.
* **MIDI channel 1 only.**
* **Pitches 48 to 84** (C3 to C6). Transpose by whole octaves if the score is outside this range.
* **Up to 3 notes sounding at the same time**: chords of up to three notes and overlapping melodies are fine. A 4th note
  sounding at the same moment is refused with `ERR_VOICES`. The same pitch must not be struck again while it still sounds.
* At most **1,024 notes** (every note of a chord counts) and **16,384 bytes**.

Tempo changes are fine. Velocity, program change, control change, pitch bend and text are read but ignored. The first
note starts immediately (leading silence is not played).

**Real recognition output almost never meets these rules as it comes** (it is usually Type 1, several tracks and channels,
and often has four or more notes at once). Prepare every file before sending it, then check it. Both tools are pure
Python and live in `test_tools/` (copy `poly_midi.py` with them):

```bash
python3 test_tools/prepare_polyphonic_midi.py omr_output.mid playable.mid   # merges tracks, fits the range, keeps <= 3 notes at once
python3 test_tools/check_poly_midi.py playable.mid                          # what the board will do, or exactly why it would refuse
```

`prepare` always keeps the **highest note (the melody) and the lowest (the bass)** at every moment and gives the remaining
voices to the notes that still have longest to sound; it never moves a note in time. Show the report to the user, so
they can see what was simplified. Show the checker's message if a file is still refused.

---

## 7. Drop-in Python class (tested)

Needs `pip install pyserial`. It keeps the port open, speaks the protocol above, and raises `MspError` with the board's
own text on any refusal. It was run against a simulated board (all the normal and error paths in section 5), not against
real hardware on a Pi.

```python
import collections
import struct
import time
import zlib

import serial  # pip install pyserial

PRESETS = {"sine": 0, "clarinet": 1, "trumpet": 2, "marimba": 3}   # ids = firmware AUDIO_INSTRUMENT_*
MAX_MIDI_BYTES = 16384


class MspError(Exception):
    """The board refused something (the text starts with its ERR_ code) or stopped answering."""


class MspPlayer:
    """One object per serial port. Not thread-safe: give it to ONE worker thread, or wrap calls in a lock."""

    def __init__(self, port="/dev/serial0", baud=115200):
        self.ser = serial.Serial(port, baud, bytesize=8, parity="N", stopbits=1, timeout=0.05, write_timeout=5)
        self._partial = bytearray()
        self._lines = collections.deque()
        self.state = "idle"                 # "idle" or "playing"

    # ---------------------------------------------------------------- low level
    def _feed(self, data):
        for byte in data:
            if byte == 10:                  # LF ends a line
                text = bytes(self._partial).rstrip(b"\r").decode("ascii", "replace")
                self._partial.clear()
                if text:
                    self._lines.append(text)
            elif len(self._partial) < 256:
                self._partial.append(byte)

    def _read_line(self, deadline):
        while not self._lines:
            if time.monotonic() >= deadline:
                raise MspError("timed out waiting for the board")
            self.ser.timeout = 0.05
            self._feed(self.ser.read(max(1, self.ser.in_waiting)))
        return self._lines.popleft()

    def _expect(self, token, timeout=5.0):
        """Return the first line that starts with `token`. Status lines in between are skipped; ERR_ raises."""
        deadline = time.monotonic() + timeout
        while True:
            line = self._read_line(deadline)
            word = line.split()[0]
            if word.startswith("ERR_"):
                raise MspError(line)
            if word == token:
                return line
            if word == "DONE":
                self.state = "idle"
            elif word in ("IDLE", "PLAYING") or line.startswith("SMID v"):
                pass
            else:
                raise MspError("unexpected reply while waiting for %s: %s" % (token, line))

    @staticmethod
    def _header(command, argument=0, length=0, crc=0):
        return struct.pack("<4sBBBxII", b"SMID", 2, command, argument, length, crc)

    @staticmethod
    def _check_ack(line, length, crc):
        fields = line.split()
        if len(fields) != 3 or int(fields[1]) != length or int(fields[2], 16) != crc:
            raise MspError("board acknowledged a different length/CRC: " + line)

    # ------------------------------------------------------------------ public
    def sync(self, quiet=2.6):
        """Call once after opening the port (and after a failure) while nothing is playing.
        Lets any abandoned earlier transfer time out on the board, then clears old input."""
        self.ser.reset_input_buffer()
        end = time.monotonic() + quiet
        while time.monotonic() < end:
            self.ser.timeout = 0.05
            self.ser.read(256)
        self.ser.reset_input_buffer()
        self._partial.clear()
        self._lines.clear()
        self.state = "idle"

    def select_preset(self, preset):
        """Choose the instrument for notes that start after this. Refused (ERR_BUSY) while playing."""
        preset_id = PRESETS[preset] if isinstance(preset, str) else int(preset)
        self.ser.write(self._header(2, preset_id))
        line = self._expect("ACK_INSTRUMENT")
        if line.split()[1:] != [str(preset_id)]:
            raise MspError("board selected a different instrument: " + line)
        self._expect("IDLE")

    def play(self, midi_bytes):
        """Send a whole .mid file. Returns when the board says PLAYING (the song then runs on its own)."""
        if not 1 <= len(midi_bytes) <= MAX_MIDI_BYTES:
            raise ValueError("MIDI file must be 1..%d bytes, got %d" % (MAX_MIDI_BYTES, len(midi_bytes)))
        crc = zlib.crc32(midi_bytes) & 0xFFFFFFFF
        self.ser.write(self._header(0, 0, len(midi_bytes), crc))
        self._check_ack(self._expect("ACK_READY"), len(midi_bytes), crc)
        self.ser.write(midi_bytes)                                   # only after ACK_READY
        self._check_ack(self._expect("ACK_RECEIVED"), len(midi_bytes), crc)
        self._expect("ACK_VALID")
        self._expect("PLAYING")
        self.state = "playing"

    def poll(self):
        """Non-blocking. Returns the lines the board sent since the last call; DONE sets state to "idle"."""
        self._feed(self.ser.read(self.ser.in_waiting))
        out = []
        while self._lines:
            line = self._lines.popleft()
            out.append(line)
            if line.split()[0] == "DONE":
                self.state = "idle"
        return out

    def stop(self):
        """Silence the board at once (works any time between frames)."""
        self.ser.write(self._header(1))
        self._expect("ACK_STOPPED")
        self._expect("IDLE")
        self.state = "idle"

    def recover(self, timeout=4.0):
        """After an MspError: wait for the board's IDLE. Returns True if it arrived."""
        self.ser.reset_output_buffer()
        end = time.monotonic() + timeout
        try:
            while True:
                if self._read_line(end) == "IDLE":
                    return True
        except MspError:
            return False

    def close(self):
        self.ser.close()
```

Typical use:

```python
msp = MspPlayer("/dev/serial0")
msp.sync()                                   # once, at startup
try:
    msp.select_preset("trumpet")
    msp.play(open("omr_output.mid", "rb").read())
except MspError as err:
    print("player said:", err)               # map ERR_ codes to messages with the table in section 5
    msp.recover()
# later, e.g. every 200 ms from the status endpoint:
for line in msp.poll():
    print(line)                              # "DONE" means the song finished (msp.state == "idle")
```

---

## 8. Fitting it into the web app

Keep **your** design; these are the only constraints the board imposes.

* **One owner of the serial port.** Two requests writing at once corrupt a frame. Put the `MspPlayer` in a single worker
  thread (or guard every call with one lock) and have the web handlers queue work to it.
* **Do not block the page while a song plays.** `play()` returns at `PLAYING`; after that, call `poll()` on a timer (for
  example from your status endpoint) and treat `DONE` as "finished". `msp.state` tells you whether a song is playing.
* **Suggested endpoints** (rename freely):

| Your endpoint | Calls | Notes |
|---|---|---|
| list presets | none | return the table in section 4 (id, name, description) |
| choose preset | `select_preset(id)` | disable the control while `state == "playing"` |
| play | `select_preset(current)` then `play(midi)` | run `prepare_polyphonic_midi.py` and `check_poly_midi.py` first; show the board's `ERR_` text if refused |
| stop | `stop()` | always allowed; use it for a Stop button |
| status | `poll()` | report `idle` / `playing` / last error to the page |

* **Sheet music flow:** photo -> OMR -> `.mid` -> `prepare_polyphonic_midi.py` -> `check_poly_midi.py` (section 6) -> play.
  The board now plays chords of up to three notes, but it still refuses a file with more than three at once, so
  prepare every file first; do not send raw OMR output.
* **Startup and reconnect:** call `sync()` after opening the port. If the board is reset or unplugged, reopen and `sync()`.

---

## 9. Troubleshooting

| Symptom | Likely cause |
|---|---|
| No `SMID v2 READY` after a board reset | wrong port (try the other USB port), wrong wiring (TX/RX swapped), baud not 115200, or the Pi login console is still on the serial port |
| `ERR_HEADER` right after choosing a preset | the board still has firmware from before the instrument command: reflash |
| `ERR_BUSY` | a song is playing: send STOP first, or wait for `DONE` |
| `ERR_MIDI` | the file breaks a rule in section 6: run `check_poly_midi.py` to see which |
| `ERR_VOICES` | four or more notes sound at once: run `prepare_polyphonic_midi.py` |
| `ERR_TIMEOUT` mid-transfer | the Pi paused more than 2 s while sending, or a wire is loose |
| Works on the PC, not on the Pi | use the USB route first to separate wiring problems from software |
| Sounds very quiet on trumpet | expected (see section 4); raise the speaker volume |

---

## 10. First Pi test (about 10 minutes)

Do these in order; stop at the first failure.

1. Open the port, reset the board, confirm you read `SMID v2 READY` and `IDLE`.
2. `python3 newmiditst.py --stop --port <PORT>` replies `ACK_STOPPED`, `IDLE`.
3. Play `test_tools/board_tests/reference_midi/d5_reference.mid` with the sine: lines `ACK_READY`, `ACK_RECEIVED`, `ACK_VALID`, `PLAYING`, `DONE`, `IDLE`, and you hear four notes.
4. `--set-instrument clarinet` replies `ACK_INSTRUMENT 1`, `IDLE`; play the file again and hear the difference. Repeat for trumpet (2) and marimba (3).
5. Start a long song (`ode_to_joy_msp.mid`) and send `--set-instrument trumpet` meanwhile: expect `ERR_BUSY`, and the song keeps playing.
6. Press Stop mid-song: expect `ACK_STOPPED`, `IDLE`, immediate silence.
7. Play `test_tools/board_tests/poly_midi/p02_triad_held.mid`: you hear a C major chord. Then send `p11_four_note_chord_REFUSED.mid`:
   expect `ERR_VOICES`, then `IDLE`, and nothing plays; the next good file plays normally.
8. Play a real song with accompaniment from the Pi: `test_tools/board_tests/piano_midi/piano_02_ode_block.mid` (melody plus a
   two-note left-hand chord, 3 notes at once). Then the same song alone, `piano_02_ode_solo.mid`, and compare. Send each file
   exactly like any other: the sender needs no change for chords, only `ERR_VOICES` handling.

Record what happened (lines seen, what you heard). The Pi link is untested until this passes.

---

## 11. Where things are in this repo

| What | Path |
|---|---|
| Working command-line sender (copy to the Pi) | `test_tools/board_tests/newmiditst.py` |
| Plays one file in every voice, for listening tests | `test_tools/board_tests/play_instrument_samples.py` |
| Known-good MIDI files | `test_tools/board_tests/reference_midi/` |
| Make any MIDI file playable / check a file | `test_tools/prepare_polyphonic_midi.py`, `test_tools/check_poly_midi.py` (need `test_tools/poly_midi.py`) |
| Chord and overlap test files | `test_tools/board_tests/poly_midi/` (13 files, `manifest.txt` says what each is for) |
| Song test files, melody + left hand (10 songs, 25 files) | `test_tools/board_tests/piano_midi/` (`manifest.txt`; made by `piano_songs.py`) |
| The polyphony design and tests | `POLYPHONY.md` |
| Firmware limits and reply text (source of truth) | `projects/gpiointerrupt_freertos/uart_task.c`, `control_task.c`, `audio.h` |
| Board test guide, including the preset and polyphony tests | `HARDWARE_TEST_GUIDE.md` sections 11, 12 and 13 (piano songs) |
