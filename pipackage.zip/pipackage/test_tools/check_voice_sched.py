"""Host test of the REAL polyphonic scheduler (projects/gpiointerrupt_freertos/voice_sched.h).

    python check_voice_sched.py [--random N]

voice_sched.h is pure C, so it is compiled with Visual Studio's cl.exe and driven the way playback.c drives it
(wait the returned milliseconds, advance the clock, call again). For every case the voice start/stop calls are
logged and compared with what the note list says should happen:

  * valid songs (never more than 3 notes sounding at a time): every note starts at exactly its start time, on a
    free lane, and stops at exactly start + length; the song ends when the last note ends;
  * overloaded songs (4 to 6 notes at once, which the parser refuses but rounding could in principle create):
    never more than 3 lanes sound, every note still starts on time, the song still finishes;
  * running late (the clock jumps past due times): nothing is lost, notes get only the time they have left.

Exit code 0 = all passed. Needs Visual Studio 2022 C++ build tools (cl.exe).
"""

import argparse
import random
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE.parent / "projects" / "gpiointerrupt_freertos"
VCVARS = r"C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"

DRIVER = r'''
#include <stdio.h>
#include "voice_sched.h"
static uint32_t g_now;
static void on(void *c, uint8_t lane, uint8_t note, uint32_t rem) { (void)c; printf("ON %lu %u %u %lu\n", (unsigned long)g_now, lane, note, (unsigned long)rem); }
static void off(void *c, uint8_t lane) { (void)c; printf("OFF %lu %u\n", (unsigned long)g_now, lane); }
int main(void)
{
    static MelodyEvent notes[2048];
    int tests, t;
    if (scanf("%d", &tests) != 1) return 1;
    for (t = 0; t < tests; t++) {
        int count, mode, i;
        unsigned long iterations = 0;
        VoiceSched s;
        uint32_t delta;
        scanf("%d %d", &count, &mode);
        for (i = 0; i < count; i++) {
            unsigned note, start, dur;
            scanf("%u %u %u", &note, &start, &dur);
            notes[i].midiNote = (uint8_t)note; notes[i].startMs = start; notes[i].durationMs = dur;
        }
        Sched_init(&s, notes, (uint32_t)count);
        g_now = 0; s.nowMs = 0;
        for (;;) {
            delta = Sched_advance(&s, on, off, 0);
            if (delta == 0U || ++iterations > 100000UL) break;
            g_now += delta + (mode == 1 ? 37U : 0U);
            s.nowMs = g_now;
        }
        printf("END %lu %lu %d\n", (unsigned long)g_now, iterations, (int)Sched_busy(&s));
    }
    return 0;
}
'''


def run_cases(exe, cases):
    text = "{}\n".format(len(cases))
    for notes, mode in cases:
        text += "{} {}\n".format(len(notes), mode) + "".join("{} {} {}\n".format(*n) for n in notes)
    out = subprocess.run([str(exe)], input=text, capture_output=True, text=True).stdout.splitlines()
    runs, log = [], []
    for line in out:
        f = line.split()
        if f[0] == "END":
            runs.append((log, int(f[1]), int(f[2]), int(f[3])))
            log = []
        else:
            log.append((f[0], int(f[1]), int(f[2])) + tuple(int(x) for x in f[3:]))
    assert len(runs) == len(cases), (len(runs), len(cases))
    return runs


def intervals(log, notes_by_lane=None):
    """Rebuild (note, start, end) from the ON/OFF log; also returns the maximum number of lanes sounding at once."""
    open_lane, done, peak, sounding = {}, [], 0, 0
    for entry in log:
        if entry[0] == "ON":
            _, t, lane, note, rem = entry
            if lane in open_lane:                       # taken over while still sounding
                n0, s0 = open_lane.pop(lane)
                done.append((n0, s0, t))
                sounding -= 1
            open_lane[lane] = (note, t)
            sounding += 1
            peak = max(peak, sounding)
        else:
            _, t, lane = entry
            n0, s0 = open_lane.pop(lane)
            done.append((n0, s0, t))
            sounding -= 1
    return done, peak, open_lane


def max_overlap(notes):
    points = sorted({n[1] for n in notes})
    return max(sum(1 for m in notes if m[1] <= p < m[1] + m[2]) for p in points) if notes else 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--random", type=int, default=400)
    args = ap.parse_args()
    failures = 0

    def check(name, ok, detail=""):
        nonlocal failures
        print(("PASS " if ok else "FAIL ") + name + (("  -- " + detail) if detail else ""))
        failures += 0 if ok else 1

    tmp = tempfile.TemporaryDirectory()
    work = Path(tmp.name)
    (work / "driver.c").write_text(DRIVER)
    b = subprocess.run('"{}" >nul && cl /nologo /W3 /D_CRT_SECURE_NO_WARNINGS /I"{}" /Fe:sched.exe driver.c'.format(VCVARS, SRC), cwd=work,
                       shell=True, capture_output=True, text=True)
    if not (work / "sched.exe").exists():
        print(b.stdout[-1500:])
        raise SystemExit("could not compile voice_sched.h")
    exe = work / "sched.exe"
    warns = [l for l in b.stdout.splitlines() if "warning" in l.lower()]
    check("voice_sched.h and the test driver compile with no warnings", not warns, "; ".join(warns[:2]))

    rnd = random.Random(7)

    def valid_song(n, limit=3):
        notes, t = [], 0
        for _ in range(n):
            t += rnd.choice([0, 0, 1, 5, 50, 250, 500])
            for _try in range(20):
                dur = rnd.choice([1, 2, 30, 120, 250, 500, 1500, 3000])
                cand = notes + [(rnd.randint(48, 84), t, dur)]
                if max_overlap(cand) <= limit:
                    notes = cand
                    break
        return notes or [(60, 0, 100)]

    # fixed cases ------------------------------------------------------------------------------------
    fixed = {
        "single note": [(60, 0, 500)],
        "melody with rests": [(60, 0, 250), (62, 500, 250), (64, 1000, 250)],
        "triad": [(60, 0, 1000), (64, 0, 1000), (67, 0, 1000)],
        "staggered 3 voices": [(60, 0, 2000), (64, 500, 1500), (67, 1000, 1000)],
        "back-to-back chords": [(60, 0, 500), (64, 0, 500), (67, 0, 500), (62, 500, 500), (65, 500, 500), (69, 500, 500)],
        "note ends as next begins": [(60, 0, 100), (62, 100, 100), (64, 200, 100)],
        "chord of 3 then 1-ms overlap of a 4th": [(60, 0, 500), (64, 0, 500), (67, 0, 500), (72, 499, 200)],
    }
    runs = run_cases(exe, [(v, 0) for v in fixed.values()])
    for (name, notes), (log, end_t, iters, busy) in zip(fixed.items(), runs):
        got, peak, still_open = intervals(log)
        want = sorted((n, s, s + d) for n, s, d in notes)
        starts_ok = sorted((e[3], e[1]) for e in log if e[0] == "ON") == sorted((n, s) for n, s, d in notes)
        if name.startswith("chord of 3 then 1-ms"):
            check("fixed: " + name + " (4th voice takes over the lane that ends first)",
                  peak <= 3 and starts_ok and not still_open and busy == 0, "peak {} lanes".format(peak))
        else:
            check("fixed: " + name, sorted(got) == want and peak <= 3 and not still_open and busy == 0 and end_t == max(e for _, _, e in want),
                  "peak {} lanes, ended at {} ms".format(peak, end_t))

    # random valid songs: exact -------------------------------------------------------------------
    songs = [valid_song(rnd.randint(1, 40)) for _ in range(args.random)]
    runs = run_cases(exe, [(s, 0) for s in songs])
    bad = 0
    for notes, (log, end_t, iters, busy) in zip(songs, runs):
        got, peak, still_open = intervals(log)
        want = sorted((n, s, s + d) for n, s, d in notes)
        if not (sorted(got) == want and peak <= 3 and not still_open and busy == 0 and end_t == max(e for _, _, e in want)):
            bad += 1
    check("random valid songs: {} songs, every note exactly on time, <= 3 lanes, finishes at the last note end".format(len(songs)), bad == 0,
          "{} bad".format(bad))

    # overloaded songs: properties ----------------------------------------------------------------
    over = [valid_song(rnd.randint(5, 40), limit=6) for _ in range(args.random)]
    runs = run_cases(exe, [(s, 0) for s in over])
    bad = overloaded = 0
    for notes, (log, end_t, iters, busy) in zip(over, runs):
        got, peak, still_open = intervals(log)
        overloaded += max_overlap(notes) > 3
        ons = sorted((e[3], e[1]) for e in log if e[0] == "ON")
        if not (peak <= 3 and ons == sorted((n, s) for n, s, d in notes) and not still_open and busy == 0):
            bad += 1
    check("overloaded songs: {} songs ({} really exceed 3 at once): never > 3 lanes, every note starts on time, finishes".format(len(over), overloaded),
          bad == 0, "{} bad".format(bad))

    # running late --------------------------------------------------------------------------------
    late = [valid_song(rnd.randint(1, 25)) for _ in range(120)]
    runs = run_cases(exe, [(s, 1) for s in late])
    bad = 0
    for notes, (log, end_t, iters, busy) in zip(late, runs):
        got, peak, still_open = intervals(log)
        count_on = sum(1 for e in log if e[0] == "ON")
        all_remaining_ok = all(e[4] >= 1 for e in log if e[0] == "ON")
        if not (peak <= 3 and count_on == len(notes) and all_remaining_ok and not still_open and busy == 0):
            bad += 1
    check("running late (clock +37 ms behind each step): {} songs, no note lost, remaining time >= 1 ms, <= 3 lanes".format(len(late)), bad == 0,
          "{} bad".format(bad))

    runs = run_cases(exe, [([], 0)])
    check("empty note list finishes immediately", runs[0][1] == 0 and runs[0][3] == 0 and not runs[0][0])
    tmp.cleanup()
    print("\n{} failure(s)".format(failures))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
