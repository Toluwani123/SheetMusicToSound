"""Tests for prepare_polyphonic_midi.py (the converter from any MIDI file to one the board accepts).

    python check_prepare_midi.py [--fuzz N]

Fixed cases check the rules one at a time; the fuzz builds random multi-track, multi-channel Type-1 songs with up
to six notes at once and checks, for every one, that the output
  * is accepted by the firmware rules (poly_midi.reference_parse, the same oracle used against midi.c),
  * never has more than the allowed number of notes sounding,
  * keeps the melody (highest sounding note) and the bass (lowest sounding note) at every moment,
  * never moves a note in time: every output note is covered by input notes of the same pitch.
Exit code 0 = all passed. Pure Python, no compiler needed.
"""

import argparse
import random
import sys
import tempfile
from pathlib import Path

import poly_midi as pm
import prepare_polyphonic_midi as pp


def sounding(notes, t):
    return [p for p, s, e in notes if s <= t < e]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fuzz", type=int, default=400)
    args = ap.parse_args()
    failures = 0

    def check(name, ok, detail=""):
        nonlocal failures
        print(("PASS " if ok else "FAIL ") + name + (("  -- " + detail) if detail else ""))
        failures += 0 if ok else 1

    def out_notes(out):
        status, notes = pm.reference_parse(out)
        assert status == "OK", status
        return notes

    # already playable: nothing changes ------------------------------------------------------------
    src = [(60, 0, 960), (64, 0, 960), (67, 480, 1440), (72, 960, 1920)]
    out, rep = pp.prepare(pm.build_midi(src))
    got = sorted((p, s, e) for p, s, e, _, _ in pm.read_notes(out)[0])
    check("a file the board already accepts comes back with the same notes", got == sorted(src) and rep["notes_dropped"] == 0 and rep["notes_cut_short"] == 0)

    # Type 1, treble + bass, several channels ----------------------------------------------------------
    treble = [(72, 0, 480, 0), (74, 480, 960, 0), (76, 960, 1440, 0), (77, 1440, 1920, 0)]
    middle = [(64, 0, 960, 1), (62, 960, 1920, 1)]
    bass = [(48, 0, 1920, 2)]
    out, rep = pp.prepare(pm.build_type1([treble, middle, bass]))
    notes = out_notes(out)
    check("Type 1 file with three tracks becomes a playable Type 0 file", len(notes) == 7 and rep["peak_after"] <= 3,
          "{} notes, most at once {}".format(len(notes), rep["peak_after"]))

    # four-note chord: keep melody and bass, one middle note ----------------------------------------------
    out, rep = pp.prepare(pm.build_midi([(60, 0, 960), (64, 0, 960), (67, 0, 960), (72, 0, 960)]))
    pitches = sorted(p for p, _, _ in out_notes(out))
    check("four-note chord: highest and lowest kept, one middle note dropped", pitches == [60, 67, 72] and rep["notes_dropped"] == 1, str(pitches))

    # long bass + a busy melody with 4 at once ---------------------------------------------------------------
    song = [(48, 0, 3840), (55, 0, 480), (64, 0, 3840), (72, 0, 480)]
    out, rep = pp.prepare(pm.build_midi(song))
    ps = sorted(p for p, _, _ in out_notes(out))
    check("held bass and held middle note outrank a short middle note", ps == [48, 64, 72] and rep["notes_dropped"] == 1, str(ps))

    # a bass note displaced by a brief lower note comes back when that note ends ---------------------------------------
    song = [(50, 0, 1920), (48, 480, 720), (60, 0, 1920), (64, 0, 1920), (76, 0, 1920)]
    out, rep = pp.prepare(pm.build_midi(song))
    notes = out_notes(out)
    low_at = lambda t: min(p for p, s, d in notes if s <= t < s + d)
    check("the bass is always the lowest note of the original, even after a brief lower note passes",
          low_at(250) == 50 and low_at(600) == 48 and low_at(1500) == 50 and rep["notes_restarted"] >= 1,
          "lowest at 250/600/1500 ms: {}/{}/{}, restarted {}".format(low_at(250), low_at(600), low_at(1500), rep["notes_restarted"]))

    # a new note arrives while three are sounding: a middle note is cut, the melody always stays ----------------
    song = [(48, 0, 1920), (60, 0, 1920), (64, 0, 480), (76, 240, 1920)]
    out, rep = pp.prepare(pm.build_midi(song))
    notes = out_notes(out)
    check("late fourth note: melody (76) and bass (48) always kept, a middle note cut short or dropped",
          any(p == 76 for p, _, _ in notes) and any(p == 48 for p, _, _ in notes) and rep["peak_after"] <= 3,
          "kept {}; cut {}, dropped {}".format(sorted(notes), rep["notes_cut_short"], rep["notes_dropped"]))

    # range handling ---------------------------------------------------------------------------------------
    out, rep = pp.prepare(pm.build_midi([(30, 0, 480), (38, 480, 960), (45, 960, 1440)]))
    pitches = [p for p, _, _ in out_notes(out)]
    check("a piece below the range is moved up by whole octaves", pitches == [54, 62, 69] and rep["octave_shift"] == 2, str(pitches))
    out, rep = pp.prepare(pm.build_midi([(60, 0, 480), (62, 480, 960), (100, 960, 1440)]))
    pitches = [p for p, _, _ in out_notes(out)]
    check("one stray high note is folded down an octave or more", pitches[:2] == [60, 62] and pitches[2] == 76 and rep["notes_folded"] == 2, str(pitches))

    # percussion, repeated pitch, empty ------------------------------------------------------------------------
    out, rep = pp.prepare(pm.build_type1([[(60, 0, 480, 0)], [(36, 0, 480, 9), (38, 480, 960, 9)]]))
    check("percussion channel is dropped", len(out_notes(out)) == 1 and rep["percussion_dropped"] == 2)
    pair = [pp.Note(60, 0, 960), pp.Note(60, 480, 1440), pp.Note(62, 0, 960), pp.Note(62, 0, 480), pp.Note(64, 0, 480), pp.Note(64, 480, 960)]
    merged_notes, merges = pp._merge_same_pitch(pair)
    check("overlapping same-pitch notes (a doubled unison) merge into one; notes that only touch stay separate",
          sorted((n.pitch, n.start, n.end) for n in merged_notes) == [(60, 0, 1440), (62, 0, 960), (64, 0, 480), (64, 480, 960)] and merges == 2,
          "{} merges".format(merges))
    try:
        pp.prepare(pm.build_type1([[]]))
        check("a file with no notes is refused", False)
    except ValueError as exc:
        check("a file with no notes is refused with a plain message", "no playable notes" in str(exc), str(exc))

    # size limits ---------------------------------------------------------------------------------------------------
    big = pm.build_midi([(48 + i % 37, i * 5, i * 5 + 4) for i in range(1100)], ppq=480)
    try:
        pp.prepare(big)
        check("more than 1024 notes is refused", False)
    except ValueError as exc:
        check("more than 1024 notes is refused with a plain message", "1024" in str(exc), str(exc))
    out, rep = pp.prepare(big, truncate=True)
    check("--truncate keeps the first 1024 notes", len(out_notes(out)) == 1024 and rep["notes_truncated"] == 76)

    # command line ------------------------------------------------------------------------------------------------------
    with tempfile.TemporaryDirectory() as tmp:
        i, o = Path(tmp) / "in.mid", Path(tmp) / "out.mid"
        i.write_bytes(pm.build_type1([treble, middle, bass]))
        code = pp.main([str(i), str(o)])
        check("command line writes a file the firmware rules accept", code == 0 and pm.reference_parse(o.read_bytes())[0] == "OK")
        i.write_bytes(b"not midi at all")
        check("command line reports an unreadable file and exits non-zero", pp.main([str(i), str(o)]) == 1)

    # fuzz -------------------------------------------------------------------------------------------------------------------
    rnd = random.Random(99)
    bad = 0
    stats = {"cut": 0, "dropped": 0, "reduced": 0}
    for case in range(args.fuzz):
        tracks = []
        for _ in range(rnd.randint(1, 4)):
            t, trk, ch = 0, [], rnd.randint(0, 7)
            for _ in range(rnd.randint(2, 18)):
                t += rnd.choice([0, 0, 120, 240, 480])
                trk.append((rnd.randint(48, 84), t, t + rnd.choice([120, 240, 480, 960, 1920]), ch))
            tracks.append(trk)
        data = pm.build_type1(tracks, ppq=480, tempo_us=rnd.choice([500000, 400000]))
        raw = [(p, s, e) for trk in tracks for p, s, e, _ in trk]
        try:
            out, rep = pp.prepare(data)
        except ValueError:
            bad += 1
            continue
        notes_in = [(p, s, e) for p, s, e, _, _ in pm.read_notes(data)[0]]
        status, notes_ms = pm.reference_parse(out)
        notes_out = [(p, s, e) for p, s, e, _, _ in pm.read_notes(out)[0]]
        ok = status == "OK" and rep["peak_after"] <= 3
        # no note moves: each output note is covered by input notes of the same pitch (overlapping unisons count as one)
        union = {}
        for ip, is_, ie in sorted(notes_in, key=lambda n: (n[0], n[1])):
            row = union.setdefault(ip, [])
            if row and is_ <= row[-1][1]:
                row[-1][1] = max(row[-1][1], ie)
            else:
                row.append([is_, ie])
        ok &= all(any(a <= s and e <= b for a, b in union.get(p, [])) for p, s, e in notes_out)
        # melody and bass preserved at every moment
        moments = sorted({s for _, s, _ in notes_in} | {e for _, _, e in notes_in})
        for t in moments:
            a, b = sounding(notes_in, t), sounding(notes_out, t)
            if a and (not b or max(a) != max(b) or min(a) != min(b)):
                ok = False
                break
        stats["reduced"] += rep["peak_before"] > 3
        stats["cut"] += rep["notes_cut_short"]
        stats["dropped"] += rep["notes_dropped"]
        bad += not ok
    check("fuzz: {} random multi-track songs: output accepted, <= 3 at once, melody and bass kept at every moment, no note moved".format(args.fuzz), bad == 0,
          "{} bad; {} songs needed reduction, {} notes cut short, {} dropped".format(bad, stats["reduced"], stats["cut"], stats["dropped"]))

    print("\n{} failure(s)".format(failures))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
