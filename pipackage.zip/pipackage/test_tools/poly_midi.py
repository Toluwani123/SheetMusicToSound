"""Small Standard-MIDI-File library for the polyphony work (no third-party packages).

  build_midi(notes, ...)   write a Type-0, single-track, channel-1 file from (pitch, start_tick, end_tick) notes
  read_notes(data)         read ANY Type 0/1 file (all tracks, all channels) into absolute-tick notes + tempo map
  reference_parse(data)    an independent Python implementation of the FIRMWARE's contract (midi.c), used as the
                           oracle in check_poly_parser.py. Returns ("OK", notes) or (error_name, None) where
                           notes = [(pitch, start_ms, duration_ms), ...] exactly as the firmware stores them.

Firmware contract (see midi.h): Type 0, one track, PPQN, channel 1 (status low nibble 0), pitches 48..84,
at most 3 notes sounding at once, <= 1024 notes, End Of Track last with nothing still sounding.
"""

import struct

NOTE_MIN, NOTE_MAX = 48, 84
MAX_VOICES = 3
MAX_NOTES = 1024


# ------------------------------------------------------------------ writing --

def vlq(value):
    out = [value & 0x7F]
    value >>= 7
    while value:
        out.append((value & 0x7F) | 0x80)
        value >>= 7
    return bytes(reversed(out))


def build_midi(notes, ppq=480, tempo_us=500000, extra_events=(), channel=0, program=None):
    """notes: iterable of (pitch, start_tick, end_tick). extra_events: (tick, bytes) raw events (meta, controllers).
    At the same tick Note Offs are written before Note Ons so a note can end exactly as another begins."""
    events = []
    for pitch, start, end in notes:
        events.append((start, 1, bytes([0x90 | channel, pitch, 90])))
        events.append((end, 0, bytes([0x80 | channel, pitch, 0])))
    for tick, raw in extra_events:
        events.append((tick, 0, raw))
    events.sort(key=lambda e: (e[0], e[1]))
    track = bytearray()
    track += vlq(0) + b"\xFF\x51\x03" + tempo_us.to_bytes(3, "big")
    if program is not None:
        track += vlq(0) + bytes([0xC0 | channel, program])
    last = 0
    for tick, _, raw in events:
        track += vlq(tick - last) + raw
        last = tick
    track += vlq(0) + b"\xFF\x2F\x00"
    return b"MThd" + struct.pack(">IHHH", 6, 0, 1, ppq) + b"MTrk" + struct.pack(">I", len(track)) + bytes(track)


def build_type1(tracks, ppq=480, tempo_us=500000, extra_events=()):
    """A Type-1 file like OMR/notation software writes: a tempo track plus one track per entry of `tracks`.
    Each track is a list of (pitch, start_tick, end_tick, channel)."""
    def chunk(events):
        body, last = bytearray(), 0
        for tick, _, raw in sorted(events, key=lambda e: (e[0], e[1])):
            body += vlq(tick - last) + raw
            last = tick
        body += vlq(0) + b"\xFF\x2F\x00"
        return b"MTrk" + struct.pack(">I", len(body)) + bytes(body)
    out = [chunk([(0, 0, b"\xFF\x51\x03" + tempo_us.to_bytes(3, "big"))] + [(t, 0, raw) for t, raw in extra_events])]
    for notes in tracks:
        ev = []
        for pitch, start, end, ch in notes:
            ev.append((start, 1, bytes([0x90 | ch, pitch, 90])))
            ev.append((end, 0, bytes([0x80 | ch, pitch, 0])))
        out.append(chunk(ev))
    return b"MThd" + struct.pack(">IHHH", 6, 1, len(out), ppq) + b"".join(out)


# ------------------------------------------------------------------ reading --

def _read_vlq(data, i):
    value = 0
    for _ in range(4):
        b = data[i]
        i += 1
        value = (value << 7) | (b & 0x7F)
        if not b & 0x80:
            return value, i
    raise ValueError("VLQ too long")


def read_notes(data, info=None):
    """Read any SMF (Type 0 or 1, any channels). Returns (notes, ppq, tempo_map).
    notes: [(pitch, start_tick, end_tick, track, channel)] in absolute ticks; tempo_map: [(tick, us_per_quarter)].
    If `info` is a dict, info["retriggers"] counts notes struck again while the same pitch still sounded."""
    if data[:4] != b"MThd":
        raise ValueError("not a MIDI file")
    fmt, ntracks, division = struct.unpack(">HHH", data[8:14])
    if division & 0x8000:
        raise ValueError("SMPTE time division is not supported")
    i = 8 + struct.unpack(">I", data[4:8])[0]
    notes, tempos = [], []
    for t in range(ntracks):
        while data[i:i + 4] != b"MTrk":
            i += 8 + struct.unpack(">I", data[i + 4:i + 8])[0]
        length = struct.unpack(">I", data[i + 4:i + 8])[0]
        j, end, tick, running = i + 8, i + 8 + length, 0, 0
        sounding = {}
        while j < end:
            delta, j = _read_vlq(data, j)
            tick += delta
            status = data[j]
            if status < 0x80:
                status = running
            else:
                j += 1
                if status < 0xF0:
                    running = status
            if status == 0xFF:
                mtype = data[j]
                size, j = _read_vlq(data, j + 1)
                if mtype == 0x51 and size == 3:
                    tempos.append((tick, int.from_bytes(data[j:j + 3], "big")))
                j += size
                if mtype == 0x2F:
                    break
            elif status in (0xF0, 0xF7):
                size, j = _read_vlq(data, j)
                j += size
            else:
                kind, ch = status & 0xF0, status & 0x0F
                size = 1 if kind in (0xC0, 0xD0) else 2
                a = data[j]
                b = data[j + 1] if size == 2 else 0
                j += size
                if kind == 0x90 and b > 0:
                    if (a, ch) in sounding:             # retrigger: close the old one first
                        notes.append((a, sounding.pop((a, ch)), tick, t, ch))
                        if info is not None:
                            info["retriggers"] = info.get("retriggers", 0) + 1
                            info.setdefault("retrigger_pitch", a)
                    sounding[(a, ch)] = tick
                elif kind in (0x80, 0x90) and (a, ch) in sounding:
                    notes.append((a, sounding.pop((a, ch)), tick, t, ch))
        for (a, ch), s in sounding.items():             # unterminated notes end at the track end
            notes.append((a, s, tick, t, ch))
        i = end
    tempos.sort()
    return sorted(notes, key=lambda n: (n[1], n[0])), division, tempos


def exact_ms(tick, ppq, tempos):
    """Time of an absolute tick in milliseconds (float), following the tempo map [(tick, us_per_quarter)]."""
    us, last_tick, tempo = 0.0, 0, 500000
    for t, new_tempo in sorted(tempos):
        if t >= tick:
            break
        us += (t - last_tick) * tempo / ppq
        last_tick, tempo = t, new_tempo
    return (us + (tick - last_tick) * tempo / ppq) / 1000.0


# -------------------------------------------------------- firmware oracle ----

def _ms(us):
    ms = (us + 500) // 1000
    return 1 if (us > 0 and ms == 0) else ms


def reference_parse(data, capacity=MAX_NOTES):
    """Independent re-implementation of Midi_parse()'s contract. Returns ("OK", notes) or (error, None)."""
    n = len(data)
    be16 = lambda k: (data[k] << 8) | data[k + 1]
    be32 = lambda k: (data[k] << 24) | (data[k + 1] << 16) | (data[k + 2] << 8) | data[k + 3]
    if n < 22 or data[0:4] != b"MThd" or be32(4) != 6 or be16(8) != 0 or be16(10) != 1:
        return "MALFORMED", None
    division = be16(12)
    if division == 0 or division & 0x8000 or data[14:18] != b"MTrk" or be32(18) != n - 22:
        return "MALFORMED", None
    i, tempo, frac, now_us = 22, 500000, 0, 0
    running = 0
    first_us = None
    out, active = [], []          # active: list of (pitch, index in out)
    while i < n:
        delta, shift_ok = 0, False
        for count in range(4):
            if i >= n:
                return "MALFORMED", None
            b = data[i]
            i += 1
            delta = (delta << 7) | (b & 0x7F)
            if not b & 0x80:
                shift_ok = True
                break
        if not shift_ok:
            return "MALFORMED", None
        num = delta * tempo + frac
        now_us += num // division
        frac = num % division
        if i >= n:
            return "MALFORMED", None
        status = data[i]
        if status < 0x80:
            if running == 0:
                return "MALFORMED", None
            status = running
        else:
            i += 1
            running = status if status < 0xF0 else 0
        if status == 0xFF:
            if i >= n:
                return "MALFORMED", None
            mtype = data[i]
            i += 1
            if mtype >= 0x80:
                return "MALFORMED", None
            length, ok = 0, False
            for count in range(4):
                if i >= n:
                    return "MALFORMED", None
                b = data[i]
                i += 1
                length = (length << 7) | (b & 0x7F)
                if not b & 0x80:
                    ok = True
                    break
            if not ok or length > n - i:
                return "MALFORMED", None
            fixed = {0x00: 2, 0x20: 1, 0x21: 1, 0x2F: 0, 0x51: 3, 0x54: 5, 0x58: 4, 0x59: 2}
            if mtype in fixed and length != fixed[mtype]:
                return "MALFORMED", None
            if mtype == 0x51:
                tempo = int.from_bytes(data[i:i + 3], "big")
                if tempo == 0:
                    return "MALFORMED", None
            elif mtype == 0x2F:
                return ("OK", [tuple(note) for note in out]) if (not active and out and i == n) else ("MALFORMED", None)
            elif (mtype == 0x20 and data[i] > 15) or (mtype == 0x21 and data[i] > 127):
                return "MALFORMED", None
            i += length
            continue
        if status >= 0xF0 or status & 0x0F:
            return "MALFORMED", None
        kind = status & 0xF0
        size = 1 if kind in (0xC0, 0xD0) else 2
        if size > n - i or any(data[i + k] >= 0x80 for k in range(size)):
            return "MALFORMED", None
        a = data[i]
        b = data[i + 1] if size == 2 else 0
        i += size
        if kind not in (0x80, 0x90):
            continue
        if kind == 0x90 and b != 0:
            if not NOTE_MIN <= a <= NOTE_MAX or any(p == a for p, _ in active):
                return "MALFORMED", None
            if len(active) >= MAX_VOICES:
                return "TOO_MANY_VOICES", None
            if len(out) >= capacity:
                return "NOTE_CAPACITY", None
            if first_us is None:
                first_us = now_us
            out.append([a, _ms(now_us - first_us), 0])
            active.append((a, len(out) - 1))
        else:
            hit = next((k for k, (p, _) in enumerate(active) if p == a), None)
            if hit is None:
                return "MALFORMED", None
            idx = active.pop(hit)[1]
            end_ms = _ms(now_us - first_us)
            out[idx][2] = end_ms - out[idx][1] if end_ms > out[idx][1] else 1
    return "MALFORMED", None
