"""Run every PC-side test for the polyphony milestone, one after the other, and print one line per suite.

    python run_polyphony_tests.py            # everything (about 2 minutes; the host-tooling self-test is the slow part)
    python run_polyphony_tests.py --quick    # skip the slow existing self-test

THIS RUNS ON THE PC ONLY. It never opens the COM port, so it cannot make the board or the speaker play anything.
To hear the board, run:  python board_tests\\board_hello.py --port COM5   (then board_tests\\check_poly_board.py).

None of this needs the board. Exit code 0 = every suite passed.
(The architecture check reports a failure if a Debug build folder exists inside the project: delete that folder
 from the project copy you ship, or ignore that one line.)

Needs Python with numpy only for generate/analyze tools (not for these tests) and Visual Studio 2022 C++ build
tools (cl.exe) for the suites that compile the real firmware files on the PC.
"""

import argparse
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
APP = ROOT / "projects" / "gpiointerrupt_freertos"
KERNEL = ROOT / "projects" / "freertos_kernel_glo"
BASELINE = ROOT / "checkpoints" / "00_before_globals_rtos" / "gpiointerrupt" / "gpiointerrupt.c"

SUITES = [
    ("MIDI parser (real midi.c vs oracle, fuzz)", [sys.executable, "check_poly_parser.py"]),
    ("voice scheduler (real voice_sched.h)", [sys.executable, "check_voice_sched.py"]),
    ("audio engine (real audio.c: one voice == previous milestone, chords, voices)", [sys.executable, "check_poly_audio.py"]),
    ("end to end (real parser + playback + audio)", [sys.executable, "check_poly_playback.py"]),
    ("piano songs (melody + left hand: rules, tunes, hands never cross)", [sys.executable, "check_piano_songs.py"]),
    ("piano board script, against a simulated board", [sys.executable, "board_tests/check_piano_board.py", "--selftest"]),
    ("envelope (new code == previous milestone without decay)", [sys.executable, "check_envelope_decay.py"]),
    ("MIDI preparation tool (any MIDI -> playable)", [sys.executable, "check_prepare_midi.py"]),
    ("board test script, against a simulated board", [sys.executable, "board_tests/check_poly_board.py", "--selftest"]),
    ("instrument tables are up to date", [sys.executable, "generate_instrument_tables.py", "--check"]),
    ("waveform arithmetic (existing)", [sys.executable, "-I", "verify_waveform_math.py", str(APP), str(KERNEL), str(BASELINE)]),
    ("UART transmit queue checks (existing)", [sys.executable, "-I", "check_uart_tx.py"]),
    ("architecture / ISR rules / headers (existing)", [sys.executable, "-I", "check_architecture.py"]),
    ("host tooling self-test (existing, slow)", [sys.executable, "selftest_host_tooling.py"]),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    args = ap.parse_args()
    failed = []
    print("PC-only tests: nothing here talks to the board or makes a sound. To hear the board:")
    print("    cd board_tests ; python board_hello.py --port COM5\n")
    for name, cmd in SUITES:
        if args.quick and "slow" in name:
            print("SKIP  {}".format(name))
            continue
        started = time.monotonic()
        print("....  {}{}".format(name, "   (about 2 minutes, no output until it finishes: please wait)" if "slow" in name else ""), flush=True)
        cwd = HERE / "board_tests" if "selftest_host_tooling" in " ".join(cmd) else HERE
        r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
        out = r.stdout + r.stderr
        lines = [l for l in out.strip().splitlines() if l.strip()]
        summary = [l for l in lines if "failure(s)" in l or "passed" in l.lower() or "PASSED" in l]
        last = (summary or lines)[-1:] or [""]
        ok = r.returncode == 0
        fail_lines = [l for l in out.splitlines() if l.startswith("FAIL")]
        if not ok and "architecture" in name and fail_lines and all("stale build products" in l for l in fail_lines):
            ok = True                                   # only the Debug folder left by your own CCS build: not a problem
            last = ["only note: a Debug build folder exists in the project (from your CCS build); ignored"]
        print("{}  {}  ({:.0f} s)  {}".format("PASS" if ok else "FAIL", name, time.monotonic() - started, last[0][:70]))
        if not ok:
            failed.append(name)
            for l in [l for l in out.splitlines() if l.startswith("FAIL")][:6]:
                print("        " + l[:150])
    print("\n{}".format("ALL SUITES PASSED" if not failed else "{} suite(s) FAILED: {}".format(len(failed), "; ".join(failed))))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
