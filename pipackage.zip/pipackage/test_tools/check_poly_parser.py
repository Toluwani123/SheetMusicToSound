"""Host test of the REAL firmware MIDI parser (projects/gpiointerrupt_freertos/midi.c), polyphonic version.

    python check_poly_parser.py [--fuzz N]        (default 600 random cases)

midi.c is pure C (no hardware), so it is compiled here with Visual Studio's cl.exe and run on:
  * fixed cases: chords, overlaps, back-to-back chords, 4-note chord (must be refused), duplicate pitch,
    out-of-range pitch, tempo change inside a chord, leading silence, running status, 1024/1025 notes ...
  * the single-line reference songs, compared with the PREVIOUS milestone's parser (timing drift report)
  * random songs and randomly damaged files, compared case by case with the independent Python oracle
    (poly_midi.reference_parse).
Exit code 0 = everything agreed. Needs Visual Studio 2022 C++ build tools (cl.exe).
"""

import argparse
import random
import subprocess
import sys
import tempfile
from pathlib import Path

import poly_midi as pm

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
NEW_DIR = ROOT / "projects" / "gpiointerrupt_freertos"
OLD_DIR = HERE.parent.parent / "uart_tx_queue_milestone" / "projects" / "gpiointerrupt_freertos"
REF_DIR = HERE / "board_tests" / "reference_midi"
VCVARS = r"C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"

NEW_DRIVER = r'''
#include <stdio.h>
#include <stdlib.h>
#include "midi.h"
int main(void)
{
    static MelodyEvent out[MAX_PARSED_NOTES];
    char path[1024];
    while (fgets(path, sizeof path, stdin)) {
        size_t len = strlen(path); while (len && (path[len-1]=='\n'||path[len-1]=='\r')) path[--len] = 0;
        FILE *f = fopen(path, "rb"); static unsigned char buf[70000]; size_t n = f ? fread(buf, 1, sizeof buf, f) : 0;
        uint32_t count = 0, i; MidiParseResult r;
        if (f) fclose(f);
        r = Midi_parse(buf, (uint32_t)n, out, MAX_PARSED_NOTES, &count);
        printf("R %d %lu\n", (int)r, (unsigned long)count);
        if (r == MIDI_PARSE_OK) for (i = 0; i < count; i++)
            printf("N %u %lu %lu\n", (unsigned)out[i].midiNote, (unsigned long)out[i].startMs, (unsigned long)out[i].durationMs);
    }
    return 0;
}
'''
OLD_DRIVER = r'''
#include <stdio.h>
#include <stdlib.h>
#include "midi.h"
int main(void)
{
    static MelodyEvent out[MAX_PARSED_NOTES];
    char path[1024];
    while (fgets(path, sizeof path, stdin)) {
        size_t len = strlen(path); while (len && (path[len-1]=='\n'||path[len-1]=='\r')) path[--len] = 0;
        FILE *f = fopen(path, "rb"); static unsigned char buf[70000]; size_t n = f ? fread(buf, 1, sizeof buf, f) : 0;
        uint32_t count = 0, i; MidiParseResult r;
        if (f) fclose(f);
        r = Midi_parse(buf, (uint32_t)n, out, MAX_PARSED_NOTES, &count);
        printf("R %d %lu\n", (int)r, (unsigned long)count);
        if (r == MIDI_PARSE_OK) for (i = 0; i < count; i++)
            printf("N %u %lu %lu\n", (unsigned)out[i].midiNote, (unsigned long)out[i].durationMs, (unsigned long)out[i].restAfterMs);
    }
    return 0;
}
'''
RESULT_NAME = {0: "OK", 1: "MALFORMED", 2: "NOTE_CAPACITY", 3: "TOO_MANY_VOICES"}


def build_exe(workdir, src_dir, driver_text, name):
    d = Path(workdir) / name
    d.mkdir()
    (d / "driver.c").write_text("#include <string.h>\n" + driver_text)
    r = subprocess.run('"{}" >nul && cl /nologo /W3 /I"{}" /Fe:{}.exe driver.c "{}"'.format(
        VCVARS, src_dir, name, src_dir / "midi.c"), cwd=d, shell=True, capture_output=True, text=True)
    exe = d / (name + ".exe")
    warnings = [l for l in r.stdout.splitlines() if "warning" in l.lower() and "midi" in l.lower()]
    if not exe.exists():
        print(r.stdout[-1500:], r.stderr[-500:])
        raise SystemExit("could not compile " + name)
    return exe, warnings


def run_files(exe, paths):
    out = subprocess.run([str(exe)], input="\n".join(map(str, paths)) + "\n", capture_output=True, text=True).stdout.splitlines()
    results, cur = [], None
    for line in out:
        f = line.split()
        if f[0] == "R":
            cur = [int(f[1]), int(f[2]), []]
            results.append(cur)
        else:
            cur[2].append(tuple(int(x) for x in f[1:]))
    assert len(results) == len(paths), (len(results), len(paths))
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fuzz", type=int, default=600)
    args = ap.parse_args()
    failures = 0

    def check(name, ok, detail=""):
        nonlocal failures
        print(("PASS " if ok else "FAIL ") + name + (("  -- " + detail) if detail else ""))
        failures += 0 if ok else 1

    rnd = random.Random(2026)
    tmp = tempfile.TemporaryDirectory()
    work = Path(tmp.name)
    new_exe, warns = build_exe(work, NEW_DIR, NEW_DRIVER, "newparse")
    check("midi.c compiles with no warnings", not warns, "; ".join(warns[:2]))

    cases = {}                         # name -> (bytes, expected firmware result name)
    T = 480                            # ticks per quarter at 500000 us = 500 ms per quarter
    cases["triad held 1 s"] = pm.build_midi([(60, 0, 960), (64, 0, 960), (67, 0, 960)])
    cases["two notes overlapping"] = pm.build_midi([(60, 0, 960), (64, 480, 1440)])
    cases["three staggered voices"] = pm.build_midi([(60, 0, 1920), (64, 480, 1920), (67, 960, 1920)])
    cases["chords back to back"] = pm.build_midi([(60, 0, 480), (64, 0, 480), (67, 0, 480), (62, 480, 960), (65, 480, 960), (69, 480, 960)])
    cases["four-note chord"] = pm.build_midi([(60, 0, 480), (64, 0, 480), (67, 0, 480), (72, 0, 480)])
    cases["fourth note joins late"] = pm.build_midi([(60, 0, 960), (64, 0, 960), (67, 100, 960), (72, 200, 960)])
    cases["same pitch twice at once"] = pm.build_midi([(60, 0, 960), (60, 240, 720)])
    cases["pitch below range (47)"] = pm.build_midi([(47, 0, 480)])
    cases["pitch above range (85)"] = pm.build_midi([(60, 0, 480), (85, 0, 480)])
    cases["lowest and highest legal pitch"] = pm.build_midi([(48, 0, 480), (84, 0, 480)])
    cases["leading silence"] = pm.build_midi([(60, 960, 1440), (64, 960, 1440)])
    cases["tempo change inside a chord"] = pm.build_midi([(60, 0, 1920), (64, 0, 1920), (67, 480, 1920)],
                                                          extra_events=[(960, b"\xFF\x51\x03" + (250000).to_bytes(3, "big"))])
    cases["ignored controllers and program"] = pm.build_midi([(60, 0, 480), (64, 0, 480)], program=40,
                                                              extra_events=[(100, bytes([0xB0, 64, 127])), (200, bytes([0xE0, 0, 64]))])
    cases["one-tick note (about 1 ms)"] = pm.build_midi([(60, 0, 1), (64, 100, 580)])
    cases["silence between chords"] = pm.build_midi([(60, 0, 480), (64, 0, 480), (62, 1920, 2400)])
    cases["1024 notes (limit)"] = pm.build_midi([(48 + i % 37, i * 10, i * 10 + 8) for i in range(1024)], ppq=480)
    cases["1025 notes (over limit)"] = pm.build_midi([(48 + i % 37, i * 10, i * 10 + 8) for i in range(1025)], ppq=480)
    # Note Off written as Note On velocity 0, with running status, by hand
    trk = bytes([0x00, 0xFF, 0x51, 0x03, 0x07, 0xA1, 0x20,
                 0x00, 0x90, 60, 80, 0x00, 64, 80,           # running status: second Note On
                 0x83, 0x60, 60, 0, 0x00, 64, 0,             # both ended with velocity 0 (running status)
                 0x00, 0xFF, 0x2F, 0x00])
    cases["running status and velocity-0 note offs"] = b"MThd" + (6).to_bytes(4, "big") + bytes([0, 0, 0, 1, 1, 0xE0]) + b"MTrk" + len(trk).to_bytes(4, "big") + trk
    cases["not a MIDI file"] = b"hello world, this is not midi at all......"
    cases["Type 1 file"] = pm.build_midi([(60, 0, 480)])[:9] + b"\x01" + pm.build_midi([(60, 0, 480)])[10:]

    names = list(cases)
    paths = []
    for k, nm in enumerate(names):
        p = work / "case{}.mid".format(k)
        p.write_bytes(cases[nm])
        paths.append(p)
    got = run_files(new_exe, paths)
    expected_error = {"four-note chord": "TOO_MANY_VOICES", "fourth note joins late": "TOO_MANY_VOICES",
                      "same pitch twice at once": "MALFORMED", "pitch below range (47)": "MALFORMED",
                      "pitch above range (85)": "MALFORMED", "1025 notes (over limit)": "NOTE_CAPACITY",
                      "not a MIDI file": "MALFORMED", "Type 1 file": "MALFORMED"}
    for nm, (code, count, notes) in zip(names, got):
        want = expected_error.get(nm, "OK")
        ora, ora_notes = pm.reference_parse(cases[nm])
        agree = RESULT_NAME[code] == want == ora and (want != "OK" or notes == [tuple(x) for x in ora_notes])
        check("case: " + nm, agree, "firmware {} {} notes; oracle {}; expected {}".format(RESULT_NAME[code], count, ora, want))

    # a few exact expectations, worked out by hand (500 ms per quarter note, 480 ticks per quarter)
    byname = {nm: g for nm, g in zip(names, got)}
    check("triad: three notes start together and last 1000 ms",
          byname["triad held 1 s"][2] == [(60, 0, 1000), (64, 0, 1000), (67, 0, 1000)], str(byname["triad held 1 s"][2]))
    check("staggered voices: starts 0/500/1000, each 2000 ms long",
          byname["three staggered voices"][2] == [(60, 0, 1920 * 500 // 480 - 0), (64, 500, 1920 * 500 // 480 - 500), (67, 1000, 1920 * 500 // 480 - 1000)],
          str(byname["three staggered voices"][2]))
    check("leading silence is dropped (first note starts at 0)", byname["leading silence"][2][0][1] == 0)
    check("note ending exactly as the next starts: no gap or overlap after rounding",
          all(a[1] + a[2] == b[1] for a, b in zip(byname["chords back to back"][2][:3], byname["chords back to back"][2][3:])))
    # 500 ms per quarter for the first 960 ticks (1000 ms), then 250 ms per quarter: the two long notes run to tick
    # 1920, i.e. 1000 + 2 quarters * 250 = 1500 ms; the third note starts at tick 480 (500 ms) and also ends at 1500 ms.
    check("tempo change inside a chord is applied (long notes end at 1500 ms)",
          byname["tempo change inside a chord"][2] == [(60, 0, 1500), (64, 0, 1500), (67, 500, 1000)],
          str(byname["tempo change inside a chord"][2]))

    # ---- single-line reference songs vs the previous milestone's parser
    if OLD_DIR.exists():
        old_exe, _ = build_exe(work, OLD_DIR, OLD_DRIVER, "oldparse")
        mono = sorted(REF_DIR.glob("*.mid")) + sorted((HERE / "board_tests" / "midi_tests_milestone").glob("*.mid"))
        new_res, old_res = run_files(new_exe, mono), run_files(old_exe, mono)
        for f, (nc, nn, nnotes), (oc, on, onotes) in zip(mono, new_res, old_res):
            if oc != 0 or nc != 0:
                check("single-line song accepted by both parsers: " + f.name, nc == oc, "new {} old {}".format(nc, oc))
                continue
            # the exact time of each note straight from the file's ticks (independent of both parsers)
            notes, ppq, tempos = pm.read_notes(f.read_bytes())
            t0 = pm.exact_ms(notes[0][1], ppq, tempos)
            ideal = [(n[0], pm.exact_ms(n[1], ppq, tempos) - t0, pm.exact_ms(n[2], ppq, tempos) - pm.exact_ms(n[1], ppq, tempos)) for n in notes]
            new_err = max(max(abs(a[1] - b[1]), abs(a[2] - b[2])) for a, b in zip(nnotes, ideal))
            t, old_err, same_pitch = 0, 0.0, nn == on
            for (pitch, dur, rest), (ipitch, istart, idur) in zip(onotes, ideal):
                old_err = max(old_err, abs(t - istart))
                same_pitch &= pitch == ipitch
                t += dur + rest
            check("single-line song: {} ({} notes) same notes, new timing within 1 ms of exact".format(f.name, nn),
                  same_pitch and new_err <= 1.0 and nn == len(ideal),
                  "new parser worst error {:.2f} ms; previous parser {:.2f} ms".format(new_err, old_err))
        print("     (the new parser times every note from the song start, so it no longer accumulates the old per-note rounding)")
    else:
        print("SKIP comparison with the previous milestone parser (folder not found)")

    # ---- fuzz: random valid songs (polyphony 1..4) and random damage, against the oracle
    def random_song():
        """Half the songs are sparse (mostly playable with chords of up to 3), half dense (often more than 3 at once)."""
        sparse = rnd.random() < 0.55
        gaps = [0, 0, 240, 480, 960, 1920] if sparse else [0, 0, 0, 120, 240, 480, 960]
        durs = [60, 120, 240, 480] if sparse else [1, 60, 120, 240, 480, 960, 1920]
        notes = []
        t = 0
        for _ in range(rnd.randint(1, 60)):
            t += rnd.choice(gaps)
            dur = rnd.choice(durs)
            pitch = rnd.randint(46, 86) if rnd.random() < 0.03 else rnd.randint(48, 84)
            if any(p == pitch and s < t + dur and e > t for p, s, e in notes):
                continue                                   # avoid same-pitch overlap unless wanted
            if sparse and sum(1 for p, s, e in notes if s <= t < e) >= 3:
                continue                                   # keep sparse songs within 3 voices
            notes.append((pitch, t, t + dur))
        if not notes:
            notes = [(60, 0, 480)]
        return pm.build_midi(notes, ppq=rnd.choice([96, 120, 480, 960]), tempo_us=rnd.choice([250000, 500000, 428571, 1000000]))

    fuzz_cases = []
    for _ in range(args.fuzz):
        data = random_song()
        mode = rnd.random()
        if mode < 0.25:                                    # byte damage
            b = bytearray(data)
            for _ in range(rnd.randint(1, 3)):
                b[rnd.randrange(len(b))] = rnd.randrange(256)
            data = bytes(b)
        elif mode < 0.35:
            data = data[:rnd.randrange(1, len(data))]      # truncated
        fuzz_cases.append(data)
    fpaths = []
    for k, d in enumerate(fuzz_cases):
        p = work / "fuzz{}.mid".format(k)
        p.write_bytes(d)
        fpaths.append(p)
    fres = run_files(new_exe, fpaths)
    bad, counts = 0, {}
    for k, (d, (code, count, notes)) in enumerate(zip(fuzz_cases, fres)):
        ora, ora_notes = pm.reference_parse(d)
        counts[ora] = counts.get(ora, 0) + 1
        if RESULT_NAME[code] != ora or (ora == "OK" and notes != [tuple(x) for x in ora_notes]):
            bad += 1
            if bad <= 3:
                print("     mismatch on fuzz case {}: C={} oracle={}".format(k, RESULT_NAME[code], ora))
    check("fuzz: {} random/damaged files, C parser == oracle on result and every note".format(len(fuzz_cases)), bad == 0,
          "{} mismatches; outcomes seen: {}".format(bad, counts))
    tmp.cleanup()
    print("\n{} failure(s)".format(failures))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
