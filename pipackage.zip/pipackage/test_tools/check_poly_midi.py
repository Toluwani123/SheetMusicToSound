"""Check a MIDI file against the MSP player's rules (up to 3 notes at once) and explain the answer.

    python check_poly_midi.py song.mid [more.mid ...]

Prints what the board will do with the file: either the notes it will play (start, length, how many sound at
once) or the reason it would be refused (and the reply the board would send). Exit code 0 = every file accepted.
If a file is refused, `prepare_polyphonic_midi.py` can usually repair it.
"""

import sys
from pathlib import Path

import poly_midi as pm

NAMES = "C C# D D# E F F# G G# A A# B".split()
REPLY = {"TOO_MANY_VOICES": "ERR_VOICES", "NOTE_CAPACITY": "ERR_NOTE_CAPACITY", "MALFORMED": "ERR_MIDI"}


def pitch_name(p):
    return "{}{}".format(NAMES[p % 12], p // 12 - 1)


def explain(data):
    """Plain-language reasons a file might be refused, found with the permissive reader."""
    reasons = []
    if data[:4] != b"MThd":
        return ["this is not a Standard MIDI file"]
    fmt = int.from_bytes(data[8:10], "big")
    ntracks = int.from_bytes(data[10:12], "big")
    if fmt != 0 or ntracks != 1:
        reasons.append("it is Type {} with {} track(s); the board needs Type 0 with exactly one track".format(fmt, ntracks))
    info = {}
    try:
        notes, ppq, tempos = pm.read_notes(data, info)
    except (ValueError, IndexError) as exc:
        return reasons + ["the file could not be read: {}".format(exc)]
    channels = {n[4] for n in notes}
    if channels - {0}:
        reasons.append("it uses MIDI channel(s) {}; the board only plays channel 1".format(", ".join(str(c + 1) for c in sorted(channels))))
    low = [n for n in notes if n[0] < pm.NOTE_MIN]
    high = [n for n in notes if n[0] > pm.NOTE_MAX]
    if low or high:
        reasons.append("{} note(s) are outside C3..C6 (lowest {}, highest {})".format(
            len(low) + len(high), pitch_name(min(n[0] for n in notes)), pitch_name(max(n[0] for n in notes))))
    if notes:
        times = sorted({n[1] for n in notes})
        peak, at = 0, 0
        for t in times:
            c = sum(1 for n in notes if n[1] <= t < n[2])
            if c > peak:
                peak, at = c, t
        if peak > pm.MAX_VOICES:
            reasons.append("{} notes sound at once (first at tick {}); the board plays at most {}".format(peak, at, pm.MAX_VOICES))
        same = [(a, b) for i, a in enumerate(notes) for b in notes[i + 1:] if a[0] == b[0] and a[1] < b[2] and b[1] < a[2]]
        if same:
            reasons.append("the same pitch ({}) sounds twice at once".format(pitch_name(same[0][0][0])))
        elif info.get("retriggers"):
            reasons.append("the same pitch ({}) is struck again while it still sounds".format(pitch_name(info["retrigger_pitch"])))
    if len(notes) > pm.MAX_NOTES:
        reasons.append("{} notes is more than the board's {}".format(len(notes), pm.MAX_NOTES))
    if len(data) > 16384:
        reasons.append("{} bytes is more than the board's 16384".format(len(data)))
    return reasons or ["some other part of the file breaks the board's strict rules (text, SysEx or a damaged chunk)"]


def check(path):
    data = Path(path).read_bytes()
    status, notes = pm.reference_parse(data)
    if status == "OK":
        peak = 0
        for _, s, d in notes:
            peak = max(peak, sum(1 for _, s2, d2 in notes if s2 <= s < s2 + d2))
        end = max(s + d for _, s, d in notes)
        print("{}: ACCEPTED - {} notes, up to {} at once, {:.1f} s".format(Path(path).name, len(notes), peak, end / 1000))
        for p, s, d in notes[:12]:
            print("    {:>7.3f} s  {:<4s} for {:.3f} s".format(s / 1000, pitch_name(p), d / 1000))
        if len(notes) > 12:
            print("    ... and {} more".format(len(notes) - 12))
        return True
    print("{}: REFUSED - the board would reply {}".format(Path(path).name, REPLY[status]))
    for r in explain(data):
        print("    - " + r)
    print("    try:  python prepare_polyphonic_midi.py {} playable.mid".format(Path(path).name))
    return False


def main(argv):
    if not argv:
        print(__doc__)
        return 2
    results = [check(p) for p in argv]
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
