"""Turn ANY MIDI file (Type 0 or 1, many tracks, many channels, any number of simultaneous notes) into a file the
MSP432 player accepts: Type 0, one track, channel 1, pitches 48..84, at most 3 notes sounding at once.

    python prepare_polyphonic_midi.py score.mid playable.mid [--max-voices 3] [--keep-percussion] [--truncate]

What it does, in order (the report says how much of each happened):
  1. merge every track and channel into one list of notes (percussion channel 10 is dropped unless asked);
  2. remove zero-length notes; two notes of the same pitch that overlap (a unison doubled on two tracks) are
     merged into one longer note, because the firmware refuses a repeated pitch while it sounds;
  3. move the whole piece by whole octaves so as many notes as possible fall in 48..84 (C3..C6), then fold any
     remaining stray note by octaves into range;
  4. reduce to at most --max-voices notes at any moment. Every stretch of time between two note starts/ends is
     judged on its own. When more notes would sound than there are voices, the HIGHEST note (the melody) and the
     LOWEST note (the bass) are always kept; the free voices go to the notes that still have the longest to sound,
     preferring a note that is already sounding. A middle note that loses its voice is cut off and does not come
     back; a melody or bass note that was displaced returns, as a fresh strike, the moment it is the highest or
     lowest again;
  5. write Type 0, one track, channel 1, keeping the original timing, tempo changes and ticks-per-quarter;
  6. check the result with an independent copy of the firmware's rules (poly_midi.reference_parse).

Notes are never moved in time: a note starts when it did in the original, or (only for a displaced melody or
bass note) at the moment it takes over the top or bottom again.
Exit code 0 = a playable file was written.
"""

import argparse
import sys
from pathlib import Path

import poly_midi as pm


class Note:
    __slots__ = ("pitch", "start", "end")

    def __init__(self, pitch, start, end):
        self.pitch, self.start, self.end = pitch, start, end


def _merge_same_pitch(notes):
    """Overlapping notes of the same pitch become one note (start of the first, end of the last).
    Notes that merely touch stay separate. Returns (notes, how_many_merges). Input need not be sorted."""
    by_pitch, merged = {}, 0
    for n in sorted(notes, key=lambda n: (n.pitch, n.start, n.end)):
        row = by_pitch.setdefault(n.pitch, [])
        if row and n.start < row[-1].end:
            row[-1].end = max(row[-1].end, n.end)
            merged += 1
        else:
            row.append(n)
    out = sorted((n for row in by_pitch.values() for n in row), key=lambda n: (n.start, n.pitch))
    return out, merged


def peak_polyphony(notes):
    times = sorted({n.start for n in notes})
    return max((sum(1 for m in notes if m.start <= t < m.end) for t in times), default=0)


def reduce_voices(notes, max_voices):
    """Keep at most max_voices notes sounding at any moment, judging each stretch of time on its own.
    Returns (output_notes, dropped, cut_short, restarted):
      dropped    notes that never got a voice,  cut_short  notes that sounded for less than their full length,
      restarted  extra strikes of melody/bass notes that came back after being displaced."""
    bounds = sorted({n.start for n in notes} | {n.end for n in notes})
    dead = set()                                   # middle notes that lost their voice and stay silent
    runs = {}                                      # note -> list of [start, end] stretches it sounds
    previous = set()
    for a, b in zip(bounds, bounds[1:]):
        sounding = [n for n in notes if n.start <= a and n.end >= b]
        if len(sounding) <= max_voices:
            selected = sounding
            protected = []
        else:
            by_pitch = sorted(sounding, key=lambda n: n.pitch)
            protected = [by_pitch[-1]]                                   # the melody
            if max_voices > 1:
                protected.append(by_pitch[0])                            # the bass
            middle = [n for n in sounding if n not in protected and n not in dead]
            # free voices: notes already sounding first, then the longest still to sound, then higher pitch
            middle.sort(key=lambda n: (0 if n in previous else 1, -(n.end - a), -n.pitch))
            selected = protected + middle[:max_voices - len(protected)]
        for n in sounding:
            if n not in selected and n not in protected:
                dead.add(n)                                              # a middle note that is cut does not return
        for n in selected:
            if n in protected:
                dead.discard(n)
            stretch = runs.setdefault(n, [])
            if stretch and stretch[-1][1] == a:
                stretch[-1][1] = b                                       # still sounding: extend
            else:
                stretch.append([a, b])                                   # a fresh strike
        previous = set(selected)
    out, dropped, cut, restarted = [], 0, 0, 0
    for n in notes:
        stretches = runs.get(n, [])
        if not stretches:
            dropped += 1
            continue
        restarted += len(stretches) - 1
        if sum(e - s_ for s_, e in stretches) < n.end - n.start:
            cut += 1
        out.extend(Note(n.pitch, s_, e) for s_, e in stretches)
    return out, dropped, cut, restarted


def prepare(data, max_voices=3, keep_percussion=False, truncate=False):
    """Returns (output_bytes, report). Raises ValueError with a plain-language message if it cannot be done."""
    if not 1 <= max_voices <= pm.MAX_VOICES:
        raise ValueError("--max-voices must be 1 to %d" % pm.MAX_VOICES)
    raw, ppq, tempos = pm.read_notes(data)
    if ppq > 32767:
        raise ValueError("ticks per quarter note out of range")
    rep = {"input_notes": len(raw), "tracks": len({n[3] for n in raw}), "channels": len({n[4] for n in raw})}
    rep["percussion_dropped"] = 0 if keep_percussion else sum(1 for n in raw if n[4] == 9)
    notes = [Note(p, s, e) for p, s, e, _, ch in raw if keep_percussion or ch != 9]
    rep["zero_length_dropped"] = sum(1 for n in notes if n.end <= n.start)
    notes = [n for n in notes if n.end > n.start]
    if not notes:
        raise ValueError("the file contains no playable notes")

    notes, rep["same_pitch_merged"] = _merge_same_pitch(notes)

    # whole-piece octave placement: fewest notes out of range, then the smallest move
    shift = min(range(-6, 7), key=lambda k: (sum(1 for n in notes if not pm.NOTE_MIN <= n.pitch + 12 * k <= pm.NOTE_MAX), abs(k)))
    folded = 0
    for n in notes:
        n.pitch += 12 * shift
        while n.pitch < pm.NOTE_MIN:
            n.pitch += 12
            folded += 1
        while n.pitch > pm.NOTE_MAX:
            n.pitch -= 12
            folded += 1
    rep["octave_shift"], rep["notes_folded"] = shift, folded
    notes, merged2 = _merge_same_pitch(notes)                          # folding can make two notes share a pitch
    rep["same_pitch_merged"] += merged2

    rep["peak_before"] = peak_polyphony(notes)
    notes, rep["notes_dropped"], rep["notes_cut_short"], rep["notes_restarted"] = reduce_voices(notes, max_voices)
    notes = sorted((n for n in notes if n.end > n.start), key=lambda n: (n.start, n.pitch))
    rep["peak_after"] = peak_polyphony(notes)
    assert rep["peak_after"] <= max_voices

    if len(notes) > pm.MAX_NOTES:
        if not truncate:
            raise ValueError("%d notes is more than the player's %d; split the score, or use --truncate to keep the first %d"
                             % (len(notes), pm.MAX_NOTES, pm.MAX_NOTES))
        rep["notes_truncated"] = len(notes) - pm.MAX_NOTES
        notes = notes[:pm.MAX_NOTES]
    else:
        rep["notes_truncated"] = 0

    last_tick = max(n.end for n in notes)
    first_tempo = next((us for t, us in tempos if t == 0), 500000)
    extra = [(t, b"\xFF\x51\x03" + us.to_bytes(3, "big")) for t, us in tempos if 0 < t <= last_tick]
    out = pm.build_midi([(n.pitch, n.start, n.end) for n in notes], ppq=ppq, tempo_us=first_tempo, extra_events=extra)
    if len(out) > 16384:
        raise ValueError("the result is %d bytes, over the player's 16384-byte limit; shorten the score" % len(out))
    status, parsed = pm.reference_parse(out)
    if status != "OK":
        raise ValueError("internal check failed: the firmware rules say " + status)
    rep["output_notes"], rep["output_bytes"] = len(notes), len(out)
    return out, rep


def format_report(rep):
    lines = ["read {input_notes} notes from {tracks} track(s) / {channels} channel(s)".format(**rep)]
    for key, text in (("percussion_dropped", "percussion notes dropped"), ("zero_length_dropped", "zero-length notes dropped"),
                      ("same_pitch_merged", "overlapping same-pitch notes merged"),
                      ("notes_folded", "notes folded by an octave into range"), ("notes_dropped", "notes dropped to fit the voices"),
                      ("notes_cut_short", "notes cut short to fit the voices"),
                      ("notes_restarted", "melody/bass notes struck again after being displaced"),
                      ("notes_truncated", "notes cut off at the 1024-note limit")):
        if rep.get(key):
            lines.append("  {} {}".format(rep[key], text))
    if rep["octave_shift"]:
        lines.append("  whole piece moved {:+d} octave(s)".format(rep["octave_shift"]))
    lines.append("most notes at once: {} before, {} after".format(rep["peak_before"], rep["peak_after"]))
    lines.append("wrote {output_notes} notes, {output_bytes} bytes; the firmware rules accept it".format(**rep))
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--max-voices", type=int, default=3)
    ap.add_argument("--keep-percussion", action="store_true")
    ap.add_argument("--truncate", action="store_true", help="cut the score at 1024 notes instead of refusing")
    args = ap.parse_args(argv)
    try:
        out, rep = prepare(args.input.read_bytes(), args.max_voices, args.keep_percussion, args.truncate)
    except (ValueError, OSError, IndexError) as exc:
        print("cannot prepare {}: {}".format(args.input.name, exc), file=sys.stderr)
        return 1
    args.output.write_bytes(out)
    print(format_report(rep))
    return 0


if __name__ == "__main__":
    sys.exit(main())
