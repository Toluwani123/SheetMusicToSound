"""Play one MIDI file once in every instrument voice, one after the other.

    python play_instrument_samples.py                                # twinkle_simple.mid, all voices, COM5
    python play_instrument_samples.py reference_midi\\ode_to_joy_msp.mid --port COM5
    python play_instrument_samples.py --instruments trumpet marimba  # only some voices

For each voice this runs newmiditst.py exactly as you would by hand:
    python newmiditst.py FILE --instrument NAME --wait-playback --port PORT
so every run waits for the board's DONE before the next voice starts. Stops at the first failure.
Needs firmware with the instrument command (SMID v2, opcode 2) and pyserial.
"""

import argparse
import sys
import time
from pathlib import Path

import newmiditst

HERE = Path(__file__).resolve().parent


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("midi_file", nargs="?", type=Path, default=HERE / "reference_midi" / "twinkle_simple.mid")
    parser.add_argument("--port", default="COM5")
    parser.add_argument("--instruments", nargs="+", choices=sorted(newmiditst.INSTRUMENTS),
                        default=list(newmiditst.INSTRUMENTS))
    parser.add_argument("--pause", type=float, default=1.5, help="seconds of silence between voices (default 1.5)")
    args = parser.parse_args(argv)
    if not args.midi_file.exists():
        print("MIDI file not found:", args.midi_file, file=sys.stderr)
        return 2

    results = []
    for i, name in enumerate(args.instruments):
        print("\n=== {} ({}/{}): {} ===".format(name.upper(), i + 1, len(args.instruments), args.midi_file.name))
        code = newmiditst.main([str(args.midi_file), "--instrument", name, "--wait-playback", "--port", args.port])
        results.append((name, code))
        if code != 0:
            print("\nStopped: {} did not complete (exit code {}).".format(name, code), file=sys.stderr)
            break
        if i + 1 < len(args.instruments):
            time.sleep(args.pause)

    print("\nSummary")
    for name, code in results:
        print("  {:9s} {}".format(name, "OK" if code == 0 else "FAILED (exit {})".format(code)))
    return 0 if results and all(c == 0 for _, c in results) and len(results) == len(args.instruments) else 1


if __name__ == "__main__":
    sys.exit(main())
