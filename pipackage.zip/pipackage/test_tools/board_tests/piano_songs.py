"""Homophonic piano test songs: a melody (right hand) with simple left-hand accompaniment, as MIDI for the board.

    python piano_songs.py            # (re)write piano_midi/*.mid and manifest.txt
    python piano_songs.py --list     # print the song list

Ten well-known public-domain tunes. Every song comes as a SOLO (melody alone, one voice) and with one or more
accompaniment styles. The board plays at most 3 notes at once, so the left hand is one or two notes:
    solo     the melody alone                                   (1 note at a time)
    bass     melody + one bass note per chord                   (2 at a time)
    block    melody + a two-note chord held                     (3 at a time)
    oompah   melody + bass, chord, bass, chord ... (3/4: bass, chord, chord)   (alternates 2 and 3)
    ground   (Canon) melody + the famous 8-note bass            (2 at a time)
    ground3  (Canon) melody + the bass + an inner chord note    (3 at a time)
    under    (Fur Elise) melody + a two-note chord under its long notes   (alternates 1 and 3)

The melodies are written out here from the well-known tunes; they are NOT copied from any score. Twinkle is checked
note for note against reference_midi/twinkle_simple.mid and Ode to Joy (D major, the key and tempo of
reference_midi/ode_to_joy_msp.mid) against its first 44 notes by check_piano_songs.py. If a tune sounds wrong to
your ear, tell me the song and the bar.

Notation below: "C5:2" = note C in octave 5 (middle C is C4 = MIDI 60) for 2 beats; "R:1" a rest; a beat is a quarter note.
Chords: "C:4 G:2" = C major for 4 beats then G major for 2. Left-hand notes always stay below the melody.
"""

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import poly_midi as pm                                      # noqa: E402

OUT = HERE / "piano_midi"
PPQ = 480
NOTE_PC = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def midi_number(name):
    pc = NOTE_PC[name[0]]
    i = 1
    while name[i] in "#b":
        pc += 1 if name[i] == "#" else -1
        i += 1
    return 12 * (int(name[i:]) + 1) + pc


def parse_melody(text):
    """-> list of (pitch or None, start_beat, beats)"""
    out, t = [], 0.0
    for tok in text.split():
        name, _, d = tok.partition(":")
        beats = float(d) if d else 1.0
        out.append((None if name == "R" else midi_number(name), t, beats))
        t += beats
    return out


def parse_chords(text):
    out, t = [], 0.0
    for tok in text.split():
        name, _, d = tok.partition(":")
        out.append((name, t, float(d)))
        t += float(d)
    return out


def chord_parts(name):
    """-> (root pitch class, is_minor)"""
    minor = name.endswith("m")
    root = name[:-1] if minor else name
    return NOTE_PC[root[0]] + (1 if root.endswith("#") else 0), minor


def lowest_at_or_above(pc, floor):
    p = floor + (pc - floor) % 12
    return p


def left_hand_pitches(chord):
    """bass root (C3..B3 area), third and fifth above it."""
    pc, minor = chord_parts(chord)
    bass = lowest_at_or_above(pc, 48)
    return bass, bass + (3 if minor else 4), bass + 7


SONGS = [
    dict(key="twinkle", title="Twinkle, Twinkle, Little Star", bpm=100, meter="4/4",
         melody="C5 C5 G5 G5 A5 A5 G5:2 F5 F5 E5 E5 D5 D5 C5:2 G5 G5 F5 F5 E5 E5 D5:2 G5 G5 F5 F5 E5 E5 D5:2 "
                "C5 C5 G5 G5 A5 A5 G5:2 F5 F5 E5 E5 D5 D5 C5:2",
         chords="C:4 F:2 C:2 F:2 C:2 G:2 C:2 C:2 F:2 C:2 G:2 C:2 F:2 C:2 G:2 C:4 F:2 C:2 F:2 C:2 G:2 C:2",
         variants=["solo", "bass", "block", "oompah"], pattern="BD", unit=1.0,
         listen="C major, the tune everyone knows (12 bars). With the left hand you hear the harmony change under 'A A' (F chord) and 'D D' (G chord)."),
    dict(key="ode", title="Ode to Joy (Beethoven), in D major", bpm=144, meter="4/4",
         melody="F#5 F#5 G5 A5 A5 G5 F#5 E5 D5 D5 E5 F#5 F#5:1.5 E5:.5 E5:2 "
                "F#5 F#5 G5 A5 A5 G5 F#5 E5 D5 D5 E5 F#5 E5:1.5 D5:.5 D5:2 "
                "E5 E5 F#5 D5 E5 F#5:.5 G5:.5 F#5 D5 E5 F#5:.5 G5:.5 F#5 E5 D5 E5 A4:2 "
                "F#5 F#5 G5 A5 A5 G5 F#5 E5 D5 D5 E5 F#5 E5:1.5 D5:.5 D5:2",
         chords="D:4 A:4 D:4 D:2 A:2 D:4 A:4 D:4 A:2 D:2 A:2 D:2 A:2 D:2 A:4 D:1 A:3 D:4 A:4 D:4 A:2 D:2",
         variants=["solo", "bass", "block", "oompah"], pattern="BD", unit=1.0,
         listen="The same key and tempo as ode_to_joy_msp.mid: four lines, then the bridge ('E E F# D'), then the first line again."),
    dict(key="mary", title="Mary Had a Little Lamb", bpm=120, meter="4/4",
         melody="E5 D5 C5 D5 E5 E5 E5:2 D5 D5 D5:2 E5 G5 G5:2 E5 D5 C5 D5 E5 E5 E5 E5 D5 D5 E5 D5 C5:4",
         chords="C:4 C:4 G:4 C:4 C:4 C:4 G:4 C:4",
         variants=["solo", "block"], pattern="BD", unit=1.0,
         listen="Eight bars in C; ends low and settled on C."),
    dict(key="jingle", title="Jingle Bells (chorus)", bpm=120, meter="4/4",
         melody="E5 E5 E5:2 E5 E5 E5:2 E5 G5 C5:1.5 D5:.5 E5:4 F5 F5 F5:1.5 F5:.5 F5 E5 E5 E5:.5 E5:.5 E5 D5 D5 E5 D5:2 G5:2 "
                "E5 E5 E5:2 E5 E5 E5:2 E5 G5 C5:1.5 D5:.5 E5:4 F5 F5 F5:1.5 F5:.5 F5 E5 E5 E5:.5 E5:.5 G5 G5 F5 D5 C5:4",
         chords="C:4 C:4 C:4 C:4 F:4 F:2 C:2 C:2 G:2 G:4 C:4 C:4 C:4 C:4 F:4 F:2 C:2 C:2 G:2 C:4",
         variants=["solo", "oompah"], pattern="BD", unit=1.0,
         listen="'Jingle bells, jingle bells, jingle all the way ...' twice; the second time ends on 'G G F D C'."),
    dict(key="frere", title="Frere Jacques (Are You Sleeping?)", bpm=112, meter="4/4",
         melody="C5 D5 E5 C5 C5 D5 E5 C5 E5 F5 G5:2 E5 F5 G5:2 G5:.5 A5:.5 G5:.5 F5:.5 E5 C5 G5:.5 A5:.5 G5:.5 F5:.5 E5 C5 "
                "C5 G4 C5:2 C5 G4 C5:2",
         chords="C:4 C:4 C:4 C:4 G:2 C:2 G:2 C:2 C:4 C:4",
         variants=["solo", "bass"], pattern="BD", unit=1.0,
         listen="The round tune, each line twice. Bass-only accompaniment: melody and one low note, two voices."),
    dict(key="clair", title="Au clair de la lune", bpm=96, meter="4/4",
         melody="C5 C5 C5 D5 E5:2 D5:2 C5 E5 D5 D5 C5:4 C5 C5 C5 D5 E5:2 D5:2 C5 E5 D5 D5 C5:4",
         chords="C:4 C:2 G:2 C:2 G:2 C:4 C:4 C:2 G:2 C:2 G:2 C:4",
         variants=["solo", "block"], pattern="BD", unit=1.0,
         listen="A slow French lullaby, the first two lines played twice."),
    dict(key="row", title="Row, Row, Row Your Boat", bpm=120, meter="6/8",
         melody="C5:1.5 C5:1.5 C5:1 D5:.5 E5:1.5 E5:1 D5:.5 E5:1 F5:.5 G5:3 "
                "C6:.5 C6:.5 C6:.5 G5:.5 G5:.5 G5:.5 E5:.5 E5:.5 E5:.5 C5:.5 C5:.5 C5:.5 G5:1 F5:.5 E5:1 D5:.5 C5:3",
         chords="C:3 C:3 C:1.5 G:1.5 C:3 C:3 C:3 G:3 C:3",
         variants=["solo", "oompah"], pattern="BD", unit=1.5,
         listen="6/8 swing: 'Row row row your boat ... Merrily merrily merrily merrily'. The top note C6 is the highest the board can play."),
    dict(key="birthday", title="Happy Birthday to You", bpm=100, meter="3/4",
         melody="G4:.5 G4:.5 A4 G4 C5 B4:2 G4:.5 G4:.5 A4 G4 D5 C5:2 G4:.5 G4:.5 G5 E5 C5 B4 A4 F5:.5 F5:.5 E5 C5 D5 C5:3",
         chords="C:1 C:3 G:3 G:3 C:3 C:3 G:2 F:1 C:2 G:1 C:3",
         variants=["solo", "oompah"], pattern="BDD", unit=1.0,
         listen="Three-four time with a short pick-up; waltz accompaniment (bass, chord, chord)."),
    dict(key="canon", title="Canon in D (Pachelbel)", bpm=88, meter="4/4",
         melody="F#5:2 E5:2 D5:2 C#5:2 B4:2 A4:2 B4:2 C#5:2 D5:2 C#5:2 B4:2 A4:2 G4:2 F#4:2 G4:2 A4:2",
         chords="D:2 A:2 Bm:2 F#m:2 G:2 D:2 G:2 A:2 D:2 A:2 Bm:2 F#m:2 G:2 D:2 G:2 A:2",
         variants=["solo", "ground", "ground3"], pattern="BD", unit=1.0,
         ground_bass=[62, 57, 59, 54, 55, 50, 55, 57], ground_inner=[54, 61, 62, 57, 59, 54, 59, 61],
         listen="The famous descending line over the eight-note bass (D A B F# G D G A); the second pass starts an octave lower."),
    dict(key="elise", title="Fur Elise (opening, Beethoven)", bpm=84, meter="3/8",
         melody="E5:.25 D#5:.25 E5:.25 D#5:.25 E5:.25 B4:.25 D5:.25 C5:.25 A4:.5 R:.25 C4:.25 E4:.25 A4:.25 B4:.5 R:.25 "
                "E4:.25 G#4:.25 B4:.25 C5:.5 R:.25 "
                "E5:.25 D#5:.25 E5:.25 D#5:.25 E5:.25 B4:.25 D5:.25 C5:.25 A4:.5 R:.25 C4:.25 E4:.25 A4:.25 B4:.5 R:.25 "
                "E4:.25 C5:.25 B4:.25 A4:1.5",
         chords=None, variants=["solo", "under"], pattern="BD", unit=1.0,
         under={69: (52, 57), 71: (56, 59), 72: (52, 57)},          # A4 -> A minor, B4 -> E major, C5 -> A minor
         listen="The famous opening, played through twice. With 'under', the long notes (A, B, C) get a left-hand chord and the fast runs stay alone."),
]

VARIANT_TEXT = {
    "solo": "melody alone (1 voice)", "bass": "melody + bass note (2 voices)", "block": "melody + two-note chord (3 voices)",
    "oompah": "melody + alternating bass / chord (2-3 voices)", "ground": "melody + the ground bass (2 voices)",
    "ground3": "melody + ground bass + inner note (3 voices)", "under": "melody + chord under the long notes (1-3 voices)",
}


def ticks(beats):
    return int(round(beats * PPQ))


def gap_for(beats):
    return 40 if beats >= 1 else 25 if beats >= 0.5 else 15


def melody_notes(song):
    out = []
    for pitch, start, beats in parse_melody(song["melody"]):
        if pitch is not None:
            out.append((pitch, ticks(start), ticks(start + beats) - gap_for(beats)))
    return out


def accompaniment_notes(song, style):
    notes = []
    if style == "under":
        for pitch, start, beats in parse_melody(song["melody"]):
            if pitch in song["under"] and beats >= 0.5:
                for lh in song["under"][pitch]:
                    notes.append((lh, ticks(start), ticks(start + beats) - 30))
        return notes
    chords = parse_chords(song["chords"])
    if style in ("ground", "ground3"):
        for i, (name, start, beats) in enumerate(chords):
            k = i % 8
            notes.append((song["ground_bass"][k], ticks(start), ticks(start + beats) - 30))
            if style == "ground3":
                notes.append((song["ground_inner"][k], ticks(start), ticks(start + beats) - 30))
        return notes
    unit = song.get("unit", 1.0)
    for name, start, beats in chords:
        bass, third, fifth = left_hand_pitches(name)
        end = start + beats
        if style == "bass":
            notes.append((bass, ticks(start), ticks(end) - 30))
        elif style == "block":
            notes += [(bass, ticks(start), ticks(end) - 30), (third, ticks(start), ticks(end) - 30)]
        elif style == "oompah":
            pattern, t, i = song["pattern"], start, 0
            while t < end - 1e-9:
                slot_end = min(t + unit, end)
                ch = pattern[i % len(pattern)]
                if ch == "B":
                    notes.append((bass, ticks(t), ticks(slot_end) - 25))
                elif ch == "D":
                    notes += [(third, ticks(t), ticks(slot_end) - 25), (fifth, ticks(t), ticks(slot_end) - 25)]
                t, i = slot_end, i + 1
        else:
            raise ValueError(style)
    return notes


def total_beats(song):
    return sum(b for _, _, b in parse_melody(song["melody"]))


def build():
    """-> list of dict(name, song key, variant, notes, seconds, listen, title)"""
    entries = []
    for n, song in enumerate(SONGS, 1):
        mel_beats = total_beats(song)
        if song.get("chords"):
            chord_beats = sum(b for _, _, b in parse_chords(song["chords"]))
            assert abs(chord_beats - mel_beats) < 1e-9, "{}: chords cover {} beats but the melody has {}".format(song["key"], chord_beats, mel_beats)
        melody = melody_notes(song)
        for variant in song["variants"]:
            notes = melody + (accompaniment_notes(song, variant) if variant != "solo" else [])
            entries.append(dict(name="piano_{:02d}_{}_{}".format(n, song["key"], variant), key=song["key"], variant=variant,
                                notes=notes, seconds=mel_beats * 60.0 / song["bpm"], title=song["title"],
                                tempo_us=int(round(60e6 / song["bpm"])), listen=song["listen"]))
    return entries


def write_all():
    OUT.mkdir(exist_ok=True)
    for old in OUT.glob("*.mid"):
        old.unlink()
    rows = []
    for e in build():
        data = pm.build_midi(e["notes"], ppq=PPQ, tempo_us=e["tempo_us"])
        status, parsed = pm.reference_parse(data)
        assert status == "OK", "{}: the firmware rules say {}".format(e["name"], status)
        (OUT / (e["name"] + ".mid")).write_bytes(data)
        peak = max(sum(1 for _, s2, d2 in parsed if s2 <= s < s2 + d2) for _, s, _ in parsed)
        rows.append((e["name"], e["title"], VARIANT_TEXT[e["variant"]], peak, len(parsed), round(e["seconds"]), len(data), e["listen"]))
    lines = ["# piano test songs (generated by piano_songs.py; do not edit)",
             "# file | song | what it is | most notes at once | notes | seconds | bytes | what you should hear"]
    lines += [" | ".join(str(x) for x in r) for r in rows]
    (OUT / "manifest.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return rows


if __name__ == "__main__":
    if "--list" in sys.argv:
        for s in SONGS:
            print("{:9s} {:34s} {} bpm {}  variants: {}".format(s["key"], s["title"], s["bpm"], s["meter"], ", ".join(s["variants"])))
    else:
        rows = write_all()
        for r in rows:
            print("{:28s} {:34s} {:26s} max {} at once, {:3d} notes, {:3d} s".format(r[0], r[1][:34], r[2][:26], r[3], r[4], r[5]))
        print("wrote", OUT, "({} files)".format(len(rows)))
