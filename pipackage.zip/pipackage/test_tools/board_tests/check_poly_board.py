"""Polyphony test run for the real board: sends every file in poly_midi/ and checks the board's replies.

    python check_poly_board.py --port COM5                      # the whole list, sine voice
    python check_poly_board.py --port COM5 --instrument marimba # same, with another instrument preset
    python check_poly_board.py --port COM5 --only p02 p03       # just some files (prefix match)
    python check_poly_board.py --port COM5 --ask                # after each file, type y/n for "did it sound right"
    python check_poly_board.py --selftest                       # no board: test THIS script against a simulated board

For each file it checks the exact reply sequence:
    playable files:  ACK_READY, ACK_RECEIVED, ACK_VALID, PLAYING, DONE (then IDLE)
    refused files:   ACK_READY, ACK_RECEIVED, ERR_VOICES (or ERR_MIDI), IDLE
and prints what you should HEAR (LISTEN:). The script cannot hear: the sound is your part of each test.
The list and the expectations come from generate_poly_tests.py. Exit code 0 = every reply sequence was right.
"""

import argparse
import sys
import time
import zlib
from pathlib import Path

import newmiditst as nm
import generate_poly_tests as gen

HERE = Path(__file__).resolve().parent
TIMEOUT_SLACK = 12.0


def read_lines_until(reader, stop, timeout, log):
    """Read lines (recording them) until stop(line) is true; raises ResponseTimeout."""
    deadline = time.monotonic() + timeout
    while True:
        line = reader.read_line(deadline)
        print("   MSP:", line)
        log.append(line)
        if stop(line):
            return line


def run_one(port, reader, payload, expected, seconds):
    """Send one file. Returns (passed, lines_after_ACK_RECEIVED_or_all, text)."""
    crc = zlib.crc32(payload) & 0xFFFFFFFF
    log = []
    try:
        nm.write_all(port, nm.make_header(payload)[0])
        ready = read_lines_until(reader, lambda l: l.startswith("ACK_READY") or l.startswith("ERR_"), nm.ACK_TIMEOUT, log)
        if ready.startswith("ERR_"):
            return False, log, "board refused the header: " + ready
        nm.verify_transfer_ack(ready, "ACK_READY", len(payload), crc)
        nm.write_all(port, payload)
        received = read_lines_until(reader, lambda l: l.startswith("ACK_RECEIVED") or l.startswith("ERR_"), nm.ACK_TIMEOUT, log)
        if received.startswith("ERR_"):
            return False, log, "transfer failed: " + received
        nm.verify_transfer_ack(received, "ACK_RECEIVED", len(payload), crc)
        verdict = read_lines_until(reader, lambda l: l == "ACK_VALID" or l.startswith("ERR_"), nm.ACK_TIMEOUT, log)
        if expected == "OK":
            if verdict != "ACK_VALID":
                return False, log, "expected the song to be accepted but the board said " + verdict
            read_lines_until(reader, lambda l: l == "PLAYING", nm.ACK_TIMEOUT, log)
            read_lines_until(reader, lambda l: l == "DONE", seconds + TIMEOUT_SLACK, log)
            try:
                read_lines_until(reader, lambda l: l == "IDLE", 1.0, log)
            except nm.ResponseTimeout:
                pass                                         # DONE is only followed by IDLE when the receiver is idle
            return True, log, "accepted, played, DONE"
        if verdict != expected:
            return False, log, "expected {} but the board said {}".format(expected, verdict)
        read_lines_until(reader, lambda l: l == "IDLE", 3.0, log)
        return True, log, "refused with {} as intended, then IDLE".format(expected)
    except nm.TransferError as exc:
        return False, log, "problem: " + str(exc)


def run_suite(port, only=None, instrument=None, ask=False, sync_seconds=nm.STARTUP_QUIET_SECONDS):
    gen.write_all()                                          # make sure the files match the list
    entries = gen.build()
    if only:
        entries = [e for e in entries if any(e[0].startswith(p) for p in only)]
    if not entries:
        print("no test file matches", only)
        return 2
    reader = nm.LineReader(port)
    if sync_seconds:
        print("Synchronizing with receiver ({:.1f} s)...".format(sync_seconds))
        port.reset_input_buffer()
        end = time.monotonic() + sync_seconds
        while time.monotonic() < end:
            port.timeout = min(0.05, max(0.001, end - time.monotonic()))
            port.read(256)
        port.reset_input_buffer()
    if instrument is not None:
        try:
            nm.set_instrument(port, reader, instrument)
        except nm.TransferError as exc:
            print("could not select the instrument:", exc)
            return 2
    results = []
    for name, notes, expected, seconds, listen in entries:
        print("\n=== {}  (expect {})".format(name, expected))
        print("   LISTEN:", listen)
        payload = (gen.OUT / (name + ".mid")).read_bytes()
        passed, lines, text = run_one(port, reader, payload, expected, seconds)
        print("   {}  {}".format("PASS" if passed else "FAIL", text))
        heard = ""
        if ask and passed and expected == "OK":
            heard = input("   Did it sound right? [y/n/skip] ").strip().lower() or "skip"
        elif ask and passed:
            heard = input("   Confirm that NOTHING played [y/n] ").strip().lower() or "skip"
        results.append((name, passed, text, heard))
        if not passed:
            nm.wait_for_recovery(port, reader)
    print("\n==== summary ====")
    bad = 0
    for name, passed, text, heard in results:
        extra = ("   heard: " + heard) if heard else ""
        print("{:32s} {}{}".format(name, "PASS" if passed else "FAIL", extra))
        bad += (not passed) or heard == "n"
    print("\n{} of {} files behaved correctly on the wire{}".format(
        sum(1 for r in results if r[1]), len(results), "; listening answers: " + ", ".join("{}={}".format(r[0][:3], r[3]) for r in results if r[3]) if ask else ""))
    return 1 if bad else 0


# ------------------------------------------------------------------------ simulated board -------------------

class FakeBoard:
    """Stands in for the serial port in --selftest: answers like the polyphonic firmware, using the firmware-rules oracle."""

    def __init__(self):
        import struct
        self.struct = struct
        self.out = bytearray()
        self.inbuf = bytearray()
        self.timeout = 0.05
        self.write_timeout = 5
        self.expect = None
        self.instrument = 0

    def say(self, text):
        self.out += text.encode()

    def read(self, n=1):
        if not self.out:
            time.sleep(min(self.timeout or 0, 0.005))
            return b""
        data = bytes(self.out[:n])
        del self.out[:n]
        return data

    @property
    def in_waiting(self):
        return len(self.out)

    def reset_input_buffer(self):
        self.out.clear()

    def reset_output_buffer(self):
        pass

    def write(self, data):
        import poly_midi as pm
        self.inbuf += data
        while True:
            if self.expect is not None:
                length, crc = self.expect
                if len(self.inbuf) < length:
                    return len(data)
                payload = bytes(self.inbuf[:length])
                del self.inbuf[:length]
                self.expect = None
                self.say("ACK_RECEIVED %d %08X\r\n" % (length, zlib.crc32(payload) & 0xFFFFFFFF))
                status, _ = pm.reference_parse(payload)
                if status == "OK":
                    self.say("ACK_VALID\r\nPLAYING\r\nDONE\r\nIDLE\r\n")
                else:
                    self.say({"TOO_MANY_VOICES": "ERR_VOICES", "NOTE_CAPACITY": "ERR_NOTE_CAPACITY"}.get(status, "ERR_MIDI") + "\r\nIDLE\r\n")
                continue
            if len(self.inbuf) < 16:
                return len(data)
            _, _, cmd, arg, _, length, crc = self.struct.unpack("<4sBBBBII", bytes(self.inbuf[:16]))
            del self.inbuf[:16]
            if cmd == 0:
                self.say("ACK_READY %d %08X\r\n" % (length, crc))
                self.expect = (length, crc)
            elif cmd == 1:
                self.say("ACK_STOPPED\r\nIDLE\r\n")
            elif cmd == 2:
                self.instrument = arg
                self.say("ACK_INSTRUMENT %d\r\nIDLE\r\n" % arg)


def selftest():
    failures = 0
    board = FakeBoard()
    code = run_suite(board, instrument=3, sync_seconds=0)
    print("\nself-test: suite against a correct simulated board -> exit code", code)
    failures += code != 0
    # a board that wrongly accepts the 4-note chord must make the suite fail
    class LaxBoard(FakeBoard):
        def write(self, data):
            r = super().write(data)
            if b"ERR_VOICES" in self.out:
                self.out[:] = self.out.replace(b"ERR_VOICES\r\nIDLE\r\n", b"ACK_VALID\r\nPLAYING\r\nDONE\r\nIDLE\r\n")
            return r
    code = run_suite(LaxBoard(), only=["p11"], sync_seconds=0)
    print("\nself-test: a board that plays a 4-note chord -> exit code", code, "(must be non-zero)")
    failures += code == 0
    print("\nself-test {}".format("FAILED" if failures else "passed"))
    return 1 if failures else 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--port", default="COM5")
    ap.add_argument("--instrument", choices=sorted(nm.INSTRUMENTS), help="select this instrument preset first")
    ap.add_argument("--only", nargs="+", metavar="PREFIX", help="run only files whose name starts with one of these")
    ap.add_argument("--ask", action="store_true", help="ask after each file whether it sounded right")
    ap.add_argument("--selftest", action="store_true", help="test this script against a simulated board (no hardware)")
    args = ap.parse_args(argv)
    if args.selftest:
        return selftest()
    if nm.serial is None:
        print("Install pySerial first: python -m pip install pyserial", file=sys.stderr)
        return 2
    try:
        with nm.serial.Serial(args.port, nm.BAUD, bytesize=nm.serial.EIGHTBITS, parity=nm.serial.PARITY_NONE,
                              stopbits=nm.serial.STOPBITS_ONE, timeout=0.05, write_timeout=nm.WRITE_TIMEOUT) as port:
            return run_suite(port, args.only, nm.INSTRUMENTS[args.instrument] if args.instrument else None, args.ask)
    except (nm.serial.SerialException, OSError) as exc:
        print("Serial connection failed:", exc, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
