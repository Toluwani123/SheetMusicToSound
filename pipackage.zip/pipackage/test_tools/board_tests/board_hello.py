"""First check on the real board: talks to it, plays a note and a chord, and tells you where silence comes from.

    python board_hello.py --port COM5

It does NOT need the other test files and takes about 20 seconds. Steps, each with a plain verdict:
  1. does the board answer at all?            (STOP -> ACK_STOPPED, IDLE)
  2. does it accept and "play" one note?       (the replies PLAYING and DONE)  -> you say whether you HEARD it
  3. does it accept and play a 3-note chord?   -> you say whether you heard three notes
The script cannot hear. If the replies are right but you heard nothing, the software did its job and the problem
is in the audio path (amplifier, speaker, wiring, volume), and the script says what to try next.
Exit code 0 = replies were right and you heard everything.
"""

import argparse
import sys
import time
import zlib
from pathlib import Path

import newmiditst as nm
import generate_poly_tests as gen

NOTE = "p01_single_note"
CHORD = "p02_triad_held"


def play(port, reader, name, seconds):
    payload = (gen.OUT / (name + ".mid")).read_bytes()
    log = []

    def take(stop, timeout):
        deadline = time.monotonic() + timeout
        while True:
            line = reader.read_line(deadline)
            print("      board says:", line)
            log.append(line)
            if stop(line):
                return line

    crc = zlib.crc32(payload) & 0xFFFFFFFF
    nm.write_all(port, nm.make_header(payload)[0])
    take(lambda l: l.startswith("ACK_READY") or l.startswith("ERR_"), nm.ACK_TIMEOUT)
    if log[-1].startswith("ERR_"):
        return False, log
    nm.write_all(port, payload)
    take(lambda l: l == "ACK_VALID" or l.startswith("ERR_"), nm.ACK_TIMEOUT)
    if log[-1].startswith("ERR_"):
        return False, log
    take(lambda l: l == "PLAYING", nm.ACK_TIMEOUT)
    take(lambda l: l == "DONE", seconds + 10)
    return True, log


def run_hello(port, ask=input, sync_seconds=nm.STARTUP_QUIET_SECONDS, say=print):
    """Returns 0 when replies were right and everything was heard. `ask` and `say` are replaceable for the self-test."""
    gen.write_all()
    reader = nm.LineReader(port)
    if sync_seconds:
        say("Settling the link ({:.1f} s)...".format(sync_seconds))
        port.reset_input_buffer()
        end = time.monotonic() + sync_seconds
        while time.monotonic() < end:
            port.timeout = 0.05
            port.read(256)
        port.reset_input_buffer()

    say("\nSTEP 1: does the board answer?")
    try:
        nm.write_all(port, nm.make_stop_header())
        nm.wait_response(reader, "ACK_STOPPED")
        nm.wait_response(reader, "IDLE")
        say("   OK: the board answered STOP. The firmware is running and the link works.")
    except nm.TransferError as exc:
        say("   NO ANSWER ({}).".format(exc))
        say("   The board is not talking to this computer. Check, in this order:")
        say("     - the port: Device Manager > Ports > 'XDS110 Class Application/User UART (COMx)', then use --port COMx")
        say("     - nothing else has the port open (CCS serial terminal, another python window)")
        say("     - the board is running: press its RESET button, wait 3 s, run this again")
        say("     - a build was really flashed (CCS: Run/Debug finished without errors; then unplug and replug USB)")
        return 2

    problems = 0
    for step, (name, seconds, what) in enumerate(((NOTE, 1.5, "one note (C4)"), (CHORD, 2.5, "a C major chord (three notes together)")), 2):
        say("\nSTEP {}: play {}".format(step, what))
        say("   LISTEN to the speaker now...")
        ok, log = play(port, reader, name, seconds)
        if not ok:
            say("   The board REFUSED the file ({}). That is a software/protocol problem, not the speaker:".format(log[-1]))
            say("   send me this whole output.")
            nm.wait_for_recovery(port, reader)
            return 3
        say("   The board accepted it and reported DONE: the software side worked.")
        heard = ask("   Did you hear {}? [y/n] ".format(what)).strip().lower()
        if not heard.startswith("y"):
            problems += 1
            say("   Replies right but no sound: the firmware thinks it played, so look at the AUDIO PATH:")
            say("     - speaker volume / the BoosterPack's speaker and amplifier connections (the amplifier is switched on by PH2)")
            say("     - is the speaker/audio BoosterPack seated on the right headers?")
            say("     - flash the PREVIOUS milestone (folder uart_tx_queue_milestone) and play the same note. If that is silent too,")
            say("       it is hardware; if it plays and this one does not, send me this output.")
            if step == 3:
                say("     (if the single note was fine but the chord was not, say which: silent, one note only, or distorted)")
            break
    say("\n" + ("All good: replies correct and you heard the note and the chord." if not problems else "Stopped: see the advice above."))
    return 1 if problems else 0


def selftest():
    from check_poly_board import FakeBoard
    lines = []
    code = run_hello(FakeBoard(), ask=lambda p: "y", sync_seconds=0, say=lambda *a: lines.append(" ".join(map(str, a))))
    ok_a = code == 0
    lines.clear()
    code_b = run_hello(FakeBoard(), ask=lambda p: "n", sync_seconds=0, say=lambda *a: lines.append(" ".join(map(str, a))))
    ok_b = code_b == 1 and any("AUDIO PATH" in l for l in lines)

    class DeadBoard(FakeBoard):
        def write(self, data):
            return len(data)                                    # swallows everything, never answers

    lines.clear()
    code_c = run_hello(DeadBoard(), ask=lambda p: "y", sync_seconds=0, say=lambda *a: lines.append(" ".join(map(str, a))))
    ok_c = code_c == 2 and any("not talking" in l for l in lines)
    print("self-test: good board, everything heard      -> exit 0 :", "PASS" if ok_a else "FAIL")
    print("self-test: replies fine but nothing heard    -> advice : ", "PASS" if ok_b else "FAIL")
    print("self-test: board that never answers          -> advice : ", "PASS" if ok_c else "FAIL")
    return 0 if (ok_a and ok_b and ok_c) else 1


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--port", default="COM5")
    ap.add_argument("--selftest", action="store_true", help="test this script against a simulated board")
    args = ap.parse_args(argv)
    if args.selftest:
        return selftest()
    if nm.serial is None:
        print("Install pySerial first: python -m pip install pyserial", file=sys.stderr)
        return 2
    try:
        with nm.serial.Serial(args.port, nm.BAUD, bytesize=nm.serial.EIGHTBITS, parity=nm.serial.PARITY_NONE,
                              stopbits=nm.serial.STOPBITS_ONE, timeout=0.05, write_timeout=nm.WRITE_TIMEOUT) as port:
            return run_hello(port)
    except (nm.serial.SerialException, OSError) as exc:
        print("Cannot open {}: {}".format(args.port, exc), file=sys.stderr)
        print("Wrong port name, or another program (CCS terminal, another python window) is using it.", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
