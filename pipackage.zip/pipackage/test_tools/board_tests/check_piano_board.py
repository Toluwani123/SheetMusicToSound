"""Play the homophonic piano test songs on the real board (melody with left-hand accompaniment).

    python check_piano_board.py --list                          # the songs and variants
    python check_piano_board.py --port COM5                     # everything, sine voice (about 8 minutes)
    python check_piano_board.py --port COM5 --songs twinkle ode # some songs (name prefix)
    python check_piano_board.py --port COM5 --variants solo block --instrument clarinet --ask
    python check_piano_board.py --port COM5 --quick             # per song: the solo, then one accompanied version
    python check_piano_board.py --selftest                      # no board: test this script against a simulated board

For each file it checks the board's replies (ACK_READY, ACK_RECEIVED, ACK_VALID, PLAYING, DONE) and prints what you
should HEAR. The script cannot hear: with --ask it asks after each song whether you recognised the tune and whether the
accompaniment sounded right, and lists your answers at the end. Variants per song: solo (melody alone), bass (melody + 1 low
note), block (melody + 2-note chord), oompah (alternating bass/chord), ground / ground3 (Canon), under (Fur Elise).
Exit code 0 = every reply sequence was right and every answer you gave was yes.
"""

import argparse
import sys
import time
from pathlib import Path

import newmiditst as nm
import piano_songs as ps
from check_poly_board import FakeBoard, run_one

HERE = Path(__file__).resolve().parent


def select(entries, songs=None, variants=None, quick=False):
    out = [e for e in entries
           if (not songs or any(e["key"].startswith(s) for s in songs)) and (not variants or e["variant"] in variants)]
    if quick:
        keep, seen = [], set()
        for e in out:
            if e["variant"] == "solo":
                keep.append(e)
            elif e["key"] not in seen:
                keep.append(e)
                seen.add(e["key"])
        out = keep
    return out


def run_suite(port, songs=None, variants=None, instrument=0, ask=False, quick=False, sync_seconds=nm.STARTUP_QUIET_SECONDS, pause=1.0):
    ps.write_all()
    entries = select(ps.build(), songs, variants, quick)
    if not entries:
        print("no song matches", songs, variants)
        return 2
    reader = nm.LineReader(port)
    if sync_seconds:
        print("Settling the link ({:.1f} s)...".format(sync_seconds))
        port.reset_input_buffer()
        end = time.monotonic() + sync_seconds
        while time.monotonic() < end:
            port.timeout = 0.05
            port.read(256)
        port.reset_input_buffer()
    nm.set_instrument(port, reader, instrument)
    total = sum(e["seconds"] for e in entries)
    print("\n{} files, about {:.0f} minutes of music.".format(len(entries), total / 60))
    results = []
    for n, e in enumerate(entries, 1):
        print("\n=== [{}/{}] {}  --  {}  ({}; about {:.0f} s)".format(n, len(entries), e["title"], ps.VARIANT_TEXT[e["variant"]], e["name"], e["seconds"]))
        print("   LISTEN:", e["listen"])
        data = (ps.OUT / (e["name"] + ".mid")).read_bytes()
        passed, log, text = run_one(port, reader, data, "OK", e["seconds"])
        print("   {}  {}".format("PASS" if passed else "FAIL", text))
        heard = ""
        if ask and passed:
            heard = input("   Recognisable and clean? [y/n/skip, add a note after n if you like] ").strip().lower() or "skip"
        results.append((e["name"], passed, heard))
        if not passed:
            nm.wait_for_recovery(port, reader)
        time.sleep(pause)
    print("\n==== summary ====")
    bad = 0
    for name, passed, heard in results:
        print("{:30s} {}{}".format(name, "PASS" if passed else "FAIL", ("   heard: " + heard) if heard else ""))
        bad += (not passed) or heard.startswith("n")
    print("\n{} of {} files behaved correctly on the wire".format(sum(1 for r in results if r[1]), len(results)))
    if ask:
        flagged = [r[0] for r in results if r[2].startswith("n")]
        print("you flagged: {}".format(", ".join(flagged) if flagged else "nothing"))
    return 1 if bad else 0


def selftest():
    code = run_suite(FakeBoard(), instrument=1, sync_seconds=0, pause=0)
    print("\nself-test (whole list): exit code", code)
    code2 = run_suite(FakeBoard(), songs=["tw", "ode"], variants=["solo", "block"], sync_seconds=0, pause=0)
    code3 = run_suite(FakeBoard(), quick=True, sync_seconds=0, pause=0)
    answers = iter(["y", "n too fast", "y"])
    import builtins
    real = builtins.input
    builtins.input = lambda prompt="": next(answers, "y")
    try:
        code4 = run_suite(FakeBoard(), songs=["mary"], ask=True, sync_seconds=0, pause=0)
    finally:
        builtins.input = real
    ok = code == 0 and code2 == 0 and code3 == 0 and code4 == 1
    print("\nself-test {} (whole list {}, filtered {}, quick {}, a 'n' answer makes the exit code non-zero: {})".format(
        "passed" if ok else "FAILED", code == 0, code2 == 0, code3 == 0, code4 == 1))
    return 0 if ok else 1


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--port", default="COM5")
    ap.add_argument("--songs", nargs="+", metavar="NAME", help="song name prefixes, e.g. twinkle ode canon")
    ap.add_argument("--variants", nargs="+", choices=sorted(ps.VARIANT_TEXT), help="only these accompaniment styles")
    ap.add_argument("--instrument", choices=sorted(nm.INSTRUMENTS), default="sine", help="default: sine")
    ap.add_argument("--ask", action="store_true", help="ask after each song whether it sounded right")
    ap.add_argument("--quick", action="store_true", help="per song: the solo and one accompanied version")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args(argv)
    if args.list:
        for e in ps.build():
            print("{:30s} {:34s} {:46s} ~{:3.0f} s".format(e["name"], e["title"][:34], ps.VARIANT_TEXT[e["variant"]], e["seconds"]))
        return 0
    if args.selftest:
        return selftest()
    if nm.serial is None:
        print("Install pySerial first: python -m pip install pyserial", file=sys.stderr)
        return 2
    try:
        with nm.serial.Serial(args.port, nm.BAUD, bytesize=nm.serial.EIGHTBITS, parity=nm.serial.PARITY_NONE,
                              stopbits=nm.serial.STOPBITS_ONE, timeout=0.05, write_timeout=nm.WRITE_TIMEOUT) as port:
            return run_suite(port, args.songs, args.variants, nm.INSTRUMENTS[args.instrument], args.ask, args.quick)
    except (nm.serial.SerialException, OSError) as exc:
        print("Cannot open {}: {}".format(args.port, exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
