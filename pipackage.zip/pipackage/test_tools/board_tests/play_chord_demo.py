"""Hear the difference between chords: C major, F major and G major, in a low and a high register, on the real board.

    python play_chord_demo.py --port COM5                        # low then high register, SINE voice
    python play_chord_demo.py --port COM5 --instrument clarinet  # or trumpet, marimba
    python play_chord_demo.py --port COM5 --registers low mid high
    python play_chord_demo.py --port COM5 --registers high --repeat 2

For each register it plays two parts (about 18 seconds):
  1. THE PROGRESSION: C major, then F major, then G major, two seconds each, a short pause between.
  2. EACH CHORD TAKEN APART: its three notes one at a time (low to high), then all three together. This is how you
     check that the chord really has three different notes and that each chord sounds different.

The sine voice is selected first unless you choose another instrument, so you always know what you are hearing.
Registers (the board plays C3 to C6, so the highest G major has to be an inversion):
    low   C3 E3 G3   F3 A3 C4   G3 B3 D4
    mid   C4 E4 G4   F4 A4 C5   G4 B4 D5
    high  C5 E5 G5   F5 A5 C6   D5 G5 B5   (G major as D G B: root-position G B D would need a D6, above the board's range)
"""

import argparse
import sys
import time
from pathlib import Path

import newmiditst as nm
import generate_poly_tests as gen
import poly_midi as pm
from check_poly_board import run_one

Q = gen.Q                                           # 480 ticks = 500 ms
NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
FEEL = {"C major": "bright, settled", "F major": "also major, but 'opening up'", "G major": "bright and strong, wants to go home to C"}
VOICINGS = {
    "low":  [("C major", [48, 52, 55]), ("F major", [53, 57, 60]), ("G major", [55, 59, 62])],
    "mid":  [("C major", [60, 64, 67]), ("F major", [65, 69, 72]), ("G major", [67, 71, 74])],
    "high": [("C major", [72, 76, 79]), ("F major", [77, 81, 84]), ("G major", [74, 79, 83])],
}
OUT = gen.HERE / "poly_midi_demo"


def pitch_name(p):
    return "{}{}".format(NOTE_NAMES[p % 12], p // 12 - 1)


def progression(chords):
    notes, t = [], 0
    for _, pitches in chords:
        notes += [(p, t, t + 4 * Q) for p in pitches]
        t += 4 * Q + 150 * 480 // 500                # 2 s chord, 150 ms pause
    return notes


def taken_apart(chords):
    notes, t = [], 0
    for _, pitches in chords:
        for k, p in enumerate(pitches):               # one note at a time, low to high
            notes.append((p, t + k * Q // 2, t + k * Q // 2 + Q // 2 - 40))
        t += 3 * Q // 2 + 120 * 480 // 500             # then a short breath
        notes += [(p, t, t + 3 * Q) for p in pitches]  # then all three together, 1.5 s
        t += 3 * Q + 450 * 480 // 500                 # and a clear pause before the next chord
    return notes


def build_files(register):
    OUT.mkdir(exist_ok=True)
    chords = VOICINGS[register]
    for _, ps in chords:
        assert all(pm.NOTE_MIN <= p <= pm.NOTE_MAX for p in ps), "voicing outside the board's range"
    files = {}
    for name, notes, seconds in (("progression", progression(chords), 6.5), ("taken_apart", taken_apart(chords), 11.5)):
        data = pm.build_midi(notes, ppq=Q)
        status, _ = pm.reference_parse(data)
        assert status == "OK", "{} {}: the firmware rules say {}".format(register, name, status)
        (OUT / "demo_{}_{}.mid".format(register, name)).write_bytes(data)
        files[name] = (data, seconds)
    return files


def run_demo(port, registers, instrument, repeat=1, sync_seconds=nm.STARTUP_QUIET_SECONDS, pause=2.0):
    all_files = {r: build_files(r) for r in registers}
    reader = nm.LineReader(port)
    if sync_seconds:
        print("Settling the link ({:.1f} s)...".format(sync_seconds))
        port.reset_input_buffer()
        end = time.monotonic() + sync_seconds
        while time.monotonic() < end:
            port.timeout = 0.05
            port.read(256)
        port.reset_input_buffer()
    nm.set_instrument(port, reader, instrument)
    ok = True
    for register in registers:
        chords = VOICINGS[register]
        print("\n##################  {} REGISTER  ##################".format(register.upper()))
        for name, pitches in chords:
            print("   {:<8s} {:<14s} {}".format(name, "  ".join(pitch_name(p) for p in pitches), FEEL[name]))
        for r in range(repeat):
            print("\n=== PART 1 ({}): C major -> F major -> G major, about 6 seconds{}".format(
                register, "" if repeat == 1 else "   [{} of {}]".format(r + 1, repeat)))
            data, seconds = all_files[register]["progression"]
            passed, log, text = run_one(port, reader, data, "OK", seconds)
            print("   " + ("done" if passed else "PROBLEM: " + text))
            ok &= passed
            if not passed:
                break
            time.sleep(1.5)
        if not ok:
            break
        print("\n=== PART 2 ({}): each chord taken apart, about 11 seconds".format(register))
        print("   For each chord: its three notes one at a time (low to high), then all three together.")
        data, seconds = all_files[register]["taken_apart"]
        passed, log, text = run_one(port, reader, data, "OK", seconds)
        print("   " + ("done" if passed else "PROBLEM: " + text))
        ok &= passed
        if not ok:
            break
        time.sleep(pause)
    print("\n" + ("Finished. If any chord still sounded wrong, tell me the register, the chord and what you heard."
                  if ok else "Stopped because the board refused a file: send me this output."))
    return 0 if ok else 1


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--port", default="COM5")
    ap.add_argument("--instrument", choices=sorted(nm.INSTRUMENTS), default="sine", help="default: sine")
    ap.add_argument("--registers", nargs="+", choices=sorted(VOICINGS), default=["low", "high"],
                    help="which registers to play, in order (default: low high)")
    ap.add_argument("--repeat", type=int, default=1, help="play each progression this many times (default 1)")
    ap.add_argument("--selftest", action="store_true", help="check the files and the script against a simulated board")
    args = ap.parse_args(argv)
    if args.selftest:
        from check_poly_board import FakeBoard
        for register in VOICINGS:
            for name, (data, _) in build_files(register).items():
                status, notes = pm.reference_parse(data)
                peak = max(sum(1 for _, s2, d2 in notes if s2 <= s < s2 + d2) for _, s, _ in notes)
                print("{:<5s} {:<12s} firmware rules {}, {:2d} notes, at most {} at once".format(register, name, status, len(notes), peak))
        code = run_demo(FakeBoard(), ["low", "mid", "high"], nm.INSTRUMENTS["clarinet"], repeat=2, sync_seconds=0, pause=0)
        print("self-test", "passed" if code == 0 else "FAILED")
        return code
    if nm.serial is None:
        print("Install pySerial first: python -m pip install pyserial", file=sys.stderr)
        return 2
    try:
        with nm.serial.Serial(args.port, nm.BAUD, bytesize=nm.serial.EIGHTBITS, parity=nm.serial.PARITY_NONE,
                              stopbits=nm.serial.STOPBITS_ONE, timeout=0.05, write_timeout=nm.WRITE_TIMEOUT) as port:
            return run_demo(port, args.registers, nm.INSTRUMENTS[args.instrument], args.repeat)
    except (nm.serial.SerialException, OSError) as exc:
        print("Cannot open {}: {}".format(args.port, exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
