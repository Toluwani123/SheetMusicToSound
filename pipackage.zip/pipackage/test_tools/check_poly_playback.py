"""End-to-end host test: real MIDI bytes -> real parser (midi.c) -> real playback (playback.c) -> real audio (audio.c).

    python check_poly_playback.py

The three firmware files are compiled together on the PC (Visual Studio cl.exe) with stand-ins for the MSP432 driver
calls. The Timer3 interrupt is fired by the test exactly as the hardware would (after the wait the code armed), the
sample interrupt is run for the elapsed time, and after EVERY wake-up the test checks which notes are sounding:

  * for chords, overlaps, back-to-back chords, rests and the single-line reference songs: the set of pitches
    sounding after each wake-up equals what the MIDI file says should be sounding at that millisecond; the song
    ends at the last note's end; the completion hook fires exactly once; everything is silent afterwards;
  * STOP in the middle: silent at once, nothing restarts when a late timer interrupt arrives, no completion;
  * a gap longer than the hardware timer's 35.8 s limit is waited out in several shots (and the next note still
    starts at exactly the right time).

Exit code 0 = all passed. Needs Visual Studio 2022 C++ build tools (cl.exe).
"""

import subprocess
import sys
import tempfile
from pathlib import Path

import poly_midi as pm
import check_poly_audio as ca

HERE = Path(__file__).resolve().parent
SRC = HERE.parent / "projects" / "gpiointerrupt_freertos"
REF = HERE / "board_tests" / "reference_midi"

def build_driverlib():
    text = ca.DRIVERLIB_STUB
    text = text.replace("#define INT_TIMER2A 37",
                        "#define INT_TIMER2A 37\n#define SYSCTL_PERIPH_TIMER3 6\n#define TIMER3_BASE 0x3\n#define TIMER_CFG_ONE_SHOT 0x21\n#define INT_TIMER3A 38\n"
                        "static uint32_t stub_t3_load = 0; static int stub_t3_armed = 0; static uint32_t stub_t3_arms = 0;")
    for old, new in (
        ("static inline void TimerDisable(uint32_t b, uint32_t t) { (void)b; (void)t; stub_timer_disable++; }",
         "static inline void TimerDisable(uint32_t b, uint32_t t) { (void)t; if (b == TIMER3_BASE) stub_t3_armed = 0; else stub_timer_disable++; }"),
        ("static inline void TimerEnable(uint32_t b, uint32_t t) { (void)b; (void)t; stub_timer_enable++; }",
         "static inline void TimerEnable(uint32_t b, uint32_t t) { (void)t; if (b == TIMER3_BASE) { stub_t3_armed = 1; stub_t3_arms++; } else stub_timer_enable++; }"),
        ("static inline void TimerLoadSet(uint32_t b, uint32_t t, uint32_t v) { (void)b; (void)t; (void)v; }",
         "static inline void TimerLoadSet(uint32_t b, uint32_t t, uint32_t v) { (void)t; if (b == TIMER3_BASE) stub_t3_load = v; }"),
    ):
        assert old in text, old[:50]
        text = text.replace(old, new)
    text = text.replace("#endif\n", "static inline void IntPendClear(uint32_t i) { (void)i; }\n"
                                    "static inline uint32_t TimerIntStatus(uint32_t b, bool m) { (void)b; (void)m; return 0; }\n#endif\n")
    return text


GLOBALS = ca.GLOBALS_STUB.replace("#define IRQ_PRIO_AUDIO_SAMPLE 0", "#define IRQ_PRIO_AUDIO_SAMPLE 0\n#define IRQ_PRIO_PLAYBACK 2")

HARNESS = r'''
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "audio.c"
#include "midi.c"
#include "playback.c"

static int g_fail = 0, g_hook = 0;
static void check_(const char *name, int ok, const char *fmt, ...)
{
    printf("%s %s", ok ? "PASS" : "FAIL", name);
    if (fmt) { va_list ap; va_start(ap, fmt); printf("  -- "); vprintf(fmt, ap); va_end(ap); }
    printf("\n");
    if (!ok) g_fail++;
}
#define check(...) check_(__VA_ARGS__, NULL)

static void hook(void) { g_hook++; }
static uint32_t armed_ms(void) { return (stub_t3_load + 1U) / (SYSTEM_CLOCK_HZ / 1000U); }
static void run_audio(uint32_t ms) { uint32_t i, n = ms * 20U; for (i = 0; i < n; i++) timer2ISR(); }

/* bitmask of the pitches sounding right now (pitch - 48 fits in 37 bits: use a 64-bit mask) */
static uint64_t sounding_mask(void)
{
    uint64_t m = 0; uint32_t i;
    for (i = 0; i < AUDIO_MAX_VOICES; i++) if (g_voices[i].active) m |= 1ULL << (g_voices[i].midiNote - 48U);
    return m;
}

static MelodyEvent notes[MAX_PARSED_NOTES];

/* expected mask at song time t, from the parsed note list */
static uint64_t expected_mask(uint32_t count, uint32_t t, int *over3)
{
    uint64_t m = 0; uint32_t i; int n = 0;
    for (i = 0; i < count; i++)
        if (notes[i].startMs <= t && t < notes[i].startMs + notes[i].durationMs) { m |= 1ULL << (notes[i].midiNote - 48U); n++; }
    if (n > 3) *over3 = 1;
    return m;
}

int main(void)
{
    char path[1024];
    static unsigned char buf[70000];
    uint32_t stops;
    Audio_init();
    Playback_init(hook);

    /* ---- files: parse with the real parser, play with the real playback, compare at every wake-up */
    while (fgets(path, sizeof path, stdin))
    {
        size_t len = strlen(path); FILE *f; size_t n; uint32_t count = 0, t = 0, wakes = 0, maxArm = 0, last_end = 0, i;
        MidiParseResult r; int bad = 0, over3 = 0; char label[300];
        while (len && (path[len-1] == '\n' || path[len-1] == '\r')) path[--len] = 0;
        if (strcmp(path, "STOPTEST") == 0) break;
        f = fopen(path, "rb"); n = f ? fread(buf, 1, sizeof buf, f) : 0; if (f) fclose(f);
        snprintf(label, sizeof label, "%s", strrchr(path, '\\') ? strrchr(path, '\\') + 1 : path);
        r = Midi_parse(buf, (uint32_t)n, notes, MAX_PARSED_NOTES, &count);
        if (r != MIDI_PARSE_OK) { printf("SKIP %s (parser result %d)\n", label, (int)r); continue; }
        for (i = 0; i < count; i++) if (notes[i].startMs + notes[i].durationMs > last_end) last_end = notes[i].startMs + notes[i].durationMs;
        g_hook = 0; stub_dac_n = 0;
        if (!Playback_start(notes, count)) { check(label, 0, "Playback_start refused"); continue; }
        if (sounding_mask() != expected_mask(count, 0, &over3)) bad++;
        while (Playback_isActive() && wakes < 200000U)
        {
            uint32_t ms = armed_ms();
            if (!stub_t3_armed) { bad++; break; }
            if (ms > maxArm) maxArm = ms;
            run_audio(ms > 2000U ? 2000U : ms);          /* the sample interrupt runs while we wait (capped, for speed) */
            t += ms; wakes++;
            stub_t3_armed = 0;
            timer3ISR();                                   /* the wait elapsed */
            if (Playback_isActive() && sounding_mask() != expected_mask(count, t, &over3)) { bad++; if (bad < 4) printf("     wake at %u ms: sounding %llx expected %llx\n", t, (unsigned long long)sounding_mask(), (unsigned long long)expected_mask(count, t, &over3)); }
        }
        check(label, bad == 0 && t == last_end && g_hook == 1 && !Playback_isActive() && Audio_activeVoices() == 0 && stub_amp_off,
              "%u notes, %u wake-ups, ended at %u ms (last note ends %u), completion hook %d, silent %d%s",
              count, wakes, t, last_end, g_hook, Audio_activeVoices() == 0 && stub_amp_off, bad ? ", MISMATCHES" : "");
        check("  completion reported exactly once", Playback_takeCompletion() && !Playback_takeCompletion());
    }

    /* ---- STOP in the middle of a chord song */
    {
        uint32_t i, count = 0; int over3 = 0;
        for (i = 0; i < 12; i++) { notes[i].midiNote = (uint8_t)(60 + (i % 3) * 4); notes[i].startMs = (i / 3) * 500U; notes[i].durationMs = 400U; }
        count = 12;
        g_hook = 0;
        Playback_start(notes, count);
        run_audio(300); stub_t3_armed = 0; timer3ISR();                 /* some voices stop, wait continues */
        run_audio(300);
        Playback_stop();
        check("STOP: silent at once, no voices, timer off", Audio_activeVoices() == 0 && !Audio_isNoteActive() && stub_amp_off && !stub_t3_armed && !Playback_isActive());
        stub_t3_armed = 1; timer3ISR();                                  /* a late timer interrupt after STOP */
        check("STOP: a late timer interrupt starts nothing", Audio_activeVoices() == 0 && !Playback_isActive());
        check("STOP: no completion is reported", g_hook == 0 && !Playback_takeCompletion() && !Playback_completionReady());
        (void)over3;
    }

    /* ---- gap longer than the hardware timer allows */
    {
        uint32_t t = 0, maxArm = 0, wakes = 0, secondStart = 0;
        notes[0].midiNote = 60; notes[0].startMs = 0;      notes[0].durationMs = 100;
        notes[1].midiNote = 64; notes[1].startMs = 100000; notes[1].durationMs = 100;
        g_hook = 0;
        Playback_start(notes, 2);
        while (Playback_isActive() && wakes < 50)
        {
            uint32_t ms = armed_ms(); if (ms > maxArm) maxArm = ms;
            t += ms; wakes++; stub_t3_armed = 0; timer3ISR();
            if (secondStart == 0 && (sounding_mask() & (1ULL << (64 - 48)))) secondStart = t;
        }
        check("gap of 100 s is waited out in several shots, none longer than the timer allows",
              maxArm <= PLAYBACK_MAX_WAIT_MS && wakes >= 4 && secondStart == 100000 && g_hook == 1,
              "longest wait %u ms (limit %u), %u wake-ups, second note started at %u ms", maxArm, (uint32_t)PLAYBACK_MAX_WAIT_MS, wakes, secondStart);
    }

    /* ---- refusals */
    check("empty or oversize note lists are refused", !Playback_start(notes, 0) && !Playback_start(NULL, 5) && !Playback_start(notes, MAX_PARSED_NOTES + 1));

    printf("\n%d failure(s)\n", g_fail);
    return g_fail ? 1 : 0;
}
'''


def main():
    with tempfile.TemporaryDirectory() as tmp:
        t = Path(tmp)
        (t / "ti" / "devices" / "msp432e4" / "driverlib").mkdir(parents=True)
        (t / "ti" / "devices" / "msp432e4" / "driverlib" / "driverlib.h").write_text(build_driverlib())
        (t / "globals.h").write_text(GLOBALS)
        new_audio = (SRC / "audio.c").read_text()
        assert new_audio.count("#define AUDIO_ISR_PROFILE        1") == 1
        (t / "audio.c").write_text(new_audio.replace("#define AUDIO_ISR_PROFILE        1", "#define AUDIO_ISR_PROFILE        0"))
        for name in ("audio.h", "audio_instruments.h", "midi.c", "midi.h", "playback.c", "playback.h", "voice_sched.h"):
            (t / name).write_text((SRC / name).read_text())
        (t / "harness.c").write_text(HARNESS)
        b = subprocess.run('"{}" >nul && cl /nologo /W3 /D_CRT_SECURE_NO_WARNINGS /I. /Fe:e2e.exe harness.c'.format(ca.VCVARS),
                           cwd=t, shell=True, capture_output=True, text=True)
        exe = t / "e2e.exe"
        if not exe.exists():
            print("FAIL could not compile midi.c + playback.c + audio.c on the PC")
            print(b.stdout[-3500:])
            return 2

        files = []
        def add(name, data):
            p = t / (name + ".mid")
            p.write_bytes(data)
            files.append(p)
        add("single note", pm.build_midi([(60, 0, 480)]))
        add("triad held", pm.build_midi([(60, 0, 960), (64, 0, 960), (67, 0, 960)]))
        add("two voices overlapping", pm.build_midi([(60, 0, 960), (64, 480, 1440)]))
        add("three staggered voices", pm.build_midi([(60, 0, 1920), (64, 480, 1920), (67, 960, 1920)]))
        add("chords back to back", pm.build_midi([(60, 0, 480), (64, 0, 480), (67, 0, 480), (62, 480, 960), (65, 480, 960), (69, 480, 960)]))
        add("chords with rests", pm.build_midi([(60, 0, 240), (64, 0, 240), (67, 0, 240), (62, 960, 1200), (65, 960, 1200)]))
        add("melody over a held bass", pm.build_midi([(48, 0, 3840)] + [(60 + (i % 5) * 2, i * 480, i * 480 + 400) for i in range(8)]))
        add("tempo change in a chord", pm.build_midi([(60, 0, 1920), (64, 0, 1920), (67, 480, 1920)],
                                                      extra_events=[(960, b"\xFF\x51\x03" + (250000).to_bytes(3, "big"))]))
        add("fast chord run", pm.build_midi([(48 + (i * 3) % 30 + k * 4, i * 60, i * 60 + 150) for i in range(40) for k in range(1)]))
        for f in sorted(REF.glob("*.mid")):
            files.append(f)
        sys.path.insert(0, str(HERE / "board_tests"))
        import piano_songs
        piano_songs.write_all()
        for f in sorted(piano_songs.OUT.glob("*.mid")):      # the homophonic piano songs, 25 files
            files.append(f)
        stdin = "\n".join(str(p) for p in files) + "\nSTOPTEST\n"
        r = subprocess.run([str(exe)], input=stdin, cwd=t, capture_output=True, text=True)
        print(r.stdout, end="")
        if r.stderr:
            print(r.stderr)
        return r.returncode


if __name__ == "__main__":
    sys.exit(main())
