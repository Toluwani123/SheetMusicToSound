"""Fit the oscilloscope captures in waveforms/ and compare them with the wave tables.

    python analyze_scope_waveforms.py                 # analyse, write instrument_spectra.json + plots + report
    python analyze_scope_waveforms.py --no-write      # analyse and print only

Instruments (see SOURCES): clarinet, trumpet, marimba are built into the firmware. The organ and the
guitar were scrapped for now: they are still analysed and kept under "archived" in the json so they
can be switched back on (set enabled=True here, add them to audio.c/audio.h, regenerate).

Inputs (waveforms/)
  <name>img.png / <name>.png   screenshot of the live scope; the red trace is digitised.
  <name>.txt                   OWON text export, 5000 samples at 250 kS/s (the scope's "S" readout), CH1.
  Which file is fitted is chosen per instrument in SOURCES, with the reason. Where the other file
  is steady enough it is used as a cross-check (cosine similarity of the harmonic strengths).

Method
  1. Find the repeat period of the note (fold-dispersion for a screenshot, self-similarity for text).
  2. Least-squares fit of harmonics 1..13: y = sum_k A_k cos(2 pi k f0 t + phi_k).
  3. Keep harmonics 1..9 (the audio sample rate allows no more), amplitudes relative to the
     strongest one, phases relative to the fundamental (a time shift only).
  4. Report how much of the raw cycle each table explains, against a baseline (the previous
     hand-picked recipe where there was one, otherwise a plain sine), and how much the first 9
     harmonics can explain at best.

Needs numpy and Pillow (matplotlib optional, for the comparison plots).
"""

import argparse
import json
import math
import re
import sys
from pathlib import Path

import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import generate_instrument_tables as gen            # noqa: E402  (shares the table builder)

ROOT = HERE.parent
WAVES = ROOT / "waveforms"
OUT_JSON = gen.SPECTRA_JSON
PREVIEW = HERE / "instrument_preview"
REPORT = HERE / "instrument_match_report.txt"

K_FIT = 13
K_TABLE = 9                    # default harmonic limit; an entry in SOURCES can raise it (marimba: 10)
OWON_FS = 250000.0               # "S (250KS/s)" readout on the screenshots

SOURCES = {
    "clarinet": dict(
        enabled=True, kind="png", file="clarinetimg.png", rows=(105, 800), xmin=0, periods=(100, 300),
        label="G5, scope reading 784.9 Hz", f0_hz=784.865,
        why="clarinet.txt holds only scope noise, so the screenshot is the only usable capture"),
    "trumpet": dict(
        enabled=True, kind="png", file="trumpet.png", rows=(0, 404), xmin=0, periods=(100, 420),
        label="trumpet capture", f0_hz=None,
        txt_check=("trumpet.txt", [(1070, 1363), (2433, 1303), (3736, 1246)]),
        why="the screenshot shows 4 evenly spaced, equally deep cycles; in trumpet.txt the pitch drifts "
            "(pulses 1363, 1303, 1246 samples apart), so it cannot give one stable fit"),
    "guitar": dict(
        enabled=False, kind="png", file="guitar.png", rows=(0, 314), xmin=14, periods=(100, 420),
        label="guitar capture", f0_hz=None,
        txt_check=("guitar.txt", [(2000, 1129), (3129, 1129), (3700, 1129)]),
        why="scrapped for now (did not sound convincing); the screenshot is a stable 4.4-cycle wave, "
            "guitar.txt disagrees with it (see cross-check); kept so it can be switched back on"),
    "marimba": dict(
        enabled=True, kind="txt", file="marimba.txt", window=(1500, 5000), lags=(700, 1500), max_harmonic=10,
        label="A3, about 221 Hz", f0_hz=None,
        png_check=("marimba.png", (0, 314), 14, (20, 200)),
        why="marimba.txt is a stable 221 Hz note (92% explained) with the marimba's typical 4th and 10th "
            "overtones; marimba.png is a different, much higher note that is almost a pure sine and would "
            "only duplicate the sine preset"),
    "organ": dict(
        enabled=False, kind="txt", file="organ.txt", window=(3000, 5000), lags=(300, 1500),
        label="C4, about 264 Hz", f0_hz=None,
        why="scrapped for now (did not sound convincing); kept so it can be switched back on"),
}

# The first hand-picked recipes (amplitude only, sine phase), kept as the "before" baseline.
OLD_RECIPES = {
    "clarinet": {1: 1.00, 3: 0.75, 5: 0.50, 7: 0.14, 9: 0.12},
    "organ": {1: 1.00, 2: 0.70, 3: 0.45, 4: 0.30, 6: 0.15, 8: 0.08},
}

LINES = []


def say(text=""):
    print(text)
    LINES.append(text)


# ------------------------------------------------------------------ loading --

def read_owon_ch1(path):
    values = []
    for line in Path(path).read_text().splitlines():
        m = re.match(r"\s*(\d{5})\s+(-?[\d.]+)\s+(-?[\d.]+)", line)
        if m:
            values.append(float(m.group(2)))
    return np.array(values)


def has_signal(ch1):
    """A capture of silence is a handful of quantisation levels at a constant noise level."""
    return len(set(ch1)) > 8 and ch1.std() > 100.0


def digitize_red_trace(png, rows, xmin=0):
    a = np.array(Image.open(png).convert("RGB")).astype(int)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    red = (r > 170) & (g < 110) & (b < 110)
    keep = np.zeros_like(red)
    keep[rows[0]:rows[1], xmin:] = True            # xmin skips the scope's trigger marker at the left edge
    red &= keep
    x = np.arange(a.shape[1])
    y = np.full(len(x), np.nan)
    for i in x:
        hits = np.nonzero(red[:, i])[0]
        if len(hits):
            y[i] = hits.mean()
    good = np.isfinite(y)
    return x[good].astype(float), -(y[good] - y[good].mean())       # screen y grows downward


# ------------------------------------------------------------------ fitting --

def harmonic_fit(t, y, f0, K):
    """y ~ c + sum_k A_k cos(2 pi k f0 t + phi_k). Returns (A[1..K], phi[1..K], R^2)."""
    cols = [np.ones_like(t)]
    for k in range(1, K + 1):
        cols += [np.cos(2 * np.pi * k * f0 * t), np.sin(2 * np.pi * k * f0 * t)]
    design = np.stack(cols, 1)
    coef, *_ = np.linalg.lstsq(design, y, rcond=None)
    resid = y - design @ coef
    amp = np.array([math.hypot(coef[2 * k - 1], coef[2 * k]) for k in range(1, K + 1)])
    phase = np.array([math.atan2(-coef[2 * k], coef[2 * k - 1]) for k in range(1, K + 1)])
    return amp, phase, 1.0 - resid.var() / y.var()


def refine_f0(t, y, f_lo, f_hi, step, K):
    best = None
    for f0 in np.arange(f_lo, f_hi, step):
        amp, phase, r2 = harmonic_fit(t, y, f0, K)
        if best is None or r2 > best[0]:
            best = (r2, f0, amp, phase)
    return best


def dispersion_period(x, y, p_lo, p_hi, step=0.25, bins=24):
    """Trial period whose folded cycles scatter least."""
    best = None
    for p in np.arange(p_lo, p_hi, step):
        idx = (((x % p) / p) * bins).astype(int)
        v = sum(y[idx == k].var() * np.sum(idx == k) for k in range(bins) if np.sum(idx == k) > 1) / len(y)
        if best is None or v < best[0]:
            best = (v, p)
    return best[1]


def self_similarity_period(a, base, n, lag_lo, lag_hi):
    """Lag at which a[base:base+n] best repeats itself, and the correlation there."""
    def corr(lag):
        u = a[base:base + n] - a[base:base + n].mean()
        v = a[base + lag:base + lag + n] - a[base + lag:base + lag + n].mean()
        return float(u @ v / math.sqrt((u @ u) * (v @ v)))
    best = max(((corr(lag), lag) for lag in range(lag_lo, min(lag_hi, len(a) - base - n))), key=lambda p: p[0])
    return best[1], best[0]


def to_spec(amp, phase, kmax=K_TABLE):
    """Relative amplitudes (strongest = 1) and phases with the fundamental at zero (a time shift)."""
    amp, phase = amp[:kmax], phase[:kmax]
    rel = amp / amp.max()
    ph = [(phase[k] - (k + 1) * phase[0] + math.pi) % (2 * math.pi) - math.pi for k in range(kmax)]
    return [{"n": k + 1, "amp": round(float(rel[k]), 4), "phase": round(float(ph[k]), 4)} for k in range(kmax)]


# --------------------------------------------------------------- comparison --

def fold_cycle(t, y, f0, bins=256):
    idx = (((t * f0) % 1.0) * bins).astype(int)
    total = np.bincount(idx, y, bins)
    count = np.bincount(idx, minlength=bins)
    cycle = np.where(count > 0, total / np.maximum(count, 1), np.nan)
    known = np.isfinite(cycle)
    pos = np.arange(bins)
    filled = np.interp(np.arange(-bins, 2 * bins), np.concatenate([pos[known] - bins, pos[known], pos[known] + bins]),
                       np.concatenate([cycle[known]] * 3))[bins:2 * bins]
    return filled - filled.mean()


def shape_match(measured, table):
    """Best R^2 of measured ~ scale * table(shifted); the table's amplitude and phase offset are free."""
    m = measured - measured.mean()
    tab = np.asarray(table, float) - np.mean(table)
    corr = np.fft.irfft(np.fft.rfft(m) * np.conj(np.fft.rfft(tab)), n=len(m))
    shift = int(np.argmax(corr))
    shifted = np.roll(tab, shift)
    scale = (m @ shifted) / (shifted @ shifted)
    resid = m - scale * shifted
    return 1.0 - (resid @ resid) / (m @ m), shifted * scale


def table_spectrum(table, kmax=K_TABLE):
    """Amplitude of harmonics 1..kmax actually present in an integer table, relative to the strongest."""
    spec = np.abs(np.fft.rfft(np.asarray(table, float) - np.mean(table)))[1:kmax + 1]
    return spec / spec.max()


def baseline_table(name):
    """The previous hand-picked recipe if there was one, otherwise the plain sine."""
    if name in OLD_RECIPES:
        return gen.build_table({n: (a, -math.pi / 2) for n, a in OLD_RECIPES[name].items()})[0], "previous recipe"
    return gen.sine_table(), "plain sine"


def new_table(spec):
    return gen.build_table({h["n"]: (h["amp"], h["phase"]) for h in spec})[0]


def compare(name, cycle, spec, fit_amp):
    kmax = len(spec)
    base, base_label = baseline_table(name)
    new = new_table(spec)
    r2_old, shifted_old = shape_match(cycle, base)
    r2_new, shifted_new = shape_match(cycle, new)
    recon = np.array([sum(a * math.cos(2 * math.pi * (k + 1) * i / 256 + p)
                          for k, (a, p) in enumerate(zip(fit_amp[:kmax], [h["phase"] for h in spec])))
                      for i in range(256)])
    ceiling, _ = shape_match(cycle, recon)
    say("  one folded cycle of the raw capture explained by:")
    say("    baseline ({:<15s}                  R2 = {:.3f}".format(base_label + ")", r2_old))
    say("    new table (fitted amplitudes and phases)   R2 = {:.3f}".format(r2_new))
    say("    best any {}-harmonic table could do{}R2 = {:.3f}".format(kmax, " " * (9 - len(str(kmax))), ceiling))
    say("  harmonic amplitudes (strongest = 1.00):   n:  measured / baseline / new")
    measured = fit_amp[:kmax] / fit_amp[:kmax].max()
    old_s, new_s = table_spectrum(base, kmax), table_spectrum(new, kmax)
    for k in range(kmax):
        say("      h{}   {:5.2f}  {:5.2f}  {:5.2f}".format(k + 1, measured[k], old_s[k], new_s[k]))
    return r2_old, r2_new, ceiling, cycle, shifted_old, shifted_new, measured, old_s, new_s, base_label


def plot(name, result, label):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return None
    r2_old, r2_new, ceiling, cycle, s_old, s_new, measured, old_s, new_s, base_label = result
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 3.8), gridspec_kw={"width_ratios": [1.6, 1]})
    x = np.arange(256) / 256.0
    ax1.plot(x, cycle / np.abs(cycle).max(), ".", color="0.6", ms=3, label="oscilloscope capture, folded to one cycle")
    ax1.plot(x, s_old / np.abs(cycle).max(), "--", color="tab:blue", lw=1.6, label="{} (R$^2$ = {:.2f})".format(base_label, r2_old))
    ax1.plot(x, s_new / np.abs(cycle).max(), "-", color="tab:red", lw=2, label="new table (R$^2$ = {:.2f})".format(r2_new))
    ax1.set_title("{}: one cycle ({})".format(name, label), fontsize=10)
    ax1.set_xlabel("position in the cycle")
    ax1.set_yticks([])
    ax1.legend(fontsize=7, loc="upper right")
    n = np.arange(1, len(measured) + 1)
    w = 0.27
    ax2.bar(n - w, measured, w, color="0.45", label="measured")
    ax2.bar(n, old_s, w, color="tab:blue", label=base_label)
    ax2.bar(n + w, new_s, w, color="tab:red", label="new")
    ax2.set_xticks(n)
    ax2.set_xlabel("harmonic")
    ax2.set_ylabel("amplitude (strongest = 1)")
    ax2.legend(fontsize=7)
    fig.tight_layout()
    PREVIEW.mkdir(exist_ok=True)
    path = PREVIEW / "match_{}.png".format(name)
    fig.savefig(path, dpi=110)
    plt.close(fig)
    return path


# --------------------------------------------------------------- per source --

def fit_source(name, src):
    """Returns (spec, fit_amp, cycle, f0_cycles_per_unit, r2, detail_text, cycles_seen)."""
    if src["kind"] == "png":
        x, y = digitize_red_trace(WAVES / src["file"], src["rows"], src.get("xmin", 0))
        p0 = dispersion_period(x, y, *src["periods"])
        r2, f0, amp, phase = refine_f0(x, y, 1.0 / (p0 + 1.0), 1.0 / (p0 - 1.0), 1.0 / p0 ** 2 * 0.02, K_FIT)
        cycles = (x.max() - x.min()) / (1.0 / f0)
        detail = "trace: {} columns, period {:.2f} px = {:.2f} cycles across the screen".format(len(x), 1.0 / f0, cycles)
        cycle = fold_cycle(x, y, f0)
    else:
        a = read_owon_ch1(WAVES / src["file"])
        lo, hi = src["window"]
        lag, c = self_similarity_period(a, lo, 800, *src["lags"])
        t = np.arange(lo, hi) / OWON_FS
        y = a[lo:hi] - a[lo:hi].mean()
        f_guess = OWON_FS / lag
        r2, f0, amp, phase = refine_f0(t, y, f_guess - 3.0, f_guess + 3.0, 0.05, K_FIT)
        cycles = (hi - lo) * f0 / OWON_FS
        detail = "after the onset the waveform repeats every {} samples (correlation {:.2f}) = {:.1f} Hz".format(lag, c, f0)
        cycle = fold_cycle(t, y, f0)
    return to_spec(amp, phase, src.get("max_harmonic", K_TABLE)), amp, cycle, r2, detail, cycles


def cross_check(name, spec, check):
    """Cosine similarity between the fitted harmonic strengths and the exact cycles of the text capture."""
    fname, cycles = check
    a = read_owon_ch1(WAVES / fname)
    ref = np.array([h["amp"] for h in spec])
    sims = []
    say("  cross-check against {} (one exact cycle at a time, harmonics 1..9 relative):".format(fname))
    for start, length in cycles:
        t = np.arange(start, start + length) / OWON_FS
        y = a[start:start + length] - a[start:start + length].mean()
        amp, _, r2 = harmonic_fit(t, y, OWON_FS / length, K_FIT)
        v = amp[:len(spec)] / amp[:len(spec)].max()
        sim = float(v @ ref / (np.linalg.norm(v) * np.linalg.norm(ref)))
        sims.append(round(sim, 2))
        say("    cycle @{:4d} len {:4d}: {}   similarity {:.2f}".format(start, length, " ".join("%.2f" % q for q in v), sim))
    say("    fitted:                      {}".format(" ".join("%.2f" % q for q in ref)))
    return sims


def cross_check_png(spec, check):
    """Cosine similarity between the fitted harmonic strengths and the screenshot's own fit."""
    fname, rows, xmin, periods = check
    x, y = digitize_red_trace(WAVES / fname, rows, xmin)
    p0 = dispersion_period(x, y, *periods)
    r2, f0, amp, _ = refine_f0(x, y, 1.0 / (p0 + 1.0), 1.0 / (p0 - 1.0), 1.0 / p0 ** 2 * 0.02, K_FIT)
    kmax = len(spec)
    v = amp[:kmax] / amp[:kmax].max()
    ref = np.array([h["amp"] for h in spec])
    sim = float(v @ ref / (np.linalg.norm(v) * np.linalg.norm(ref)))
    say("  cross-check against {}: {:.1f} cycles on screen (R2 {:.3f}), harmonics 1..{} relative:".format(
        fname, (x.max() - x.min()) * f0, r2, kmax))
    say("    screenshot: {}   similarity {:.2f}".format(" ".join("%.2f" % q for q in v), sim))
    say("    fitted:     {}".format(" ".join("%.2f" % q for q in ref)))
    say("    (similarity compares timbre only: the screenshot is a different, higher note than the text capture)")
    return [round(sim, 2)]


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--no-write", action="store_true", help="print only; do not write json, plots or report")
    parser.add_argument("--guitar-from", choices=("png", "txt"), default="png",
                        help="fit the guitar from the screenshot (default) or from guitar.txt; the two captures disagree")
    args = parser.parse_args()
    if args.guitar_from == "txt":
        SOURCES["guitar"].update(kind="txt", file="guitar.txt", window=(2600, 5000), lags=(900, 1400),
                                 why="chosen with --guitar-from txt; this capture starts in silence and fits only ~80%")
        SOURCES["guitar"].pop("rows", None)
    result = {"generated_by": "test_tools/analyze_scope_waveforms.py",
              "instruments": [n for n, s in SOURCES.items() if s["enabled"]], "archived": {}}
    plots = []

    for name, src in SOURCES.items():
        say("")
        say(name.upper() + ("" if src["enabled"] else "  (archived: not built into the firmware)"))
        say("  source: {} -- {}".format(src["file"], src["why"]))
        if src["kind"] == "png":
            txt = WAVES / (Path(src["file"]).stem.replace("img", "").replace("pic", "") + ".txt")
            if txt.exists() and not has_signal(read_owon_ch1(txt)):
                say("  note: {} holds only scope noise and is ignored".format(txt.name))
        spec, amp, cycle, r2, detail, cycles = fit_source(name, src)
        say("  " + detail)
        say("  fit with {} harmonics: R2 = {:.3f}".format(K_FIT, r2))
        res = compare(name, cycle, spec, amp)
        sims = None
        if "txt_check" in src:
            sims = cross_check(name, spec, src["txt_check"])
        elif "png_check" in src:
            sims = cross_check_png(spec, src["png_check"])
        entry = {
            "source": "fitted to waveforms/{} ({})".format(src["file"], src["label"]),
            "f0_hz": src["f0_hz"], "fit_r2": round(float(r2), 3),
            "confidence": "{:.1f} cycles in the capture, {:.0f}% of the trace explained by {} harmonics".format(
                cycles, 100 * r2, K_FIT),
            "why_this_file": src["why"], "harmonics": spec}
        if sims is not None:
            entry["text_crosscheck_similarity"] = sims
        if src["enabled"]:
            result[name] = entry
        else:
            result["archived"][name] = entry
        plots.append(plot(name, res, src["label"]))

    if not args.no_write:
        OUT_JSON.write_text(json.dumps(result, indent=2) + "\n")
        REPORT.write_text("\n".join(LINES) + "\n")
        say("")
        say("wrote {}".format(OUT_JSON))
        for p in plots:
            if p:
                say("wrote {}".format(p))
        say("next: python generate_instrument_tables.py --preview instrument_preview")
    return 0


if __name__ == "__main__":
    sys.exit(main())
