"""Host test of the audio envelope, using the REAL C code from audio.c (not a re-implementation).

    python check_envelope_decay.py [path\\to\\old\\audio.c]

It extracts envelopeGainQ15() from the current projects\\gpiointerrupt_freertos\\audio.c and from an
older audio.c (default: checkpoints\\before_marimba\\src\\audio.c, the version before the decay stage
existed), compiles both with Visual Studio's cl.exe, and checks:

  1. With no decay stage, the new function returns EXACTLY what the old one did, for every sample of
     every tested note length and ramp setting (so sine, clarinet and trumpet are unchanged).
  2. The marimba decay (taken from the MARIMBA_* values in audio.c): starts at full level, never rises,
     settles at the floor, release never rises and ends at exactly 0, and every value is within 0..ONE.

Needs Visual Studio 2022 with the C++ build tools (cl.exe). Exit code 0 = all passed.
"""

import re
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
NEW_C = ROOT / "projects" / "gpiointerrupt_freertos" / "audio.c"
OLD_C = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "checkpoints" / "before_marimba" / "src" / "audio.c"
VCVARS = r"C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"


def extract_function(text, name):
    m = re.search(r"static inline uint32_t " + name + r"\s*\(", text)
    if not m:
        raise SystemExit("cannot find " + name)
    i = text.index("{", m.start())
    depth = 0
    for j in range(i, len(text)):
        depth += text[j] == "{"
        depth -= text[j] == "}"
        if depth == 0:
            return text[m.start():j + 1]
    raise SystemExit("unbalanced braces in " + name)


def define(text, name):
    m = re.search(r"#define\s+" + name + r"\s+\(?([0-9]+)U?\)?", text)
    if not m:
        raise SystemExit("cannot find #define " + name)
    return int(m.group(1))


def main():
    new_text, old_text = NEW_C.read_text(), OLD_C.read_text()
    one = define(new_text, "ENV_GAIN_ONE")
    assert one == define(old_text, "ENV_GAIN_ONE") == 32768
    fn_new = extract_function(new_text, "envelopeGainQ15")      # new signature: (const volatile VoiceEnvelope *e, uint32_t n)
    env_type = re.search(r"typedef struct\s*\{[^}]*\}\s*VoiceEnvelope;", new_text).group(0)
    fn_old = extract_function(old_text, "envelopeGainQ15").replace("envelopeGainQ15", "oldGain")
    rate_per_ms = define(new_text, "AUDIO_SAMPLE_RATE_HZ") // 1000
    ms = lambda name: define(new_text, name) * rate_per_ms
    marimba = dict(attack=ms("MARIMBA_ATTACK_MS"), release=ms("MARIMBA_RELEASE_MS"), decay=ms("MARIMBA_DECAY_MS"),
                   floor=define(new_text, "MARIMBA_DECAY_FLOOR_PERCENT") * one // 100)

    c = r'''
#include <stdint.h>
#include <stdio.h>
#define ENV_GAIN_ONE 32768U
static volatile uint32_t g_envAttackSamples, g_envReleaseStart, g_envReleaseSamples, g_envReleaseEnd;
static volatile uint32_t g_envDecaySamples, g_envDecayFloor;       /* read by the previous milestone's function */
%s
static volatile VoiceEnvelope g_e;                                 /* read by the new, per-voice function */
%s
%s
static uint32_t newGain(uint32_t n) { return envelopeGainQ15(&g_e, n); }
/* same shrink rule as audioConfigureEnvelope() */
static void configure(uint32_t usable, uint32_t attack, uint32_t release, uint32_t decay, uint32_t floorLevel)
{
    if ((attack + release) > usable) { attack = usable / 2U; release = usable / 2U; }
    g_envAttackSamples = attack; g_envReleaseSamples = release;
    g_envReleaseEnd = usable; g_envReleaseStart = usable - release;
    g_envDecaySamples = decay; g_envDecayFloor = floorLevel;
    g_e.attack = attack; g_e.releaseSamples = release; g_e.releaseEnd = usable; g_e.releaseStart = usable - release;
    g_e.decay = decay; g_e.decayFloor = floorLevel;
}
int main(void)
{
    static const uint32_t usables[] = {0,1,2,3,10,19,20,21,38,39,40,41,100,199,200,201,399,400,401,1000,2500,6000,9999,20000,40000};
    static const uint32_t ramps[][2] = {{100,100},{0,0},{500,400},{600,500},{40,600},{60,30},{1,1},{300,0},{0,300}};
    uint32_t mismatches = 0, compared = 0, u, r, n;
    for (u = 0; u < sizeof(usables)/sizeof(usables[0]); u++)
        for (r = 0; r < sizeof(ramps)/sizeof(ramps[0]); r++) {
            configure(usables[u], ramps[r][0], ramps[r][1], 0U, 0U);
            for (n = 0; n < usables[u] + 8U; n++) {
                compared++;
                if (newGain(n) != oldGain(n)) mismatches++;
            }
        }
    printf("COMPARE %%lu %%lu\n", (unsigned long)compared, (unsigned long)mismatches);
    {
        static const uint32_t lens[] = {50, 200, 1000, 6000, 7040, 9000, 20000};
        for (u = 0; u < sizeof(lens)/sizeof(lens[0]); u++) {
            configure(lens[u], %lu, %lu, %lu, %lu);
            printf("MARIMBA %%lu %%lu %%lu %%lu %%lu", (unsigned long)lens[u], (unsigned long)g_envAttackSamples,
                   (unsigned long)g_envReleaseStart, (unsigned long)g_envReleaseEnd, (unsigned long)g_envReleaseSamples);
            for (n = 0; n < lens[u] + 8U; n++) printf(" %%lu", (unsigned long)newGain(n));
            printf("\n");
        }
    }
    return 0;
}
''' % (env_type, fn_old, fn_new, marimba["attack"], marimba["release"], marimba["decay"], marimba["floor"])

    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / "envtest.c"
        src.write_text(c)
        build = subprocess.run('"{}" >nul && cl /nologo /W3 /Fe:envtest.exe envtest.c'.format(VCVARS), cwd=tmp,
                               shell=True, capture_output=True, text=True)
        exe = Path(tmp) / "envtest.exe"
        if not exe.exists():
            print("FAIL could not compile the extracted C code with cl.exe")
            print(build.stdout[-1500:], build.stderr[-500:])
            return 2
        warnings = [l for l in build.stdout.splitlines() if "warning" in l.lower()]
        out = subprocess.run([str(exe)], capture_output=True, text=True).stdout.splitlines()

    failures = 0

    def check(name, ok, detail=""):
        nonlocal failures
        print(("PASS " if ok else "FAIL ") + name + (("  -- " + detail) if detail else ""))
        failures += 0 if ok else 1

    check("extracted C compiles with no warnings", not warnings, "; ".join(warnings[:2]))
    cmp_line = next(l for l in out if l.startswith("COMPARE")).split()
    compared, mismatches = int(cmp_line[1]), int(cmp_line[2])
    check("no decay stage: new envelope == old envelope, every sample", mismatches == 0,
          "{} samples compared, {} mismatches".format(compared, mismatches))

    p = marimba
    for line in (l for l in out if l.startswith("MARIMBA")):
        f = line.split()
        usable, attack, rel_start, rel_end, rel_samples = (int(x) for x in f[1:6])
        g = [int(x) for x in f[6:]]
        tag = "marimba, note of {} samples".format(usable)
        check(tag + ": values within 0..ONE", all(0 <= v <= 32768 for v in g))
        if usable == 0:
            continue
        check(tag + ": starts at 0 and reaches full level at the end of the attack",
              g[0] == 0 and (attack == 0 or g[attack] == 32768), "g[attack]={}".format(g[attack] if attack < len(g) else None))
        body = g[attack:rel_start + 1] if rel_start >= attack else []
        check(tag + ": never rises after the attack", all(b <= a for a, b in zip(g[attack:], g[attack + 1:])),
              "first rise at n={}".format(next((attack + i + 1 for i, (a, b) in enumerate(zip(g[attack:], g[attack + 1:])) if b > a), None)))
        if attack + p["decay"] <= rel_start:
            check(tag + ": settles at the floor", g[attack + p["decay"]] == p["floor"] and g[rel_start - 1] == p["floor"],
                  "floor {} got {}".format(p["floor"], g[attack + p["decay"]]))
        check(tag + ": ends at exactly 0 from the release end", all(v == 0 for v in g[rel_end:]),
              "g[release_end]={}".format(g[rel_end] if rel_end < len(g) else None))
    print("\n{} failure(s)".format(failures))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
