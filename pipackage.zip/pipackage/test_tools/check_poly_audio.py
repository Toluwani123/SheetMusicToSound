"""Host test of the REAL polyphonic audio engine (projects/gpiointerrupt_freertos/audio.c).

    python check_poly_audio.py

audio.c is compiled on the PC with Visual Studio's cl.exe, with stand-ins for the MSP432 driver calls, and the
real sample interrupt (timer2ISR) is run sample by sample. The only change to the code under test is turning off
the cycle-counter profiling (it reads CPU registers that do not exist on a PC). Checks:

  1. ONE VOICE == PREVIOUS MILESTONE. For every instrument, note range, note length and voice number, the DAC
     codes equal, bit for bit, what the previous (single-voice) audio.c produced. Its envelope code is extracted
     from the original milestone folder and run beside the new engine. A single note is exactly as before.
  2. CHORDS ARE THE AVERAGE. Three voices equal (d0 + d1 + d2) / 3 of the voices played alone, exactly, once the
     gain has settled; two voices of different instruments likewise (d0 + d1) / 2.
  3. NO CLIPPING and a SMOOTH gain: a three-note chord never reaches a DAC limit; the mix gain never moves more
     than the 10 ms slew per sample when voices join or leave.
  4. VOICE HANDLING: start/stop one voice at a time, last voice off silences the DAC and the amplifier, restart
     replaces a note, bad voice numbers are ignored, each voice latches the instrument chosen when it began, the
     hardware timer starts once (not once per voice), a silent engine writes nothing.

Exit code 0 = all passed. Needs Visual Studio 2022 C++ build tools (cl.exe).
"""

import re
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
NEW_DIR = HERE.parent / "projects" / "gpiointerrupt_freertos"
OLD_AUDIO = HERE.parent.parent / "uart_tx_queue_milestone" / "projects" / "gpiointerrupt_freertos" / "audio.c"
VCVARS = r"C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"

DRIVERLIB_STUB = r'''
#ifndef STUB_DRIVERLIB_H
#define STUB_DRIVERLIB_H
#include <stdint.h>
#include <stdbool.h>
#define SYSCTL_PERIPH_GPIOD 1
#define SYSCTL_PERIPH_GPIOH 2
#define SYSCTL_PERIPH_GPION 3
#define SYSCTL_PERIPH_SSI2 4
#define SYSCTL_PERIPH_TIMER2 5
#define GPIO_PORTD_BASE 0xD
#define GPIO_PORTH_BASE 0x8
#define GPIO_PORTN_BASE 0xE
#define GPIO_PIN_1 2
#define GPIO_PIN_2 4
#define GPIO_PIN_3 8
#define GPIO_PD3_SSI2CLK 11
#define GPIO_PD1_SSI2XDAT0 12
#define SSI2_BASE 0x42
#define SSI_FRF_MOTO_MODE_1 1
#define SSI_MODE_MASTER 0
#define TIMER2_BASE 0x2
#define TIMER_A 0xFF
#define TIMER_CFG_PERIODIC 0x22
#define TIMER_TIMA_TIMEOUT 1
#define INT_TIMER2A 37
/* what the audio code did to the "hardware" */
#define STUB_LOG_MAX 600000
static uint16_t stub_dac_log[STUB_LOG_MAX];
static uint32_t stub_dac_n = 0;
static uint32_t stub_timer_enable = 0, stub_timer_disable = 0;
static int stub_amp_off = 1;
static inline void SysCtlPeripheralEnable(uint32_t p) { (void)p; }
static inline bool SysCtlPeripheralReady(uint32_t p) { (void)p; return true; }
static inline void GPIOPinConfigure(uint32_t p) { (void)p; }
static inline void GPIOPinTypeSSI(uint32_t b, uint32_t p) { (void)b; (void)p; }
static inline void GPIOPinTypeGPIOOutput(uint32_t b, uint32_t p) { (void)b; (void)p; }
static inline void GPIOPinWrite(uint32_t b, uint32_t p, uint32_t v) { if (b == GPIO_PORTH_BASE && p == GPIO_PIN_2) stub_amp_off = (v != 0); }
static inline void SSIDisable(uint32_t b) { (void)b; }
static inline void SSIEnable(uint32_t b) { (void)b; }
static inline void SSIConfigSetExpClk(uint32_t a, uint32_t b, uint32_t c, uint32_t d, uint32_t e, uint32_t f) { (void)a; (void)b; (void)c; (void)d; (void)e; (void)f; }
static inline void SSIDataPut(uint32_t b, uint32_t d) { (void)b; if (stub_dac_n < STUB_LOG_MAX) stub_dac_log[stub_dac_n] = (uint16_t)d; stub_dac_n++; }
static inline bool SSIBusy(uint32_t b) { (void)b; return false; }
static inline bool SSIDataGetNonBlocking(uint32_t b, uint32_t *d) { (void)b; (void)d; return false; }
static inline void TimerDisable(uint32_t b, uint32_t t) { (void)b; (void)t; stub_timer_disable++; }
static inline void TimerEnable(uint32_t b, uint32_t t) { (void)b; (void)t; stub_timer_enable++; }
static inline void TimerConfigure(uint32_t b, uint32_t c) { (void)b; (void)c; }
static inline void TimerLoadSet(uint32_t b, uint32_t t, uint32_t v) { (void)b; (void)t; (void)v; }
static inline void TimerIntRegister(uint32_t b, uint32_t t, void (*h)(void)) { (void)b; (void)t; (void)h; }
static inline void TimerIntClear(uint32_t b, uint32_t m) { (void)b; (void)m; }
static inline void TimerIntEnable(uint32_t b, uint32_t m) { (void)b; (void)m; }
static inline void IntPrioritySet(uint32_t i, uint32_t p) { (void)i; (void)p; }
static inline bool IntMasterDisable(void) { return false; }
static inline bool IntMasterEnable(void) { return true; }
#endif
'''

GLOBALS_STUB = r'''
#ifndef STUB_GLOBALS_H
#define STUB_GLOBALS_H
#include <stdint.h>
typedef struct { uint32_t LastDacCode, AudioInterruptCount, AudioIsrLastCycles, AudioIsrMaxCycles; } StubDiagnostics;
typedef struct { StubDiagnostics Diagnostics; } Globals;
static Globals Glo;
#define SYSTEM_CLOCK_HZ 120000000U
#define IRQ_PRIO_AUDIO_SAMPLE 0
#endif
'''

HARNESS = r'''
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "audio.c"          /* the real audio engine */

/* ---- the previous milestone's single-voice envelope code, extracted verbatim and renamed ---- */
static volatile uint32_t g_envSampleIndex, g_envAttackSamples, g_envReleaseStart, g_envReleaseSamples, g_envReleaseEnd;
static volatile uint32_t g_envDecaySamples, g_envDecayFloor;
#include "old_funcs.h"

static int g_fail = 0;
static void check_(const char *name, int ok, const char *fmt, ...)
{
    printf("%s %s", ok ? "PASS" : "FAIL", name);
    if (fmt) { va_list ap; va_start(ap, fmt); printf("  -- "); vprintf(fmt, ap); va_end(ap); }
    printf("\n");
    if (!ok) g_fail++;
}
#define check(...) check_(__VA_ARGS__, NULL)    /* the detail text is optional */

static void reset_audio(void)
{
    Audio_stopNote();
    Audio_setInstrument(AUDIO_INSTRUMENT_SINE);
    stub_dac_n = 0;
}

static void run_isr(uint32_t n) { uint32_t i; for (i = 0; i < n; i++) timer2ISR(); }

static uint16_t *g_ref;

static void old_reference(uint8_t instr, uint8_t note, uint32_t durMs, uint32_t samples)
{
    const Instrument *inst = &g_instruments[instr];
    uint32_t freq = midiNoteToFrequencyMilliHz(note);
    uint32_t inc = (uint32_t)(((uint64_t)freq << 32) / ((uint64_t)AUDIO_SAMPLE_RATE_HZ * 1000ULL));
    uint32_t phase = 0U, idx = 0U, i;
    oldConfigureEnvelope(durMs, inst);
    for (i = 0; i < samples; i++)
    {
        uint32_t waveform = sineTableInterpolate(phase, inst->table);
        uint32_t gain = oldEnvelopeGainQ15(idx);
        int32_t centered, out;
        if (idx != UINT32_MAX) idx++;
        centered = ((int32_t)waveform - (int32_t)DAC_IDLE_CODE) * AUDIO_OUTPUT_GAIN;
        centered = (centered * (int32_t)gain) / (int32_t)ENV_GAIN_ONE;
        out = (int32_t)DAC_IDLE_CODE + centered;
        if (out < 0) out = 0; else if (out > (int32_t)DAC_MAX_CODE) out = (int32_t)DAC_MAX_CODE;
        g_ref[i] = (uint16_t)out;
        phase += inc;
    }
}

int main(void)
{
    static const uint8_t notes[] = {48, 55, 60, 72, 84};
    static const uint32_t durs[] = {1, 8, 125, 417, 1000};
    uint32_t instr, ni, di, voice, i, k;
    uint32_t cases = 0, bad = 0;
    static uint16_t solo[3][30000], chord[30000];
    static uint32_t gainLog[30000];

    g_ref = (uint16_t *)malloc(sizeof(uint16_t) * 40000);
    Audio_init();

    /* 1. one voice == previous milestone, bit for bit */
    for (instr = 0; instr < AUDIO_INSTRUMENT_COUNT; instr++)
        for (ni = 0; ni < sizeof notes; ni++)
            for (di = 0; di < sizeof(durs)/sizeof(durs[0]); di++)
                for (voice = 0; voice < AUDIO_MAX_VOICES; voice++)
                {
                    uint32_t samples = durs[di] * 20U + 300U, first;
                    reset_audio();
                    Audio_setInstrument((uint8_t)instr);
                    Audio_startVoice((uint8_t)voice, notes[ni], durs[di]);
                    first = stub_dac_n;                       /* the idle code written at start */
                    run_isr(samples);
                    old_reference((uint8_t)instr, notes[ni], durs[di], samples);
                    cases++;
                    for (i = 0; i < samples; i++)
                        if (stub_dac_log[first + i] != g_ref[i]) { bad++; if (bad < 4) printf("     first difference: instr %u note %u dur %u voice %u sample %u new %u old %u\n", instr, notes[ni], durs[di], voice, i, stub_dac_log[first + i], g_ref[i]); break; }
                }
    check("one voice == previous milestone, bit for bit", bad == 0,
          "%u cases (4 instruments x 5 notes x 5 lengths x 3 voice numbers), %u differ", cases, bad);

    /* 2. a chord is the average of its voices (all voices exactly the same envelope/instrument) */
    {
        static const uint8_t chordNotes[3] = {60, 64, 67};
        uint32_t settledFrom = 400, mism = 0, N = 20000;
        uint32_t clamped = 0; int32_t peak = 0;
        for (k = 0; k < 3; k++)
        {
            reset_audio();
            Audio_startVoice((uint8_t)k, chordNotes[k], 3000);
            { uint32_t f = stub_dac_n; run_isr(N); memcpy(solo[k], &stub_dac_log[f], N * 2); }
        }
        reset_audio();
        for (k = 0; k < 3; k++) Audio_startVoice((uint8_t)k, chordNotes[k], 3000);
        check("three voices started for the chord", Audio_activeVoices() == 3, "active voices %u", Audio_activeVoices());
        { uint32_t f = stub_dac_n; for (i = 0; i < N; i++) { timer2ISR(); gainLog[i] = g_mixGain; } memcpy(chord, &stub_dac_log[f], N * 2); }
        for (i = settledFrom; i < N; i++)
        {
            int32_t d = ((int32_t)solo[0][i] - 8192) + ((int32_t)solo[1][i] - 8192) + ((int32_t)solo[2][i] - 8192);
            int32_t want = 8192 + (d * (int32_t)(ENV_GAIN_ONE / 3U)) / (int32_t)ENV_GAIN_ONE;
            if ((int32_t)chord[i] != want) { mism++; if (mism < 4) printf("     chord sample %u: got %u want %d\n", i, chord[i], want); }
            if (chord[i] == 0 || chord[i] == DAC_MAX_CODE) clamped++;
            { int32_t dev = (int32_t)chord[i] - 8192; if (dev < 0) dev = -dev; if (dev > peak) peak = dev; }
        }
        check("three-note chord == average of the three voices played alone (exact, after the gain settles)", mism == 0,
              "%u samples compared, %u differ", N - settledFrom, mism);
        check("three-note chord never clips and stays inside the single-note swing", clamped == 0 && peak <= 7500,
              "largest deviation %d of 7500 allowed, %u clipped samples", peak, clamped);
        check("mix gain settles at one third", gainLog[settledFrom] == ENV_GAIN_ONE / 3U, "gain %u (one third = %u)", gainLog[settledFrom], ENV_GAIN_ONE / 3U);
    }

    /* two different instruments mix independently (marimba decay on one voice, sine on the other) */
    {
        uint32_t N = 12000, mism = 0, settledFrom = 400;
        uint16_t a[12000], b[12000], m[12000];
        reset_audio(); Audio_setInstrument(AUDIO_INSTRUMENT_MARIMBA); Audio_startVoice(0, 60, 2000);
        { uint32_t f = stub_dac_n; run_isr(N); memcpy(a, &stub_dac_log[f], N * 2); }
        reset_audio(); Audio_setInstrument(AUDIO_INSTRUMENT_SINE); Audio_startVoice(1, 67, 2000);
        { uint32_t f = stub_dac_n; run_isr(N); memcpy(b, &stub_dac_log[f], N * 2); }
        reset_audio();
        Audio_setInstrument(AUDIO_INSTRUMENT_MARIMBA); Audio_startVoice(0, 60, 2000);
        Audio_setInstrument(AUDIO_INSTRUMENT_SINE);    Audio_startVoice(1, 67, 2000);
        { uint32_t f = stub_dac_n; run_isr(N); memcpy(m, &stub_dac_log[f], N * 2); }
        for (i = settledFrom; i < N; i++)
        {
            int32_t d = ((int32_t)a[i] - 8192) + ((int32_t)b[i] - 8192);
            int32_t want = 8192 + (d * (int32_t)(ENV_GAIN_ONE / 2U)) / (int32_t)ENV_GAIN_ONE;
            if ((int32_t)m[i] != want) { mism++; if (mism < 4) printf("     mix sample %u: got %u want %d\n", i, m[i], want); }
        }
        check("marimba (with decay) + sine mix independently: output == average of the two alone", mism == 0, "%u differ of %u", mism, N - settledFrom);
    }

    /* 3. the mix gain only ever moves by the slew step */
    {
        uint32_t N = 6000, worst = 0, g_prev;
        reset_audio();
        Audio_startVoice(0, 60, 3000);
        g_prev = g_mixGain;
        for (i = 0; i < N; i++)
        {
            uint32_t diff;
            if (i == 1000) Audio_startVoice(1, 64, 3000);
            if (i == 2000) Audio_startVoice(2, 67, 3000);
            if (i == 3500) Audio_stopVoice(1);
            if (i == 4500) Audio_stopVoice(2);
            timer2ISR();
            diff = g_mixGain > g_prev ? g_mixGain - g_prev : g_prev - g_mixGain;
            if (diff > worst) worst = diff;
            g_prev = g_mixGain;
        }
        check("mix gain moves by at most the 10 ms slew per sample as voices join and leave", worst <= AUDIO_MIX_SLEW_Q15,
              "largest step %u, slew limit %u", worst, (uint32_t)AUDIO_MIX_SLEW_Q15);
        check("mix gain returns to full after the chord thins to one voice", g_mixGain == ENV_GAIN_ONE, "gain %u", g_mixGain);
    }

    /* 4. voice handling */
    {
        reset_audio();
        Audio_startVoice(0, 60, 2000); Audio_startVoice(1, 64, 2000); Audio_startVoice(2, 67, 2000);
        check("three voices sounding, amplifier on", Audio_activeVoices() == 3 && Audio_isNoteActive() && !stub_amp_off);
        Audio_stopVoice(1);
        check("stopping one voice leaves the other two sounding", Audio_activeVoices() == 2 && Audio_isNoteActive() && !stub_amp_off);
        Audio_stopVoice(0);
        Audio_stopVoice(2);
        check("last voice off: silent, DAC at midpoint, amplifier off, engine idle",
              Audio_activeVoices() == 0 && !Audio_isNoteActive() && stub_amp_off && stub_dac_log[stub_dac_n - 1] == DAC_IDLE_CODE);
        {
            uint32_t before = stub_dac_n;
            run_isr(50);
            check("a silent engine writes nothing to the DAC", stub_dac_n == before, "%u writes", stub_dac_n - before);
        }

        reset_audio();
        Audio_startVoice(0, 60, 2000); run_isr(500);
        Audio_startVoice(0, 72, 2000);
        check("restarting a sounding voice replaces its note (still one voice, fresh start)",
              Audio_activeVoices() == 1 && g_voices[0].midiNote == 72 && g_voices[0].sampleIndex == 0 && g_voices[0].phase == 0);

        reset_audio();
        { uint32_t n0 = stub_dac_n;
          Audio_startVoice(3, 60, 500); Audio_startVoice(255, 60, 500); Audio_stopVoice(3); Audio_stopVoice(200);
          check("voice numbers beyond the last voice are ignored", Audio_activeVoices() == 0 && stub_dac_n == n0 && !Audio_isNoteActive()); }

        reset_audio();
        Audio_startVoice(0, 60, 2000); Audio_startVoice(1, 64, 2000);
        Audio_startVoice(1, 47, 2000);
        check("an unsupported note number stops that voice only", Audio_activeVoices() == 1 && g_voices[0].active && !g_voices[1].active);

        reset_audio();
        Audio_setInstrument(AUDIO_INSTRUMENT_CLARINET);  Audio_startVoice(0, 60, 2000);
        Audio_setInstrument(AUDIO_INSTRUMENT_TRUMPET);   Audio_startVoice(1, 64, 2000);
        Audio_setInstrument(AUDIO_INSTRUMENT_MARIMBA);   Audio_startVoice(2, 67, 2000);
        check("each voice latches the instrument chosen when its note began",
              g_voices[0].table == clarinetTable && g_voices[1].table == trumpetTable && g_voices[2].table == marimbaTable);
        check("only the marimba voice has a decay stage",
              g_voices[0].env.decay == 0 && g_voices[1].env.decay == 0 && g_voices[2].env.decay != 0);

        reset_audio();
        { uint32_t en = stub_timer_enable;
          Audio_startVoice(0, 60, 1000); Audio_startVoice(1, 64, 1000); Audio_startVoice(2, 67, 1000);
          check("the sample timer is switched on once for a chord, not once per voice", stub_timer_enable - en == 1, "%u enables", stub_timer_enable - en); }

        reset_audio();
        Audio_startVoice(0, 60, 2000); Audio_startVoice(1, 64, 2000); Audio_startVoice(2, 67, 2000);
        run_isr(300);
        Audio_stopNote();
        check("Audio_stopNote silences every voice at once", Audio_activeVoices() == 0 && !Audio_isNoteActive() && stub_amp_off && stub_dac_log[stub_dac_n - 1] == DAC_IDLE_CODE);

        reset_audio();
        Audio_startNote(60, 500);
        check("Audio_startNote still starts a note (voice 0)", Audio_activeVoices() == 1 && g_voices[0].active && g_voices[0].midiNote == 60);
    }

    free(g_ref);
    printf("\n%d failure(s)\n", g_fail);
    return g_fail ? 1 : 0;
}
'''


def extract(text, header_regex):
    m = re.search(header_regex, text)
    if not m:
        raise SystemExit("cannot find " + header_regex)
    i = text.index("{", m.end())
    depth = 0
    for j in range(i, len(text)):
        depth += text[j] == "{"
        depth -= text[j] == "}"
        if depth == 0:
            return text[m.start():j + 1]
    raise SystemExit("unbalanced braces")


def main():
    old = OLD_AUDIO.read_text()
    old_env = extract(old, r"static inline uint32_t envelopeGainQ15\(\s*uint32_t n\s*\)").replace("envelopeGainQ15", "oldEnvelopeGainQ15")
    old_cfg = extract(old, r"static void audioConfigureEnvelope\(\s*uint32_t durationMs,\s*const Instrument \*instrument\s*\)")
    old_cfg = old_cfg.replace("audioConfigureEnvelope", "oldConfigureEnvelope")
    new = (NEW_DIR / "audio.c").read_text()
    assert new.count("#define AUDIO_ISR_PROFILE        1") == 1, "profiling define not found"
    new_test = new.replace("#define AUDIO_ISR_PROFILE        1", "#define AUDIO_ISR_PROFILE        0")

    with tempfile.TemporaryDirectory() as tmp:
        t = Path(tmp)
        (t / "ti" / "devices" / "msp432e4" / "driverlib").mkdir(parents=True)
        (t / "ti" / "devices" / "msp432e4" / "driverlib" / "driverlib.h").write_text(DRIVERLIB_STUB)
        (t / "globals.h").write_text(GLOBALS_STUB)
        (t / "audio.c").write_text(new_test)
        (t / "audio.h").write_text((NEW_DIR / "audio.h").read_text())
        (t / "audio_instruments.h").write_text((NEW_DIR / "audio_instruments.h").read_text())
        (t / "old_funcs.h").write_text(old_env + "\n\n" + old_cfg + "\n")
        (t / "harness.c").write_text(HARNESS)
        b = subprocess.run('"{}" >nul && cl /nologo /W3 /D_CRT_SECURE_NO_WARNINGS /I. /Fe:audiotest.exe harness.c'.format(VCVARS),
                           cwd=t, shell=True, capture_output=True, text=True)
        exe = t / "audiotest.exe"
        if not exe.exists():
            print("FAIL could not compile audio.c on the PC")
            print(b.stdout[-3500:], b.stderr[-800:])
            return 2
        warns = [l for l in b.stdout.splitlines() if "warning" in l.lower() and "audio.c" in l.lower()]
        r = subprocess.run([str(exe)], cwd=t, capture_output=True, text=True)
        print(r.stdout, end="")
        if r.stderr:
            print(r.stderr)
        if warns:
            print("note: cl.exe reported {} warning(s) in audio.c (MSVC-specific, gcc -Wall -Wextra for ARM is clean):".format(len(warns)))
            for w in warns[:4]:
                print("   ", w.strip()[:160])
        return r.returncode


if __name__ == "__main__":
    sys.exit(main())
