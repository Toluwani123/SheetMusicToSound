"""PC checks of the homophonic piano test songs (board_tests/piano_songs.py). No board needed.

    python check_piano_songs.py

For every generated file:
  * the firmware rules accept it (poly_midi.reference_parse) and the most notes at once is what its style promises
    (solo 1, bass/ground 2, block/ground3/oompah/under up to 3);
  * the melody is note for note the same in every variant of a song (the accompaniment only adds notes);
  * every left-hand note is lower than the lowest melody note (the hands never cross, so a pitch is never doubled);
  * the accompaniment ends with the melody.
And against your own reference files, whose tunes you already test with:
  * Twinkle: all 42 pitches equal reference_midi/twinkle_simple.mid (mine is an octave higher, so the hands stay apart);
  * Ode to Joy: the first 44 notes equal reference_midi/ode_to_joy_msp.mid (same D major key); its last phrase is an
    embellished variant, so only the shared opening is compared.
Exit code 0 = all passed.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "board_tests"))
import piano_songs as ps          # noqa: E402
import poly_midi as pm            # noqa: E402

HERE = Path(__file__).resolve().parent
REF = HERE / "board_tests" / "reference_midi"
EXPECTED_PEAK = {"solo": (1, 1), "bass": (2, 2), "ground": (2, 2), "block": (3, 3), "ground3": (3, 3), "oompah": (2, 3), "under": (3, 3)}


def peak(notes):
    return max(sum(1 for _, s2, d2 in notes if s2 <= s < s2 + d2) for _, s, _ in notes)


def intervals(pitches):
    return [b - a for a, b in zip(pitches, pitches[1:])]


def main():
    failures = 0

    def check(name, ok, detail=""):
        nonlocal failures
        print(("PASS " if ok else "FAIL ") + name + (("  -- " + detail) if detail else ""))
        failures += 0 if ok else 1

    rows = ps.write_all()
    entries = ps.build()
    check("{} files written, all accepted by the firmware rules".format(len(rows)), len(rows) == len(entries) >= 20,
          "{} songs".format(len({e["key"] for e in entries})))
    check("at least 6 different songs", len({e["key"] for e in entries}) >= 6, ", ".join(sorted({e["key"] for e in entries})))

    by_key = {}
    for e in entries:
        data = (ps.OUT / (e["name"] + ".mid")).read_bytes()
        status, notes = pm.reference_parse(data)
        lo, hi = EXPECTED_PEAK[e["variant"]]
        p = peak(notes)
        check("{}: {} voices at most (style {})".format(e["name"], p, e["variant"]), status == "OK" and lo <= p <= hi,
              "expected {}..{}".format(lo, hi))
        by_key.setdefault(e["key"], {})[e["variant"]] = notes

    for key, variants in by_key.items():
        solo = variants["solo"]
        melody_ms = {(p, s) for p, s, d in solo}
        melody_lowest = min(p for p, s, d in solo)
        melody_end = max(s + d for p, s, d in solo)
        for v, notes in variants.items():
            if v == "solo":
                continue
            kept = {(p, s) for p, s, d in notes}
            low_hand = [(p, s, d) for p, s, d in notes if (p, s) not in melody_ms]
            same = melody_ms <= kept and all((p, s, d) in set(notes) for p, s, d in solo)
            check("{} {}: the melody is note for note the same as the solo".format(key, v), same)
            check("{} {}: left hand below the melody's lowest note ({}), {} accompaniment notes".format(
                key, v, ps.pitch_name(melody_lowest) if hasattr(ps, "pitch_name") else melody_lowest, len(low_hand)),
                  low_hand and max(p for p, s, d in low_hand) < melody_lowest, "highest left-hand pitch {}".format(max(p for p, s, d in low_hand)))
            lh_end = max(s + d for p, s, d in low_hand)
            check("{} {}: accompaniment ends with the melody".format(key, v), abs(lh_end - melody_end) <= 150, "{} ms apart".format(abs(lh_end - melody_end)))

    # your reference files ------------------------------------------------------------------------------
    for key, ref_name, count in (("twinkle", "twinkle_simple.mid", None), ("ode", "ode_to_joy_msp.mid", 44)):
        ref = REF / ref_name
        if not ref.exists():
            print("SKIP {}: {} not found".format(key, ref_name))
            continue
        ref_notes = [n[0] for n in pm.read_notes(ref.read_bytes())[0]]
        mine = [p for p, s, d in sorted(by_key[key]["solo"], key=lambda n: n[1])]
        n = count or max(len(ref_notes), len(mine))
        octaves = (mine[0] - ref_notes[0]) // 12                      # mine may sit whole octaves higher (hands kept apart)
        same_tune = [p + 12 * (-octaves) for p in mine[:n]] == ref_notes[:n] and (mine[0] - ref_notes[0]) % 12 == 0
        prefix = next((i for i, (a, b) in enumerate(zip(ref_notes, [p - 12 * octaves for p in mine])) if a != b),
                      min(len(ref_notes), len(mine)))
        check("{}: melody is the tune in {} ({} notes compared; {} in a row identical{})".format(
            key, ref_name, n, prefix, "" if octaves == 0 else ", mine {} octave(s) higher".format(octaves)), same_tune,
              "reference {} notes, mine {} notes".format(len(ref_notes), len(mine)))

    print("\n{} failure(s)".format(failures))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
