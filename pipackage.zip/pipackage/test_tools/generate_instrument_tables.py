"""Generate the instrument wave tables (clarinet, trumpet, guitar) for the MSP432E401Y audio ISR.

Writes  projects/gpiointerrupt_freertos/audio_instruments.h  (do not edit that file by hand).
Optionally renders .wav previews that follow the firmware's own arithmetic, so the
sounds can be judged on a PC before flashing.

    python generate_instrument_tables.py                      # (re)write the header
    python generate_instrument_tables.py --check              # fail if the header is stale
    python generate_instrument_tables.py --preview PREVIEWDIR # also write one .wav per instrument (and the sine)

Where the shapes come from
  The harmonic amplitudes and phases are MEASURED, not chosen by hand: they are in
  instrument_spectra.json, written by analyze_scope_waveforms.py from the oscilloscope
  captures in waveforms/ (virtual instruments played into a PC oscilloscope). Which instruments
  are built is the "instruments" list in that file.
  To change a sound, capture it again, rerun the analysis, then rerun this script.

How a table is made
  * 256 entries, one cycle, DAC codes around the 8192 midpoint, exactly like sineTable.
  * The cycle is a sum of the first 9 harmonics with the measured amplitudes AND phases,
    so the waveform SHAPE (not only the spectrum) follows the capture.
  * The cycle is started at its steepest rising zero crossing, so entry 0 is the midpoint
    (a note starts and ends at the DAC idle level, like the existing sine).
  * Harmonics are limited by the sample rate: 20 kHz (Nyquist 10 kHz). The highest note is
    C6 = 1046.5 Hz, so its 9th harmonic (9.4 kHz) is the last that does not fold back. Clarinet
    and trumpet use 9. The marimba keeps a 10th harmonic, its strongest overtone (without it the
    table explains 67% of the capture, with it 99.7%); only the single note C6 is affected, its
    10th harmonic (10.5 kHz) folding to 9.5 kHz as a quiet, very high tone. MAX_HARMONIC is 10.
  * Scaling: the peak deviation never exceeds the sine's 2500 (so the existing x3 gain cannot
    clip), AND the RMS never exceeds the sine's RMS (2500 / sqrt 2), so switching instrument
    does not make the speaker louder. Whichever limit is tighter wins.
"""

import argparse
import json
import math
import re
import sys
import wave
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent / "projects" / "gpiointerrupt_freertos"
AUDIO_C = PROJECT / "audio.c"
HEADER = PROJECT / "audio_instruments.h"
SPECTRA_JSON = HERE / "instrument_spectra.json"

TABLE_SIZE = 256
DAC_IDLE = 8192
SINE_PEAK = 2500                         # same amplitude as the existing sineTable
SINE_RMS = SINE_PEAK / math.sqrt(2.0)
OUTPUT_GAIN = 3                          # AUDIO_OUTPUT_GAIN in audio.c
SAMPLE_RATE = 20000
ENV_ONE = 32768
MAX_HARMONIC = 10


def load_spectra():
    """Return ({name: {n: (amp, phase_rad)}}, raw json) for the instruments listed in the json."""
    if not SPECTRA_JSON.exists():
        raise SystemExit("Missing " + str(SPECTRA_JSON) + " -- run analyze_scope_waveforms.py first")
    data = json.loads(SPECTRA_JSON.read_text())
    out = {}
    for name in data["instruments"]:
        out[name] = {int(h["n"]): (float(h["amp"]), float(h["phase"])) for h in data[name]["harmonics"]}
    return out, data


def waveform(harmonics, u):
    """One cycle of the sum of harmonics at fractional position u (0..1)."""
    return sum(a * math.cos(2.0 * math.pi * n * u + ph) for n, (a, ph) in harmonics.items())


def rising_zero_crossing(harmonics):
    """Fractional cycle position of the steepest rising zero crossing."""
    steps = 8192
    vals = [waveform(harmonics, i / steps) for i in range(steps)]
    best = None
    for i in range(steps):
        v0, v1 = vals[i], vals[(i + 1) % steps]
        if v0 < 0.0 <= v1 and (best is None or v1 - v0 > best[0]):
            best = (v1 - v0, i, v0, v1)
    _, i, v0, v1 = best
    return (i + (-v0 / (v1 - v0))) / steps


def build_table(harmonics):
    """harmonics: {n: (amplitude, phase in radians)} with n <= MAX_HARMONIC."""
    assert max(harmonics) <= MAX_HARMONIC
    u0 = rising_zero_crossing(harmonics)
    raw = [waveform(harmonics, u0 + i / TABLE_SIZE) for i in range(TABLE_SIZE)]
    peak = max(abs(v) for v in raw)
    rms = math.sqrt(sum(v * v for v in raw) / TABLE_SIZE)
    scale = min(SINE_PEAK / peak, SINE_RMS / rms)
    deviation = [int(round(v * scale)) for v in raw]
    table = [DAC_IDLE + d for d in deviation]
    assert table[0] == DAC_IDLE, "table must start at the DAC midpoint"
    assert max(abs(d) for d in deviation) <= SINE_PEAK
    assert 0 <= min(table) and max(table) <= 16383
    return table, scale


def sine_table():
    return [int(round(DAC_IDLE + SINE_PEAK * math.sin(2.0 * math.pi * i / TABLE_SIZE)))
            for i in range(TABLE_SIZE)]


def render_header(spectra, meta):
    out = []
    out.append("/*")
    out.append(" * audio_instruments.h -- {} wave tables for audio.c.".format(", ".join(spectra)))
    out.append(" *")
    out.append(" * GENERATED by test_tools/generate_instrument_tables.py from")
    out.append(" * test_tools/instrument_spectra.json (harmonic amplitudes and phases fitted to the")
    out.append(" * oscilloscope captures in waveforms/). Do not edit by hand.")
    out.append(" *")
    out.append(" * Same format as sineTable in audio.c: 256 entries, one cycle, DAC codes around")
    out.append(" * the 8192 midpoint, peak deviation <= 2500, RMS <= the sine's RMS.")
    out.append(" * Included by audio.c only (the tables are static).")
    out.append(" */")
    out.append("#ifndef AUDIO_INSTRUMENTS_H")
    out.append("#define AUDIO_INSTRUMENTS_H")
    out.append("")
    out.append("#include <stdint.h>")
    for label in spectra:
        name = label + "Table"
        harmonics = spectra[label]
        table, scale = build_table(harmonics)
        recipe = ", ".join("h{}={:.2f}".format(n, a) for n, (a, _) in sorted(harmonics.items()))
        out.append("")
        out.append("/* {}: {} (scale {:.4f})".format(label, meta[label]["source"], scale))
        out.append("   amplitudes relative to the strongest harmonic: {} */".format(recipe))
        out.append("static const uint16_t {}[256] =".format(name))
        out.append("{")
        for row in range(0, TABLE_SIZE, 8):
            out.append("    " + ", ".join(str(v) for v in table[row:row + 8]) +
                       ("," if row + 8 < TABLE_SIZE else ""))
        out.append("};")
    out.append("")
    out.append("#endif /* AUDIO_INSTRUMENTS_H */")
    return "\n".join(out) + "\n"


# ---------------------------------------------------------------- preview ----

def read_define(text, name, default=None):
    m = re.search(r"#define\s+" + name + r"\s+\(?([0-9]+)U?\)?", text)
    if not m:
        if default is not None:
            return default
        raise SystemExit("Could not find #define " + name + " in audio.c")
    return int(m.group(1))


def midi_milli_hz(note):
    return int(round(440000.0 * 2.0 ** ((note - 69) / 12.0)))


def interpolate(table, phase):
    index = phase >> 24
    nxt = (index + 1) & 255
    fraction = (phase >> 8) & 0xFFFF
    first = table[index]
    scaled = (first << 16) + (table[nxt] - first) * fraction + (1 << 15)
    return scaled >> 16


def envelope_gain(n, attack, release_start, release_end, release_samples, decay=0, floor=0):
    """Mirror of envelopeGainQ15() in audio.c, including the optional decay stage."""
    if n < attack:
        return (n * ENV_ONE) // attack
    level = ENV_ONE
    if decay:
        into = n - attack
        if into < decay:
            left = ((decay - into) * ENV_ONE) // decay
            span = ((ENV_ONE - floor) * left) >> 15
            level = floor + ((span * left) >> 15)
        else:
            level = floor
    if n < release_start:
        return level
    if n < release_end:
        return (level * (((release_end - n) * ENV_ONE) // release_samples)) >> 15
    return 0


def render_note(table, note, duration_ms, attack_ms, release_ms, decay_ms=0, floor_percent=0):
    """Mirror audio.c: DDS phase, interpolation, Q15 envelope, x3 gain, clamp."""
    samples = duration_ms * (SAMPLE_RATE // 1000)
    usable = max(samples - 2, 0)                      # ENV_END_GUARD_SAMPLES = 2
    attack = attack_ms * (SAMPLE_RATE // 1000)
    release = release_ms * (SAMPLE_RATE // 1000)
    if attack + release > usable:
        attack = release = usable // 2
    release_end = usable
    release_start = usable - release
    decay = decay_ms * (SAMPLE_RATE // 1000)
    floor = (floor_percent * ENV_ONE) // 100
    increment = (midi_milli_hz(note) << 32) // (SAMPLE_RATE * 1000)
    phase = 0
    codes = []
    for n in range(samples):
        gain = envelope_gain(n, attack, release_start, release_end, release, decay, floor)
        centered = (interpolate(table, phase) - DAC_IDLE) * OUTPUT_GAIN
        centered = int(centered * gain / ENV_ONE)     # truncates toward zero like C
        codes.append(min(max(DAC_IDLE + centered, 0), 16383))
        phase = (phase + increment) & 0xFFFFFFFF
    return codes


def write_preview(directory, name, table, attack_ms, release_ms, decay_ms=0, floor_percent=0):
    # C major scale up and down, 350 ms notes, 40 ms rests.
    scale = [60, 62, 64, 65, 67, 69, 71, 72, 71, 69, 67, 65, 64, 62, 60]
    pcm = []
    for note in scale:
        pcm.extend(render_note(table, note, 350, attack_ms, release_ms, decay_ms, floor_percent))
        pcm.extend([DAC_IDLE] * (40 * (SAMPLE_RATE // 1000)))
    path = Path(directory) / "preview_{}.wav".format(name)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SAMPLE_RATE)
        w.writeframes(b"".join(int(max(min((c - DAC_IDLE) * 4, 32767), -32768)).to_bytes(2, "little", signed=True)
                               for c in pcm))
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--check", action="store_true", help="do not write; fail if audio_instruments.h is stale")
    parser.add_argument("--preview", metavar="DIR", help="also write preview_*.wav files into DIR")
    args = parser.parse_args()

    spectra, meta = load_spectra()
    text = render_header(spectra, meta)
    if args.check:
        current = HEADER.read_text() if HEADER.exists() else ""
        if current != text:
            print("FAIL audio_instruments.h is missing or differs from the generator output")
            return 1
        print("PASS audio_instruments.h matches the generator")
    else:
        HEADER.write_text(text, newline="\n")
        print("Wrote", HEADER)

    for name in spectra:
        table, scale = build_table(spectra[name])
        deviation = [v - DAC_IDLE for v in table]
        rms = math.sqrt(sum(d * d for d in deviation) / TABLE_SIZE)
        print("{:9s} peak {:5d} (limit {})  rms {:7.1f} (sine {:.1f})  harmonics up to {}".format(
            name, max(abs(d) for d in deviation), SINE_PEAK, rms, SINE_RMS, max(spectra[name])))

    if args.preview:
        audio = AUDIO_C.read_text()
        Path(args.preview).mkdir(parents=True, exist_ok=True)
        specs = [("sine", sine_table(), read_define(audio, "ENV_RAMP_MS"), read_define(audio, "ENV_RAMP_MS"), 0, 0)]
        for name in spectra:
            specs.append((name, build_table(spectra[name])[0],
                          read_define(audio, name.upper() + "_ATTACK_MS"), read_define(audio, name.upper() + "_RELEASE_MS"),
                          read_define(audio, name.upper() + "_DECAY_MS", 0),
                          read_define(audio, name.upper() + "_DECAY_FLOOR_PERCENT", 0)))
        for name, table, attack_ms, release_ms, decay_ms, floor_percent in specs:
            print("Wrote", write_preview(args.preview, name, table, attack_ms, release_ms, decay_ms, floor_percent))
    return 0


if __name__ == "__main__":
    sys.exit(main())
