# Next presentation — outline only (no deck created)

Four content slides and your own demo slide. Everything on slides 1–4 is true today; replace the placeholders in
slide 4 and 5 only with what you actually measure on the board.

## Slide 1 — File/module organization and the shared globals

* From one 2,500-line `gpiointerrupt.c` to seven focused modules + one shared header:
  `audio · midi · playback · uart_task · control_task` (+ `main_freertos`, `globals`).
* One rule per file (what it owns): audio = DAC/Timer2; midi = pure parser; playback = Timer3 scheduling;
  uart_task = UART0 + framing; control_task = lifecycle + task creation.
* **Show:** the `globals.h` / `globals.c` excerpt (`extern Globals Glo;` / `Globals Glo = {0};`) and the `Glo.Bios` /
  `Glo.Diagnostics` split. Say: the header *declares*, the source *allocates*; include guards stop double processing but
  do not protect data — that is what semaphores and mutexes are for.
* Sources: `IMPLEMENTATION_SUMMARY.md` §2–3.

## Slide 2 — Task / semaphore flow

* Three tasks: **UART0ReadTask (3)** receives, **PayloadTask (2)** validates and starts, **MonitorTask (1)** shows life.
* Real wake-ups: UART interrupt → `UARTReadSem` → UART task; payload complete → `PayloadSem` → PayloadTask; melody end
  (Timer3 ISR) → `PayloadSem` → `DONE`. A mutex (`UARTTxMutex`) keeps each reply in one piece.
* **Show:** the arrow diagram (ISR → ring → semaphore → task → semaphore → task) and the two excerpts:
  `xSemaphoreGiveFromISR(Glo.Bios.UARTReadSem …)` / `xSemaphoreTake(…, 10 ms)` and
  `Uart_beginReply(); … Uart_endReply();`.
* Mention the two priority scales: task priorities vs NVIC priorities (audio ISR at 0, above the kernel ceiling).
* Sources: `IMPLEMENTATION_SUMMARY.md` §4–5, §7.

## Slide 3 — What stayed the same: the monophonic architecture

* Same sound path: 20 kHz sample ISR, 256-entry sine table with linear interpolation, 5 ms attack/release envelopes,
  Timer3 note/rest scheduling, STOP at a frame boundary, busy rejection, the same serial replies.
* Verified unchanged by script: the sine table and 14 constants equal the baseline; every moved function is listed.
* "A modest architecture milestone, not a new synthesis feature" — no polyphony, DMA or protocol change.
* Sources: `evidence/offline_waveform_math.txt`, `offline_code_moves.txt`.

## Slide 4 — Actual verification (keep the categories separate)

| Done now (no board) | Pending on your board |
|---|---|
| CCS headless build: 0 errors, 0 warnings; flash 33.7 KB, RAM 68.6 KB | flash and run |
| link inspection: one `main`, vectors → FreeRTOS handlers, no NoRTOS | `Glo.Bios` handles + wake counters |
| architecture / ISR rules / header compile checks | tests A–E, D3–D5 regressions, R1–R3 |
| waveform arithmetic + unchanged vs baseline | listening: pitch, clicks, silence after STOP |
| static stack ≥ 2.7× margin; kernel == upstream V10.2.1 | `AudioIsrMaxCycles`, real stack/heap minima |

* One honest sentence: "Hardware results are not in yet — the board test is the next step."

## Slide 5 — Your demo (you create it)

Suggested content: video of a melody with the LED blinking → STOP cuts the sound → silence → a new file → normal
completion; plus the `Glo` watch window screenshot and the serial log. Checklist in `FINAL_TEST_PLAN.md` §6.
