# Final test plan — one consolidated hardware session

The commands are in `START_HERE_TESTING.md` (section numbers below point there). This file says **what each test is for,
what a pass looks like, and which kind of evidence it produces**. Evidence categories are kept separate on purpose:

* **OFFLINE** — already done without a board (`evidence\offline_*.txt`); listed here only so nothing is re-claimed as hardware.
* **SERIAL** — the script's UART sequence and coarse durations (the script prints PASS).
* **LISTEN** — you judge the sound; the scripts cannot.
* **CCS** — you read `Glo` in the Expressions view.

Nothing in the "Result" column is filled in: the board has not been run.

## 1. Build and startup

| ID | Test | Expected | Category | How |
|---|---|---|---|---|
| 1.1 | Clean build of both projects | 0 errors; kernel library built as a reference; one `.out` | OFFLINE done (headless CCS 21); redo in the GUI | §1 |
| 1.2 | Exactly one `main`, one startup, no NoRTOS library, no old monolith | symbols/map checked | OFFLINE done (`offline_link_output.txt`) | §7 |
| 1.3 | Required module pairs built; no `#include` of a `.c`; one definition of `Glo`, tables, buffers | | OFFLINE done (`offline_architecture.txt`) | §7 |
| 1.4 | Versions, stack/heap allocation recorded | CCS 21.0.1, GCC 9.2.1, SDK 4.20.00.12, FreeRTOS 10.2.1; RAM 68,624 B; heap 32 KB; MSP stack 2 KB | OFFLINE done (`dependencies\DEPENDENCIES.md`, `build_output\size_report.txt`) | |
| 1.5 | Flash and run; serial banner/IDLE compatible with the sender; no unsolicited text | `SMID v2 READY`, `IDLE` once after start; nothing else while idle | SERIAL + CCS | §2, §4.0 |

## 2. The RTOS objects are real and used

| ID | Test | Expected | Category |
|---|---|---|---|
| 2.1 | `Glo.Bios` handles | six non-zero handles | CCS (§3) |
| 2.2 | Idle behaviour: tasks blocked, not spinning | `UartTimeoutPasses` +≈100/s; `UartWakeCount`, `PayloadWakeCount`, `RxIsrCount` flat; `MonitorTicks` +4/s | CCS (§3) |
| 2.3 | Producer/consumer sites (code excerpts) | table in `IMPLEMENTATION_SUMMARY.md` §4 and `offline_architecture.txt` | OFFLINE done |
| 2.4 | During a transfer | `RxIsrCount`, `RxBytes`, `UartWakeCount` rise; afterwards `PayloadWakeCount` rises and `TransferSuccessCount` increments | CCS after §4.4 |
| 2.5 | During playback | LED keeps blinking; `MonitorTicks` keeps advancing; audio smooth | LISTEN + CCS |
| 2.6 | Mutex boundary | replies never interleave (STOP during `DONE`, R1) | SERIAL (R1 + D4 checks) |

## 3. Audio (unchanged contract)

| ID | Test | Expected | Category | How |
|---|---|---|---|---|
| 3.1 | Waveform math, constants, table identical to baseline | 0 failures | OFFLINE done (`offline_waveform_math.txt`) | |
| 3.2 | Tests A–E | `PASS: milestone tests A, B, C, D, E …` and the listening table | SERIAL + LISTEN | §4.1 |
| 3.3 | Low/middle/high notes, repeated/short notes, rests, Twinkle, Ode to Joy, five consecutive runs | as in the baseline; short-note faintness expected; no new popping; silence after STOP/DONE | LISTEN | §4.1 |
| 3.4 | Interpolation and envelope still enabled | `AUDIO_USE_INTERPOLATION 1`, `AUDIO_USE_ENVELOPE 1` in `audio.c` | OFFLINE done | |

## 4. Control and transfer regressions

| ID | Test | Expected | Category | How |
|---|---|---|---|---|
| 4.1 | Success sequence | `ACK_READY → ACK_RECEIVED → ACK_VALID → PLAYING → DONE → IDLE` with the same length/CRC fields | SERIAL | §4.0, §4.1 |
| 4.2 | STOP mid-sustain and during rapid notes; new file afterwards | `ACK_STOPPED`, `IDLE`, immediate silence, next file plays | SERIAL + LISTEN | §4.1 D, §4.3 |
| 4.3 | Busy rejection then recovery | `ERR_BUSY`, `IDLE`; original note continues; STOP works | SERIAL + LISTEN | §4.3 `check_playback_control.py` check 2 |
| 4.4 | CRC error before `ACK_RECEIVED`; malformed MIDI after a valid transfer; no playback on error | `ERR_CRC` (no `ACK_RECEIVED`); `ERR_MIDI` after `ACK_RECEIVED`; silence | SERIAL + LISTEN | §4.3 `check_recovery.py`, `check_midi_compatibility.py` |
| 4.5 | Truncated header / payload time out **without another incoming byte** | `ERR_TIMEOUT` then `IDLE`; later file works | SERIAL | §4.2 R2; §4.3 recovery check 3 |
| 4.6 | Oversize request; maximum payload; maximum notes | `ERR_SIZE`; 16,384-byte file accepted; 1,024 notes accepted; 1,025 → `ERR_NOTE_CAPACITY` | SERIAL | §4.3, §4.4 |
| 4.7 | Transfer with `MonitorTask` running; RX overflow/error counters | `RxOverflowCount = RxErrorCount = 0` after §4.4 | CCS | §4.4 |
| 4.8 | Extra bytes during hand-off / `VALIDATE` are not silently ignored | R3: `ERR_SIZE`+`IDLE` or STOP honoured in order | SERIAL | §4.2 R3 |
| 4.9 | Rapid STOP/restart: no stale completion or delayed start | R1 passes; nothing plays after any STOP | SERIAL + LISTEN | §4.2 R1 |

## 5. Timing and memory

| ID | Test | Expected | Category |
|---|---|---|---|
| 5.1 | Audio ISR maximum | read `AudioIsrMaxCycles`; µs = cycles ÷ 120; must stay well under 6,000 cycles (50 µs); compare with the baseline value | CCS (§5) |
| 5.2 | Task stacks | `StackFreeMin*Words` (words) show margin; static estimate says ≥ 2.7× | CCS (§5); OFFLINE estimate done |
| 5.3 | Heap, assertions, overflow, malloc failure | `HeapMinFreeBytes` well above 0; all fault counters 0 | CCS (§5) |

Limits of 5.1: the profiler brackets the ISR body with the DWT cycle counter; it excludes hardware entry/exit
(≈12 cycles each way), says nothing about interrupt latency or jitter caused by masking, and runs at `-O0` like the baseline.

## 6. Evidence to collect for the presentation

* Code excerpts: `IMPLEMENTATION_SUMMARY.md` §3 (`extern Globals Glo` + single definition), §4 (semaphore give/take that
  triggers work; mutex around a complete reply).
* Screenshot of the `Glo` expression (Bios + Diagnostics) at idle and after a transfer.
* Protocol logs in `evidence\board\` (success, STOP, error recovery).
* Video: a melody with the LED blinking, a STOP, silence, a new file, normal completion.
* State results by category (build / offline / serial / listening / timing) — never merge them.

If a check fails, use `START_HERE_TESTING.md` §6 to localise it with the checkpoints; do not abandon FreeRTOS or accept
a header-only result without first finding the stage that introduced the defect.
