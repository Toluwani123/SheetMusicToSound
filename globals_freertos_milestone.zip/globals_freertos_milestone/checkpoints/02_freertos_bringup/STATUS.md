# Checkpoint 02 — freertos_bringup (Stage 2: correct FreeRTOS integration)

**What it is.** The final FreeRTOS infrastructure (kernel library project, `FreeRTOSConfig.h`, SDK startup + DPL, FreeRTOS
`.lds`, `syscfg` with `RTOS = FreeRTOS`, `main_freertos.c`) running the Stage 1 modules from ONE temporary task
(`vTaskDelay(1)` polling) plus a monitor task. **Not for transfer tests:** a 1 ms poll can overrun the 16-byte UART FIFO at full
rate. It exists to prove startup, vectors, linking and scheduling before the real design was added.

**Verified.** Headless CCS build of both projects: 0 errors, 0 warnings (`evidence/`). One `main`, one startup
(`resetISR`), kernel handlers present, no NoRTOS library; text 30,640 / data 1,112 / bss 66,476 B.
Integration facts: FreeRTOS V10.2.1 (the SDK-validated release), SDK `FreeRTOSConfig.h` for this board (tick 1 kHz, 3 priority
bits, `configMAX_SYSCALL_INTERRUPT_PRIORITY` 1), SDK startup sets 120 MHz and routes SVC/PendSV/SysTick to the kernel;
DriverLib `IntRegister` copies that vector table, so `TimerIntRegister` is safe; the kernel uses SysTick, so Timers 2/3/4 are free.

**Hardware behaviour.** Not run.
