/*
 * main_freertos.c -- STAGE 2 BRING-UP ONLY.
 *
 * One temporary task runs the Stage 1 polled receiver (1 ms sleep, so the 16-byte
 * UART FIFO can overrun at full rate: NOT for transfer tests) next to MonitorTask,
 * to prove startup, vectors, DPL, linking and scheduling before the real task
 * design is added in Stage 3.
 *
 * Startup path (FreeRTOS, replaces main_nortos.c / NoRTOS_start):
 *   reset -> startup_msp432e4_gcc.c (FPU on, 120 MHz clock, .data/.bss) -> main()
 * The same startup file already places the kernel's SVC/PendSV/SysTick
 * handlers in the vector table, so DriverLib's later TimerIntRegister() /
 * UARTIntRegister() copy of that table into RAM keeps them.
 */
#include <stdint.h>
#include <stddef.h>

#include <FreeRTOS.h>
#include <task.h>

#include <ti/drivers/Board.h>
#include <ti/drivers/GPIO.h>

#include "globals.h"
#include "audio.h"
#include "control_task.h"
#include "uart_task.h"
#include "ti_drivers_config.h"

static void BringupTask(void *arg)
{
    (void)arg;
    for (;;)
    {
        Uart_service();
        Control_service();
        vTaskDelay(pdMS_TO_TICKS(1));
    }
}

static void BringupMonitorTask(void *arg)
{
    (void)arg;
    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(250));
        GPIO_toggle(CONFIG_GPIO_LED_0);
        Glo.Diagnostics.MonitorTicks++;
    }
}

/* Fault paths: record, make the output silent on a best-effort basis, stop. */
static void Fault_halt(void)
{
    Audio_stopNote();
    taskDISABLE_INTERRUPTS();
    for (;;)
    {
    }
}

int main(void)
{
    Board_init();      /* SDK board setup (Power_init, DMA flash access); clock is set by the startup code */
    GPIO_init();       /* TI GPIO driver: LEDs used by MonitorTask */

    /* Proven audio hardware, PH2 control and Timer2 setup, unchanged. */
    Audio_init();

    Control_init();
    if ((xTaskCreate(BringupTask, "Bringup", 768U, NULL, 2U, &Glo.Bios.UART0ReadTask) != pdPASS) ||
        (xTaskCreate(BringupMonitorTask, "Monitor", 256U, NULL, 1U, &Glo.Bios.MonitorTask) != pdPASS))
    {
        Glo.Diagnostics.CreateFailCount++;
        Fault_halt();
    }

    vTaskStartScheduler();

    /* Only reached if the scheduler could not allocate its idle/timer task. */
    Glo.Diagnostics.CreateFailCount++;
    Fault_halt();
    return 0;
}

/* ------------------------------------------------------------------------
 * Kernel hooks (enabled in FreeRTOSConfig.h)
 * --------------------------------------------------------------------- */

void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName)
{
    uint32_t i;

    (void)xTask;
    Glo.Diagnostics.StackOverflowCount++;
    for (i = 0U; (i < (configMAX_TASK_NAME_LEN - 1U)) && (pcTaskName[i] != '\0'); i++)
    {
        Glo.Diagnostics.StackOverflowTaskName[i] = pcTaskName[i];
    }
    Fault_halt();
}

void vApplicationMallocFailedHook(void)
{
    Glo.Diagnostics.MallocFailCount++;
    Fault_halt();
}

/* configASSERT() target (FreeRTOSConfig.h). */
void vAssertCalled(const char *pcFile, int iLine)
{
    (void)pcFile;
    Glo.Diagnostics.AssertCount++;
    Glo.Diagnostics.AssertLine = (uint32_t)iLine;
    Fault_halt();
}
