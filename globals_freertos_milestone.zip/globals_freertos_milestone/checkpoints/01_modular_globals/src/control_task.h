/*
 * control_task.h -- protocol lifecycle coordinator (control_task.c).
 *
 * Validates a received payload (CRC, MIDI parse), starts playback in the
 * proven reply order, handles STOP and reports completion. STAGE 1 runs it
 * from the NoRTOS mainThread adapter; later stages move it into PayloadTask.
 */
#ifndef CONTROL_TASK_H
#define CONTROL_TASK_H

/* Initialise playback and the transport with the controller's hooks. */
void Control_init(void);

/* STAGE 1 ONLY: one pass of payload validation + completion reporting. */
void Control_service(void);

#endif /* CONTROL_TASK_H */
