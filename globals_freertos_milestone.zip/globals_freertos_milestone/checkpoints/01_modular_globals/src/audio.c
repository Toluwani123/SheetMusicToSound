/*
 * audio.c -- DAC8311 output, sine/pitch tables, interpolation, envelope and
 * the Timer2 sample ISR.
 *
 * Moved verbatim from gpiointerrupt.c (baseline latestb4rtos.zip); only names
 * and ownership changed. Hardware owned here: SSI2 (PD3 clock, PD1 data),
 * PN3 DAC SYNC, PH2 amplifier shutdown (HIGH = off) and Timer2.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/*
 * Tell DriverLib exactly which MSP432E4 device
 * we are compiling for.
 *
 * This MUST appear before driverlib.h.
 */
#ifndef __MSP432E401Y__
#define __MSP432E401Y__
#endif

#include <ti/devices/msp432e4/driverlib/driverlib.h>

#include "audio.h"
#include "globals.h"


/* ============================================================
 * AUDIO CONFIGURATION
 * ============================================================
 */
#define DAC_SPI_BIT_RATE_HZ      2000000U

/*
 * DAC8311 midpoint.
 *
 * DAC range = 0 ... 16383
 */
#define DAC_IDLE_CODE            8192U


/*
 * Audio sample rate:
 *
 * 120 MHz / 6000 = 20,000 samples/second.
 */
#define AUDIO_SAMPLE_RATE_HZ     20000U
#define AUDIO_TIMER_COUNTS       6000U


#define SINE_TABLE_SIZE          256U
#define SINE_TABLE_BITS          8U

/* Highest DAC8311 code (14-bit). Every output is clamped to 0..this. */
#define DAC_MAX_CODE             16383U

/* Existing output gain applied to the table's deviation from midpoint. */
#define AUDIO_OUTPUT_GAIN        3


/* ============================================================
 * WAVEFORM QUALITY OPTIONS (Milestone: interpolation + ramps)
 * ============================================================
 *
 * Set either option to 0 and rebuild to reproduce the previous
 * nearest-entry / hard-switched output for before/after recordings.
 * With both set to 0 the DAC codes equal the pre-milestone firmware.
 */
#ifndef AUDIO_USE_INTERPOLATION
#define AUDIO_USE_INTERPOLATION  1
#endif
#ifndef AUDIO_USE_ENVELOPE
#define AUDIO_USE_ENVELOPE       1
#endif

/* Fraction bits kept between adjacent table entries (Q16). The lowest
 * 8 phase bits are dropped: they are far below one DAC code step.
 */
#define INTERP_FRACTION_BITS     16U

/* Linear attack/release length. 5 ms = 100 samples at 20 kHz. */
#define ENV_RAMP_MS              5U
#define ENV_RAMP_SAMPLES         ((AUDIO_SAMPLE_RATE_HZ / 1000U) * ENV_RAMP_MS)

/* The release reaches zero this many samples before the scheduled Note Off,
 * absorbing the small start offset between Timer2 and Timer3.
 */
#define ENV_END_GUARD_SAMPLES    2U

/* Q15 gain: 0 = silence, ENV_GAIN_ONE = existing normal amplitude. */
#define ENV_GAIN_ONE             32768U

/* Record audio-ISR execution time with the Cortex-M4 cycle counter. */
#define AUDIO_ISR_PROFILE        1

/* Bit-mask wraparound below is only valid for a power-of-two table. */
typedef char sineTableSizeIsPowerOfTwo[
    ((SINE_TABLE_SIZE == (1U << SINE_TABLE_BITS)) &&
     ((SINE_TABLE_SIZE & (SINE_TABLE_SIZE - 1U)) == 0U)) ? 1 : -1];


/* ============================================================
 * SINE-WAVE TABLE
 * ============================================================
 */

/* 256 samples of one cycle: round(8192 + 2500*sin(2*pi*i/256)).
 * Precomputed constants: no runtime floating-point sine calculation.
 * The audio ISR retains its existing x3 gain and 20 kHz update rate.
 */
static const uint16_t sineTable[SINE_TABLE_SIZE] =
{
    8192, 8253, 8315, 8376, 8437, 8498, 8559, 8619,
    8680, 8740, 8799, 8859, 8918, 8976, 9034, 9092,
    9149, 9205, 9261, 9316, 9370, 9424, 9477, 9529,
    9581, 9632, 9681, 9730, 9778, 9825, 9871, 9916,
    9960, 10003, 10044, 10085, 10125, 10163, 10200, 10236,
    10271, 10304, 10336, 10367, 10397, 10425, 10452, 10478,
    10502, 10524, 10546, 10566, 10584, 10601, 10617, 10631,
    10644, 10655, 10665, 10673, 10680, 10685, 10689, 10691,
    10692, 10691, 10689, 10685, 10680, 10673, 10665, 10655,
    10644, 10631, 10617, 10601, 10584, 10566, 10546, 10524,
    10502, 10478, 10452, 10425, 10397, 10367, 10336, 10304,
    10271, 10236, 10200, 10163, 10125, 10085, 10044, 10003,
    9960, 9916, 9871, 9825, 9778, 9730, 9681, 9632,
    9581, 9529, 9477, 9424, 9370, 9316, 9261, 9205,
    9149, 9092, 9034, 8976, 8918, 8859, 8799, 8740,
    8680, 8619, 8559, 8498, 8437, 8376, 8315, 8253,
    8192, 8131, 8069, 8008, 7947, 7886, 7825, 7765,
    7704, 7644, 7585, 7525, 7466, 7408, 7350, 7292,
    7235, 7179, 7123, 7068, 7014, 6960, 6907, 6855,
    6803, 6752, 6703, 6654, 6606, 6559, 6513, 6468,
    6424, 6381, 6340, 6299, 6259, 6221, 6184, 6148,
    6113, 6080, 6048, 6017, 5987, 5959, 5932, 5906,
    5882, 5860, 5838, 5818, 5800, 5783, 5767, 5753,
    5740, 5729, 5719, 5711, 5704, 5699, 5695, 5693,
    5692, 5693, 5695, 5699, 5704, 5711, 5719, 5729,
    5740, 5753, 5767, 5783, 5800, 5818, 5838, 5860,
    5882, 5906, 5932, 5959, 5987, 6017, 6048, 6080,
    6113, 6148, 6184, 6221, 6259, 6299, 6340, 6381,
    6424, 6468, 6513, 6559, 6606, 6654, 6703, 6752,
    6803, 6855, 6907, 6960, 7014, 7068, 7123, 7179,
    7235, 7292, 7350, 7408, 7466, 7525, 7585, 7644,
    7704, 7765, 7825, 7886, 7947, 8008, 8069, 8131
};


/* ============================================================
 * MIDI NOTE FREQUENCY TABLE
 * ============================================================
 *
 * Frequencies are stored in milli-Hz.
 *
 * Example:
 *
 * MIDI 60:
 * 261.626 Hz
 * =
 * 261626 milli-Hz
 *
 * This avoids using floating point.
 */

static const uint32_t midiFrequencyMilliHz[] =
{
    130813,     /* 48 C3  */
    138591,     /* 49 C#3 */
    146832,     /* 50 D3  */
    155563,     /* 51 D#3 */
    164814,     /* 52 E3  */
    174614,     /* 53 F3  */
    184997,     /* 54 F#3 */
    195998,     /* 55 G3  */
    207652,     /* 56 G#3 */
    220000,     /* 57 A3  */
    233082,     /* 58 A#3 */
    246942,     /* 59 B3  */

    261626,     /* 60 C4  */
    277183,     /* 61 C#4 */
    293665,     /* 62 D4  */
    311127,     /* 63 D#4 */
    329628,     /* 64 E4  */
    349228,     /* 65 F4  */
    369994,     /* 66 F#4 */
    391995,     /* 67 G4  */
    415305,     /* 68 G#4 */
    440000,     /* 69 A4  */
    466164,     /* 70 A#4 */
    493883,     /* 71 B4  */

    523251,     /* 72 C5  */
    554365,     /* 73 C#5 */
    587330,     /* 74 D5  */
    622254,     /* 75 D#5 */
    659255,     /* 76 E5  */
    698456,     /* 77 F5  */
    739989,     /* 78 F#5 */
    783991,     /* 79 G5  */
    830609,     /* 80 G#5 */
    880000,     /* 81 A5  */
    932328,     /* 82 A#5 */
    987767,     /* 83 B5  */

    1046502     /* 84 C6  */
};

/* ============================================================
 * AUDIO STATE
 * ============================================================
 */

/* Diagnostics live in Glo.Diagnostics: LastDacCode, AudioInterruptCount,
 * AudioIsrLastCycles, AudioIsrMaxCycles (single writer: the audio paths). */

static volatile uint32_t g_phaseAccumulator = 0;
static volatile uint32_t g_phaseIncrement = 0;

static volatile bool g_noteActive = false;

static volatile uint8_t g_currentMidiNote =
    AUDIO_NOTE_NONE;


/* Per-note envelope, in audio samples since Note On. Written only while
 * Timer2 is disabled (audioStartMidiNote/audioStopMidiNote), read by
 * timer2ISR. Release ends at g_envReleaseEnd, before the scheduled Note Off.
 */
static volatile uint32_t g_envSampleIndex = 0U;
static volatile uint32_t g_envAttackSamples = 0U;
static volatile uint32_t g_envReleaseStart = 0U;
static volatile uint32_t g_envReleaseSamples = 0U;
static volatile uint32_t g_envReleaseEnd = 0U;

/* CCS watch values: audio ISR duration in CPU cycles (120 cycles = 1 us).
 * Max is cleared when each melody starts; write 0 in CCS to clear manually.
 */

#if AUDIO_ISR_PROFILE
#define CORE_DEMCR               (*(volatile uint32_t *)0xE000EDFCU)
#define CORE_DWT_CTRL            (*(volatile uint32_t *)0xE0001000U)
#define CORE_DWT_CYCCNT          (*(volatile uint32_t *)0xE0001004U)
#define CORE_DEMCR_TRCENA        (1U << 24)
#define CORE_DWT_CYCCNTENA       (1U << 0)
#endif


/* ============================================================
 * MIDI NOTE -> FREQUENCY
 * ============================================================
 */

static uint32_t midiNoteToFrequencyMilliHz(
    uint8_t midiNote
)
{
    if ((midiNote < AUDIO_NOTE_MIN) ||
        (midiNote > AUDIO_NOTE_MAX))
    {
        return 0;
    }


    return midiFrequencyMilliHz[
        midiNote - AUDIO_NOTE_MIN
    ];
}

/* ============================================================
 * DAC8311 WRITE
 * ============================================================
 */

static void DAC8311_write(
    uint16_t sample
)
{
    uint32_t dummyData;


    /*
     * DAC8311 is 14-bit.
     */
    sample &= 0x3FFFU;


    /*
     * Begin transaction.
     *
     * DAC SYNC is active LOW.
     *
     * Your working jumper setup uses PN3.
     */
    GPIOPinWrite(
        GPIO_PORTN_BASE,
        GPIO_PIN_3,
        0
    );


    /*
     * Send complete 16-bit DAC word.
     */
    SSIDataPut(
        SSI2_BASE,
        (uint32_t)sample
    );


    /*
     * Wait until SPI transmission has finished.
     */
    while (SSIBusy(SSI2_BASE))
    {
    }


    /*
     * Finish DAC transaction.
     */
    GPIOPinWrite(
        GPIO_PORTN_BASE,
        GPIO_PIN_3,
        GPIO_PIN_3
    );


    /*
     * Drain dummy RX data.
     */
    while (SSIDataGetNonBlocking(
               SSI2_BASE,
               &dummyData))
    {
    }


    Glo.Diagnostics.LastDacCode =
        sample;
}

/* ============================================================
 * TIMER2 AUDIO ISR
 * ============================================================
 *
 * Timer2 has ONE job:
 *
 * generate audio samples at 20 kHz.
 */

/*
 * Linear interpolation between adjacent sine-table entries.
 *
 * 32-bit phase = [ 8-bit index | 16-bit fraction | 8 unused bits ].
 * Position 20.25 -> index 20, next 21, fraction 0.25 (16384/65536).
 *
 *     sample = first + fraction * (next - first)
 *
 * next wraps 255 -> 0 by mask (table length is a power of two), so the
 * last entry interpolates toward entry 0 and never reads past the table.
 * The difference is signed (falling half of the sine). The scaled sum
 * first*2^16 + difference*fraction lies between first and next scaled,
 * so it is never negative: it is shifted as unsigned, rounding half up.
 * Maximum 10692*2^16 + 2^15 < 2^32, so no overflow.
 */
static inline uint32_t sineTableInterpolate(
    uint32_t phase
)
{
    uint32_t index =
        phase >> (32U - SINE_TABLE_BITS);

    uint32_t nextIndex =
        (index + 1U) & (SINE_TABLE_SIZE - 1U);

    uint32_t fraction =
        (phase >> (32U - SINE_TABLE_BITS - INTERP_FRACTION_BITS)) &
        ((1U << INTERP_FRACTION_BITS) - 1U);

    int32_t first =
        (int32_t)sineTable[index];

    int32_t difference =
        (int32_t)sineTable[nextIndex] - first;

    uint32_t scaled =
        ((uint32_t)first << INTERP_FRACTION_BITS) +
        (uint32_t)(difference * (int32_t)fraction) +
        (1U << (INTERP_FRACTION_BITS - 1U));

    return scaled >> INTERP_FRACTION_BITS;
}


/*
 * Linear attack/sustain/release gain in Q15 for the n-th sample of a note.
 * Attack: 0 -> ONE over g_envAttackSamples. Release: ONE -> 0, reaching
 * exactly 0 at g_envReleaseEnd and staying 0 until the note is stopped.
 * Each divide uses an exact ratio, so no step truncation can leave a
 * residual level; operands are at most ENV_RAMP_SAMPLES * 2^15.
 */
static inline uint32_t envelopeGainQ15(
    uint32_t n
)
{
    uint32_t attack = g_envAttackSamples;
    uint32_t releaseStart = g_envReleaseStart;
    uint32_t releaseEnd = g_envReleaseEnd;

    if (n < attack)
    {
        return (n * ENV_GAIN_ONE) / attack;
    }
    if (n < releaseStart)
    {
        return ENV_GAIN_ONE;
    }
    if (n < releaseEnd)
    {
        return ((releaseEnd - n) * ENV_GAIN_ONE) / g_envReleaseSamples;
    }
    return 0U;
}


static void timer2ISR(void)
{
    uint32_t phase;

    uint32_t waveform;

    uint32_t gain;

    int32_t centeredSample;

    int32_t output;

#if AUDIO_ISR_PROFILE
    uint32_t startCycles = CORE_DWT_CYCCNT;
    uint32_t elapsedCycles;
#endif


    TimerIntClear(
        TIMER2_BASE,
        TIMER_TIMA_TIMEOUT
    );


    if (g_noteActive)
    {
        /*
         * Read the phase once so index and fraction
         * come from the same accumulator value.
         */
        phase = g_phaseAccumulator;

#if AUDIO_USE_INTERPOLATION
        waveform = sineTableInterpolate(phase);
#else
        waveform = sineTable[phase >> (32U - SINE_TABLE_BITS)];
#endif

#if AUDIO_USE_ENVELOPE
        gain = envelopeGainQ15(g_envSampleIndex);
        if (g_envSampleIndex != UINT32_MAX)
        {
            g_envSampleIndex++;
        }
#else
        gain = ENV_GAIN_ONE;
#endif

        /*
         * Gain is applied to the deviation from the DAC midpoint, then the
         * midpoint is restored. Signed division truncates toward zero, so
         * positive and negative halves scale symmetrically (no DC drift).
         * |7500 * 32768| < 2^31.
         */
        centeredSample =
            ((int32_t)waveform - (int32_t)DAC_IDLE_CODE) *
            AUDIO_OUTPUT_GAIN;

        centeredSample =
            (centeredSample * (int32_t)gain) /
            (int32_t)ENV_GAIN_ONE;

        output =
            (int32_t)DAC_IDLE_CODE + centeredSample;

        if (output < 0)
        {
            output = 0;
        }
        else if (output > (int32_t)DAC_MAX_CODE)
        {
            output = (int32_t)DAC_MAX_CODE;
        }


        DAC8311_write(
            (uint16_t)output
        );


        /*
         * Advance oscillator phase. Unsigned 32-bit
         * wraparound is the intended cycle wrap.
         */
        g_phaseAccumulator =
            phase + g_phaseIncrement;
    }


    Glo.Diagnostics.AudioInterruptCount++;

#if AUDIO_ISR_PROFILE
    elapsedCycles = CORE_DWT_CYCCNT - startCycles;
    Glo.Diagnostics.AudioIsrLastCycles = elapsedCycles;
    if (elapsedCycles > Glo.Diagnostics.AudioIsrMaxCycles)
    {
        Glo.Diagnostics.AudioIsrMaxCycles = elapsedCycles;
    }
#endif
}

/* ============================================================
 * AUDIO HARDWARE INITIALIZATION
 * ============================================================
 */

static void Audio_hardwareInit(void)
{
    uint32_t dummyData;


    /*
     * Required GPIO / SSI hardware.
     */
    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_GPIOD
    );

    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_GPION
    );

    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_GPIOH
    );

    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_SSI2
    );


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_GPIOD))
    {
    }


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_GPION))
    {
    }


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_GPIOH))
    {
    }


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_SSI2))
    {
    }


    /*
     * PD3 = SSI2CLK
     */
    GPIOPinConfigure(
        GPIO_PD3_SSI2CLK
    );


    /*
     * PD1 = SSI2XDAT0 / MOSI
     */
    GPIOPinConfigure(
        GPIO_PD1_SSI2XDAT0
    );


    GPIOPinTypeSSI(
        GPIO_PORTD_BASE,
        GPIO_PIN_1 |
        GPIO_PIN_3
    );


    /*
     * PN3 = DAC SYNC.
     */
    GPIOPinTypeGPIOOutput(
        GPIO_PORTN_BASE,
        GPIO_PIN_3
    );


    /*
     * PH2 = amplifier shutdown control.
     *
     * This is the corrected pin that removed
     * the static in your setup.
     */
    GPIOPinTypeGPIOOutput(
        GPIO_PORTH_BASE,
        GPIO_PIN_2
    );


    /*
     * DAC SYNC idles HIGH.
     */
    GPIOPinWrite(
        GPIO_PORTN_BASE,
        GPIO_PIN_3,
        GPIO_PIN_3
    );


    /*
     * Amplifier starts OFF.
     *
     * TPA301 shutdown is active HIGH.
     */
    GPIOPinWrite(
        GPIO_PORTH_BASE,
        GPIO_PIN_2,
        GPIO_PIN_2
    );


    /*
     * Configure SSI2.
     */
    SSIDisable(
        SSI2_BASE
    );


    SSIConfigSetExpClk(
        SSI2_BASE,
        SYSTEM_CLOCK_HZ,
        SSI_FRF_MOTO_MODE_1,
        SSI_MODE_MASTER,
        DAC_SPI_BIT_RATE_HZ,
        16
    );


    /*
     * Clear receive FIFO.
     */
    while (SSIDataGetNonBlocking(
               SSI2_BASE,
               &dummyData))
    {
    }


    SSIEnable(
        SSI2_BASE
    );


    /*
     * Start DAC at midpoint / silence.
     */
    DAC8311_write(
        DAC_IDLE_CODE
    );
}

/* ============================================================
 * TIMER2 INITIALIZATION
 * ============================================================
 */

static void Audio_timerInit(void)
{
    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_TIMER2
    );


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_TIMER2))
    {
    }


    TimerDisable(
        TIMER2_BASE,
        TIMER_A
    );


    TimerConfigure(
        TIMER2_BASE,
        TIMER_CFG_PERIODIC
    );


    /*
     * 120 MHz / 6000 =
     * 20,000 samples/sec.
     */
    TimerLoadSet(
        TIMER2_BASE,
        TIMER_A,
        AUDIO_TIMER_COUNTS - 1U
    );


    TimerIntRegister(
        TIMER2_BASE,
        TIMER_A,
        timer2ISR
    );


    TimerIntClear(
        TIMER2_BASE,
        TIMER_TIMA_TIMEOUT
    );


    TimerIntEnable(
        TIMER2_BASE,
        TIMER_TIMA_TIMEOUT
    );


    /*
     * Audio starts silent.
     *
     * Timer2 does NOT start yet.
     */
    g_phaseAccumulator = 0;

    g_phaseIncrement = 0;

    g_noteActive = false;

    g_currentMidiNote =
        AUDIO_NOTE_NONE;

#if AUDIO_ISR_PROFILE
    /* Usually already enabled by the debugger; harmless if repeated. */
    CORE_DEMCR |= CORE_DEMCR_TRCENA;
    CORE_DWT_CYCCNT = 0U;
    CORE_DWT_CTRL |= CORE_DWT_CYCCNTENA;
#endif
}

/* ============================================================
 * NOTE OFF
 * ============================================================
 */

void Audio_stopNote(void)
{
    /*
     * Stop waveform generation first.
     */
    TimerDisable(
        TIMER2_BASE,
        TIMER_A
    );


    TimerIntClear(
        TIMER2_BASE,
        TIMER_TIMA_TIMEOUT
    );


    /*
     * No active note.
     */
    g_noteActive = false;

    g_currentMidiNote =
        AUDIO_NOTE_NONE;


    /*
     * Reset oscillator.
     */
    g_phaseAccumulator = 0;

    g_phaseIncrement = 0;


    /*
     * Cancel any envelope in progress (STOP, errors,
     * end of melody). Gain restarts from 0 next note.
     */
    g_envSampleIndex = 0U;
    g_envAttackSamples = 0U;
    g_envReleaseStart = 0U;
    g_envReleaseSamples = 0U;
    g_envReleaseEnd = 0U;


    /*
     * Return DAC to midpoint.
     */
    DAC8311_write(
        DAC_IDLE_CODE
    );


    /*
     * Shut down amplifier.
     *
     * HIGH = amplifier OFF.
     */
    GPIOPinWrite(
        GPIO_PORTH_BASE,
        GPIO_PIN_2,
        GPIO_PIN_2
    );
}

/* ============================================================
 * NOTE ON
 * ============================================================
 */

/* Milliseconds -> Timer3 counts, clamped to the 32-bit load register.
 * Shared by the scheduler and the envelope so both use the same note end.
 */
uint32_t Audio_msToCpuCounts(
    uint32_t milliseconds
)
{
    uint64_t timerCounts;

    if (milliseconds == 0U)
    {
        milliseconds = 1U;
    }

    timerCounts =
        ((uint64_t)SYSTEM_CLOCK_HZ * milliseconds) / 1000ULL;

    if (timerCounts > 0xFFFFFFFFULL)
    {
        timerCounts = 0xFFFFFFFFULL;
    }

    return (uint32_t)timerCounts;
}

/*
 * Fit attack + release inside the scheduled note.
 *
 * usable = note samples - guard. Normal notes: 5 ms attack, 5 ms release
 * ending 'guard' samples before Note Off. If usable < 2 ramps (notes under
 * ~10 ms), both ramps shrink to usable/2 so the note still rises and falls
 * inside its own duration. A 0 ms note is scheduled as 1 ms (20 samples),
 * like before. Timing of Note Off, rests and the next onset is unchanged.
 */
static void audioConfigureEnvelope(
    uint32_t durationMs
)
{
    uint32_t noteSamples =
        Audio_msToCpuCounts(durationMs) / AUDIO_TIMER_COUNTS;

    uint32_t usable = 0U;

    uint32_t ramp = ENV_RAMP_SAMPLES;

    if (noteSamples > ENV_END_GUARD_SAMPLES)
    {
        usable = noteSamples - ENV_END_GUARD_SAMPLES;
    }

    if ((2U * ramp) > usable)
    {
        ramp = usable / 2U;
    }

    g_envSampleIndex = 0U;
    g_envAttackSamples = ramp;
    g_envReleaseSamples = ramp;
    g_envReleaseEnd = usable;
    g_envReleaseStart = usable - ramp;
}


void Audio_startNote(
    uint8_t midiNote,
    uint32_t durationMs
)
{
    uint32_t frequencyMilliHz;


    frequencyMilliHz =
        midiNoteToFrequencyMilliHz(
            midiNote
        );


    /*
     * Unsupported note.
     */
    if (frequencyMilliHz == 0U)
    {
        Audio_stopNote();

        return;
    }


    /*
     * Defensive protection:
     *
     * never leave an old note sounding when
     * starting a new one.
     */
    if (g_noteActive)
    {
        Audio_stopNote();
    }


    TimerDisable(
        TIMER2_BASE,
        TIMER_A
    );


    /*
     * DDS phase increment:
     *
     * frequency * 2^32
     * ----------------
     * sample rate
     *
     * Frequency is stored in milli-Hz,
     * therefore sample rate is multiplied
     * by 1000.
     */
    g_phaseIncrement =
        (uint32_t)(
            ((uint64_t)frequencyMilliHz << 32)
            /
            (
                (uint64_t)AUDIO_SAMPLE_RATE_HZ *
                1000ULL
            )
        );


    g_phaseAccumulator = 0;


    /*
     * Timer2 is disabled here, so the ISR cannot
     * observe a half-written envelope.
     */
    audioConfigureEnvelope(
        durationMs
    );


    g_currentMidiNote =
        midiNote;


    g_noteActive = true;


    /*
     * Start from silent DAC level.
     */
    DAC8311_write(
        DAC_IDLE_CODE
    );


    /*
     * Enable amplifier.
     *
     * LOW = amplifier ON.
     */
    GPIOPinWrite(
        GPIO_PORTH_BASE,
        GPIO_PIN_2,
        0
    );


    TimerIntClear(
        TIMER2_BASE,
        TIMER_TIMA_TIMEOUT
    );


    /*
     * Begin generating sine samples.
     */
    TimerEnable(
        TIMER2_BASE,
        TIMER_A
    );
}



/* ============================================================
 * PUBLIC INTERFACE (declared in audio.h)
 * ============================================================
 */

/* DAC/SSI/GPIO hardware, then Timer2 (not started). Order as in the baseline. */
void Audio_init(void)
{
    Audio_hardwareInit();
    Audio_timerInit();
}

bool Audio_isNoteActive(void)
{
    return g_noteActive;
}

/* The profiler maximum is cleared when each melody starts. */
void Audio_clearIsrMax(void)
{
    Glo.Diagnostics.AudioIsrMaxCycles = 0U;
}
