/*
 * control_task.c -- protocol lifecycle: validate, start, STOP, completion.
 *
 * STAGE 1 (NoRTOS): also holds the thin mainThread() adapter called by
 * main_nortos.c. Owns the single parsed-event array (1,024 events); playback
 * borrows it until completion/STOP, and Midi_parse() only runs while no song
 * is playing (a header is refused with ERR_BUSY during playback).
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#include <ti/drivers/GPIO.h>

#include "ti_drivers_config.h"
#include "globals.h"
#include "audio.h"
#include "midi.h"
#include "playback.h"
#include "uart_task.h"
#include "control_task.h"

static MelodyEvent s_melody[MAX_PARSED_NOTES];

static bool Control_isBusy(void)
{
    return Playback_isActive();
}

static void Control_stopPlayback(void)
{
    Playback_stop();
}

static const UartHooks s_uartHooks =
{
    Control_isBusy,
    Control_stopPlayback
};

void Control_init(void)
{
    Playback_init(NULL);
    Uart_init(&s_uartHooks);
}

/* CRC -> ACK_RECEIVED -> parse -> ACK_VALID -> start -> PLAYING, exactly the
 * baseline order; CRC failure is reported before ACK_RECEIVED. */
static void Control_processPayload(void)
{
    UartPayload payload;
    MidiParseResult parsed;
    uint32_t actualCrc;
    uint32_t count = 0U;

    if (!Uart_acquirePayload(&payload))
    {
        return;
    }

    actualCrc = Uart_crc32(payload.data, payload.length);
    Glo.Diagnostics.LastCalculatedCrc32 = actualCrc;
    if (actualCrc != payload.expectedCrc32)
    {
        Uart_payloadRejected("ERR_CRC");
        return;
    }

    Uart_sendAck("ACK_RECEIVED", payload.length, actualCrc);
    parsed = Midi_parse(payload.data, payload.length, s_melody,
                        MAX_PARSED_NOTES, &count);
    if (parsed != MIDI_PARSE_OK)
    {
        /* Parsing is reached only after accepting a header while idle. */
        Playback_stop();
        Uart_payloadRejected((parsed == MIDI_PARSE_NOTE_CAPACITY) ?
                             "ERR_NOTE_CAPACITY" : "ERR_MIDI");
        return;
    }

    Glo.Diagnostics.TransferSuccessCount++;
    Uart_sendReply("ACK_VALID\r\n");
    Playback_start(s_melody, count);
    Uart_sendReply("PLAYING\r\n");
    Uart_payloadAccepted();
}

/* DONE only after real silence; IDLE only if the receiver is between frames. */
static void Control_reportCompletion(void)
{
    if (!Playback_takeCompletion())
    {
        return;
    }

    Uart_beginReply();
    Uart_putText("DONE\r\n");
    if (Uart_receiverIdle())
    {
        Uart_putText("IDLE\r\n");
    }
    Uart_endReply();
}

void Control_service(void)
{
    Control_processPayload();
    Control_reportCompletion();
}

/* ============================================================
 * STAGE 1 ONLY: thin NoRTOS adapter (called by main_nortos.c)
 * ============================================================ */

void *mainThread(void *arg0)
{
    (void)arg0;
    GPIO_init();

    /* Preserve the proven audio hardware, PH2 control and timer setup. */
    Audio_init();
    Control_init();

    while (1)
    {
        Uart_service();
        Control_service();
    }
}
