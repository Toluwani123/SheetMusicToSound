/*
 * globals.c -- the single definition of the shared Globals object.
 */
#include "globals.h"

Globals Glo = {0};
