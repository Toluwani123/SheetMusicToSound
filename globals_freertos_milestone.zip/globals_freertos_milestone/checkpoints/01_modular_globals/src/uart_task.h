/*
 * uart_task.h -- UART0 transport interface (uart_task.c).
 *
 * Owns UART0, the Timer4 millisecond transfer clock, the file buffer and the
 * framing/timeout/recovery state machine. The controller (control_task.c)
 * never touches raw receiver state: it borrows a completed payload through
 * Uart_acquirePayload() and returns it with Uart_payloadAccepted() or
 * Uart_payloadRejected().
 *
 * Protocol: SMID v2 (v1 MIDI accepted); keep MAX_MIDI_FILE_SIZE coordinated
 * with newmiditst.py.
 */
#ifndef UART_TASK_H
#define UART_TASK_H

#include <stdint.h>
#include <stdbool.h>

#define MAX_MIDI_FILE_SIZE       16384U

/* Callbacks supplied by the controller; both run in the transport's context. */
typedef struct
{
    bool (*isBusy)(void);         /* header time: is a song still playing? */
    void (*stopPlayback)(void);   /* STOP frame: hard silence, then ACK_STOPPED */
} UartHooks;

/* A completely received payload, valid until accepted/rejected. */
typedef struct
{
    const uint8_t *data;
    uint32_t length;
    uint32_t expectedCrc32;
} UartPayload;

/* UART0, Timer4, receiver reset and the READY banner. */
void Uart_init(const UartHooks *hooks);

/* STAGE 1 ONLY: one polled pass of timeout/receive handling. */
void Uart_service(void);

/* Take ownership of a published payload (true once per payload). The receiver
 * accepts no new bytes until the payload is accepted or rejected. */
bool Uart_acquirePayload(UartPayload *out);
void Uart_payloadAccepted(void);                   /* receiver -> WAIT_MAGIC */
void Uart_payloadRejected(const char *errorText);  /* ERR_x line, then RECOVER */

/* True while the receiver is between frames (used for IDLE after DONE). */
bool Uart_receiverIdle(void);

/* CRC-32/ISO-HDLC, matching zlib.crc32(). "123456789" -> 0xCBF43926. */
uint32_t Uart_crc32(const uint8_t *data, uint32_t length);

/* Replies. A complete message (or required group) is sent between begin and
 * end; Uart_sendReply/Uart_sendAck do that for one call. */
void Uart_beginReply(void);
void Uart_putText(const char *text);
void Uart_endReply(void);
void Uart_sendReply(const char *text);
void Uart_sendAck(const char *name, uint32_t length, uint32_t crc);

#endif /* UART_TASK_H */
