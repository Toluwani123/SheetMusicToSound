/*
 * uart_task.c -- UART0 transport: framing, CRC helper, timeouts, recovery.
 *
 * STAGE 1: the baseline polled receiver moved out of gpiointerrupt.c, with
 * validation/parsing/playback decisions handed to control_task.c through
 * Uart_acquirePayload()/Uart_payloadAccepted()/Uart_payloadRejected().
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <string.h>

#ifndef __MSP432E401Y__
#define __MSP432E401Y__
#endif

#include <ti/devices/msp432e4/driverlib/driverlib.h>

#include "uart_task.h"
#include "globals.h"


/* SMID v2: byte 5 is opcode (0=MIDI, 1=STOP); v1 MIDI remains accepted.
 * STOP has zero length/CRC and is recognized only at a header boundary.
 * MIDI uses a 16-byte header, then an acknowledged raw MIDI payload.
 * Multi-byte transport fields are little-endian; MIDI itself is unchanged.
 * Keep these limits coordinated with newmiditst.py.
 */

#define SMID_HEADER_SIZE         16U
#define SMID_PROTOCOL_VERSION    2U
#define SMID_LEGACY_VERSION      1U
#define SMID_COMMAND_MIDI        0U
#define SMID_COMMAND_STOP        1U
#define RX_HEADER_TIMEOUT_MS     1000U
#define RX_PAYLOAD_IDLE_MS       2000U
#define RX_PAYLOAD_TOTAL_MS      10000U
#define RX_RECOVERY_QUIET_MS      250U
#define RX_SERVICE_BYTE_BUDGET   64U

static uint8_t fileBuffer[MAX_MIDI_FILE_SIZE];
static uint8_t headerBytes[SMID_HEADER_SIZE];
static uint32_t headerBytesReceived = 0U;
static uint32_t magicBytesMatched = 0U;
static uint32_t expectedLength = 0U;
static uint32_t bytesReceived = 0U;
static uint32_t expectedCrc32 = 0U;
static uint32_t headerStartedMs = 0U;
static uint32_t payloadStartedMs = 0U;
static uint32_t lastRxByteMs = 0U;

typedef enum
{
    WAIT_MAGIC = 0,
    READ_HEADER,
    READ_PAYLOAD,
    VALIDATE,
    RECOVER
} ReceiverState;

static ReceiverState receiverState = WAIT_MAGIC;

/* Timer4 supplies time even when Timer2 (audio) is stopped. */
static volatile uint32_t g_transferMilliseconds = 0U;

static const UartHooks *s_hooks = NULL;

/* Payload ownership: set when the complete payload has been published to the
 * controller, and when the controller has taken it. Cleared by reset. */
static bool s_payloadPublished = false;
static bool s_payloadTaken = false;


/* ============================================================
 * UART INITIALIZATION
 * ============================================================
 */

static void UART0_init(void)
{
    /*
     * Enable UART0 and GPIO Port A.
     */
    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_UART0
    );


    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_GPIOA
    );


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_UART0))
    {
    }


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_GPIOA))
    {
    }


    /*
     * PA0 = UART RX
     * PA1 = UART TX
     */
    GPIOPinConfigure(
        GPIO_PA0_U0RX
    );


    GPIOPinConfigure(
        GPIO_PA1_U0TX
    );


    GPIOPinTypeUART(
        GPIO_PORTA_BASE,
        GPIO_PIN_0 |
        GPIO_PIN_1
    );


    /*
     * Use 16 MHz alternate UART clock.
     */
    UARTClockSourceSet(
        UART0_BASE,
        UART_CLOCK_ALTCLK
    );


    /*
     * 115200 baud
     * 8 data bits
     * 1 stop bit
     * no parity
     */
    UARTConfigSetExpClk(
        UART0_BASE,
        16000000U,
        115200,
        UART_CONFIG_WLEN_8 |
        UART_CONFIG_STOP_ONE |
        UART_CONFIG_PAR_NONE
    );


    UARTEnable(
        UART0_BASE
    );
}

/* ============================================================
 * UART PRINT
 * ============================================================
 */

static void UART0_writeString(
    const char *text
)
{
    while (*text != '\0')
    {
        UARTCharPut(
            UART0_BASE,
            *text
        );


        text++;
    }
}

/* ============================================================
 * DELIVERABLE 2: TRANSFER CLOCK, CRC AND RECOVERABLE UART RECEIVER
 * ============================================================ */

static void transferTimer4ISR(void)
{
    TimerIntClear(TIMER4_BASE, TIMER_TIMA_TIMEOUT);
    g_transferMilliseconds++;
}

static void TransferClock_init(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER4);
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER4))
    {
    }

    TimerDisable(TIMER4_BASE, TIMER_A);
    TimerConfigure(TIMER4_BASE, TIMER_CFG_PERIODIC);
    TimerClockSourceSet(TIMER4_BASE, TIMER_CLOCK_SYSTEM);
    TimerLoadSet(TIMER4_BASE, TIMER_A, (SYSTEM_CLOCK_HZ / 1000U) - 1U);
    TimerIntRegister(TIMER4_BASE, TIMER_A, transferTimer4ISR);
    TimerIntClear(TIMER4_BASE, TIMER_TIMA_TIMEOUT);
    g_transferMilliseconds = 0U;
    TimerIntEnable(TIMER4_BASE, TIMER_TIMA_TIMEOUT);
    TimerEnable(TIMER4_BASE, TIMER_A);
}

static uint32_t readLittleEndian32(const uint8_t *data)
{
    return ((uint32_t)data[0]) |
           ((uint32_t)data[1] << 8U) |
           ((uint32_t)data[2] << 16U) |
           ((uint32_t)data[3] << 24U);
}

/* CRC-32/ISO-HDLC, matching zlib.crc32(data).
 * ASCII "123456789" must produce 0xCBF43926.
 */
uint32_t Uart_crc32(const uint8_t *data, uint32_t length)
{
    uint32_t crc = 0xFFFFFFFFU;
    uint32_t i;
    uint32_t bit;

    for (i = 0U; i < length; i++)
    {
        crc ^= (uint32_t)data[i];
        for (bit = 0U; bit < 8U; bit++)
        {
            if ((crc & 1U) != 0U)
            {
                crc = (crc >> 1U) ^ 0xEDB88320U;
            }
            else
            {
                crc >>= 1U;
            }
        }
    }
    return crc ^ 0xFFFFFFFFU;
}

/* Small formatters avoid pulling printf into the embedded build. */
static void UART0_writeDecimal(uint32_t value)
{
    char digits[10];
    uint32_t count = 0U;
    do
    {
        digits[count++] = (char)('0' + (value % 10U));
        value /= 10U;
    } while (value != 0U);

    while (count != 0U)
    {
        UARTCharPut(UART0_BASE, digits[--count]);
    }
}

static void UART0_writeHex32(uint32_t value)
{
    static const char hex[] = "0123456789ABCDEF";
    uint32_t shift;
    for (shift = 32U; shift != 0U; shift -= 4U)
    {
        UARTCharPut(UART0_BASE, hex[(value >> (shift - 4U)) & 0xFU]);
    }
}

void Uart_sendAck(const char *name,
                  uint32_t length,
                  uint32_t crc)
{
    Uart_beginReply();
    UART0_writeString(name);
    UARTCharPut(UART0_BASE, ' ');
    UART0_writeDecimal(length);
    UARTCharPut(UART0_BASE, ' ');
    UART0_writeHex32(crc);
    UART0_writeString("\r\n");
    Uart_endReply();
}

static void UARTReceiver_reset(void)
{
    headerBytesReceived = 0U;
    magicBytesMatched = 0U;
    expectedLength = 0U;
    bytesReceived = 0U;
    expectedCrc32 = 0U;
    headerStartedMs = 0U;
    payloadStartedMs = 0U;
    lastRxByteMs = g_transferMilliseconds;
    s_payloadPublished = false;
    s_payloadTaken = false;
    receiverState = WAIT_MAGIC;
}

static void UARTReceiver_fail(const char *error)
{
    /* One error line per failed attempt, even if more bad bytes arrive.
     * Never stop an already playing melody in this routine: ERR_BUSY and
     * UART noise during playback must not modify the active melody.
     */
    if (receiverState == RECOVER)
    {
        lastRxByteMs = g_transferMilliseconds;
        return;
    }

    Glo.Diagnostics.TransferErrorCount++;
    UARTReceiver_reset();
    receiverState = RECOVER;
    Uart_beginReply();
    UART0_writeString(error);
    UART0_writeString("\r\n");
    Uart_endReply();
    lastRxByteMs = g_transferMilliseconds;
}

static void UARTReceiver_checkTimeout(void)
{
    uint32_t now = g_transferMilliseconds;

    /* Unsigned subtraction also works when the millisecond counter wraps. */
    if (((receiverState == READ_HEADER) ||
         ((receiverState == WAIT_MAGIC) && (magicBytesMatched != 0U))) &&
        ((uint32_t)(now - headerStartedMs) >= RX_HEADER_TIMEOUT_MS))
    {
        UARTReceiver_fail("ERR_TIMEOUT");
    }
    else if ((receiverState == READ_PAYLOAD) &&
             (((uint32_t)(now - lastRxByteMs) >= RX_PAYLOAD_IDLE_MS) ||
              ((uint32_t)(now - payloadStartedMs) >= RX_PAYLOAD_TOTAL_MS)))
    {
        UARTReceiver_fail("ERR_TIMEOUT");
    }
    else if ((receiverState == RECOVER) &&
             !UARTCharsAvail(UART0_BASE) &&
             ((uint32_t)(now - lastRxByteMs) >= RX_RECOVERY_QUIET_MS))
    {
        UARTReceiver_reset();
        /* IDLE means the receiver accepts another header. Playback may
         * still be active after ERR_BUSY; that next header will be refused.
         */
        Uart_sendReply("IDLE\r\n");
    }
}

static void UARTReceiver_acceptHeader(void)
{
    uint8_t version = headerBytes[4];
    uint8_t command = headerBytes[5];

    if ((version != SMID_PROTOCOL_VERSION) && (version != SMID_LEGACY_VERSION))
    {
        UARTReceiver_fail("ERR_VERSION");
        return;
    }
    if ((headerBytes[6] != 0U) || (headerBytes[7] != 0U) ||
        ((version == SMID_LEGACY_VERSION) && (command != SMID_COMMAND_MIDI)))
    {
        UARTReceiver_fail("ERR_HEADER");
        return;
    }
    if ((command != SMID_COMMAND_MIDI) && (command != SMID_COMMAND_STOP))
    {
        UARTReceiver_fail("ERR_COMMAND");
        return;
    }
    if (command == SMID_COMMAND_STOP)
    {
        if ((readLittleEndian32(&headerBytes[8]) != 0U) ||
            (readLittleEndian32(&headerBytes[12]) != 0U))
        {
            UARTReceiver_fail("ERR_HEADER");
            return;
        }
        if ((s_hooks != NULL) && (s_hooks->stopPlayback != NULL))
        {
            s_hooks->stopPlayback();
        }
        UARTReceiver_reset();
        Uart_sendReply("ACK_STOPPED\r\nIDLE\r\n");
        return;
    }

    expectedLength = readLittleEndian32(&headerBytes[8]);
    expectedCrc32 = readLittleEndian32(&headerBytes[12]);
    Glo.Diagnostics.LastTransferLength = expectedLength;
    Glo.Diagnostics.LastExpectedCrc32 = expectedCrc32;
    Glo.Diagnostics.LastCalculatedCrc32 = 0U;

    if ((expectedLength == 0U) || (expectedLength > MAX_MIDI_FILE_SIZE))
    {
        UARTReceiver_fail("ERR_SIZE");
        return;
    }
    if ((s_hooks != NULL) && (s_hooks->isBusy != NULL) && s_hooks->isBusy())
    {
        UARTReceiver_fail("ERR_BUSY");
        return;
    }

    bytesReceived = 0U;
    receiverState = READ_PAYLOAD;
    Uart_sendAck("ACK_READY", expectedLength, expectedCrc32);
    /* Start after queuing the acknowledgement, giving the host a full
     * idle interval to receive it and begin sending the payload.
     */
    payloadStartedMs = g_transferMilliseconds;
    lastRxByteMs = payloadStartedMs;
}

static void UARTReceiver_processByte(uint8_t byte)
{
    static const uint8_t magic[4] = {'S', 'M', 'I', 'D'};
    uint32_t now = g_transferMilliseconds;
    lastRxByteMs = now;

    if (receiverState == RECOVER)
    {
        return;
    }

    if (receiverState == WAIT_MAGIC)
    {
        if (byte == magic[magicBytesMatched])
        {
            if (magicBytesMatched == 0U)
            {
                headerStartedMs = now;
            }
            magicBytesMatched++;
            if (magicBytesMatched == 4U)
            {
                memcpy(headerBytes, magic, sizeof(magic));
                headerBytesReceived = 4U;
                magicBytesMatched = 0U;
                receiverState = READ_HEADER;
            }
        }
        else if (byte == magic[0])
        {
            /* Preserve a new 'S', e.g. the second S in "SSMID". */
            magicBytesMatched = 1U;
            headerStartedMs = now;
        }
        else
        {
            magicBytesMatched = 0U;
        }
        return;
    }

    if (receiverState == READ_HEADER)
    {
        if (headerBytesReceived >= SMID_HEADER_SIZE)
        {
            UARTReceiver_fail("ERR_HEADER");
            return;
        }
        headerBytes[headerBytesReceived++] = byte;
        if (headerBytesReceived == SMID_HEADER_SIZE)
        {
            UARTReceiver_acceptHeader();
        }
        return;
    }

    if (receiverState == READ_PAYLOAD)
    {
        if ((bytesReceived >= expectedLength) ||
            (bytesReceived >= MAX_MIDI_FILE_SIZE))
        {
            UARTReceiver_fail("ERR_SIZE");
            return;
        }
        /* All payload bytes are data: do not look for SMID or commands. */
        fileBuffer[bytesReceived++] = byte;
        if (bytesReceived == expectedLength)
        {
            receiverState = VALIDATE;
        }
    }
}

/* The payload is complete (receiverState == VALIDATE). Apply the baseline
 * unexpected-data guard, then hand the buffer to the controller. */
static void UARTReceiver_publishPayload(void)
{
    if ((receiverState != VALIDATE) || s_payloadPublished)
    {
        return;
    }

    /* The host must wait for the result before sending anything else. */
    if (UARTCharsAvail(UART0_BASE))
    {
        UARTReceiver_fail("ERR_SIZE");
        return;
    }

    s_payloadPublished = true;
}

static void UARTReceiver_service(void)
{
    uint32_t count;
    uint32_t uartErrors;
    int32_t rawByte;

    /* This call runs even when no bytes arrive. */
    UARTReceiver_checkTimeout();

    uartErrors = UARTRxErrorGet(UART0_BASE);
    if (uartErrors != 0U)
    {
        UARTRxErrorClear(UART0_BASE);
        UARTReceiver_fail("ERR_UART");
    }

    /* Bounded work keeps the clock and completion checks responsive. */
    for (count = 0U; count < RX_SERVICE_BYTE_BUDGET; count++)
    {
        if (!UARTCharsAvail(UART0_BASE))
        {
            break;
        }
        UARTReceiver_checkTimeout();
        rawByte = UARTCharGetNonBlocking(UART0_BASE);
        if (rawByte < 0)
        {
            break;
        }

        /* UART data-register bits 11:8 contain per-character error flags.
         * Inspect them before converting the word to an 8-bit payload.
         */
        uartErrors = UARTRxErrorGet(UART0_BASE);
        if ((((uint32_t)rawByte & 0x00000F00U) != 0U) ||
            (uartErrors != 0U))
        {
            UARTRxErrorClear(UART0_BASE);
            UARTReceiver_fail("ERR_UART");
            lastRxByteMs = g_transferMilliseconds;
            continue;
        }

        UARTReceiver_processByte((uint8_t)rawByte);
        if (receiverState == VALIDATE)
        {
            break;
        }
    }

    /* Also catch an overrun reported immediately after the last read. */
    if (UARTRxErrorGet(UART0_BASE) != 0U)
    {
        UARTRxErrorClear(UART0_BASE);
        UARTReceiver_fail("ERR_UART");
    }
    UARTReceiver_checkTimeout();
    UARTReceiver_publishPayload();
}


/* ============================================================
 * PUBLIC INTERFACE (declared in uart_task.h)
 * ============================================================ */

void Uart_beginReply(void)
{
    /* Stage 3 adds the UARTTxMutex here. */
}

void Uart_endReply(void)
{
}

void Uart_putText(const char *text)
{
    UART0_writeString(text);
}

void Uart_sendReply(const char *text)
{
    Uart_beginReply();
    UART0_writeString(text);
    Uart_endReply();
}

void Uart_init(const UartHooks *hooks)
{
    s_hooks = hooks;

    /* Timer4 is reserved for the transfer clock; no SysConfig edit. */
    TransferClock_init();
    UART0_init();
    UARTRxErrorClear(UART0_BASE);
    UARTReceiver_reset();
    Uart_sendReply("\r\nSMID v2 READY\r\nIDLE\r\n");
}

void Uart_service(void)
{
    UARTReceiver_service();
}

bool Uart_acquirePayload(UartPayload *out)
{
    if ((receiverState != VALIDATE) || !s_payloadPublished || s_payloadTaken)
    {
        return false;
    }

    s_payloadTaken = true;
    out->data = fileBuffer;
    out->length = expectedLength;
    out->expectedCrc32 = expectedCrc32;
    return true;
}

void Uart_payloadAccepted(void)
{
    if (receiverState != VALIDATE)
    {
        return;
    }

    UARTReceiver_reset();
}

void Uart_payloadRejected(const char *errorText)
{
    if (receiverState != VALIDATE)
    {
        return;
    }

    UARTReceiver_fail(errorText);
}

bool Uart_receiverIdle(void)
{
    return (receiverState == WAIT_MAGIC) && (magicBytesMatched == 0U);
}
