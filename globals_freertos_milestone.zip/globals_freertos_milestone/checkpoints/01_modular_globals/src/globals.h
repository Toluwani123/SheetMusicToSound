/*
 * globals.h -- the one shared header of the project.
 *
 * Declares the Globals type and 'extern Globals Glo'; globals.c defines it
 * exactly once. 'volatile' members are debugger-visibility aids and counters
 * with a documented single writer; they provide no locking.
 *
 * STAGE 1 (NoRTOS, modular): only Glo.Diagnostics exists. The Glo.Bios group
 * of FreeRTOS handles is added when the RTOS is integrated (Stage 2/3), so no
 * fake task/semaphore types are invented here.
 */
#ifndef GLOBALS_H
#define GLOBALS_H

#include <stdint.h>

/* Core clock set by the startup code: 120 MHz. Single definition. */
#define SYSTEM_CLOCK_HZ          120000000U

typedef struct
{
    /* Transfer results (writers: UART transport / controller, one at a time). */
    volatile uint32_t TransferSuccessCount;   /* was g_transferSuccessCount */
    volatile uint32_t TransferErrorCount;     /* was g_transferErrorCount   */
    volatile uint32_t LastTransferLength;     /* was g_lastTransferLength   */
    volatile uint32_t LastExpectedCrc32;      /* was g_lastExpectedCrc32    */
    volatile uint32_t LastCalculatedCrc32;    /* was g_lastCalculatedCrc32  */

    /* Audio (writer: audio module only). */
    volatile uint16_t LastDacCode;            /* was g_lastDacCode           */
    volatile uint32_t AudioInterruptCount;    /* was g_audioInterruptCount   */
    volatile uint32_t AudioIsrLastCycles;     /* was g_audioIsrLastCycles    */
    volatile uint32_t AudioIsrMaxCycles;      /* was g_audioIsrMaxCycles     */
} GlobalsDiagnostics;

typedef struct
{
    GlobalsDiagnostics Diagnostics;
} Globals;

extern Globals Glo;

#endif /* GLOBALS_H */
