# Checkpoint 01 — modular_globals (Stage 1: split modules + shared global pattern)

**What it is.** The baseline code split into `audio`, `midi`, `playback`, `uart_task`, `control_task`, plus `globals.h/.c`
(`Glo.Diagnostics` only — no RTOS handles yet, no fake types). Still **NoRTOS**: `main_nortos.c` calls a thin `mainThread()`
in `control_task.c`, and the UART receiver is still the original *polled* state machine. `src/` is a complete set of files.

**How to rebuild it.** Copy `src\*` over a copy of `00_before_globals_rtos\gpiointerrupt` (replace `gpiointerrupt.c`; keep
its `.project/.cproject/syscfg/lds` — the `dot_*.txt` files are those metadata files, rename them back) and build.
`test_tools\check_code_moves.py` proves the moved code is verbatim.

**Verified.** Headless CCS build, 0 errors: text 19,128 B (+740 B vs baseline), bss +16 B. `evidence/move_check.txt`: 22 of 41
baseline functions identical after renames; the other differences are exactly the module-boundary edits (`static`,
`Glo.Diagnostics`, `events,count` parameters, `Midi_parse` result codes, hook/ack plumbing).

**Hardware behaviour.** Expected unchanged from the baseline (same code, same priorities, same polled receiver) — **not run**.
