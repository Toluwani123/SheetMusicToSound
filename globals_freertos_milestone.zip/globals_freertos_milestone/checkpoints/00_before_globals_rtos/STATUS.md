# Checkpoint 00 — before_globals_rtos (Stage 0: establish current truth)

**What it is.** The untouched baseline: the user's working `gpiointerrupt` project, copied before any change.
`gpiointerrupt/` holds `gpiointerrupt.c` (2,517 lines), `main_nortos.c`, `gpiointerrupt.syscfg`, the NoRTOS linker script and
the CCS metadata (renamed `dot_*.txt` so nothing here can be imported or built by accident).

**Verified.**
* The user's `workspace_ccstheia\gpiointerrupt` is identical to the supplied `latestb4rtos.zip` apart from stale `Debug`/`.clangd`
  output (`diff -rq`, 0 differences; zip sha256 `7bf4d967…a7081a`, `gpiointerrupt.c` sha256 `ac9f97cf…2ac687`).
  No newer project work existed, so nothing had to be preserved.
* Settings found as the audit said: GNU 9.2.1 project, `RTOS.name = "NoRTOS"`, NoRTOS library linked, 120 MHz, SSI2/PN3/PH2,
  Timer2/3/4 roles, `AUDIO_USE_INTERPOLATION = AUDIO_USE_ENVELOPE = 1`, `ENV_RAMP_MS = 5`.
* Rebuilt headless (CCS 21.0.1, GCC 9.2.1, SysConfig 1.4.0): 0 errors, text 18,388 B — identical to the existing `.out`.
  Log: `build_log_baseline_ccs_headless.txt`.

**Hardware behaviour.** The reference for every later comparison.
