# Checkpoint 04 — final_ready_for_board_tests (Stage 4)

**What it is.** The delivered state: `../../projects/gpiointerrupt_freertos` + `../../projects/freertos_kernel_glo` (sources
identical to checkpoint 03), the real build output in `../../build_output/`, the documents, the test tools and the offline
evidence. This folder stores no second copy of the sources; `MANIFEST_SHA256.txt` lists the SHA-256 of every delivered
file so the state can be re-verified (`sha256sum -c` or the hashes in `../../dependencies/DEPENDENCIES.md`).

**Verified (no board).**

| Check | Result |
|---|---|
| CCS headless build of both projects, built in place from the delivered folders | 0 errors, 0 warnings |
| Raw program image rebuilt in three different directories | bit-identical, 33,676 bytes, SHA-256 `d36d5b52…2f89cec` |
| Link inspection (49 checks) | one `main`, one `resetISR`, vectors 11/14/15 = FreeRTOS SVC/PendSV/SysTick, no NoRTOS, all modules + kernel linked, `Glo` once |
| Architecture / ISR / priority / header-compile checks (64) | 0 failures |
| Waveform arithmetic + table and 14 constants identical to baseline (45) | 0 failures |
| Moved-code comparison | every difference from the baseline is an intended edit |
| FreeRTOS sources vs upstream V10.2.1 tag | 28 files identical |
| Static stack estimate | ≥ 2.7× headroom per task; ISR stack ≈ 1 KB of 2 KB worst case (estimate) |
| Board-test script logic against a protocol model | passes; deliberately broken models fail (tests the script, **not** the firmware) |

**Not verified — pending hardware.** Flashing and running; `Glo.Bios` handles and wake counters; tests A–E; D3–D5
regressions; R1–R3 races; listening checks; `AudioIsrMaxCycles`; measured stack/heap minima; GUI import in CCS Theia.
Everything is listed with commands in `../../START_HERE_TESTING.md`; results go in `../../FINAL_TEST_RECORD.txt`.
