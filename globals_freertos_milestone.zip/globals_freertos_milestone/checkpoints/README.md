# Checkpoints

Stage snapshots for diagnosis and rollback. They are **outside** the compiled projects (nothing here is built by
`projects\`), and none contains CCS project metadata that could be imported by accident (the baseline's `.project`,
`.cproject`, `.ccsproject` are stored as `dot_*.txt`).

| Folder | Stage | Build | Hardware |
|---|---|---|---|
| `00_before_globals_rtos` | 0 — untouched baseline (`latestb4rtos.zip` == your working project) | built, 0 errors | the reference |
| `01_modular_globals` | 1 — modules + `Glo.Diagnostics`, still NoRTOS and polled | built, 0 errors | not run |
| `02_freertos_bringup` | 2 — FreeRTOS infrastructure, one temporary polling task (**not for transfer tests**) | built, 0 errors / 0 warnings | not run |
| `03_rtos_monophonic` | 3 — the final design (identical to `projects\`) | built, 0 errors / 0 warnings | not run |
| `04_final_ready_for_board_tests` | 4 — manifest of the delivered state | — | the session in `START_HERE_TESTING.md` |

The build logs in `evidence/` folders were produced in temporary scratch workspaces (their paths in the logs no longer
exist). The authoritative final build is in `..\build_output\`, produced in place from `..\projects\`.
