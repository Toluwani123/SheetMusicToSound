/*
 * playback.c -- note/rest progression, Timer3 and completion state.
 *
 * Moved from gpiointerrupt.c. Borrows a const view of the controller-owned
 * event array; calls only the public audio API. Never parses MIDI or touches
 * the UART.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#ifndef __MSP432E401Y__
#define __MSP432E401Y__
#endif

#include <ti/devices/msp432e4/driverlib/driverlib.h>

#include "playback.h"
#include "audio.h"
#include "midi.h"
#include "globals.h"

/* Audio and MIDI describe the same pitch range; keep them in step. */
typedef char playbackNoteRangesAgree[
    ((AUDIO_NOTE_MIN == MIDI_NOTE_MIN) &&
     (AUDIO_NOTE_MAX == MIDI_NOTE_MAX) &&
     (AUDIO_NOTE_NONE == MIDI_NOTE_NONE)) ? 1 : -1];


/* ============================================================
 * PLAYBACK SCHEDULER STATE
 * ============================================================
 */

typedef enum
{
    PLAYBACK_IDLE = 0,

    PLAYBACK_NOTE,

    PLAYBACK_REST,

    PLAYBACK_COMPLETE

} PlaybackState;


static volatile PlaybackState g_playbackState =
    PLAYBACK_IDLE;

static volatile uint32_t g_melodyIndex = 0;

static volatile bool g_playbackActive = false;


/* Borrowed, read-only view of the melody being played (owned by the caller of
 * Playback_start). Valid from Playback_start until completion or Playback_stop.
 */
static const MelodyEvent *s_events = NULL;
static volatile uint32_t g_melodyLength = 0;

/* Set when a melody has been started; cleared by completion reporting or by
 * Playback_stop. Lets the task layer print DONE only for a natural finish. */
static volatile bool s_completionPending = false;

/* Called from the Timer3 ISR when the melody finishes naturally (after the
 * hard silence). Must be ISR-safe; it may only signal work. May be NULL. */
static PlaybackCompletionHook s_completionHook = NULL;

static void PlaybackTimer_armMs(
    uint32_t milliseconds
);

static void playbackStartCurrentEvent(void);


/* Cancel the entire song, including a scheduled rest. Preserve the caller's
 * interrupt-mask state; ACK_STOPPED is sent only after this function returns.
 * Timer4 remains running so transfer timeouts continue to work in silence.
 */
void Playback_stop(void)
{
    bool interruptsWereDisabled = IntMasterDisable();

    TimerDisable(TIMER3_BASE, TIMER_A);
    TimerIntClear(TIMER3_BASE, TIMER_TIMA_TIMEOUT);
    g_playbackActive = false;
    g_playbackState = PLAYBACK_IDLE;
    g_melodyIndex = 0U;
    g_melodyLength = 0U;
    s_completionPending = false;
    Audio_stopNote();

    /* Read back the peripheral clears before clearing latched NVIC requests. */
    (void)TimerIntStatus(TIMER3_BASE, false);
    (void)TimerIntStatus(TIMER2_BASE, false);
    IntPendClear(INT_TIMER3A);
    IntPendClear(INT_TIMER2A);

    if (!interruptsWereDisabled)
    {
        IntMasterEnable();
    }
}

/* ============================================================
 * TIMER3 PLAYBACK TIMER
 * ============================================================
 *
 * Timer3 has ONE job:
 *
 * musical/event timing.
 */

static void PlaybackTimer_armMs(
    uint32_t milliseconds
)
{
    /*
     * Convert milliseconds to timer counts
     * (0 ms -> 1 ms, clamped to 32 bits).
     */
    uint32_t timerCounts =
        Audio_msToCpuCounts(
            milliseconds
        );


    TimerDisable(
        TIMER3_BASE,
        TIMER_A
    );


    TimerIntClear(
        TIMER3_BASE,
        TIMER_TIMA_TIMEOUT
    );


    TimerLoadSet(
        TIMER3_BASE,
        TIMER_A,
        timerCounts - 1U
    );


    TimerEnable(
        TIMER3_BASE,
        TIMER_A
    );
}

/* ============================================================
 * START CURRENT PARSED NOTE
 * ============================================================
 */

static void playbackStartCurrentEvent(void)
{
    const MelodyEvent *event;


    /*
     * End of parsed melody.
     */
    if ((g_melodyIndex >= g_melodyLength) ||
        (g_melodyIndex >= MAX_PARSED_NOTES))
    {
        /*
         * Extra safety Note Off.
         */
        Audio_stopNote();


        g_playbackActive =
            false;


        g_playbackState =
            PLAYBACK_COMPLETE;


        if (s_completionHook != NULL)
        {
            s_completionHook();
        }


        return;
    }


    event =
        &s_events[g_melodyIndex];


    /*
     * NOTE ON.
     */
    Audio_startNote(
        event->midiNote,
        event->durationMs
    );


    g_playbackState =
        PLAYBACK_NOTE;


    /*
     * Timer3 determines when the
     * NOTE OFF occurs.
     */
    PlaybackTimer_armMs(
        event->durationMs
    );
}

/* ============================================================
 * TIMER3 ISR
 * ============================================================
 */

static void timer3ISR(void)
{
    const MelodyEvent *event;


    TimerIntClear(
        TIMER3_BASE,
        TIMER_TIMA_TIMEOUT
    );


    /* A late interrupt after STOP must not advance/restart the melody. */
    if (!g_playbackActive)
    {
        TimerDisable(TIMER3_BASE, TIMER_A);
        return;
    }
    if ((g_melodyLength > MAX_PARSED_NOTES) ||
        (g_melodyIndex >= g_melodyLength) ||
        (g_melodyIndex >= MAX_PARSED_NOTES))
    {
        Playback_stop();
        return;
    }

    /*
     * ----------------------------------------
     * NOTE duration just finished.
     * ----------------------------------------
     */
    if (g_playbackState ==
        PLAYBACK_NOTE)
    {
        event =
            &s_events[g_melodyIndex];


        /*
         * IMPORTANT:
         *
         * Explicitly turn the note OFF.
         */
        Audio_stopNote();


        /*
         * Is there a rest after this note?
         */
        if (event->restAfterMs > 0U)
        {
            g_playbackState =
                PLAYBACK_REST;


            /*
             * Timer3 now times silence.
             */
            PlaybackTimer_armMs(
                event->restAfterMs
            );
        }
        else
        {
            /*
             * No rest.
             *
             * Go directly to next note.
             */
            g_melodyIndex++;


            playbackStartCurrentEvent();
        }
    }


    /*
     * ----------------------------------------
     * REST just finished.
     * ----------------------------------------
     */
    else if (g_playbackState ==
             PLAYBACK_REST)
    {
        g_melodyIndex++;


        playbackStartCurrentEvent();
    }


    /*
     * Unexpected state.
     */
    else
    {
        Audio_stopNote();


        TimerDisable(
            TIMER3_BASE,
            TIMER_A
        );


        g_playbackActive =
            false;


        g_playbackState =
            PLAYBACK_IDLE;
    }
}

/* ============================================================
 * TIMER3 INITIALIZATION
 * ============================================================
 */

static void PlaybackTimer_init(void)
{
    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_TIMER3
    );


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_TIMER3))
    {
    }


    TimerDisable(
        TIMER3_BASE,
        TIMER_A
    );


    /*
     * One-shot because every note/rest
     * can have a different duration.
     */
    TimerConfigure(
        TIMER3_BASE,
        TIMER_CFG_ONE_SHOT
    );


    TimerIntRegister(
        TIMER3_BASE,
        TIMER_A,
        timer3ISR
    );


    /* Calls FreeRTOS *FromISR through the completion hook, so it must sit at
     * or below the kernel ceiling (and below the audio sample ISR). */
    IntPrioritySet(
        INT_TIMER3A,
        IRQ_PRIO_PLAYBACK
    );


    TimerIntClear(
        TIMER3_BASE,
        TIMER_TIMA_TIMEOUT
    );


    TimerIntEnable(
        TIMER3_BASE,
        TIMER_TIMA_TIMEOUT
    );


    g_playbackState =
        PLAYBACK_IDLE;


    g_playbackActive =
        false;


    g_melodyIndex = 0;
}

/* ============================================================
 * START PARSED MELODY
 * ============================================================
 */

bool Playback_start(const MelodyEvent *events, uint32_t count)
{
    bool started = false;
    bool interruptsWereDisabled = IntMasterDisable();

    TimerDisable(TIMER3_BASE, TIMER_A);
    TimerIntClear(TIMER3_BASE, TIMER_TIMA_TIMEOUT);
    Audio_stopNote();
    (void)TimerIntStatus(TIMER3_BASE, false);
    (void)TimerIntStatus(TIMER2_BASE, false);
    IntPendClear(INT_TIMER3A);
    IntPendClear(INT_TIMER2A);

    g_melodyIndex = 0U;
    g_playbackState = PLAYBACK_IDLE;
    g_playbackActive = false;
    Audio_clearIsrMax();
    s_events = events;
    g_melodyLength = count;
    s_completionPending = false;
    if ((events != NULL) && (g_melodyLength > 0U) && (g_melodyLength <= MAX_PARSED_NOTES))
    {
        s_completionPending = true;
        g_playbackActive = true;
        playbackStartCurrentEvent();
        started = true;
    }

    if (!interruptsWereDisabled)
    {
        IntMasterEnable();
    }

    return started;
}


/* ============================================================
 * PUBLIC INTERFACE (declared in playback.h)
 * ============================================================
 */

void Playback_init(PlaybackCompletionHook completionHook)
{
    s_completionHook = completionHook;
    PlaybackTimer_init();
}

bool Playback_isActive(void)
{
    return g_playbackActive;
}

/* True exactly once after a natural finish. Reproduces the baseline test
 * "completion pending && playback no longer active". */
bool Playback_takeCompletion(void)
{
    bool finished = false;
    bool interruptsWereDisabled = IntMasterDisable();

    if (s_completionPending && !g_playbackActive)
    {
        s_completionPending = false;
        finished = true;
    }

    if (!interruptsWereDisabled)
    {
        IntMasterEnable();
    }

    return finished;
}
