/*
 * control_task.c -- protocol lifecycle (validate -> start -> STOP -> DONE),
 * RTOS object/task creation and the low-rate monitor.
 *
 * TASKS (FreeRTOS priority; higher number = more urgent)
 *   UART0ReadTask  3  uart_task.c : receive framing, timeouts, recovery
 *   PayloadTask    2  here        : CRC, MIDI parse, start playback, DONE/IDLE
 *   MonitorTask    1  here        : 250 ms LED toggle + diagnostics snapshot
 *
 * SYNCHRONISATION (each object has a real producer and consumer)
 *   UARTReadSem  binary  uart0RxIsr (per byte batch) / Uart_payload* -> UART0ReadTask
 *   PayloadSem   binary  UART0ReadTask (payload published) and
 *                        Timer3 ISR via Control_playbackFinishedIsr -> PayloadTask
 *   UARTTxMutex  mutex   every reply, held for the whole message (uart_task.c)
 *
 * PayloadSem only says "check for work". A binary semaphore coalesces gives, so after
 * every wake PayloadTask examines BOTH sources -- Uart_acquirePayload() and
 * Playback_takeCompletion() -- whose own state holds the real information.
 *
 * STOP is handled in UART0ReadTask context through the hook below (hard silence,
 * then ACK_STOPPED/IDLE) at the instant the STOP frame is accepted. It cannot race a
 * validation: the receiver ignores the ring while PayloadTask owns a payload, and
 * the payload is returned only AFTER playback has been started and PLAYING sent.
 * A STOP that follows therefore always finds a started song to cancel, and
 * Playback_stop() discards the song's pending completion so no stale DONE follows.
 *
 * EVENT ARRAY: s_melody (1,024 events) is owned here. Midi_parse() writes it only
 * from PayloadTask while no song is playing (ERR_BUSY refuses a transfer during
 * playback, and only PayloadTask starts playback); playback borrows it read-only
 * from Playback_start() until completion or Playback_stop().
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#include <ti/drivers/GPIO.h>

#include "ti_drivers_config.h"
#include "globals.h"
#include "audio.h"
#include "midi.h"
#include "playback.h"
#include "uart_task.h"
#include "control_task.h"

/* Task priorities (FreeRTOS, not NVIC) and stack depths in WORDS (4 bytes each). */
#define PRIORITY_UART0_READ      3U
#define PRIORITY_PAYLOAD         2U
#define PRIORITY_MONITOR         1U
#define STACK_WORDS_UART0_READ   512U     /* 2048 bytes */
#define STACK_WORDS_PAYLOAD      768U     /* 3072 bytes: CRC, parser frame, reply formatting */
#define STACK_WORDS_MONITOR      256U     /* 1024 bytes */
#define MONITOR_PERIOD_MS        250U

static MelodyEvent s_melody[MAX_PARSED_NOTES];

/* ---------------------------------------------------------------- hooks */

/* Header time (UART0ReadTask): a transfer during playback is refused with ERR_BUSY. */
static bool Control_isBusy(void)
{
    return Playback_isActive();
}

/* STOP frame (UART0ReadTask): hard silence now; the transport sends ACK_STOPPED/IDLE.
 * Playback_stop() masks interrupts for the short, bounded audio quiesce, clears
 * Timer2/Timer3 and discards any pending completion report. */
static void Control_stopPlayback(void)
{
    Playback_stop();
}

static const UartHooks s_uartHooks =
{
    Control_isBusy,
    Control_stopPlayback
};

/* Timer3 ISR (priority 2, legal for FromISR): the melody ended and audio is silent.
 * Only wake PayloadTask; the UART output happens in task context. */
static void Control_playbackFinishedIsr(void)
{
    BaseType_t woken = pdFALSE;

    xSemaphoreGiveFromISR(Glo.Bios.PayloadSem, &woken);
    portYIELD_FROM_ISR(woken);
}

/* ------------------------------------------------------------ PayloadTask */

/* CRC -> ACK_RECEIVED -> parse -> ACK_VALID -> start -> PLAYING, exactly the
 * baseline order; a CRC failure is reported before ACK_RECEIVED. The receiver is
 * released (Uart_payloadAccepted) only after PLAYING, so nothing can interleave. */
static void Control_processPayload(void)
{
    UartPayload payload;
    MidiParseResult parsed;
    uint32_t actualCrc;
    uint32_t count = 0U;

    if (!Uart_acquirePayload(&payload))
    {
        return;
    }

    actualCrc = Uart_crc32(payload.data, payload.length);
    Glo.Diagnostics.LastCalculatedCrc32 = actualCrc;
    if (actualCrc != payload.expectedCrc32)
    {
        Uart_payloadRejected("ERR_CRC");
        return;
    }

    Uart_sendAck("ACK_RECEIVED", payload.length, actualCrc);
    parsed = Midi_parse(payload.data, payload.length, s_melody,
                        MAX_PARSED_NOTES, &count);
    if (parsed != MIDI_PARSE_OK)
    {
        /* Parsing is reached only after accepting a header while idle. */
        Playback_stop();
        Uart_payloadRejected((parsed == MIDI_PARSE_NOTE_CAPACITY) ?
                             "ERR_NOTE_CAPACITY" : "ERR_MIDI");
        return;
    }

    Glo.Diagnostics.TransferSuccessCount++;
    Uart_sendReply("ACK_VALID\r\n");
    if (!Playback_start(s_melody, count))
    {
        /* Unreachable after a successful parse (it guarantees count >= 1), but never
         * leave the host waiting for PLAYING/DONE. */
        Uart_payloadRejected("ERR_MIDI");
        return;
    }
    Uart_sendReply("PLAYING\r\n");
    Uart_payloadAccepted();
}

/* DONE only after real silence; IDLE only if the receiver is between frames.
 * The decision and both lines are inside one TX-mutex hold, so a STOP reply cannot
 * be interleaved or ordered after a stale DONE (Playback_stop discards completion). */
static void Control_reportCompletion(void)
{
    Uart_beginReply();
    if (Playback_takeCompletion())
    {
        Uart_putText("DONE\r\n");
        if (Uart_receiverIdle())
        {
            Uart_putText("IDLE\r\n");
        }
    }
    Uart_endReply();
}

static void Control_payloadTask(void *arg)
{
    (void)arg;

    for (;;)
    {
        xSemaphoreTake(Glo.Bios.PayloadSem, portMAX_DELAY);
        Glo.Diagnostics.PayloadWakeCount++;

        /* The semaphore coalesces: examine every source before blocking again. */
        Control_processPayload();
        Control_reportCompletion();
    }
}

/* ------------------------------------------------------------ MonitorTask */

static void Control_monitorTask(void *arg)
{
    (void)arg;

    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(MONITOR_PERIOD_MS));

        GPIO_toggle(CONFIG_GPIO_LED_0);
        Glo.Diagnostics.MonitorTicks++;

        /* Stack margins are in words (4 bytes); heap in bytes. */
        Glo.Diagnostics.StackFreeMinUartWords =
            uxTaskGetStackHighWaterMark(Glo.Bios.UART0ReadTask);
        Glo.Diagnostics.StackFreeMinPayloadWords =
            uxTaskGetStackHighWaterMark(Glo.Bios.PayloadTask);
        Glo.Diagnostics.StackFreeMinMonitorWords =
            uxTaskGetStackHighWaterMark(NULL);
        Glo.Diagnostics.StackFreeMinIdleWords =
            uxTaskGetStackHighWaterMark(xTaskGetIdleTaskHandle());
        Glo.Diagnostics.HeapFreeBytes = (uint32_t)xPortGetFreeHeapSize();
        Glo.Diagnostics.HeapMinFreeBytes = (uint32_t)xPortGetMinimumEverFreeHeapSize();
    }
}

/* ------------------------------------------------------------------ setup */

bool Control_init(void)
{
    bool created = true;

    Glo.Bios.UARTReadSem = xSemaphoreCreateBinary();
    Glo.Bios.PayloadSem = xSemaphoreCreateBinary();
    Glo.Bios.UARTTxMutex = xSemaphoreCreateMutex();
    if ((Glo.Bios.UARTReadSem == NULL) || (Glo.Bios.PayloadSem == NULL) ||
        (Glo.Bios.UARTTxMutex == NULL))
    {
        Glo.Diagnostics.CreateFailCount++;
        return false;
    }

    Playback_init(Control_playbackFinishedIsr);
    Uart_init(&s_uartHooks);

    /* xTaskCreate() returns pdPASS (1) or errCOULD_NOT_ALLOCATE_REQUIRED_MEMORY (-1). */
    created = created && (xTaskCreate(Uart_readTask, "UART0Rx", STACK_WORDS_UART0_READ, NULL,
                                      PRIORITY_UART0_READ, &Glo.Bios.UART0ReadTask) == pdPASS);
    created = created && (xTaskCreate(Control_payloadTask, "Payload", STACK_WORDS_PAYLOAD, NULL,
                                      PRIORITY_PAYLOAD, &Glo.Bios.PayloadTask) == pdPASS);
    created = created && (xTaskCreate(Control_monitorTask, "Monitor", STACK_WORDS_MONITOR, NULL,
                                      PRIORITY_MONITOR, &Glo.Bios.MonitorTask) == pdPASS);
    if (!created)
    {
        Glo.Diagnostics.CreateFailCount++;
        return false;
    }

    return true;
}
