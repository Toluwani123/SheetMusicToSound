# Checkpoint 03 — rtos_monophonic (Stage 3: the live pipeline)

**What it is.** The complete design: UART RX interrupt → 1,024-byte ring → `UARTReadSem` → `UART0ReadTask` (framing, finite
10 ms wait so timeouts run without bytes) → `PayloadSem` → `PayloadTask` (CRC, parse, start, DONE) with `UARTTxMutex`
serialising whole replies; Timer3 completion hook → `PayloadSem`; STOP/BUSY hooks; NVIC priorities audio 0 / Timer3 and UART 2 /
Timer4 3; PRIMASK quiesce in `Audio_*` and `Playback_*`; `MonitorTask` with `Glo.Diagnostics`.
`src/` = the project sources (identical to `projects\gpiointerrupt_freertos`), `FreeRTOSConfig.h` included.

**Verified.** Headless CCS build 0 errors / 0 warnings. `evidence/` has the build log, size report and link inspection.
Architecture, ISR-rule, priority and header checks pass (`evidence/offline_architecture.txt` in the main folder).

**Hardware behaviour.** Not run. This is the checkpoint under test; 04 adds only documentation, tools and build output.
