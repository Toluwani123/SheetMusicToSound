"""HOST-TOOLING SELF-TEST: runs check_rtos_extra.py against a small PROTOCOL MODEL.

This is NOT a firmware test and its PASS lines are NOT board results. The model
(MockMsp below) is written from the SMID protocol description; it only proves that
the test script's own control flow, timing windows and outcome classification behave
as intended before they are used on the real board. A deliberately broken model
variant must make the script FAIL, which shows the checks can actually fail.

python selftest_host_tooling.py          # about 1 minute (real-time delays)
"""
import struct
import sys
import threading
import time
import zlib

import check_rtos_extra as extra
import newmiditst as sender

SONG_SECONDS = 3.25  # d5_reference.mid


class MockSerial:
    """Minimal pySerial stand-in whose other end is MockMsp."""

    def __init__(self, behavior="good"):
        self.timeout = 0.05
        self.write_timeout = 5.0
        self.behavior = behavior
        self.out = []            # (due_time, bytes) lines going to the host
        self.lock = threading.Lock()
        self.rx = bytearray()
        self.state = "idle"      # idle | header | payload | playing | recover
        self.expected = 0
        self.header_started = 0.0
        self.play_until = 0.0
        self.recover_at = None
        self.pending_extra = bytearray()
        self.song_token = 0

    # -- host side API used by newmiditst ---------------------------------
    @property
    def in_waiting(self):
        with self.lock:
            return sum(len(b) for t, b in self.out if t <= time.monotonic())

    def reset_input_buffer(self):
        with self.lock:
            self.out.clear()

    def reset_output_buffer(self):
        pass

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def read(self, size=1):
        deadline = time.monotonic() + (self.timeout or 0)
        while True:
            self._tick()
            with self.lock:
                for i, (t, b) in enumerate(self.out):
                    if t <= time.monotonic():
                        chunk = bytes(b[:size])
                        if len(b) > size:
                            self.out[i] = (t, b[size:])
                        else:
                            self.out.pop(i)
                        return chunk
            if time.monotonic() >= deadline:
                return b""
            time.sleep(0.002)

    def write(self, data):
        self.rx.extend(data)
        self._consume()
        return len(data)

    # -- the modelled firmware -------------------------------------------
    def _emit(self, text, delay=0.003):
        with self.lock:
            self.out.append((time.monotonic() + delay, (text + "\r\n").encode()))

    def _tick(self):
        now = time.monotonic()
        if self.state == "header" and now - self.header_started >= 1.0:
            self._emit("ERR_TIMEOUT")
            self.state = "recover"
            self.recover_at = now + 0.25
            self.rx.clear()
        if self.state == "recover" and self.recover_at and now >= self.recover_at:
            self._emit("IDLE")
            self.state = "idle"
            self.recover_at = None
        if self.state == "playing" and now >= self.play_until:
            if self.behavior != "never_done":
                self._emit("DONE")
                self._emit("IDLE")
            self.state = "idle"

    def _consume(self):
        while True:
            if self.state in ("idle", "playing") and len(self.rx) >= 1:
                if self.rx[0:1] != b"S":
                    self.rx.pop(0)
                    continue
                self.state_before = self.state
                if self.state == "idle":
                    self.state = "header"
                    self.header_started = time.monotonic()
            if self.state == "header" or (self.state == "playing" and len(self.rx) >= 1):
                if len(self.rx) < 16:
                    return
                header = bytes(self.rx[:16])
                del self.rx[:16]
                magic, version, command, length, crc = struct.unpack("<4sBB2xII", header)
                if command == 1:  # STOP
                    self.song_token += 1
                    self.state = "idle"
                    self._emit("ACK_STOPPED")
                    self._emit("IDLE")
                    continue
                if self.state == "playing":
                    self._emit("ERR_BUSY")
                    self.state = "recover"
                    self.recover_at = time.monotonic() + 0.25
                    continue
                self.expected, self.crc = length, crc
                self.state = "payload"
                self._emit("ACK_READY %d %08X" % (length, crc))
                continue
            if self.state == "payload":
                if len(self.rx) < self.expected:
                    return
                payload = bytes(self.rx[:self.expected])
                del self.rx[:self.expected]
                extra_bytes = bytes(self.rx)
                self.rx.clear()
                if extra_bytes and self.behavior != "silent_loss":
                    if self.behavior == "outcome_a" or len(extra_bytes) % 2:
                        pass
                    # model outcome A for a glued frame when behavior == outcome_a
                if extra_bytes and self.behavior == "outcome_a":
                    self._emit("ERR_SIZE")
                    self.state = "recover"
                    self.recover_at = time.monotonic() + 0.25
                    return
                self._emit("ACK_RECEIVED %d %08X" % (self.expected, zlib.crc32(payload) & 0xFFFFFFFF))
                self._emit("ACK_VALID")
                self._emit("PLAYING")
                self.state = "playing"
                self.play_until = time.monotonic() + SONG_SECONDS
                if extra_bytes:
                    if self.behavior == "silent_loss":
                        return  # model bug: glued STOP lost, song keeps playing
                    # outcome B: the queued STOP frame is processed after PLAYING
                    self.rx.extend(extra_bytes)
                    continue
                return
            return


def run(behavior, test, **kw):
    sender.serial.Serial = lambda *a, **k: MockSerial(behavior)
    argv = ["--test", test] + (["--cycles", str(kw.get("cycles", 6))] if test == "R1" else [])
    sender.STARTUP_QUIET_SECONDS = 0.05
    return extra.main(argv)


def main():
    results = []

    def expect(name, got, want):
        ok = got == want
        results.append(ok)
        print(("SELFTEST-OK   " if ok else "SELFTEST-BAD  ") + name + f" (exit {got}, wanted {want})", flush=True)

    expect("R1 against a model that cancels correctly", run("good", "R1", cycles=6), 0)
    expect("R2 against a model that times out correctly", run("good", "R2"), 0)
    expect("R3 outcome B (STOP honoured) is accepted", run("good", "R3"), 0)
    expect("R3 outcome A (ERR_SIZE) is accepted", run("outcome_a", "R3"), 0)
    expect("R3 against a model that silently loses the glued STOP must FAIL", run("silent_loss", "R3"), 1)
    expect("R1 against a model whose song never reports DONE must FAIL", run("never_done", "R1", cycles=2), 1)
    print("\nHOST-TOOLING SELF-TEST", "PASSED" if all(results) else "FAILED",
          "- these results describe the test script only, not the firmware.")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
