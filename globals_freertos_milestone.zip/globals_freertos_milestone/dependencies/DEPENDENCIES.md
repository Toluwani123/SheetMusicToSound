# Dependencies, versions and source hashes

Everything needed to rebuild is either in this folder or installed with the tools named here.
Nothing is downloaded at build time.

## Toolchain actually used for the recorded build

| Item | Version / location |
|---|---|
| Code Composer Studio (Theia) | 21.0.1.00010, `C:\ti\ccs2101` (headless: `ccs-server-cli.bat`, GNU make 4.4.1) |
| Compiler | GNU Tools for Arm Embedded Processors 9-2019-q4-major, `arm-none-eabi-gcc 9.2.1 20191025`, `C:\ti\gcc_arm_none_eabi_9_2_1` |
| SimpleLink MSP432E4 SDK | 4.20.00.12, `C:\ti\simplelink_msp432e4_sdk_4_20_00_12` |
| SysConfig | 1.4.0, `C:\ti\sysconfig_1.4.0` |
| Target | MSP432E401Y (MSP-EXP432E401Y), Cortex-M4F, XDS110 |
| Host tools | Python 3.14.7, pySerial 3.5 (test scripts only) |
| Compiler flags | from the CCS project: `-mcpu=cortex-m4 -march=armv7e-m -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -ffunction-sections -fdata-sections -g -gdwarf-3 -gstrict-dwarf -Wall -std=c99` (no `-O`, i.e. `-O0`, as in the baseline) |

## FreeRTOS kernel

* **Version: FreeRTOS Kernel V10.2.1** (file headers read "FreeRTOS Kernel V10.2.1"; the `tskKERNEL_VERSION_NUMBER`
  macro in that release still says "V10.2.0" - an upstream quirk, not a mixed install).
  The SDK 4.20 manifest and its `imports.mak.windows` (`FREERTOS_INSTALL_DIR ?= c:/FreeRTOSv10.2.1_191129`)
  name this release; the Core SDK validated 10.2.1, so a newer kernel was **not** substituted.
* Source obtained from `https://github.com/FreeRTOS/FreeRTOS-Kernel/archive/refs/tags/V10.2.1.tar.gz`
  (sha256 `ffe63d39864d640f201ff9d51ec0559de6c107fd7a35110eac546af734f5e3dd`), which has the
  `FreeRTOS/Source/...` layout the SDK expects.
* **Where it lives:** copied into `projects/freertos_kernel_glo/FreeRTOS/` (28 files:
  `tasks.c queue.c list.c timers.c event_groups.c stream_buffer.c`, `include/`,
  `portable/GCC/ARM_CM4F/{port.c,portmacro.h}`, `portable/MemMang/heap_4.c`, `License/license.txt`).
  `kernel_sources_sha256.txt` lists each file's SHA-256; `python verify_kernel_sources.py` checks them and
  `python verify_kernel_sources.py --download` re-fetches the upstream tag and compares byte for byte
  (run at delivery: 28 files, 0 differences).
* **No `FREERTOS_INSTALL_DIR` variable is needed** by this project. (The SDK's own example projects need it.)
* Memory manager `heap_4`, port `GCC/ARM_CM4F`, `configTICK_RATE_HZ` 1000, 3 priority bits.
* `projects/freertos_kernel_glo/FreeRTOSConfig.h` = the SDK 4.20.00.12 file for this board plus four marked deltas
  (heap 128 KB -> 32 KB; malloc-failed hook on; `configASSERT` records file/line and mutes audio;
  stack-high-water and idle-handle APIs enabled).

## SDK files used (linked by CCS from the SDK, not copied, unless stated)

The kernel library project links the SDK driver-porting layer and startup file through
`${COM_TI_SIMPLELINK_MSP432E4_SDK_INSTALL_DIR}`; the app project copies the SDK's FreeRTOS linker script and
SysConfig file. SDK files and their hashes at delivery:

| SDK file (under the SDK install directory) | SHA-256 |
|---|---|
| `kernel/freertos/dpl/ClockP_freertos.c` | `61d92b133a71238a598fbd7198ca1ed241d5f532b955bdf2b91d92692dc231a9` |
| `kernel/freertos/dpl/DebugP_freertos.c` | `463bb1e095bc6865346c21988e702556f4aa5032dc7bc0eb1b1b8c8300c80c03` |
| `kernel/freertos/dpl/HwiPMSP432E4_freertos.c` | `055ed69c0ddcb2c84d0efdd28eab1473a8b80ecc98b691457a72db38dac289fc` |
| `kernel/freertos/dpl/MutexP_freertos.c` | `2fdf1034852dabd1033db6090bef4d767071b7a166bfe8d5e9ead83d5955f0b1` |
| `kernel/freertos/dpl/PowerMSP432E4_freertos.c` | `ba2dcb49ba853474ef5f3bfde9376a1631b978a5260584f38b79e0d5697368fe` |
| `kernel/freertos/dpl/SemaphoreP_freertos.c` | `053448c77aef80d63a50e7f3325fbbff2564a966a801a0f4e076fd161ec37743` |
| `kernel/freertos/dpl/SystemP_freertos.c` | `2f44ec508c9814d9e188f24cd204efef54732807562a6dc9d0e779ffabf9d56f` |
| `kernel/freertos/startup/startup_msp432e4_gcc.c` | `17a71c75ff02b65092ba5b85be717e3c956ce6f369635343d7361f8cb1edf7ec` |
| `kernel/freertos/builds/MSP_EXP432E401Y/release/FreeRTOSConfig.h` | `f6133bc3b9234f54e46e84a21c88bfe1ed135f0ad418f2eb3c6ed3d1487cebfe` |
| `examples/rtos/MSP_EXP432E401Y/drivers/gpiointerrupt/freertos/gcc/MSP_EXP432E401Y_FREERTOS.lds` | `92274a05b249040d79e4fb0c457a097c6445f76a730928260cedfeb4b20b271b` |
| `examples/rtos/MSP_EXP432E401Y/drivers/gpiointerrupt/freertos/gpiointerrupt.syscfg` | `4132f313ba3ff4d03fdd5a9a40854a0336ec56a6d076c0c5803894a6b1879543` |
| `source/ti/devices/msp432e4/driverlib/lib/gcc/m4f/msp432e4_driverlib.a` | `f5a705fd696561a110d13d9853a5f8597b086ae06c409aecfbccef08889b3b6c` |
| `source/ti/drivers/lib/drivers_msp432e4.am4fg` | `2a63d65b1ae84dc0fd094c2ad5f8abffcaaf8405d5ad40b99865ae7a0c167a9e` |

The TI POSIX layer (`ti/posix/freertos/*.c`) used by the SDK examples is **not** built: the application uses
native FreeRTOS tasks and semaphores.

## Project source hashes (delivered tree)

| File (under `projects/`) | SHA-256 |
|---|---|
| `freertos_kernel_glo/dpl/README.txt` | `ab3d71dbd3fc4d2999ccbc45c8ae11bab9de0a2340efd62f1c865eae6c85f924` |
| `freertos_kernel_glo/FreeRTOSConfig.h` | `bac64bfa35052770a9673f0369f7f47088b4bf0a2ecb233283132c1fdb977a53` |
| `freertos_kernel_glo/README.md` | `aec3621854a34f709f1cdac7f2165d828403097e17fab84c19ce8fd2eed35741` |
| `freertos_kernel_glo/sdk_startup/README.txt` | `d7c7ab398c833ca3b255b83f44930098aff89c66f1092f023ad34da27acfc949` |
| `gpiointerrupt_freertos/audio.c` | `04229d134e8488f59dfddcc257d2ff0b70e539e412782843745a818c0a5adaf2` |
| `gpiointerrupt_freertos/audio.h` | `7476d8b978c389d86f6dea46d298e3fc58aa4bc9f90118d41c7b8cd720b7a18a` |
| `gpiointerrupt_freertos/control_task.c` | `82c7a51230fd319f5a6b312068a75e43df2a7657248d6f39b05b115654f965cd` |
| `gpiointerrupt_freertos/control_task.h` | `071d85975d6c01536b6a4e1f156a11c028bf86fc3e16232409f5862d7123d844` |
| `gpiointerrupt_freertos/globals.c` | `31be1080df1b13a8b7dd02d4d86775fe7296f9080af8ef631b3082d478dbd541` |
| `gpiointerrupt_freertos/globals.h` | `46fbe17e86d545ffce0130ca7031ed58487dcfce8cec24a594e864cba253bbfc` |
| `gpiointerrupt_freertos/gpiointerrupt.syscfg` | `4132f313ba3ff4d03fdd5a9a40854a0336ec56a6d076c0c5803894a6b1879543` |
| `gpiointerrupt_freertos/main_freertos.c` | `6e79bd0826c901df64dc2b0d466e1501b87459fdcb965f9e12fdb318651ef582` |
| `gpiointerrupt_freertos/midi.c` | `51c79687b62f3cf3339d1bbe0debac5600be9fcbe653ef63012083fba7923a66` |
| `gpiointerrupt_freertos/midi.h` | `f8f10c0935d6a9846f3c281f3a4aa7f39e62bdac3b440244e18249d4ea87f540` |
| `gpiointerrupt_freertos/MSP_EXP432E401Y_FREERTOS.lds` | `92274a05b249040d79e4fb0c457a097c6445f76a730928260cedfeb4b20b271b` |
| `gpiointerrupt_freertos/playback.c` | `1a0b1cfba50701c4ad44f88f1943abd1630d6c949db412f74d9b70a929c6110c` |
| `gpiointerrupt_freertos/playback.h` | `b9cc960bbd66c27194d8b51432349a986299e76e18f0b77e2035c3bebce3e15e` |
| `gpiointerrupt_freertos/README.md` | `65d5cfafe78e9cafda3a8604818928b2180c53778967d0fc1e6e9359f75475dd` |
| `gpiointerrupt_freertos/targetConfigs/readme.txt` | `02feca4db7d4036c8bf7f75554ce0cc4798454d6ce1aa003934d95410587280e` |
| `gpiointerrupt_freertos/uart_task.c` | `5198d36e2827b36c7eba463391dcbceaff3c38c0d95296ef59c447c4a348a489` |
| `gpiointerrupt_freertos/uart_task.h` | `8507e5fe4c746119450abfdc18532160a69967cc596ddfb9d49205dc7e59ec87` |

`../build_output/SHA256.txt` has the hashes of the delivered `.out`, `.map` and kernel library.
`../checkpoints/00_before_globals_rtos/SHA256.txt` has the baseline `gpiointerrupt.c`
(`ac9f9...c687`, identical to the supplied `latestb4rtos.zip`, sha256 `7bf4d9678647c9060b40378cf07febd0f486d73d0e218a35ef8ee4c267a7081a`).

## Reproduce the build without the GUI

```powershell
cd C:\Users\iembi\workspace_ccstheia\globals_freertos_milestone\test_tools
powershell -ExecutionPolicy Bypass -File build_headless.ps1 `
    -Workspace C:\temp\ws_glo `
    -KernelProject ..\projects\freertos_kernel_glo `
    -AppProject    ..\projects\gpiointerrupt_freertos `
    -LogFile       C:\temp\build_log.txt
```

This imports both projects into a scratch workspace and runs the same GNU make/GCC/SysConfig chain as the GUI.
Output: `projects\gpiointerrupt_freertos\Debug\gpiointerrupt_freertos.out` (and `.map`).
