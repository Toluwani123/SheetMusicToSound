"""Verify the FreeRTOS kernel sources inside projects/freertos_kernel_glo.

  python verify_kernel_sources.py            compare with the recorded SHA-256 list
  python verify_kernel_sources.py --download re-fetch the upstream V10.2.1 tag and
                                             compare every file with it byte for byte

Upstream: https://github.com/FreeRTOS/FreeRTOS-Kernel/archive/refs/tags/V10.2.1.tar.gz
          sha256 ffe63d39864d640f201ff9d51ec0559de6c107fd7a35110eac546af734f5e3dd
This tag uses the FreeRTOS/Source/... layout that the SimpleLink SDK 4.20 kernel build expects
(its imports.mak default is FreeRTOSv10.2.1_191129). Only the files below are copied.
Source headers say "FreeRTOS Kernel V10.2.1"; upstream task.h still defines
tskKERNEL_VERSION_NUMBER as "V10.2.0" in this release (an upstream quirk).
"""
import hashlib
import io
import sys
import tarfile
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
KERNEL = HERE.parent / "projects" / "freertos_kernel_glo"
LIST = HERE / "kernel_sources_sha256.txt"
URL = "https://github.com/FreeRTOS/FreeRTOS-Kernel/archive/refs/tags/V10.2.1.tar.gz"
TAR_SHA256 = "ffe63d39864d640f201ff9d51ec0559de6c107fd7a35110eac546af734f5e3dd"
PREFIX = "FreeRTOS-Kernel-10.2.1/"


def project_files():
    return sorted(p for p in (KERNEL / "FreeRTOS").rglob("*") if p.is_file())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    bad = 0
    if "--download" in sys.argv:
        blob = urllib.request.urlopen(URL, timeout=120).read()
        got = sha(blob)
        print("upstream tarball sha256", got, "OK" if got == TAR_SHA256 else "MISMATCH")
        bad += got != TAR_SHA256
        tar = tarfile.open(fileobj=io.BytesIO(blob), mode="r:gz")
        for path in project_files():
            member = PREFIX + path.relative_to(KERNEL).as_posix()
            data = tar.extractfile(member).read()
            same = data == path.read_bytes()
            bad += not same
            print(("same     " if same else "DIFFERS  ") + member)
    else:
        recorded = dict(line.split("  ", 1)[::-1] for line in LIST.read_text().splitlines() if line.strip())
        for path in project_files():
            rel = path.relative_to(KERNEL).as_posix()
            ok = recorded.get(rel) == sha(path.read_bytes())
            bad += not ok
            print(("same     " if ok else "DIFFERS  ") + rel)
        missing = set(recorded) - {p.relative_to(KERNEL).as_posix() for p in project_files()}
        for rel in sorted(missing):
            bad += 1
            print("MISSING  " + rel)
    print(f"\n{bad} problem(s).")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
