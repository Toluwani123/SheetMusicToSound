# Globals + FreeRTOS monophonic milestone — implementation summary

**Status.** Implemented and built for the target. **Nothing has been run on the board.** Every hardware, listening and
timing item is listed as pending in section 11; none is claimed.

The firmware plays exactly what the previous firmware played (monophonic MIDI, 20 kHz sine with linear interpolation,
5 ms note envelopes, STOP, busy handling, the same serial replies) but is now split into modules, shares one
`Glo` object, and runs on FreeRTOS V10.2.1 with three tasks woken by real semaphores and one mutex protecting
complete serial replies.

---

## 1. What is in the delivery

| Folder / file | Purpose |
|---|---|
| `projects/gpiointerrupt_freertos/` | **The final CCS project** (app, 7 source pairs + syscfg + linker script) |
| `projects/freertos_kernel_glo/` | FreeRTOS V10.2.1 kernel library project the app references |
| `build_output/` | The real `.out`, `.map`, kernel `.a`, build log, size report, SHA-256 (built headless, see §10) |
| `checkpoints/00..04` | Stage checkpoints with their own status/evidence (kept outside the compiled projects) |
| `test_tools/` | Offline checks, headless build script, board-test scripts |
| `evidence/` | Output of every offline check |
| `START_HERE_TESTING.md` | Import, build, flash, and the single consolidated test session |
| `FINAL_TEST_PLAN.md`, `FINAL_TEST_RECORD.txt` | What to run and a blank result sheet (no invented PASS) |
| `dependencies/` | Versions, hashes, kernel verifier |
| `PRESENTATION_OUTLINE.md` | Four content slides + your demo slide (no deck made) |

The original NoRTOS project `workspace_ccstheia\gpiointerrupt` was **not modified**.

---

## 2. Files and what each one is for

One file at a time. Arrows show who may call whom; nothing calls "upward".

```
main_freertos.c  ──►  control_task.c  ──►  playback.c ──► audio.c
                          │   │
                          │   └──────────►  midi.c            (pure computation)
                          └──────────────►  uart_task.c
globals.h/.c are included by everything that shares Glo.
```

| File | Role | Private state / hardware it owns |
|---|---|---|
| `main_freertos.c` | The only `main()`: `Board_init`, `GPIO_init`, `Audio_init`, `Control_init`, `vTaskStartScheduler`. Kernel hooks (stack overflow, malloc failed, `configASSERT`) record into `Glo.Diagnostics` and mute the output. | — |
| `globals.h` / `globals.c` | `extern Globals Glo;` / its **single** definition. `Glo.Bios` = task, semaphore, mutex handles. `Glo.Diagnostics` = counters. Also the NVIC priority plan with compile-time checks. | — |
| `audio.h` / `audio.c` | DAC8311 write, 256-entry sine table, frequency table, interpolation, envelope, `Audio_startNote/stopNote`, Timer2 sample ISR. Moved verbatim. | SSI2 (PD3/PD1), PN3 SYNC, PH2 amplifier, Timer2, phase/envelope state |
| `midi.h` / `midi.c` | `Midi_parse()` and `MelodyEvent`. The old `parseSimpleMidi` body, only its output/return plumbing changed. No hardware, no RTOS. | parser workspace |
| `playback.h` / `playback.c` | Note/rest progression, `Playback_start/stop`, completion flag + hook. Calls only the public audio API. | Timer3, melody index/state |
| `uart_task.h` / `uart_task.c` | UART0 init, **RX interrupt → 1,024-byte ring**, SMID framing/timeouts/recovery (the old state machine), CRC, `Uart_beginReply/endReply` (TX mutex), `Uart_readTask`. | UART0, Timer4 (1 ms clock), ring, 16 KB payload buffer, receiver state |
| `control_task.h` / `control_task.c` | Creates the semaphores, mutex and tasks. `PayloadTask` (CRC → parse → start → completion) and `MonitorTask`. Supplies the STOP/BUSY hooks. | the 1,024-event array |

Boundaries enforced by `test_tools/check_architecture.py` (§10): no FreeRTOS call in `audio.c`/`playback.c`; `midi.c`
includes no hardware or RTOS header; `control_task.c` never touches receiver state or UART registers; `uart_task.c`
includes no playback/audio header (it reaches them only through two hooks).

---

## 3. The shared global pattern

`globals.h` declares, `globals.c` allocates (excerpt, abridged):

```c
/* globals.h */
#ifndef GLOBALS_H
#define GLOBALS_H
#include "FreeRTOS.h"  #include "task.h"  #include "semphr.h"

typedef struct {
    TaskHandle_t UART0ReadTask;   TaskHandle_t PayloadTask;   TaskHandle_t MonitorTask;
    SemaphoreHandle_t UARTReadSem; SemaphoreHandle_t PayloadSem; SemaphoreHandle_t UARTTxMutex;
} RtosHandles;

typedef struct { RtosHandles Bios; GlobalsDiagnostics Diagnostics; } Globals;
extern Globals Glo;
#endif

/* globals.c */
#include "globals.h"
Globals Glo = {0};                      /* the only definition */
```

* The include guard only prevents double processing; `extern` and `volatile` give **no** concurrency protection.
  Every `Diagnostics` member names exactly one writer, so none needs a lock.
* Authoritative state is **not** mirrored in `Glo`: receiver state, payload buffer, events, audio phase stay `static`
  in their owner. (An unsynchronised copy that the program trusts would be a bug.)
* `Glo.Bios` is filled in `Control_init()` **before** the scheduler starts and before any ISR is enabled.

---

## 4. Tasks, semaphores, mutex — every object has a producer and a consumer

| Object | Created | Producer (gives) | Consumer (takes) | What it means |
|---|---|---|---|---|
| `UARTReadSem` binary | `control_task.c:204` | `uart0RxIsr` (`uart_task.c:181`, once per received batch); `Uart_payloadAccepted/Rejected` (`:825`, `:836`) | `UART0ReadTask` (`:788`, with a **10 ms timeout**) | "bytes or an error arrived" / "payload returned, rescan the ring" |
| `PayloadSem` binary | `control_task.c:205` | `UART0ReadTask` when a payload is published (`uart_task.c:681`); Timer3 ISR hook (`control_task.c:85`) | `PayloadTask` (`control_task.c:162`) | "check for work": a payload is ready and/or a song finished |
| `UARTTxMutex` mutex | `control_task.c:206` | the task that took it, `Uart_endReply` (`:743`) | any task sending a reply, `Uart_beginReply` (`:735`) | one **complete** reply at a time; priority inheritance applies |
| `UART0ReadTask` prio 3 | `control_task.c:218` | | | receive framing, timeouts, recovery, STOP |
| `PayloadTask` prio 2 | `control_task.c:220` | | | CRC, parse, start playback, DONE/IDLE |
| `MonitorTask` prio 1 | `control_task.c:222` | | | 250 ms LED toggle + diagnostics (no serial output) |

`test_tools/check_architecture.py` prints these sites from the source and checks create/give/take counts.

### The wake-up chain (excerpts)

```c
/* uart_task.c : UART0 interrupt, priority 2 -- drain FIFO into the ring, wake the task ONCE */
    s_rxHead = head;                                   /* publish bytes (after the data) */
    ...
    if ((stored != 0U) || (faults != 0U))
    {
        xSemaphoreGiveFromISR(Glo.Bios.UARTReadSem, &woken);
        portYIELD_FROM_ISR(woken);
    }

/* uart_task.c : UART0ReadTask -- blocks, but never longer than 10 ms */
    if (xSemaphoreTake(Glo.Bios.UARTReadSem, pdMS_TO_TICKS(UART_TASK_WAIT_MS)) == pdTRUE)
        Glo.Diagnostics.UartWakeCount++;
    else
        Glo.Diagnostics.UartTimeoutPasses++;     /* timeouts are enforced even with NO new bytes */
    UARTReceiver_service();

/* uart_task.c : payload complete -> publish, then wake the controller */
    s_payloadPublished = true;
    COMPILER_BARRIER();
    xSemaphoreGive(Glo.Bios.PayloadSem);

/* control_task.c : PayloadTask -- a binary semaphore coalesces, so look at EVERY source */
    xSemaphoreTake(Glo.Bios.PayloadSem, portMAX_DELAY);
    Glo.Diagnostics.PayloadWakeCount++;
    Control_processPayload();        /* Uart_acquirePayload(): is a payload published? */
    Control_reportCompletion();      /* Playback_takeCompletion(): did a song finish?  */
```

```c
/* uart_task.c : the mutex protects a WHOLE reply, not each character */
void Uart_beginReply(void) { (void)xSemaphoreTake(Glo.Bios.UARTTxMutex, portMAX_DELAY); }
void Uart_endReply(void)   { (void)xSemaphoreGive(Glo.Bios.UARTTxMutex); }

/* control_task.c : DONE and the conditional IDLE are one hold; the decision is made INSIDE the hold */
    Uart_beginReply();
    if (Playback_takeCompletion())
    {
        Uart_putText("DONE\r\n");
        if (Uart_receiverIdle()) { Uart_putText("IDLE\r\n"); }
    }
    Uart_endReply();
```

The mutex does **not** by itself order `ACK_VALID` → `PLAYING` → `DONE`. That order comes from (a) one task
(`PayloadTask`) sending them in sequence, and (b) the receiver being frozen until `PLAYING` has been sent (§6).

---

## 5. Normal flow, traced through the code

1. **Header.** Host sends 16 bytes. The UART ISR (`uart0RxIsr`) moves them from the 16-byte hardware FIFO into the ring
   and gives `UARTReadSem`. `UART0ReadTask` wakes, pops bytes, runs the old state machine (`UARTReceiver_processByte`).
   At the 16th byte `UARTReceiver_acceptHeader` checks version/size, asks `isBusy()` (→ `Playback_isActive()`), then
   sends `ACK_READY <len> <crc>` under the mutex.
2. **Payload.** The same path fills `fileBuffer` (no command scanning inside the payload — SMID bytes in MIDI data are
   ordinary data). At the last byte `receiverState = VALIDATE`.
3. **Hand-off.** `UARTReceiver_publishPayload` applies the old unexpected-data guard (now over the **ring and the FIFO**),
   sets `s_payloadPublished` and gives `PayloadSem`.
4. **Validate.** `PayloadTask` wakes: `Uart_acquirePayload()` → CRC. Mismatch → `Uart_payloadRejected("ERR_CRC")`
   **before** `ACK_RECEIVED` (as before). Match → `ACK_RECEIVED`, then `Midi_parse()` into the event array. Failure →
   `Playback_stop()` and `ERR_MIDI` / `ERR_NOTE_CAPACITY`.
5. **Start.** `ACK_VALID` → `Playback_start()` (arms Timer3, first note via `Audio_startNote`) → `PLAYING` →
   `Uart_payloadAccepted()` (receiver back to `WAIT_MAGIC`, ring rescanned).
6. **Play.** Timer2 renders samples (priority 0, no kernel calls); Timer3 advances notes/rests; `MonitorTask` keeps
   toggling the LED and refreshing diagnostics.
7. **Finish.** Timer3 ISR: last note → hard silence → completion hook → `xSemaphoreGiveFromISR(PayloadSem)`.
   `PayloadTask` → `Playback_takeCompletion()` → `DONE`, then `IDLE` if the receiver is between frames.

### STOP

`UART0ReadTask` recognises a valid STOP header at a frame boundary (even during playback) and, **in its own context**,
calls the controller's hook → `Playback_stop()` (Timer3 off, Timer2 off, DAC to midpoint, amplifier off, pending
completion discarded), resets the receiver, and sends `ACK_STOPPED\r\nIDLE\r\n` as one reply. Latency from the last STOP
byte: ≤ ≈0.3 ms (UART receive timeout) + task switch + the masked quiesce (a few tens of µs) — estimated, not measured.

### Why a stale DONE or a resurrected song cannot happen

* `Playback_stop()` clears the song's completion flag, so a `PayloadSem` give already in flight finds nothing.
* A DONE decision and a STOP reply both run inside the TX mutex; either DONE goes out **before** `ACK_STOPPED`
  (the song really finished first) or not at all.
* The receiver does not consume the ring while `PayloadTask` owns a payload (`VALIDATE`), and the payload is returned
  only **after** playback started and `PLAYING` was sent. So a STOP can never be handled between "validated" and
  "started": it is queued and acts on the already-started song immediately afterwards (worst-case wait = CRC + parse,
  an estimated 15–25 ms at `-O0`, unmeasured).
* The `WAIT_MAGIC`→`RECOVER` change inside `UARTReceiver_fail` is made in a short `taskENTER_CRITICAL()` section so the
  other task never observes the intermediate state.

---

## 6. Ownership

| Thing | Owner | Borrowed by | Becomes reusable |
|---|---|---|---|
| UART bytes | ISR writes ring head; `UART0ReadTask` writes tail | — | per byte |
| 16 KB payload buffer `fileBuffer` | `uart_task.c` | `PayloadTask` via `UartPayload` descriptor (pointer + length + CRC, **no copy**) | `Uart_payloadAccepted/Rejected` |
| 1,024-event array `s_melody` | `control_task.c` | `playback.c` (const view) from `Playback_start` | completion or `Playback_stop` |
| receiver state | `UART0ReadTask`, except in `VALIDATE` | `PayloadTask` | state changed last by accepted/rejected |
| playback state | `playback.c` (changes under short PRIMASK sections) | readers use `Playback_isActive/takeCompletion` | — |
| UART TX | whoever holds `UARTTxMutex` | | `Uart_endReply` |

`Midi_parse` only runs while no song is playing: a header during playback is refused (`ERR_BUSY`) and only
`PayloadTask` starts songs, so parsing can never overwrite events being played.

---

## 7. Priorities — two different scales

**FreeRTOS task priorities** (higher number runs first): `UART0ReadTask` 3, `PayloadTask` 2, `MonitorTask` 1, idle 0
(kernel timer task 5, unused by the application).

**NVIC interrupt priorities** (lower number is more urgent; 3 implemented bits):

| Priority | Interrupt | Rule |
|---|---|---|
| 0 | Timer2 audio sample ISR | **above** `configMAX_SYSCALL_INTERRUPT_PRIORITY` (1): no kernel calls, never delayed by kernel critical sections |
| 2 | Timer3 note scheduler | may call `…FromISR` (completion hook) |
| 2 | UART0 RX/RT/error | `xSemaphoreGiveFromISR` only |
| 3 | Timer4 1 ms transfer clock | kernel-independent counter |
| 7 | SysTick, PendSV | set by the FreeRTOS port |

`globals.h` carries compile-time checks that audio is above the ceiling and the `FromISR` users are not.
**Behaviour change to be aware of:** in the baseline all three timer ISRs shared priority 0, so Timer3's note switch could
not be interrupted by Timer2. Now Timer2 (0) can preempt Timer3/UART (2). The shared hardware (SSI2/DAC, envelope
state) is therefore guarded by `Audio_startNote/stopNote`, `Playback_start/stop` and `Playback_takeCompletion`, which mask
interrupts (PRIMASK, nesting-safe) for one DAC transaction (~10 µs against the 50 µs sample period) — the same order
of delay the baseline imposed. No task lock is used for this.

---

## 8. Active `Glo` fields (CCS Expressions: `Glo`)

| Field | Writer | Unit / meaning | Replaces |
|---|---|---|---|
| `Bios.UART0ReadTask … UARTTxMutex` | `Control_init` | non-NULL once created | — |
| `Diagnostics.UartWakeCount` | UART0ReadTask | wakes from `UARTReadSem` | — |
| `…UartTimeoutPasses` | UART0ReadTask | 10 ms timeout passes | — |
| `…PayloadWakeCount` | PayloadTask | wakes from `PayloadSem` | — |
| `…MonitorTicks` | MonitorTask | 250 ms steps | — |
| `…RxIsrCount`, `RxBytes` | UART ISR | interrupts, bytes stored | — |
| `…RxOverflowCount`, `RxErrorCount` | UART ISR | **expected 0** | — |
| `…RxRingHighWater` | UART ISR | max bytes in the 1,024-byte ring | — |
| `…TransferSuccessCount`, `TransferErrorCount` | controller / transport | | `g_transferSuccessCount`, `g_transferErrorCount` |
| `…LastTransferLength`, `LastExpectedCrc32`, `LastCalculatedCrc32` | transport / controller | | `g_lastTransferLength`, `g_lastExpectedCrc32`, `g_lastCalculatedCrc32` |
| `…AudioIsrLastCycles`, `AudioIsrMaxCycles` | audio ISR | CPU cycles, 120 = 1 µs, budget 6000 | `g_audioIsrLastCycles`, `g_audioIsrMaxCycles` |
| `…AudioInterruptCount`, `LastDacCode` | audio | | `g_audioInterruptCount`, `g_lastDacCode` |
| `…StackFreeMin{Uart,Payload,Monitor,Idle}Words` | MonitorTask | lowest free stack, **words (4 B)** | — |
| `…HeapFreeBytes`, `HeapMinFreeBytes` | MonitorTask | bytes | — |
| `…StackOverflowCount`, `MallocFailCount`, `AssertCount/AssertLine`, `CreateFailCount` | the hook that fires | **expected 0** | — |

The other old watches (`g_playbackState`, `g_melodyIndex`, `g_melodyLength`, `g_phaseAccumulator`, `g_phaseIncrement`,
`g_noteActive`, `g_currentMidiNote`, `g_lastMidi*`) keep their names but are now `static` in their module; CCS can still
watch them by name.

---

## 9. What changed and what did not

**Unchanged (checked by script against the baseline):** the 256-entry sine table and all 14 waveform constants
(sample rate 20,000 Hz, 6,000 counts, gain 3, midpoint 8192, 14-bit clamp, interpolation Q16, envelope 5 ms = 100
samples, guard 2, Q15 one 32768); interpolation and envelope math; `AUDIO_USE_INTERPOLATION=1`,
`AUDIO_USE_ENVELOPE=1`, `AUDIO_ISR_PROFILE=1`; MIDI range 48–84, 16,384-byte file limit, 1,024-note limit; SMID header
format and every reply string; timeouts (header 1000 ms, payload idle 2000 ms, total 10000 ms, recovery quiet 250 ms);
UART0 115200 8-N-1 on its 16 MHz alternate clock; Timer2 audio / Timer3 notes / Timer4 1 ms clock; SSI2 2 MHz,
PD3/PD1, PN3 SYNC, PH2 amplifier polarity; the 120 MHz clock (now set by the SDK FreeRTOS startup from the same
`configCPU_CLOCK_HZ`); `-O0`, GNU 9.2.1 flags.

**Changed:**

| Change | Why |
|---|---|
| Monolith → 7 modules; `gpiointerrupt.c`/`main_nortos.c` retired | required layout |
| `syscfg`: `RTOS.name = "FreeRTOS"`; NoRTOS library out, kernel library project in; linker script = SDK FreeRTOS `.lds` (same memory map) | real FreeRTOS integration, one startup, one vector table |
| UART receive: polled FIFO → RX interrupt (FIFO trigger 1/2, receive timeout, error sources) + 1,024-byte ring + semaphore | event-driven, overrun-safe at 115200 under load |
| `Playback_start/stop` etc. take `events,count` instead of a shared `g_melody` | module boundary |
| NVIC priorities set explicitly (§7) | RTOS-safe |
| Heap 32 KB, malloc/assert/stack-overflow hooks, stack-high-water enabled | observability; SDK default was 128 KB |

Functions moved verbatim, edited, or replaced are listed in `evidence/offline_code_moves.txt` (17 of the 41 baseline
functions are identical after the documented renames, 22 moved with the edits shown, `UARTReceiver_validate` and
`mainThread` are replaced by the task design).

---

## 10. Verification performed, and what each category means

| Evidence | Where | Category | Result |
|---|---|---|---|
| Baseline rebuilt headless | `checkpoints/00…/build_log_baseline_ccs_headless.txt` | target build | 0 errors; text 18,388 B (identical to the user's existing `.out`) |
| Stage 1 modular NoRTOS build | `checkpoints/01…/evidence/` | target build | 0 errors; text 19,128 B |
| Stage 2 FreeRTOS bring-up build | `checkpoints/02…/evidence/` | target build + link | 0 errors, 0 warnings |
| **Final build** | `build_output/` | target build (CCS 21 headless, GNU 9.2.1, SysConfig 1.4.0) | **0 errors, 0 warnings**; `size`: text 32,564 / data 1,112 / bss 67,512 B; flash 33,676 B (3.2 %), static RAM 68,624 B (26.2 %) |
| Link output inspection | `evidence/offline_link_output.txt` | image inspection | one `main`, one `resetISR`; vectors 11/14/15 = `vPortSVCHandler`/`xPortPendSVHandler`/`xPortSysTickHandler`; no NoRTOS symbol/library; kernel + all modules linked |
| Architecture / ISR / priority / header compile | `evidence/offline_architecture.txt` | source inspection + real `-fsyntax-only` of each header | 0 failures |
| Waveform arithmetic + unchanged-vs-baseline | `evidence/offline_waveform_math.txt` | arithmetic on host | 0 failures; table and 14 constants identical to baseline |
| Moved-code comparison | `evidence/offline_code_moves.txt` | source text | every difference is an intended one |
| Static stack estimate | `evidence/static_stack_estimate.txt` | compiler frame sizes | ≥ 2.7× headroom per task; **not** a measurement |
| Kernel sources identical to upstream V10.2.1 | `dependencies/` | hash/byte comparison | 28/28 files identical |
| Board-test script logic | `evidence/offline_host_tooling_selftest.txt` | **tests the script against a protocol model, not the firmware** | passes; broken models make it fail |

Deliberately **not** done: a host (x86) build of the firmware, simulated-board "PASS" lines, or any claim about sound,
timing or the CCS GUI import (only the headless importer/builder was exercised; it is the same build engine).

---

## 11. Pending — hardware items (nothing below has been observed)

Build/flash; `Glo.Bios` handles non-NULL and tasks blocked while idle; `UartWakeCount`/`PayloadWakeCount` rising during a
transfer; `MonitorTicks` and the LED continuing during playback; `RxOverflowCount = RxErrorCount = 0` and the real
`RxRingHighWater`; tests A–E and the D3–D5 regressions; STOP/restart races (R1–R3); listening checks (pitch, clicks,
silence after STOP/DONE); `AudioIsrMaxCycles` in the final `-O0` build; measured stack/heap minima. All are laid out in
`START_HERE_TESTING.md` / `FINAL_TEST_PLAN.md`.

## 12. Judgement calls and limits you should know about

* **STOP runs in `UART0ReadTask`**, not in `PayloadTask`. It is the lowest-latency owner of the frame boundary and needs
  no extra queue; the price is that this task briefly takes the TX mutex and masks interrupts for the audio quiesce.
* **Replies still use blocking `UARTCharPut`** (as in the baseline). The longest reply (`ACK_RECEIVED 16384 <crc>`) holds
  the CPU of the sending task for ≈2.6 ms at 115200 baud; lower-priority tasks wait, interrupts (audio, RX) do not.
* **RX overflow is reported as `ERR_UART`** (the ring was sized so it should never happen; `RxOverflowCount` shows it).
* **Extra bytes during validation are not silently dropped:** bytes present at the hand-off give `ERR_SIZE` (as before,
  now also counting the ring); bytes arriving later stay in the ring and are processed as a new stream once the payload
  is returned (a stray `S` starts a header and will visibly time out). `check_rtos_extra.py` R3 exercises this.
* **Tickless idle** (SDK default) means the idle task executes `WFI`; `SysTick` keeps running so ticks stay correct. The
  SDK skips `WFI` while a debugger is attached.
* **Optimisation is `-O0`** (as before), so ISR cycle counts will be pessimistic; compare with the baseline numbers.
* **CCS shows "1 warning"** for the project in the headless problem count — the unmodified baseline shows the identical
  marker, and the compiler printed no warning for any source.
* The GUI import path (`Import → CCS Projects`) was not exercised; if Theia's dialog differs, use
  `test_tools/build_headless.ps1` to produce the `.out` and load it with the Debug view. See `START_HERE_TESTING.md`.
