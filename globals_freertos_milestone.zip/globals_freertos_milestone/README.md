# Globals + FreeRTOS monophonic milestone

Your monophonic MIDI player, split into modules, sharing one `Glo` object, running on FreeRTOS V10.2.1 with three
semaphore/mutex-driven tasks. **Built and checked offline; not yet run on the board.**

Read in this order:

1. `START_HERE_TESTING.md` — import/build/flash and the single test session (what to type, what you should hear/see).
2. `IMPLEMENTATION_SUMMARY.md` — how it works, file by file, with the task/semaphore/mutex map, ownership, STOP handling,
   what changed and what did not, evidence by category, and the judgement calls.
3. `FINAL_TEST_PLAN.md` and `FINAL_TEST_RECORD.txt` — coverage and a blank result sheet (nothing pre-filled as PASS).
4. `PRESENTATION_OUTLINE.md` — four content slides + your demo slide.

| Folder | Contents |
|---|---|
| `projects/` | **`gpiointerrupt_freertos`** (the final CCS project) and **`freertos_kernel_glo`** (FreeRTOS V10.2.1 library project) |
| `build_output/` | real `.out`, `.map`, `.bin`, kernel `.a`, build log, size report, SHA-256 |
| `checkpoints/` | `00` baseline · `01` modular NoRTOS · `02` FreeRTOS bring-up · `03` final sources · `04` manifest (each has `STATUS.md`) |
| `test_tools/` | headless build script, offline checks, `board_tests/` (milestone A–E, new R1–R3, sender) |
| `evidence/` | output of every offline check (and, later, your `board/` logs) |
| `dependencies/` | versions, hashes, FreeRTOS source verifier |

Your original `workspace_ccstheia\gpiointerrupt` project was not touched; it is the rollback.
