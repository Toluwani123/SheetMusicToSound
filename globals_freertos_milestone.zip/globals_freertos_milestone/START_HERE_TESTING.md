# START HERE — build, flash and test the FreeRTOS monophonic player

Everything below was prepared **without the board**. The target build is verified; nothing has been run on hardware.
You record the results in `FINAL_TEST_RECORD.txt`. Budget about 45 minutes.

Paths (all under `C:\Users\iembi\workspace_ccstheia\globals_freertos_milestone`, shortened to `GM\`):

| Thing | Path |
|---|---|
| Final app project | `GM\projects\gpiointerrupt_freertos` |
| Kernel library project (referenced by the app) | `GM\projects\freertos_kernel_glo` |
| Pre-built image, if you only want to flash | `GM\build_output\gpiointerrupt_freertos.out` (also `.map`) |
| Board-test scripts | `GM\test_tools\board_tests` |
| Your older protocol scripts | `C:\Users\iembi\OneDrive\Desktop\testingg` |

---

## 1. Import and build (about 5 minutes)

**In CCS Theia (what to do):**

1. Close any serial monitor that holds your COM port.
2. *File ▸ Import Project(s)…* → choose the CCS-project import, browse to `GM\projects`, tick **both**
   `freertos_kernel_glo` and `gpiointerrupt_freertos`. **Leave "copy into workspace" unchecked** so you edit the files in place.
   (The kernel project must be in the workspace because the app references it. The SDK path variable
   `COM_TI_SIMPLELINK_MSP432E4_SDK_INSTALL_DIR` is already defined by your SDK 4.20.00.12 install.)
3. Select `gpiointerrupt_freertos` ▸ *Build Project* (configuration **Debug**). The kernel library builds first.
   Expected: 0 errors. The Problems view may show **1 warning**; your existing NoRTOS project shows the same marker and the
   compiler prints none.
4. Output: `GM\projects\gpiointerrupt_freertos\Debug\gpiointerrupt_freertos.out`.

**If the import dialog differs, or you just want proof the build works first** — no GUI needed:

```powershell
cd C:\Users\iembi\workspace_ccstheia\globals_freertos_milestone\test_tools
powershell -ExecutionPolicy Bypass -File build_headless.ps1 `
    -Workspace C:\temp\ws_glo `
    -KernelProject ..\projects\freertos_kernel_glo `
    -AppProject    ..\projects\gpiointerrupt_freertos `
    -LogFile       C:\temp\build_log.txt
```

This is the exact build that produced `GM\build_output\` (0 errors, 0 warnings; the loadable image is bit-identical when
rebuilt: SHA-256 of the raw binary `d36d5b52…2f89cec`, 33,676 bytes).

If the Problems view reports `FREERTOS_INSTALL_DIR` or a missing `FreeRTOSConfig.h`, the *kernel* project was not
imported — import `freertos_kernel_glo` too. No `FREERTOS_INSTALL_DIR` variable is needed by this project.

## 2. Flash and run

1. Plug the LaunchPad in; start a Debug session with `targetConfigs\MSP432E401Y.ccxml` (XDS110), as you do today.
   (Or load `GM\build_output\gpiointerrupt_freertos.out`.)
2. **Resume/Run. Do not leave the target paused and do not set breakpoints during tests** — timeouts are real time.
3. LED D1 should blink at about 2 Hz (that is `MonitorTask`).
4. Find your COM port (Device Manager ▸ *XDS110 Class Application/User UART*), used below as `COM5`.

## 3. Prove the RTOS objects are live (before any file is sent)

In the Expressions view add **`Glo`** and expand `Bios` and `Diagnostics`. Suspend-read-resume, or enable continuous
refresh. **Read only between tests** — a suspended target misses UART timeouts and the sound stops.

| What | Expected right after reset, idle for ~10 s | What it proves |
|---|---|---|
| `Glo.Bios.UART0ReadTask`, `PayloadTask`, `MonitorTask`, `UARTReadSem`, `PayloadSem`, `UARTTxMutex` | all **non-zero** | objects created |
| `Glo.Diagnostics.UartTimeoutPasses` | rises by ≈100 per second | `UART0ReadTask` is *blocked* in its 10 ms wait and wakes only on timeout — not spinning |
| `Glo.Diagnostics.UartWakeCount`, `PayloadWakeCount`, `RxIsrCount`, `RxBytes` | stay at 0 (or tiny) | nothing wakes them without data |
| `Glo.Diagnostics.MonitorTicks` | rises 4 per second | `MonitorTask` periodic delay |
| `RxOverflowCount`, `RxErrorCount`, `StackOverflowCount`, `MallocFailCount`, `AssertCount`, `CreateFailCount` | **0** | no faults |
| `HeapMinFreeBytes` | well above 0 (static estimate: about 11 KB used, so roughly 20,000 of 32,768 free) | heap sized with margin |

After the first transfer re-read: `UartWakeCount`, `PayloadWakeCount`, `RxBytes`, `RxIsrCount` increased;
`RxRingHighWater` small; `TransferSuccessCount` incremented.

## 4. The one test session

Open PowerShell. Use `--port COMx` instead of `COM5` if yours differs (the scripts default to COM5).
Keep the speaker volume fixed. Logs go to `GM\evidence\board\`.

```powershell
cd C:\Users\iembi\workspace_ccstheia\globals_freertos_milestone\test_tools\board_tests
New-Item -ItemType Directory -Force -Path ..\..\evidence\board | Out-Null
```

### 4.0 Link check and smoke test (2 min)

```powershell
python newmiditst.py --stop --port COM5
python newmiditst.py reference_midi\d5_reference.mid --wait-playback --port COM5
```

Expected: `ACK_STOPPED`, `IDLE`; then `ACK_READY …`, `ACK_RECEIVED …`, `ACK_VALID`, `PLAYING`, `DONE`, `IDLE` and you hear
**C4 E4 G4 C5**. Silence afterwards.

### 4.1 Existing audio milestone, tests A–E (≈4 min)

```powershell
python -u check_milestone_playback.py --port COM5 2>&1 | Tee-Object -FilePath ..\..\evidence\board\milestone_A-E.txt
```

Final line `PASS: milestone tests A, B, C, D, E completed without a board reset.` Then listen (fill the record):

| Test | You should hear |
|---|---|
| A | four steady tones C3, C4, A4 (440 Hz on a tuner), C6, each 2 s, 0.5 s gaps |
| B | 8 distinct A4 pulses; a smooth fast scale; shrinking C5 blips (last ones faint ticks); a silent 2.5 s; a final G4 |
| C | Twinkle Twinkle and Ode to Joy, correct rhythm and silent rests |
| D | STOP cuts off at once (three times in the rapid file, once in the sustained note), 2 s of silence, the next phrase plays |
| E | the four-note phrase five times, silence after every `DONE` |

Short-note faintness (≤ 2 ms notes) is expected, as before. **Fail** = any sound after `ACK_STOPPED` or after `DONE`,
new popping, a missed note.

### 4.2 RTOS-specific races (≈4 min) — new

```powershell
python -u check_rtos_extra.py --port COM5 2>&1 | Tee-Object -FilePath ..\..\evidence\board\rtos_extra.txt
```

* **R1** 20 rapid STOP/restart cycles (STOP 0 ms … 0.7 s after `PLAYING`): every STOP must silence immediately, nothing may
  restart, no stale `DONE`/`PLAYING` in the 0.4 s after each STOP; a final normal song plays to `DONE`/`IDLE`.
* **R2** a truncated header followed by *nothing*: `ERR_TIMEOUT` after ≈1 s on its own, then `IDLE`.
* **R3** a STOP frame glued to the end of a payload: either `ERR_SIZE`+`IDLE` or `ACK_RECEIVED…ACK_STOPPED`+`IDLE`;
  never silent loss.

### 4.3 Your D3–D5 protocol regressions (≈10 min)

These live in your own testing folder and use the same sender (identical file hash):

```powershell
cd C:\Users\iembi\OneDrive\Desktop\testingg
python -u check_playback_control.py   --port COM5 2>&1 | Tee-Object -FilePath C:\Users\iembi\workspace_ccstheia\globals_freertos_milestone\evidence\board\d4_playback_control.txt
python -u check_recovery.py           --port COM5 2>&1 | Tee-Object -FilePath C:\Users\iembi\workspace_ccstheia\globals_freertos_milestone\evidence\board\d3_recovery.txt
python -u check_midi_compatibility.py --port COM5 2>&1 | Tee-Object -FilePath C:\Users\iembi\workspace_ccstheia\globals_freertos_milestone\evidence\board\d5_quick.txt
python -u check_midi_compatibility.py --port COM5 --suite long 2>&1 | Tee-Object -FilePath C:\Users\iembi\workspace_ccstheia\globals_freertos_milestone\evidence\board\d5_long.txt
```

Expected final lines: `PASS: all 8 Deliverable 4 protocol checks …` (busy rejection then STOP, STOP while idle, STOP during a rest,
malformed STOP, STOP-lookalike inside MIDI metadata, legacy SMID v1, three play/STOP cycles), the three recovery cases
(oversized header → `ERR_SIZE`, corrupted 16 KiB → `ERR_CRC` **before** `ACK_RECEIVED`, truncated 16 KiB → `ERR_TIMEOUT`) each
followed by good playback, and `PASS: Deliverable 5 quick/long suite completed …`.

### 4.4 Payload and note-count boundaries (≈3 min)

Still in `C:\Users\iembi\OneDrive\Desktop\testingg`:

```powershell
python newmiditst.py midi_tests\bytes_16384.mid            --port COM5 --stop-after 2     # maximum payload accepted
python newmiditst.py midi_tests\notes_1024.mid             --port COM5 --stop-after 3     # 1,024 notes accepted
python newmiditst.py midi_tests\notes_1025.mid             --port COM5                    # expect ERR_NOTE_CAPACITY, then IDLE
```

(`bytes_16385.mid` is refused by the sender itself; the firmware side of that is `check_recovery.py` check 1.)
After the 16,384-byte transfer read `Glo.Diagnostics`: `RxBytes` grew by ≈16,400, `RxOverflowCount` and `RxErrorCount`
still 0, `RxRingHighWater` far below 1,023.

## 5. Read the timing and memory numbers (after the tests)

Suspend once at the end and read, with `MonitorTask` having run for a few seconds:

| Expression | Convert | Compare with |
|---|---|---|
| `Glo.Diagnostics.AudioIsrMaxCycles` (clear it first by writing 0, then play `m6_pitch_range.mid`) | µs = cycles ÷ 120 | budget 6,000 cycles = 50 µs; baseline numbers in `milestone_waveform\MILESTONE_TEST_RECORD.txt` |
| `StackFreeMinUartWords`, `…PayloadWords`, `…MonitorWords`, `…IdleWords` | **words** × 4 = bytes | allocated 512 / 768 / 256 words; static estimate says ≥ 2.7× margin |
| `HeapMinFreeBytes` | bytes | 32,768 total |
| `StackOverflowCount`, `MallocFailCount`, `AssertCount`, `CreateFailCount` | | all 0 |

The `.map` gives the real allocation (`GM\build_output\gpiointerrupt_freertos.map`): static RAM 68,624 B of 262,144.

## 6. If something fails — localise it with the checkpoints

Each checkpoint folder has `STATUS.md`. To bisect, build the earlier stage and repeat the failing test:

| Checkpoint | What it is | How to try it |
|---|---|---|
| `checkpoints\00_before_globals_rtos` | your baseline | your original `workspace_ccstheia\gpiointerrupt` project is untouched — just rebuild it |
| `checkpoints\01_modular_globals` | modules + `Glo`, still NoRTOS and polled | copy `src\*` over a copy of the baseline project (instructions in its `STATUS.md`) |
| `checkpoints\02_freertos_bringup` | RTOS infrastructure, polled receiver in one task (**not** for transfer tests: 16-byte FIFO can overrun) | useful only to prove startup/LED/scheduler |
| `checkpoints\03_rtos_monophonic` | the final sources | identical to the project |

| Symptom | Likely cause / action |
|---|---|
| Nothing on the serial port, LED not blinking | scheduler did not start: read `Glo.Diagnostics.CreateFailCount`, `AssertCount`, `MallocFailCount`; look for the debugger parked in `Fault_halt` |
| LED blinks but no `ACK_READY` | `UARTReadSem` never given: check `RxIsrCount`; confirm the COM port and that no other program holds it |
| `ERR_UART` | read `RxOverflowCount` (ring full) vs `RxErrorCount` (line errors); report both |
| Sound after `ACK_STOPPED`/`DONE` | **fail**; record, then `python newmiditst.py --stop` |
| Clicks/jitter that the baseline did not have | compare `AudioIsrMaxCycles` with the baseline; the audio ISR is now at NVIC priority 0 and `Playback_*` mask interrupts for one DAC word |
| Stack/heap numbers near 0 | enlarge `STACK_WORDS_*` in `control_task.c` or `configTOTAL_HEAP_SIZE` in `FreeRTOSConfig.h` |

**Rollback:** the NoRTOS baseline project was never touched. Re-flash it (or `checkpoint 01`) and you are back where you started.

## 7. Offline checks you can re-run any time (no board)

```powershell
cd C:\Users\iembi\workspace_ccstheia\globals_freertos_milestone\test_tools
powershell -ExecutionPolicy Bypass -File run_offline_checks.ps1 -Image ..\build_output\gpiointerrupt_freertos.out -EvidenceDir ..\evidence
python ..\dependencies\verify_kernel_sources.py
```

Record everything in `FINAL_TEST_RECORD.txt`; put screenshots of the `Glo` expressions in `evidence\board\`.
