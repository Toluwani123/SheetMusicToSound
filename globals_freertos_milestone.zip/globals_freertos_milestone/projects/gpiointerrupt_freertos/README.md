# gpiointerrupt_freertos

FreeRTOS monophonic MIDI player for the MSP-EXP432E401Y (120 MHz Cortex-M4F), built with
GNU Arm 9.2.1 in CCS 21 / Theia and SimpleLink MSP432E4 SDK 4.20.00.12. It references the
kernel library project `../freertos_kernel_glo` (FreeRTOS V10.2.1).

| File | Role |
|---|---|
| `main_freertos.c` | The only `main()`: board init, `Control_init()`, scheduler start; kernel fault hooks |
| `globals.h` / `globals.c` | `extern Globals Glo` / its single definition: `Glo.Bios` handles, `Glo.Diagnostics` counters, NVIC priority plan |
| `audio.h` / `audio.c` | DAC8311 on SSI2, sine table, interpolation, 5 ms envelope, pitch to phase, Timer2 sample ISR |
| `midi.h` / `midi.c` | Type-0 MIDI parser (`Midi_parse`), `MelodyEvent`; no hardware, no RTOS |
| `playback.h` / `playback.c` | Note/rest progression on Timer3, start/stop, completion hook |
| `uart_task.h` / `uart_task.c` | UART0 ISR + ring, SMID framing/timeouts/recovery, CRC, reply transmit under the TX mutex, `Uart_readTask` |
| `control_task.h` / `control_task.c` | RTOS object creation, `PayloadTask`, `MonitorTask`, STOP/BUSY hooks |
| `gpiointerrupt.syscfg` | SysConfig: `RTOS = FreeRTOS`, GPIO (LEDs/buttons) |
| `MSP_EXP432E401Y_FREERTOS.lds` | SDK linker script for FreeRTOS (unchanged) |

The old monolithic `gpiointerrupt.c` and `main_nortos.c` are not part of this project.
See `../IMPLEMENTATION_SUMMARY.md` for design, `../START_HERE_TESTING.md` to build and test.
