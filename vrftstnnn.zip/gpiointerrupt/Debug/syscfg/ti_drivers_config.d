# FIXED

syscfg/ti_drivers_config.o: syscfg/ti_drivers_config.c \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/DeviceFamily.h \
 syscfg/ti_drivers_config.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/GPIO.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/gpio/GPIOMSP432E4.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp432.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp432e401y.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/core_cm4.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_version.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_compiler.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_gcc.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/mpu_armv7.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/system_msp432e401y.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/gpio.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/Power.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/utils/List.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/power/PowerMSP432E4.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/Board.h

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/DeviceFamily.h:

syscfg/ti_drivers_config.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/GPIO.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/gpio/GPIOMSP432E4.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp432.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp432e401y.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/core_cm4.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_version.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_compiler.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_gcc.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/mpu_armv7.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/system_msp432e401y.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/gpio.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/Power.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/utils/List.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/power/PowerMSP432E4.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/Board.h:
