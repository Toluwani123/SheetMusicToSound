/*
 * playback.h -- melody scheduler interface (playback.c).
 *
 * Owns Timer3 (one-shot note/rest timing) and the playback state. Uses only
 * the public audio API. Parsing and UART traffic belong to other modules.
 */
#ifndef PLAYBACK_H
#define PLAYBACK_H

#include <stdint.h>
#include <stdbool.h>

#include "midi.h"

/* Runs in the Timer3 ISR when a melody ends naturally, after audio silence.
 * It may only signal work (no UART output, no blocking calls). */
typedef void (*PlaybackCompletionHook)(void);

/* Configure Timer3 (stopped). completionHook may be NULL. */
void Playback_init(PlaybackCompletionHook completionHook);

/*
 * Start playing events[0..count-1]. The array is borrowed, not copied: the
 * caller must keep it unchanged until the melody completes or Playback_stop()
 * returns. Returns false (nothing started) for NULL, zero or oversize input.
 */
bool Playback_start(const MelodyEvent *events, uint32_t count);

/* Cancel the whole song including a scheduled rest; hard silence on return.
 * Also discards any pending completion report. Safe from any task. */
void Playback_stop(void);

bool Playback_isActive(void);

/* Returns true exactly once after a natural finish (never after a stop). */
bool Playback_takeCompletion(void);

/* Non-consuming: true if Playback_takeCompletion() would return true right now. */
bool Playback_completionReady(void);

#endif /* PLAYBACK_H */
