/*
 * globals.h -- the one shared header of the project.
 *
 * Declares the Globals type and 'extern Globals Glo'; globals.c defines the
 * object exactly once. The header only declares; the source allocates.
 *
 * Glo.Bios        live FreeRTOS handles (created in control_task.c before the
 *                 scheduler starts, used by every task/ISR that needs them).
 *                 The group name echoes the course's SYS/BIOS style; the
 *                 objects are native FreeRTOS tasks, semaphores and a queue.
 * Glo.Diagnostics counters and snapshots for the CCS watch window. Each member
 *                 names its single writer. 'volatile' only keeps the debugger
 *                 view current; it provides NO locking and none is needed for
 *                 these write-only-by-one-context counters.
 *
 * Authoritative protocol/audio state is NOT mirrored here: it stays private
 * (static) in the module that owns it.
 */
#ifndef GLOBALS_H
#define GLOBALS_H

#include <stdint.h>

#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"

/* Core clock set by the SDK startup code from configCPU_CLOCK_HZ (120 MHz).
 * Single definition: every module derives timing from this. */
#define SYSTEM_CLOCK_HZ          ((uint32_t)configCPU_CLOCK_HZ)

/* ------------------------------------------------------------------------
 * Interrupt priorities (NVIC; numerically lower = more urgent) -- NOT task
 * priorities. Cortex-M4 here implements 3 priority bits (8 levels).
 *
 *   0  Timer2A  audio sample ISR   above the kernel ceiling: it never calls
 *                                  FreeRTOS and kernel critical sections
 *                                  (BASEPRI) do not delay it.
 *   1  (free)  configMAX_SYSCALL_INTERRUPT_PRIORITY: the most urgent level an
 *              ISR may use together with FreeRTOS *FromISR calls.
 *   2  Timer3A  note/rest scheduler  gives PayloadSem on melody completion.
 *   2  UART0    RX/RT/error ISR      drains FIFO to ring, gives UARTReadSem.
 *   3  Timer4A  1 ms transfer clock  kernel-independent counter.
 *   7  SysTick, PendSV (kernel)      set by the FreeRTOS port.
 * ---------------------------------------------------------------------- */
#define IRQ_PRIO(level)          ((uint8_t)((level) << (8U - configPRIO_BITS)))
#define IRQ_PRIO_AUDIO_SAMPLE    IRQ_PRIO(0U)
#define IRQ_PRIO_PLAYBACK        IRQ_PRIO(2U)
#define IRQ_PRIO_UART_RX         IRQ_PRIO(2U)
#define IRQ_PRIO_TRANSFER_CLOCK  IRQ_PRIO(3U)

/* Compile-time proof of the rules above. */
typedef char irqAudioIsAboveKernelCeiling[
    (0 < configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY) ? 1 : -1];
typedef char irqKernelCallersAtOrBelowCeiling[
    ((2 >= configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY) &&
     (2 < configLIBRARY_LOWEST_INTERRUPT_PRIORITY)) ? 1 : -1];

typedef struct
{
    TaskHandle_t UART0ReadTask;       /* uart_task.c : Uart_readTask        */
    TaskHandle_t PayloadTask;         /* control_task.c : validate/start/DONE */
    TaskHandle_t MonitorTask;         /* control_task.c : LED + diagnostics  */
    TaskHandle_t UARTTxTask;          /* uart_tx.c : sole owner of the UART transmitter */
    SemaphoreHandle_t UARTReadSem;    /* binary: UART RX ISR / publish -> UART0ReadTask */
    SemaphoreHandle_t PayloadSem;     /* binary: UART0ReadTask / Timer3 ISR -> PayloadTask */
    QueueHandle_t UARTTxQueue;        /* complete replies: any task -> UARTTxTask (uart_tx.c) */
} RtosHandles;

typedef struct
{
    /* ---- task activity ------------------------------------------------ */
    volatile uint32_t UartWakeCount;      /* UART0ReadTask: takes of UARTReadSem that succeeded */
    volatile uint32_t UartTimeoutPasses;  /* UART0ReadTask: passes caused by the finite wait timing out */
    volatile uint32_t PayloadWakeCount;   /* PayloadTask: wakes from PayloadSem */
    volatile uint32_t MonitorTicks;       /* MonitorTask: 250 ms iterations */

    /* ---- UART receive path (writer: UART RX ISR) ---------------------- */
    volatile uint32_t RxIsrCount;         /* UART0 interrupt entries */
    volatile uint32_t RxBytes;            /* bytes stored in the ring */
    volatile uint32_t RxOverflowCount;    /* bytes dropped because the ring was full (expected 0) */
    volatile uint32_t RxErrorCount;       /* framing/parity/break/overrun events (expected 0) */
    volatile uint32_t RxRingHighWater;    /* largest ring occupancy seen, bytes */

    /* ---- transfer results (one writer at a time, see uart_task.c) ----- */
    volatile uint32_t TransferSuccessCount;   /* was g_transferSuccessCount */
    volatile uint32_t TransferErrorCount;     /* was g_transferErrorCount   */
    volatile uint32_t LastTransferLength;     /* was g_lastTransferLength   */
    volatile uint32_t LastExpectedCrc32;      /* was g_lastExpectedCrc32    */
    volatile uint32_t LastCalculatedCrc32;    /* was g_lastCalculatedCrc32  */

    /* ---- audio (writer: audio module) --------------------------------- */
    volatile uint16_t LastDacCode;            /* was g_lastDacCode          */
    volatile uint32_t AudioInterruptCount;    /* was g_audioInterruptCount  */
    volatile uint32_t AudioIsrLastCycles;     /* was g_audioIsrLastCycles; 120 cycles = 1 us */
    volatile uint32_t AudioIsrMaxCycles;      /* was g_audioIsrMaxCycles; budget 6000 cycles */

    /* ---- memory (writer: MonitorTask); stack values are WORDS (4 bytes) */
    volatile uint32_t StackFreeMinUartWords;     /* lowest free stack ever, UART0ReadTask */
    volatile uint32_t StackFreeMinPayloadWords;
    volatile uint32_t StackFreeMinTxWords;        /* lowest free stack ever, UARTTxTask */
    volatile uint32_t StackFreeMinMonitorWords;
    volatile uint32_t StackFreeMinIdleWords;
    volatile uint32_t HeapFreeBytes;
    volatile uint32_t HeapMinFreeBytes;          /* lowest free heap ever, bytes */

    /* ---- UART transmit queue (see uart_tx.c) -------------------------------
     * Quiesced drain check: TxMsgsQueued == TxMsgsTransmitted with TxQueueDepthNow
     * == 0 and TxInFlight == 0. During activity: TxMsgsQueued - TxMsgsTransmitted
     * == messages waiting + TxInFlight (read it between steps; a suspended target
     * can sit between the dequeue and the TxInFlight update, a few instructions).
     * "Transmitted" = all bytes written into the UART TX FIFO (not yet shifted out). */
    volatile uint32_t TxMsgsQueued;          /* producers (atomic add): replies accepted into the queue */
    volatile uint32_t TxMsgsTransmitted;     /* UARTTxTask: replies fully handed to the UART FIFO */
    volatile uint32_t TxBytesTransmitted;    /* UARTTxTask: characters handed to the FIFO */
    volatile uint32_t TxQueueFullCount;      /* producers: attempts that found the queue full (expected 0) */
    volatile uint32_t TxSubmitTimeoutCount;  /* producers: replies NOT accepted after the bounded wait (expected 0) */
    volatile uint32_t TxFormatErrorCount;    /* producers: reply empty or longer than the item; rejected, not truncated (expected 0) */
    volatile uint32_t TxNotReadyCount;       /* producers: submit before the queue existed (expected 0) */
    volatile uint32_t TxFaultCount;          /* UARTTxTask: FIFO took no byte for the stall limit; reply abandoned (expected 0) */
    volatile uint32_t TxMaxQueueDepth;       /* UARTTxTask: highest number of replies waiting, max UART_TX_QUEUE_DEPTH */
    volatile uint32_t TxQueueDepthNow;       /* MonitorTask: replies waiting at the last 250 ms snapshot */
    volatile uint32_t TxInFlight;            /* UARTTxTask: 1 while a dequeued reply is being written */
    /* ---- fault traps (writer: the hook that fires; all expected 0) ---- */
    volatile uint32_t StackOverflowCount;
    volatile uint32_t MallocFailCount;
    volatile uint32_t AssertCount;
    volatile uint32_t AssertLine;
    volatile uint32_t CreateFailCount;           /* RTOS object/task creation failures at startup */
    volatile char     StackOverflowTaskName[configMAX_TASK_NAME_LEN];
} GlobalsDiagnostics;

typedef struct
{
    RtosHandles Bios;
    GlobalsDiagnostics Diagnostics;
} Globals;

extern Globals Glo;

#endif /* GLOBALS_H */
