/*
 * main_freertos.c -- the one main(): board initialisation, application object
 * creation and scheduler start, plus the kernel fault hooks.
 *
 * Startup path (FreeRTOS, replaces main_nortos.c / NoRTOS_start):
 *   reset -> startup_msp432e4_gcc.c (FPU on, 120 MHz clock, .data/.bss) -> main()
 * The same startup file already places the kernel's SVC/PendSV/SysTick
 * handlers in the vector table, so DriverLib's later TimerIntRegister() /
 * UARTIntRegister() copy of that table into RAM keeps them.
 */
#include <stdint.h>
#include <stddef.h>

#include <FreeRTOS.h>
#include <task.h>

#include <ti/drivers/Board.h>
#include <ti/drivers/GPIO.h>

#include "globals.h"
#include "audio.h"
#include "control_task.h"

/* Fault paths: record, make the output silent on a best-effort basis, stop.
 * Deliberately NO UART output here: the transmit queue and UARTTxTask are not
 * usable from a fault context (the kernel may be the thing that failed) and a
 * blocking queue call must never appear in this path. The fault is visible only in
 * Glo.Diagnostics (StackOverflowCount, MallocFailCount, AssertCount, CreateFailCount). */
static void Fault_halt(void)
{
    Audio_stopNote();
    taskDISABLE_INTERRUPTS();
    for (;;)
    {
    }
}

int main(void)
{
    Board_init();      /* SDK board setup (Power_init, DMA flash access); clock is set by the startup code */
    GPIO_init();       /* TI GPIO driver: LEDs used by MonitorTask */

    /* Proven audio hardware, PH2 control and Timer2 setup, unchanged. */
    Audio_init();

    /* Creates Glo.Bios semaphores, the UART reply queue and the four tasks; nothing runs yet. */
    if (!Control_init())
    {
        Glo.Diagnostics.CreateFailCount++;
        Fault_halt();
    }

    vTaskStartScheduler();

    /* Only reached if the scheduler could not allocate its idle/timer task. */
    Glo.Diagnostics.CreateFailCount++;
    Fault_halt();
    return 0;
}

/* ------------------------------------------------------------------------
 * Kernel hooks (enabled in FreeRTOSConfig.h)
 * --------------------------------------------------------------------- */

void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName)
{
    uint32_t i;

    (void)xTask;
    Glo.Diagnostics.StackOverflowCount++;
    for (i = 0U; (i < (configMAX_TASK_NAME_LEN - 1U)) && (pcTaskName[i] != '\0'); i++)
    {
        Glo.Diagnostics.StackOverflowTaskName[i] = pcTaskName[i];
    }
    Fault_halt();
}

void vApplicationMallocFailedHook(void)
{
    Glo.Diagnostics.MallocFailCount++;
    Fault_halt();
}

/* configASSERT() target (FreeRTOSConfig.h). */
void vAssertCalled(const char *pcFile, int iLine)
{
    (void)pcFile;
    Glo.Diagnostics.AssertCount++;
    Glo.Diagnostics.AssertLine = (uint32_t)iLine;
    Fault_halt();
}
