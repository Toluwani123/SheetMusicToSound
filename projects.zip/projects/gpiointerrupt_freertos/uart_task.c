/*
 * uart_task.c -- UART0 transport: framing, CRC helper, timeouts, recovery.
 *
 * The baseline receiver state machine (header/payload framing, timeouts, recovery,
 * ERR_ lines) moved out of gpiointerrupt.c. Bytes now arrive through an interrupt
 * into a ring buffer, and UART0ReadTask wakes on UARTReadSem to run that state
 * machine. CRC/MIDI decisions belong to the controller (control_task.c), reached
 * through Uart_acquirePayload()/Uart_payloadAccepted()/Uart_payloadRejected().
 *
 * OWNERSHIP
 *  - Receiver state, counters and the file buffer belong to UART0ReadTask,
 *    EXCEPT while receiverState == VALIDATE: then the payload belongs to the
 *    controller and UART0ReadTask neither consumes ring bytes nor touches the
 *    receiver. The controller returns it only through Uart_payloadAccepted()/
 *    Uart_payloadRejected(), which change receiverState last.
 *  - The ring: UART0 ISR writes s_rxHead, UART0ReadTask writes s_rxTail.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <string.h>

#ifndef __MSP432E401Y__
#define __MSP432E401Y__
#endif

#include <ti/devices/msp432e4/driverlib/driverlib.h>

#include "uart_task.h"
#include "uart_tx.h"
#include "globals.h"


/* SMID v2: byte 5 is opcode (0=MIDI, 1=STOP); v1 MIDI remains accepted.
 * STOP has zero length/CRC and is recognized only at a header boundary.
 * MIDI uses a 16-byte header, then an acknowledged raw MIDI payload.
 * Multi-byte transport fields are little-endian; MIDI itself is unchanged.
 * Keep these limits coordinated with newmiditst.py.
 */

#define SMID_HEADER_SIZE         16U
#define SMID_PROTOCOL_VERSION    2U
#define SMID_LEGACY_VERSION      1U
#define SMID_COMMAND_MIDI        0U
#define SMID_COMMAND_STOP        1U
#define RX_HEADER_TIMEOUT_MS     1000U
#define RX_PAYLOAD_IDLE_MS       2000U
#define RX_PAYLOAD_TOTAL_MS      10000U
#define RX_RECOVERY_QUIET_MS      250U

/* Receive ring (power of two). At 115200 8-N-1 one byte takes 86.8 us, so 1024 bytes
 * is 89 ms of full-rate data -- hundreds of times the task wake-up latency. */
#define UART_RX_RING_SIZE        1024U
#define UART_RX_RING_MASK        (UART_RX_RING_SIZE - 1U)
typedef char uartRxRingIsPowerOfTwo[((UART_RX_RING_SIZE & (UART_RX_RING_SIZE - 1U)) == 0U) ? 1 : -1];

/* UART0ReadTask never sleeps longer than this, so timeouts are checked even if no
 * byte arrives (a truncated header/payload must still time out). */
#define UART_TASK_WAIT_MS        10U

/* Fault bits set by the ISR, consumed by the task. */
#define RXFAULT_UART             0x1U   /* framing/parity/break/overrun reported by UART0 */
#define RXFAULT_OVERFLOW         0x2U   /* ring full: a byte was dropped */

/* Single-core: a compiler barrier orders ring data against the index publish. */
#define COMPILER_BARRIER()       __asm volatile ("" ::: "memory")

static uint8_t fileBuffer[MAX_MIDI_FILE_SIZE];
static uint8_t headerBytes[SMID_HEADER_SIZE];
static uint32_t headerBytesReceived = 0U;
static volatile uint32_t magicBytesMatched = 0U;
static uint32_t expectedLength = 0U;
static uint32_t bytesReceived = 0U;
static uint32_t expectedCrc32 = 0U;
static uint32_t headerStartedMs = 0U;
static uint32_t payloadStartedMs = 0U;
static uint32_t lastRxByteMs = 0U;

typedef enum
{
    WAIT_MAGIC = 0,
    READ_HEADER,
    READ_PAYLOAD,
    VALIDATE,
    RECOVER
} ReceiverState;

static volatile ReceiverState receiverState = WAIT_MAGIC;

/* Timer4 supplies time even when Timer2 (audio) is stopped. */
static volatile uint32_t g_transferMilliseconds = 0U;

static const UartHooks *s_hooks = NULL;

/* Payload ownership: set when the complete payload has been published to the
 * controller, and when the controller has taken it. Cleared by reset. */
static volatile bool s_payloadPublished = false;
static volatile bool s_payloadTaken = false;

/* ============================================================
 * RECEIVE RING (UART0 ISR -> UART0ReadTask)
 * ============================================================ */

static uint8_t s_rxRing[UART_RX_RING_SIZE];
static volatile uint32_t s_rxHead = 0U;     /* next slot the ISR fills (ISR only) */
static volatile uint32_t s_rxTail = 0U;     /* next slot the task reads (task only) */
static volatile uint32_t s_rxFaultFlags = 0U;   /* RXFAULT_* : ISR sets (atomic OR), task clears */

/* UART0 interrupt: RX FIFO level, receive timeout, and line errors. Drains the whole
 * hardware FIFO into the ring, then signals the task ONCE for the batch. The binary
 * semaphore coalesces further signals, so the task never sees one wake per byte.
 * Priority IRQ_PRIO_UART_RX (2) is at/below the kernel ceiling, so FromISR is legal. */
static void uart0RxIsr(void)
{
    BaseType_t woken = pdFALSE;
    uint32_t head = s_rxHead;
    uint32_t tail;
    uint32_t used;
    uint32_t stored = 0U;
    uint32_t faults = 0U;
    uint32_t status = UARTIntStatus(UART0_BASE, true);
    int32_t raw;

    UARTIntClear(UART0_BASE, status);
    Glo.Diagnostics.RxIsrCount++;

    while (UARTCharsAvail(UART0_BASE))
    {
        raw = UARTCharGetNonBlocking(UART0_BASE);
        if (raw < 0)
        {
            break;
        }

        /* Data-register bits 11:8 carry per-character break/parity/framing/overrun
         * flags (the baseline inspected them before using the byte). */
        if (((uint32_t)raw & 0x00000F00U) != 0U)
        {
            faults |= RXFAULT_UART;
            Glo.Diagnostics.RxErrorCount++;
            continue;
        }

        tail = s_rxTail;
        if (((head + 1U) & UART_RX_RING_MASK) == tail)
        {
            faults |= RXFAULT_OVERFLOW;
            Glo.Diagnostics.RxOverflowCount++;
            continue;
        }

        s_rxRing[head] = (uint8_t)raw;
        head = (head + 1U) & UART_RX_RING_MASK;
        stored++;
    }

    if (UARTRxErrorGet(UART0_BASE) != 0U)
    {
        UARTRxErrorClear(UART0_BASE);
        faults |= RXFAULT_UART;
        Glo.Diagnostics.RxErrorCount++;
    }

    COMPILER_BARRIER();
    s_rxHead = head;
    Glo.Diagnostics.RxBytes += stored;

    tail = s_rxTail;
    used = (head - tail) & UART_RX_RING_MASK;
    if (used > Glo.Diagnostics.RxRingHighWater)
    {
        Glo.Diagnostics.RxRingHighWater = used;
    }

    if (faults != 0U)
    {
        __atomic_fetch_or(&s_rxFaultFlags, faults, __ATOMIC_SEQ_CST);
    }

    if ((stored != 0U) || (faults != 0U))
    {
        xSemaphoreGiveFromISR(Glo.Bios.UARTReadSem, &woken);
        portYIELD_FROM_ISR(woken);
    }
}

static bool UARTReceiver_ringPop(uint8_t *byte)
{
    uint32_t tail = s_rxTail;

    if (tail == s_rxHead)
    {
        return false;
    }

    COMPILER_BARRIER();
    *byte = s_rxRing[tail];
    COMPILER_BARRIER();
    s_rxTail = (tail + 1U) & UART_RX_RING_MASK;
    return true;
}

/* Unconsumed input anywhere: the ring OR the hardware FIFO. Every place that the
 * baseline asked UARTCharsAvail() now asks this, because a byte can sit in the ring. */
static bool UARTReceiver_inputPending(void)
{
    return (s_rxTail != s_rxHead) || UARTCharsAvail(UART0_BASE);
}


/* ============================================================
 * UART INITIALIZATION
 * ============================================================
 */

static void UART0_init(void)
{
    /*
     * Enable UART0 and GPIO Port A.
     */
    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_UART0
    );


    SysCtlPeripheralEnable(
        SYSCTL_PERIPH_GPIOA
    );


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_UART0))
    {
    }


    while (!SysCtlPeripheralReady(
               SYSCTL_PERIPH_GPIOA))
    {
    }


    /*
     * PA0 = UART RX
     * PA1 = UART TX
     */
    GPIOPinConfigure(
        GPIO_PA0_U0RX
    );


    GPIOPinConfigure(
        GPIO_PA1_U0TX
    );


    GPIOPinTypeUART(
        GPIO_PORTA_BASE,
        GPIO_PIN_0 |
        GPIO_PIN_1
    );


    /*
     * Use 16 MHz alternate UART clock.
     */
    UARTClockSourceSet(
        UART0_BASE,
        UART_CLOCK_ALTCLK
    );


    /*
     * 115200 baud
     * 8 data bits
     * 1 stop bit
     * no parity
     */
    UARTConfigSetExpClk(
        UART0_BASE,
        16000000U,
        115200,
        UART_CONFIG_WLEN_8 |
        UART_CONFIG_STOP_ONE |
        UART_CONFIG_PAR_NONE
    );


    UARTEnable(
        UART0_BASE
    );


    /*
     * Event-driven receive. Interrupt at 1/2 FIFO (8 bytes, ~0.7 ms of slack in the
     * 16-byte FIFO) and on the receive timeout (32 bit times after the last byte), so
     * a short tail is delivered within ~0.3 ms. The sources are armed later by
     * UART0ReadTask, once the scheduler is running.
     */
    UARTFIFOLevelSet(
        UART0_BASE,
        UART_FIFO_TX1_8,
        UART_FIFO_RX4_8
    );

    UARTIntDisable(
        UART0_BASE,
        0xFFFFFFFFU
    );

    UARTIntClear(
        UART0_BASE,
        0xFFFFFFFFU
    );

    UARTIntRegister(
        UART0_BASE,
        uart0RxIsr
    );

    IntPrioritySet(
        INT_UART0,
        IRQ_PRIO_UART_RX
    );
}

/* UART output is not done here: replies are submitted to the transmit queue
 * (uart_tx.c) and UARTTxTask writes them. This file never touches the TX FIFO. */

/* ============================================================
 * DELIVERABLE 2: TRANSFER CLOCK, CRC AND RECOVERABLE UART RECEIVER
 * ============================================================ */

static void transferTimer4ISR(void)
{
    TimerIntClear(TIMER4_BASE, TIMER_TIMA_TIMEOUT);
    g_transferMilliseconds++;
}

static void TransferClock_init(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER4);
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER4))
    {
    }

    TimerDisable(TIMER4_BASE, TIMER_A);
    TimerConfigure(TIMER4_BASE, TIMER_CFG_PERIODIC);
    TimerClockSourceSet(TIMER4_BASE, TIMER_CLOCK_SYSTEM);
    TimerLoadSet(TIMER4_BASE, TIMER_A, (SYSTEM_CLOCK_HZ / 1000U) - 1U);
    TimerIntRegister(TIMER4_BASE, TIMER_A, transferTimer4ISR);
    IntPrioritySet(INT_TIMER4A, IRQ_PRIO_TRANSFER_CLOCK);
    TimerIntClear(TIMER4_BASE, TIMER_TIMA_TIMEOUT);
    g_transferMilliseconds = 0U;
    TimerIntEnable(TIMER4_BASE, TIMER_TIMA_TIMEOUT);
    TimerEnable(TIMER4_BASE, TIMER_A);
}

static uint32_t readLittleEndian32(const uint8_t *data)
{
    return ((uint32_t)data[0]) |
           ((uint32_t)data[1] << 8U) |
           ((uint32_t)data[2] << 16U) |
           ((uint32_t)data[3] << 24U);
}

/* CRC-32/ISO-HDLC, matching zlib.crc32(data).
 * ASCII "123456789" must produce 0xCBF43926.
 */
uint32_t Uart_crc32(const uint8_t *data, uint32_t length)
{
    uint32_t crc = 0xFFFFFFFFU;
    uint32_t i;
    uint32_t bit;

    for (i = 0U; i < length; i++)
    {
        crc ^= (uint32_t)data[i];
        for (bit = 0U; bit < 8U; bit++)
        {
            if ((crc & 1U) != 0U)
            {
                crc = (crc >> 1U) ^ 0xEDB88320U;
            }
            else
            {
                crc >>= 1U;
            }
        }
    }
    return crc ^ 0xFFFFFFFFU;
}

static void UARTReceiver_reset(void)
{
    headerBytesReceived = 0U;
    magicBytesMatched = 0U;
    expectedLength = 0U;
    bytesReceived = 0U;
    expectedCrc32 = 0U;
    headerStartedMs = 0U;
    payloadStartedMs = 0U;
    lastRxByteMs = g_transferMilliseconds;
    s_payloadPublished = false;
    s_payloadTaken = false;
    receiverState = WAIT_MAGIC;
}

/* Reset and enter RECOVER. reset() passes through WAIT_MAGIC; PayloadTask must not
 * observe that (it asks Uart_receiverIdle() when deciding whether to add IDLE). */
static void UARTReceiver_enterRecover(void)
{
    taskENTER_CRITICAL();
    UARTReceiver_reset();
    receiverState = RECOVER;
    taskEXIT_CRITICAL();
    lastRxByteMs = g_transferMilliseconds;
}

/* 'error' is the ERR_ name, or NULL when the reply that would have reported it (or
 * the one before it) could not be queued: the receiver still recovers, and the
 * recovery IDLE (retried until accepted) tells the host the board is ready again. */
static void UARTReceiver_fail(const char *error)
{
    /* One error line per failed attempt, even if more bad bytes arrive.
     * Never stop an already playing melody in this routine: ERR_BUSY and
     * UART noise during playback must not modify the active melody.
     */
    if (receiverState == RECOVER)
    {
        lastRxByteMs = g_transferMilliseconds;
        return;
    }

    Glo.Diagnostics.TransferErrorCount++;
    UARTReceiver_enterRecover();

    /* A failed submit is already counted in Glo.Diagnostics.Tx*; recovery continues. */
    if (error != NULL)
    {
        (void)UartTx_sendLine(error);
    }
    lastRxByteMs = g_transferMilliseconds;
}

static void UARTReceiver_checkTimeout(void)
{
    uint32_t now = g_transferMilliseconds;

    /* Unsigned subtraction also works when the millisecond counter wraps. */
    if (((receiverState == READ_HEADER) ||
         ((receiverState == WAIT_MAGIC) && (magicBytesMatched != 0U))) &&
        ((uint32_t)(now - headerStartedMs) >= RX_HEADER_TIMEOUT_MS))
    {
        UARTReceiver_fail("ERR_TIMEOUT");
    }
    else if ((receiverState == READ_PAYLOAD) &&
             (((uint32_t)(now - lastRxByteMs) >= RX_PAYLOAD_IDLE_MS) ||
              ((uint32_t)(now - payloadStartedMs) >= RX_PAYLOAD_TOTAL_MS)))
    {
        UARTReceiver_fail("ERR_TIMEOUT");
    }
    else if ((receiverState == RECOVER) &&
             !UARTReceiver_inputPending() &&
             ((uint32_t)(now - lastRxByteMs) >= RX_RECOVERY_QUIET_MS))
    {
        /* IDLE means the receiver accepts another header. Playback may
         * still be active after ERR_BUSY; that next header will be refused.
         * Never wait here: if the queue is full stay in RECOVER and retry on the
         * next 10 ms pass. This task outranks PayloadTask, so PayloadTask cannot
         * run between the submit and the reset and see a stale "not idle".
         */
        if (UartTx_trySend("IDLE\r\n"))
        {
            UARTReceiver_reset();
        }
    }
}

static void UARTReceiver_acceptHeader(void)
{
    uint8_t version = headerBytes[4];
    uint8_t command = headerBytes[5];

    if ((version != SMID_PROTOCOL_VERSION) && (version != SMID_LEGACY_VERSION))
    {
        UARTReceiver_fail("ERR_VERSION");
        return;
    }
    if ((headerBytes[6] != 0U) || (headerBytes[7] != 0U) ||
        ((version == SMID_LEGACY_VERSION) && (command != SMID_COMMAND_MIDI)))
    {
        UARTReceiver_fail("ERR_HEADER");
        return;
    }
    if ((command != SMID_COMMAND_MIDI) && (command != SMID_COMMAND_STOP))
    {
        UARTReceiver_fail("ERR_COMMAND");
        return;
    }
    if (command == SMID_COMMAND_STOP)
    {
        if ((readLittleEndian32(&headerBytes[8]) != 0U) ||
            (readLittleEndian32(&headerBytes[12]) != 0U))
        {
            UARTReceiver_fail("ERR_HEADER");
            return;
        }
        if ((s_hooks != NULL) && (s_hooks->stopPlayback != NULL))
        {
            s_hooks->stopPlayback();
        }
        UARTReceiver_reset();
        /* Audio is already silent (hook above); the acknowledgement is only published
         * here. Both lines are ONE queue item so nothing can land between them. If it
         * cannot be queued (UARTTxTask broken), recovery sends an IDLE instead. */
        if (!UartTx_send("ACK_STOPPED\r\nIDLE\r\n"))
        {
            UARTReceiver_enterRecover();
        }
        return;
    }

    expectedLength = readLittleEndian32(&headerBytes[8]);
    expectedCrc32 = readLittleEndian32(&headerBytes[12]);
    Glo.Diagnostics.LastTransferLength = expectedLength;
    Glo.Diagnostics.LastExpectedCrc32 = expectedCrc32;
    Glo.Diagnostics.LastCalculatedCrc32 = 0U;

    if ((expectedLength == 0U) || (expectedLength > MAX_MIDI_FILE_SIZE))
    {
        UARTReceiver_fail("ERR_SIZE");
        return;
    }
    if ((s_hooks != NULL) && (s_hooks->isBusy != NULL) && s_hooks->isBusy())
    {
        UARTReceiver_fail("ERR_BUSY");
        return;
    }

    bytesReceived = 0U;
    receiverState = READ_PAYLOAD;
    if (!UartTx_sendAck("ACK_READY", expectedLength, expectedCrc32))
    {
        /* The host was not told to send: do not sit in READ_PAYLOAD waiting for it. */
        Glo.Diagnostics.TransferErrorCount++;
        UARTReceiver_enterRecover();
        return;
    }
    /* Start after queuing the acknowledgement. "Queued" is not "sent": the host sees
     * it a few ms later, which is small against the 2 s payload idle interval.
     */
    payloadStartedMs = g_transferMilliseconds;
    lastRxByteMs = payloadStartedMs;
}

static void UARTReceiver_processByte(uint8_t byte)
{
    static const uint8_t magic[4] = {'S', 'M', 'I', 'D'};
    uint32_t now = g_transferMilliseconds;
    lastRxByteMs = now;

    if (receiverState == RECOVER)
    {
        return;
    }

    if (receiverState == WAIT_MAGIC)
    {
        if (byte == magic[magicBytesMatched])
        {
            if (magicBytesMatched == 0U)
            {
                headerStartedMs = now;
            }
            magicBytesMatched++;
            if (magicBytesMatched == 4U)
            {
                memcpy(headerBytes, magic, sizeof(magic));
                headerBytesReceived = 4U;
                magicBytesMatched = 0U;
                receiverState = READ_HEADER;
            }
        }
        else if (byte == magic[0])
        {
            /* Preserve a new 'S', e.g. the second S in "SSMID". */
            magicBytesMatched = 1U;
            headerStartedMs = now;
        }
        else
        {
            magicBytesMatched = 0U;
        }
        return;
    }

    if (receiverState == READ_HEADER)
    {
        if (headerBytesReceived >= SMID_HEADER_SIZE)
        {
            UARTReceiver_fail("ERR_HEADER");
            return;
        }
        headerBytes[headerBytesReceived++] = byte;
        if (headerBytesReceived == SMID_HEADER_SIZE)
        {
            UARTReceiver_acceptHeader();
        }
        return;
    }

    if (receiverState == READ_PAYLOAD)
    {
        if ((bytesReceived >= expectedLength) ||
            (bytesReceived >= MAX_MIDI_FILE_SIZE))
        {
            UARTReceiver_fail("ERR_SIZE");
            return;
        }
        /* All payload bytes are data: do not look for SMID or commands. */
        fileBuffer[bytesReceived++] = byte;
        if (bytesReceived == expectedLength)
        {
            receiverState = VALIDATE;
        }
    }
}

/* The payload is complete (receiverState == VALIDATE). Apply the baseline
 * unexpected-data guard, then hand the buffer to the controller. */
static void UARTReceiver_publishPayload(void)
{
    if ((receiverState != VALIDATE) || s_payloadPublished)
    {
        return;
    }

    /* The host must wait for the result before sending anything else. Checked over
     * the ring AND the FIFO: bytes the ISR already moved count as unexpected too. */
    if (UARTReceiver_inputPending())
    {
        UARTReceiver_fail("ERR_SIZE");
        return;
    }

    /* Publish: the controller may take the payload from this point. */
    s_payloadPublished = true;
    COMPILER_BARRIER();
    xSemaphoreGive(Glo.Bios.PayloadSem);
}

/* One pass of receive handling, run by UART0ReadTask after every wake-up (data, error
 * or the finite-wait timeout). While the payload is owned by the controller
 * (receiverState == VALIDATE) the receiver and ring are left alone; bytes that arrive
 * meanwhile stay in the ring and are processed as a new stream once the controller
 * releases the payload (or overflow into RXFAULT_OVERFLOW -> ERR_UART, as an overrun
 * did in the baseline). */
static void UARTReceiver_service(void)
{
    uint32_t faults;
    uint8_t byte;

    /* This call runs even when no bytes arrive. */
    UARTReceiver_checkTimeout();

    if (receiverState == VALIDATE)
    {
        return;
    }

    faults = __atomic_exchange_n(&s_rxFaultFlags, 0U, __ATOMIC_SEQ_CST);
    if (faults != 0U)
    {
        UARTReceiver_fail("ERR_UART");
    }

    while ((receiverState != VALIDATE) && UARTReceiver_ringPop(&byte))
    {
        UARTReceiver_checkTimeout();
        UARTReceiver_processByte(byte);
    }

    /* Also catch a fault reported immediately after the last byte. */
    faults = __atomic_exchange_n(&s_rxFaultFlags, 0U, __ATOMIC_SEQ_CST);
    if (faults != 0U)
    {
        UARTReceiver_fail("ERR_UART");
    }
    UARTReceiver_checkTimeout();
    UARTReceiver_publishPayload();
}

/* ============================================================
 * PUBLIC INTERFACE (declared in uart_task.h)
 * ============================================================ */

void Uart_init(const UartHooks *hooks)
{
    s_hooks = hooks;

    /* Timer4 is reserved for the transfer clock; no SysConfig edit. */
    TransferClock_init();
    UART0_init();
    UARTRxErrorClear(UART0_BASE);
    UARTReceiver_reset();
}

/* UART0ReadTask: owns receiver framing, timeouts and recovery. The banner is queued
 * from here as the first thing after the scheduler starts (the queue exists since
 * Control_init); the sender does not require it, so a failed submit is only counted. */
void Uart_readTask(void *arg)
{
    (void)arg;

    UARTRxErrorClear(UART0_BASE);
    UARTIntEnable(UART0_BASE,
                  UART_INT_RX | UART_INT_RT |
                  UART_INT_OE | UART_INT_BE | UART_INT_PE | UART_INT_FE);

    (void)UartTx_send("\r\nSMID v2 READY\r\nIDLE\r\n");

    for (;;)
    {
        /* Event: UARTReadSem (given by uart0RxIsr per batch, or by the controller when it
         * returns the payload). Finite timeout: timeouts are enforced without new bytes. */
        if (xSemaphoreTake(Glo.Bios.UARTReadSem, pdMS_TO_TICKS(UART_TASK_WAIT_MS)) == pdTRUE)
        {
            Glo.Diagnostics.UartWakeCount++;
        }
        else
        {
            Glo.Diagnostics.UartTimeoutPasses++;
        }

        UARTReceiver_service();
    }
}

bool Uart_acquirePayload(UartPayload *out)
{
    if ((receiverState != VALIDATE) || !s_payloadPublished || s_payloadTaken)
    {
        return false;
    }

    s_payloadTaken = true;
    out->data = fileBuffer;
    out->length = expectedLength;
    out->expectedCrc32 = expectedCrc32;
    return true;
}

void Uart_payloadAccepted(void)
{
    if (receiverState != VALIDATE)
    {
        return;
    }

    UARTReceiver_reset();

    /* Wake UART0ReadTask to scan any bytes that arrived while the payload was out. */
    (void)xSemaphoreGive(Glo.Bios.UARTReadSem);
}

void Uart_payloadRejected(const char *errorText)   /* NULL: no line (a reply was lost) */
{
    if (receiverState != VALIDATE)
    {
        return;
    }

    UARTReceiver_fail(errorText);
    (void)xSemaphoreGive(Glo.Bios.UARTReadSem);
}

bool Uart_receiverIdle(void)
{
    return (receiverState == WAIT_MAGIC) && (magicBytesMatched == 0U);
}
