/*
 * control_task.h -- protocol lifecycle coordinator and application setup
 * (control_task.c).
 *
 * Creates the RTOS objects and tasks, then runs PayloadTask (validate, start,
 * report completion) and MonitorTask (LED + diagnostics). Requests STOP/BUSY from
 * the transport through hooks and never touches raw receiver state.
 */
#ifndef CONTROL_TASK_H
#define CONTROL_TASK_H

#include <stdbool.h>

/*
 * Create Glo.Bios.UARTReadSem / PayloadSem / UARTTxQueue, initialise playback and
 * the UART transport, and create UARTTxTask, UART0ReadTask, PayloadTask and MonitorTask.
 * Call once from main() before vTaskStartScheduler(). Returns false (and counts a
 * Glo.Diagnostics.CreateFailCount) if any allocation fails.
 */
bool Control_init(void);

#endif /* CONTROL_TASK_H */
