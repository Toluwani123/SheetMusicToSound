/*
 * audio.h -- public interface of the audio module (audio.c).
 *
 * Owns the DAC8311 on SSI2, the PN3 SYNC and PH2 amplifier pins, Timer2 and
 * the 20 kHz sample ISR. Playback code must use only these functions; it never
 * edits phase/envelope state directly.
 */
#ifndef AUDIO_H
#define AUDIO_H

#include <stdint.h>
#include <stdbool.h>

/* Pitch range of the frequency table (MIDI 48 = C3 .. 84 = C6). */
#define AUDIO_NOTE_MIN   48U
#define AUDIO_NOTE_MAX   84U
#define AUDIO_NOTE_NONE  0xFFU

/* Configure DAC, amplifier (off) and Timer2 (stopped). Call once at startup. */
void Audio_init(void);

/* Start one note; the 5 ms attack/release ramps fit inside durationMs.
 * An unsupported note number silences the output instead. */
void Audio_startNote(uint8_t midiNote, uint32_t durationMs);

/* Hard silence: stop Timer2, clear envelope, DAC to midpoint, amplifier off. */
void Audio_stopNote(void);

/* Read-only status for the scheduler/diagnostics. */
bool Audio_isNoteActive(void);

/* Milliseconds -> CPU-clock counts (0 ms -> 1 ms, clamped to 32 bits). Shared
 * by the Timer3 scheduler and the envelope so both use the same note end. */
uint32_t Audio_msToCpuCounts(uint32_t milliseconds);

/* Clear the audio-ISR maximum-cycles profiler value. */
void Audio_clearIsrMax(void);

#endif /* AUDIO_H */
