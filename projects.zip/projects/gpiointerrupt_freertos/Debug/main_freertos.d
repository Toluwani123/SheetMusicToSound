# FIXED

main_freertos.o: ../main_freertos.c \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/FreeRTOS.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOSConfig.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/projdefs.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/portable.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/deprecated_definitions.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/mpu_wrappers.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/task.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/list.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/Board.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/GPIO.h \
 ../globals.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/semphr.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/queue.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/task.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/queue.h \
 ../audio.h ../control_task.h

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/FreeRTOS.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOSConfig.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/projdefs.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/portable.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/deprecated_definitions.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/mpu_wrappers.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/task.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/list.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/Board.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/GPIO.h:

../globals.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/semphr.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/queue.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/task.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/queue.h:

../audio.h:

../control_task.h:
