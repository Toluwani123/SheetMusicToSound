# FIXED

midi.o: ../midi.c ../midi.h

../midi.h:
