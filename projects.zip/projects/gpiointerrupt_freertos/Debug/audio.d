# FIXED

audio.o: ../audio.c \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/driverlib.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp432e401y.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/core_cm4.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_version.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_compiler.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_gcc.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/mpu_armv7.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/system_msp432e401y.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/adc.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/aes.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/can.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/comp.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/cpu.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/crc.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/debug.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/des.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/eeprom.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/emac.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/epi.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/flash.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/fpu.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/gpio.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/hibernate.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/gcc/time.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/gcc/signal.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/gcc/sys/types.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/i2c.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/interrupt.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/mpu.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/pin_map.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/pwm.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/qei.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/rom.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/rom_map.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/shamd5.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/ssi.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/sw_crc.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/sysctl.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/sysexc.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/systick.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/timer.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/types.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/uart.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/udma.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/usb.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/watchdog.h \
 ../audio.h ../globals.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/FreeRTOS.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOSConfig.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/projdefs.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/portable.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/deprecated_definitions.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/mpu_wrappers.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/task.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/list.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/semphr.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/queue.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/task.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/queue.h

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/driverlib.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp432e401y.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/core_cm4.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_version.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_compiler.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_gcc.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/mpu_armv7.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/system_msp432e401y.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/adc.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/aes.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/can.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/comp.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/cpu.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/crc.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/debug.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/des.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/eeprom.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/emac.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/epi.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/flash.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/fpu.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/gpio.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/hibernate.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/gcc/time.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/gcc/signal.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/gcc/sys/types.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/i2c.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/interrupt.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/mpu.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/pin_map.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/pwm.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/qei.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/rom.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/rom_map.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/shamd5.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/ssi.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/sw_crc.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/sysctl.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/sysexc.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/systick.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/timer.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/types.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/uart.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/udma.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/usb.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/watchdog.h:

../audio.h:

../globals.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/FreeRTOS.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOSConfig.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/projdefs.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/portable.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/deprecated_definitions.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/mpu_wrappers.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/task.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/list.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/semphr.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/queue.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/task.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/queue.h:
