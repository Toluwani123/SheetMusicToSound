################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
SYSCFG_SRCS += \
../gpiointerrupt.syscfg 

LDS_SRCS += \
../MSP_EXP432E401Y_FREERTOS.lds 

C_SRCS += \
../audio.c \
../control_task.c \
../globals.c \
./syscfg/ti_drivers_config.c \
../main_freertos.c \
../midi.c \
../playback.c \
../uart_task.c \
../uart_tx.c 

GEN_FILES += \
./syscfg/ti_drivers_config.c 

GEN_MISC_DIRS += \
./syscfg 

C_DEPS += \
./audio.d \
./control_task.d \
./globals.d \
./syscfg/ti_drivers_config.d \
./main_freertos.d \
./midi.d \
./playback.d \
./uart_task.d \
./uart_tx.d 

OBJS += \
./audio.o \
./control_task.o \
./globals.o \
./syscfg/ti_drivers_config.o \
./main_freertos.o \
./midi.o \
./playback.o \
./uart_task.o \
./uart_tx.o 

GEN_MISC_FILES += \
./syscfg/ti_drivers_config.h \
./syscfg/ti_utils_build_linker.cmd.exp \
./syscfg/syscfg_c.rov.xs 

GEN_MISC_DIRS__QUOTED += \
"syscfg" 

OBJS__QUOTED += \
"audio.o" \
"control_task.o" \
"globals.o" \
"syscfg\ti_drivers_config.o" \
"main_freertos.o" \
"midi.o" \
"playback.o" \
"uart_task.o" \
"uart_tx.o" 

GEN_MISC_FILES__QUOTED += \
"syscfg\ti_drivers_config.h" \
"syscfg\ti_utils_build_linker.cmd.exp" \
"syscfg\syscfg_c.rov.xs" 

C_DEPS__QUOTED += \
"audio.d" \
"control_task.d" \
"globals.d" \
"syscfg\ti_drivers_config.d" \
"main_freertos.d" \
"midi.d" \
"playback.d" \
"uart_task.d" \
"uart_tx.d" 

GEN_FILES__QUOTED += \
"syscfg\ti_drivers_config.c" 

C_SRCS__QUOTED += \
"../audio.c" \
"../control_task.c" \
"../globals.c" \
"./syscfg/ti_drivers_config.c" \
"../main_freertos.c" \
"../midi.c" \
"../playback.c" \
"../uart_task.c" \
"../uart_tx.c" 

SYSCFG_SRCS__QUOTED += \
"../gpiointerrupt.syscfg" 


