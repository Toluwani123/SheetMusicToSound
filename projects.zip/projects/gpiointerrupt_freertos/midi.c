/*
 * midi.c -- bounded Type-0 MIDI parser.
 *
 * Moved from gpiointerrupt.c (parseSimpleMidi). Pure computation: no UART,
 * timers, RTOS or hardware access. The caller supplies the event array.
 */
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "midi.h"


/* ============================================================
 * BYTE-ORDER HELPERS
 * ============================================================
 *
 * Standard MIDI files store their normal
 * multi-byte fields big-endian.
 */

static uint16_t readBigEndian16(
    const uint8_t *data
)
{
    return
        ((uint16_t)data[0] << 8) |
        ((uint16_t)data[1]);
}


static uint32_t readBigEndian32(
    const uint8_t *data
)
{
    return
        ((uint32_t)data[0] << 24) |
        ((uint32_t)data[1] << 16) |
        ((uint32_t)data[2] << 8) |
        ((uint32_t)data[3]);
}

/* ============================================================
 * MIDI VARIABLE-LENGTH QUANTITY
 * ============================================================
 *
 * MIDI delta times are stored using VLQs.
 *
 * Example:
 *
 *      480 ticks
 *
 * is:
 *
 *      83 60
 */

static bool readMidiVLQ(
    const uint8_t *data,
    uint32_t end,
    uint32_t *index,
    uint32_t *value
)
{
    uint32_t result = 0;

    uint32_t byteCount = 0;

    uint8_t byte;


    do
    {
        /*
         * Protect against reading outside
         * the MIDI track.
         */
        if (*index >= end)
        {
            return false;
        }


        /*
         * Standard MIDI VLQ is at most
         * four bytes long.
         */
        if (byteCount >= 4U)
        {
            return false;
        }


        byte =
            data[*index];


        (*index)++;

        byteCount++;


        /*
         * Every VLQ byte contributes
         * seven data bits.
         */
        result =
            (result << 7) |
            (byte & 0x7FU);

    }
    while ((byte & 0x80U) != 0U);


    *value = result;

    return true;
}

/* ============================================================
 * TIME CONVERSION
 * ============================================================
 */

static uint32_t microsecondsToMilliseconds(
    uint64_t microseconds
)
{
    uint32_t milliseconds;


    /*
     * +500 gives basic rounding instead
     * of always truncating downward.
     */
    milliseconds =
        (uint32_t)(
            (microseconds + 500ULL)
            /
            1000ULL
        );


    /*
     * Avoid accidentally turning a real
     * non-zero note into 0 ms.
     */
    if ((microseconds > 0ULL) &&
        (milliseconds == 0U))
    {
        milliseconds = 1U;
    }


    return milliseconds;
}

/* ============================================================
 * DELIVERABLE 5: BOUNDED TYPE-0 MIDI PARSER
 * ============================================================
 * Contract: one track, PPQN, channel 0, monophonic notes 48..84.
 * Decode channel running status; Note On velocity 0 ends a note.
 * Consume/ignore A/B/C/D/E channel events while retaining elapsed time.
 * Read tempo/EOT; skip other bounded meta events. SysEx remains unsupported.
 * This parser accepts a complete file before audio playback can start.
 */


/* CCS diagnostics for the most recent parse attempt; no extra UART lines. */
static volatile uint32_t g_lastMidiRunningStatusCount = 0U;
static volatile uint32_t g_lastMidiSkippedChannelEvents = 0U;
static volatile uint32_t g_lastMidiSkippedMetaEvents = 0U;

/* Validate common fixed-size meta events before accessing/skipping their data.
 * Other meta types are opaque, length-delimited data under this contract.
 */
static bool midiMetaLengthValid(uint8_t type, uint32_t length)
{
    switch (type)
    {
        case 0x00U: return length == 2U;  /* sequence number */
        case 0x20U:                     /* channel prefix */
        case 0x21U: return length == 1U;  /* MIDI port */
        case 0x2FU: return length == 0U;  /* end of track */
        case 0x51U: return length == 3U;  /* tempo */
        case 0x54U: return length == 5U;  /* SMPTE offset metadata */
        case 0x58U: return length == 4U;  /* time signature */
        case 0x59U: return length == 2U;  /* key signature */
        default: return true;            /* text/opaque metadata */
    }
}

static bool midiTimeFitsMilliseconds(uint64_t us)
{
    /* Keep the existing millisecond scheduler, but prevent narrowing wrap. */
    return us <= ((uint64_t)UINT32_MAX * 1000ULL + 499ULL);
}

MidiParseResult Midi_parse(const uint8_t *data,
                           uint32_t fileLength,
                           MelodyEvent *out,
                           uint32_t capacity,
                           uint32_t *outCount)
{
    uint32_t index;
    uint32_t trackEnd;
    uint32_t tempoUsPerQuarter = 500000U;
    uint32_t tickFraction = 0U;
    uint16_t division;
    uint64_t currentTimeUs = 0ULL;
    uint64_t noteStartTimeUs = 0ULL;
    uint64_t lastNoteOffTimeUs = 0ULL;
    uint8_t runningStatus = 0U;
    uint8_t activeNote = MIDI_NOTE_NONE;
    bool parserNoteActive = false;

    *outCount = 0U;
    g_lastMidiRunningStatusCount = 0U;
    g_lastMidiSkippedChannelEvents = 0U;
    g_lastMidiSkippedMetaEvents = 0U;

    /* Project subset: standard six-byte header, exactly one Type-0 track. */
    if ((fileLength < 22U) || (memcmp(data, "MThd", 4U) != 0) ||
        (readBigEndian32(&data[4]) != 6U) ||
        (readBigEndian16(&data[8]) != 0U) ||
        (readBigEndian16(&data[10]) != 1U))
    {
        return MIDI_PARSE_MALFORMED;
    }
    division = readBigEndian16(&data[12]);
    if ((division == 0U) || ((division & 0x8000U) != 0U) ||
        (memcmp(&data[14], "MTrk", 4U) != 0))
    {
        return MIDI_PARSE_MALFORMED;
    }
    index = 22U;
    /* Exact equality also rejects extra chunks/bytes outside our one track. */
    if (readBigEndian32(&data[18]) != (fileLength - index))
    {
        return MIDI_PARSE_MALFORMED;
    }
    trackEnd = fileLength;

    while (index < trackEnd)
    {
        uint32_t deltaTicks;
        uint64_t numerator;
        uint64_t deltaUs;
        uint8_t status;
        uint8_t kind;
        uint32_t dataLength;
        uint32_t i;
        uint8_t first;
        uint8_t second;

        if (!readMidiVLQ(data, trackEnd, &index, &deltaTicks))
        {
            return MIDI_PARSE_MALFORMED;
        }
        /* Include every event's delta, even if its musical effect is ignored.
         * Carry the fractional microsecond: subdividing a wait into controller
         * events must not lose one rounding remainder per ignored event.
         */
        numerator = (uint64_t)deltaTicks * tempoUsPerQuarter + tickFraction;
        deltaUs = numerator / division;
        tickFraction = (uint32_t)(numerator % division);
        if (deltaUs > (UINT64_MAX - currentTimeUs))
        {
            return MIDI_PARSE_MALFORMED;
        }
        currentTimeUs += deltaUs;
        if (index >= trackEnd)
        {
            return MIDI_PARSE_MALFORMED;
        }

        status = data[index];
        if (status < 0x80U)
        {
            if (runningStatus == 0U)
            {
                return MIDI_PARSE_MALFORMED;
            }
            status = runningStatus;
            /* The current byte is the first data byte; do not consume it yet. */
            g_lastMidiRunningStatusCount++;
        }
        else
        {
            index++;
            if (status < 0xF0U)
            {
                runningStatus = status; /* includes message kind AND channel */
            }
            else
            {
                /* In SMF, meta/SysEx events cancel channel running status. */
                runningStatus = 0U;
            }
        }

        if (status == 0xFFU)
        {
            uint8_t metaType;
            uint32_t metaLength;
            if (index >= trackEnd)
            {
                return MIDI_PARSE_MALFORMED;
            }
            metaType = data[index++];
            if ((metaType >= 0x80U) ||
                !readMidiVLQ(data, trackEnd, &index, &metaLength) ||
                (metaLength > (trackEnd - index)) ||
                !midiMetaLengthValid(metaType, metaLength))
            {
                return MIDI_PARSE_MALFORMED;
            }
            if (metaType == 0x51U)
            {
                tempoUsPerQuarter = ((uint32_t)data[index] << 16) |
                                    ((uint32_t)data[index + 1U] << 8) |
                                    (uint32_t)data[index + 2U];
                if (tempoUsPerQuarter == 0U)
                {
                    return MIDI_PARSE_MALFORMED;
                }
            }
            else if (metaType == 0x2FU)
            {
                /* EOT must be the final event, with every note already ended. */
                return (!parserNoteActive && (*outCount > 0U) &&
                        (index == trackEnd)) ? MIDI_PARSE_OK : MIDI_PARSE_MALFORMED;
            }
            else
            {
                if (((metaType == 0x20U) && (data[index] > 15U)) ||
                    ((metaType == 0x21U) && (data[index] > 127U)))
                {
                    return MIDI_PARSE_MALFORMED;
                }
                g_lastMidiSkippedMetaEvents++;
            }
            index += metaLength;
            continue;
        }

        /* Channel messages only. F0/F7 SysEx and raw system statuses are not
         * part of the agreed input subset, so reject instead of guessing.
         * Channel 0 in bytes corresponds to channel 1 in many music programs.
         */
        if ((status >= 0xF0U) || ((status & 0x0FU) != 0U))
        {
            return MIDI_PARSE_MALFORMED;
        }
        kind = status & 0xF0U;
        dataLength = ((kind == 0xC0U) || (kind == 0xD0U)) ? 1U : 2U;
        if (dataLength > (trackEnd - index))
        {
            return MIDI_PARSE_MALFORMED;
        }
        for (i = 0U; i < dataLength; i++)
        {
            if (data[index + i] >= 0x80U)
            {
                return MIDI_PARSE_MALFORMED;
            }
        }
        first = data[index];
        second = (dataLength == 2U) ? data[index + 1U] : 0U;
        index += dataLength;

        if ((kind != 0x80U) && (kind != 0x90U))
        {
            /* A0/B0/C0/D0/E0: pressure, controllers, programs, pitch bend.
             * Consume correctly but do not implement their synthesis effects.
             */
            g_lastMidiSkippedChannelEvents++;
            continue;
        }
        if ((kind == 0x90U) && (second != 0U))
        {
            uint64_t restUs;
            if (parserNoteActive || (first < MIDI_NOTE_MIN) || (first > MIDI_NOTE_MAX))
            {
                return MIDI_PARSE_MALFORMED;
            }
            if (*outCount > 0U)
            {
                restUs = currentTimeUs - lastNoteOffTimeUs;
                if (!midiTimeFitsMilliseconds(restUs))
                {
                    return MIDI_PARSE_MALFORMED;
                }
                out[*outCount - 1U].restAfterMs =
                    microsecondsToMilliseconds(restUs);
            }
            activeNote = first;
            noteStartTimeUs = currentTimeUs;
            parserNoteActive = true;
        }
        else
        {
            uint64_t durationUs;
            /* Both Note Off encodings use this one bounded append path. */
            if (!parserNoteActive || (first != activeNote))
            {
                return MIDI_PARSE_MALFORMED;
            }
            if (*outCount >= capacity)
            {
                return MIDI_PARSE_NOTE_CAPACITY;
            }
            durationUs = currentTimeUs - noteStartTimeUs;
            if (!midiTimeFitsMilliseconds(durationUs))
            {
                return MIDI_PARSE_MALFORMED;
            }
            out[*outCount].midiNote = activeNote;
            out[*outCount].durationMs = microsecondsToMilliseconds(durationUs);
            out[*outCount].restAfterMs = 0U;
            (*outCount)++;
            parserNoteActive = false;
            activeNote = MIDI_NOTE_NONE;
            lastNoteOffTimeUs = currentTimeUs;
        }
    }
    return MIDI_PARSE_MALFORMED; /* missing End Of Track */
}
