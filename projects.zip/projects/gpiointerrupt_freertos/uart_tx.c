/*
 * uart_tx.c -- reply queue and UARTTxTask, the single owner of the UART0 transmitter.
 *
 * WHY A QUEUE AND AN OWNER TASK (instead of the old UARTTxMutex)
 *   Before, whichever task had a reply to send took the mutex and spent the whole
 *   physical transmission (~87 us per byte) inside UARTCharPut() at its own priority.
 *   Now a producer formats/copies its reply into a queue item and continues; this
 *   task alone moves bytes into the UART FIFO. Producers only wait if all
 *   UART_TX_QUEUE_DEPTH slots are full, and then for a bounded time.
 *   The gain is ownership and decoupling from the wire, not "queues never block".
 *
 * MESSAGE LIFETIME
 *   The queue item holds the reply BY VALUE (length + characters). xQueueSend copies
 *   it into the queue's own storage before returning, so the producer's stack buffer
 *   is never referenced afterwards, and UARTTxTask copies it out into its own stack
 *   item before transmitting, so a slot is free again as soon as transmission begins.
 *   No heap is allocated per reply.
 *
 * STORAGE COST (static, allocated once from the FreeRTOS heap at startup)
 *   item  = sizeof(UartTxMsg) = 1 + UART_TX_MSG_MAX_CHARS = 41 bytes
 *   queue = UART_TX_QUEUE_DEPTH x 41 = 328 bytes + the kernel queue header
 *   task  = STACK_WORDS_UART_TX words + TCB (see control_task.c)
 *
 * "TRANSMITTED" in Glo.Diagnostics means: every byte of the reply has been written
 * into the UART transmit FIFO (the same point at which the old UARTCharPut() returned).
 * The last bytes may still be shifting out of the 16-byte FIFO for up to ~1.4 ms.
 *
 * Diagnostics writers: producers (several tasks) use atomic adds; UARTTxTask is the
 * single writer of the Transmitted/Bytes/MaxDepth/InFlight/Fault fields.
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#ifndef __MSP432E401Y__
#define __MSP432E401Y__
#endif

#include <ti/devices/msp432e4/driverlib/driverlib.h>

#include "uart_tx.h"
#include "globals.h"

typedef struct
{
    uint8_t length;                       /* 1..UART_TX_MSG_MAX_CHARS */
    char    text[UART_TX_MSG_MAX_CHARS];  /* not NUL-terminated */
} UartTxMsg;

typedef char uartTxLengthFitsInOneByte[(UART_TX_MSG_MAX_CHARS < 256U) ? 1 : -1];

static void UartTx_count(volatile uint32_t *counter)
{
    (void)__atomic_fetch_add(counter, 1U, __ATOMIC_RELAXED);
}

/* ------------------------------------------------------------ message building */

static bool UartTx_appendText(UartTxMsg *msg, const char *text)
{
    while (*text != '\0')
    {
        if (msg->length >= UART_TX_MSG_MAX_CHARS)
        {
            return false;                 /* would truncate: refuse */
        }
        msg->text[msg->length++] = *text++;
    }
    return true;
}

static bool UartTx_appendDecimal(UartTxMsg *msg, uint32_t value)
{
    char digits[10];
    uint32_t count = 0U;

    do
    {
        digits[count++] = (char)('0' + (value % 10U));
        value /= 10U;
    } while (value != 0U);

    while (count != 0U)
    {
        if (msg->length >= UART_TX_MSG_MAX_CHARS)
        {
            return false;
        }
        msg->text[msg->length++] = digits[--count];
    }
    return true;
}

static bool UartTx_appendHex32(UartTxMsg *msg, uint32_t value)
{
    static const char hex[] = "0123456789ABCDEF";
    uint32_t shift;

    for (shift = 32U; shift != 0U; shift -= 4U)
    {
        if (msg->length >= UART_TX_MSG_MAX_CHARS)
        {
            return false;
        }
        msg->text[msg->length++] = hex[(value >> (shift - 4U)) & 0xFU];
    }
    return true;
}

/* ------------------------------------------------------------------ submission */

/* Copy 'msg' into the queue. wait == 0 never blocks. Counts every outcome. */
static bool UartTx_submit(const UartTxMsg *msg, TickType_t wait)
{
    QueueHandle_t queue = Glo.Bios.UARTTxQueue;

    if (queue == NULL)
    {
        UartTx_count(&Glo.Diagnostics.TxNotReadyCount);
        return false;
    }

    if (xQueueSend(queue, msg, 0) != pdTRUE)
    {
        UartTx_count(&Glo.Diagnostics.TxQueueFullCount);
        if (wait == 0U)
        {
            return false;
        }
        if (xQueueSend(queue, msg, wait) != pdTRUE)
        {
            UartTx_count(&Glo.Diagnostics.TxSubmitTimeoutCount);
            return false;
        }
    }

    UartTx_count(&Glo.Diagnostics.TxMsgsQueued);
    return true;
}

static bool UartTx_submitBuilt(bool built, const UartTxMsg *msg, TickType_t wait)
{
    if (!built || (msg->length == 0U))
    {
        UartTx_count(&Glo.Diagnostics.TxFormatErrorCount);
        return false;
    }
    return UartTx_submit(msg, wait);
}

bool UartTx_send(const char *text)
{
    UartTxMsg msg = { 0U, { 0 } };

    return UartTx_submitBuilt(UartTx_appendText(&msg, text), &msg,
                              pdMS_TO_TICKS(UART_TX_SUBMIT_TIMEOUT_MS));
}

bool UartTx_trySend(const char *text)
{
    UartTxMsg msg = { 0U, { 0 } };

    return UartTx_submitBuilt(UartTx_appendText(&msg, text), &msg, 0U);
}

bool UartTx_sendLine(const char *text)
{
    UartTxMsg msg = { 0U, { 0 } };
    bool built = UartTx_appendText(&msg, text) && UartTx_appendText(&msg, "\r\n");

    return UartTx_submitBuilt(built, &msg, pdMS_TO_TICKS(UART_TX_SUBMIT_TIMEOUT_MS));
}

bool UartTx_sendAck(const char *name, uint32_t length, uint32_t crc)
{
    UartTxMsg msg = { 0U, { 0 } };
    bool built = UartTx_appendText(&msg, name) && UartTx_appendText(&msg, " ") &&
                 UartTx_appendDecimal(&msg, length) && UartTx_appendText(&msg, " ") &&
                 UartTx_appendHex32(&msg, crc) && UartTx_appendText(&msg, "\r\n");

    return UartTx_submitBuilt(built, &msg, pdMS_TO_TICKS(UART_TX_SUBMIT_TIMEOUT_MS));
}

uint32_t UartTx_spacesAvailable(void)
{
    return (Glo.Bios.UARTTxQueue == NULL) ? 0U : (uint32_t)uxQueueSpacesAvailable(Glo.Bios.UARTTxQueue);
}

bool UartTx_waitForSpace(void)
{
    uint32_t waited;

    if (UartTx_spacesAvailable() != 0U)
    {
        return true;
    }

    UartTx_count(&Glo.Diagnostics.TxQueueFullCount);
    for (waited = 0U; waited < UART_TX_SUBMIT_TIMEOUT_MS; waited++)
    {
        vTaskDelay(pdMS_TO_TICKS(1U));
        if (UartTx_spacesAvailable() != 0U)
        {
            return true;
        }
    }

    UartTx_count(&Glo.Diagnostics.TxSubmitTimeoutCount);
    return false;
}

bool UartTx_createQueue(void)
{
    Glo.Bios.UARTTxQueue = xQueueCreate(UART_TX_QUEUE_DEPTH, sizeof(UartTxMsg));
    return Glo.Bios.UARTTxQueue != NULL;
}

/* ------------------------------------------------------------------ transmitter */

/* Hand every character to the UART FIFO. The task never spins on a full FIFO: it
 * sleeps one tick (the FIFO holds 16 bytes = 1.39 ms, a tick is 1 ms), so lower
 * priority tasks keep running while a reply drains. Returns false if the FIFO takes
 * nothing for UART_TX_STALL_LIMIT_MS. */
static bool UartTx_write(const char *text, uint32_t length)
{
    uint32_t sent = 0U;
    uint32_t stalledMs = 0U;

    while (sent < length)
    {
        uint32_t before = sent;

        while ((sent < length) && UARTSpaceAvail(UART0_BASE))
        {
            (void)UARTCharPutNonBlocking(UART0_BASE, (uint8_t)text[sent]);
            sent++;
        }

        if (sent == length)
        {
            break;
        }

        stalledMs = (sent == before) ? (stalledMs + 1U) : 0U;
        if (stalledMs >= UART_TX_STALL_LIMIT_MS)
        {
            return false;
        }
        vTaskDelay(pdMS_TO_TICKS(1U));
    }
    return true;
}

void UartTx_task(void *arg)
{
    UartTxMsg msg;
    uint32_t depth;

    (void)arg;

    for (;;)
    {
        if (xQueueReceive(Glo.Bios.UARTTxQueue, &msg, portMAX_DELAY) != pdTRUE)
        {
            continue;
        }

        /* Occupancy only grows between receives, so the value just before each
         * receive is the exact peak. This task is the only writer. */
        depth = (uint32_t)uxQueueMessagesWaiting(Glo.Bios.UARTTxQueue) + 1U;
        if (depth > Glo.Diagnostics.TxMaxQueueDepth)
        {
            Glo.Diagnostics.TxMaxQueueDepth = depth;
        }

        Glo.Diagnostics.TxInFlight = 1U;
#ifdef UART_TX_TEST_STALL_MS
        vTaskDelay(pdMS_TO_TICKS(UART_TX_TEST_STALL_MS));   /* saturation test build only */
#endif
        if (UartTx_write(msg.text, msg.length))
        {
            Glo.Diagnostics.TxBytesTransmitted += msg.length;
            Glo.Diagnostics.TxMsgsTransmitted++;
        }
        else
        {
            Glo.Diagnostics.TxFaultCount++;
        }
        Glo.Diagnostics.TxInFlight = 0U;
    }
}
