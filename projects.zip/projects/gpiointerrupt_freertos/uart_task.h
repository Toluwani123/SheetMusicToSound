/*
 * uart_task.h -- UART0 transport interface (uart_task.c).
 *
 * Owns UART0, its receive ISR and ring buffer, the Timer4 millisecond transfer
 * clock, the file buffer and the framing/timeout/recovery state machine. The controller (control_task.c)
 * never touches raw receiver state: it borrows a completed payload through
 * Uart_acquirePayload() and returns it with Uart_payloadAccepted() or
 * Uart_payloadRejected().
 *
 * Protocol: SMID v2 (v1 MIDI accepted); keep MAX_MIDI_FILE_SIZE coordinated
 * with newmiditst.py.
 */
#ifndef UART_TASK_H
#define UART_TASK_H

#include <stdint.h>
#include <stdbool.h>

#define MAX_MIDI_FILE_SIZE       16384U

/* Callbacks supplied by the controller; both run in the transport's context. */
typedef struct
{
    bool (*isBusy)(void);         /* header time: is a song still playing? */
    void (*stopPlayback)(void);   /* STOP frame: hard silence, then ACK_STOPPED */
} UartHooks;

/* A completely received payload, valid until accepted/rejected. */
typedef struct
{
    const uint8_t *data;
    uint32_t length;
    uint32_t expectedCrc32;
} UartPayload;

/* Configure UART0 (115200 8-N-1), its FIFO and ISR registration, Timer4 and the
 * receiver. The UART interrupt sources stay masked until UART0ReadTask starts
 * (the scheduler must be running before any ISR gives a semaphore). Call before
 * vTaskStartScheduler(), after Glo.Bios.UARTReadSem and UARTTxQueue exist. */
void Uart_init(const UartHooks *hooks);

/* UART0ReadTask entry (create with xTaskCreate). Blocks on Glo.Bios.UARTReadSem
 * with a finite timeout so receive timeouts are enforced even with no new bytes. */
void Uart_readTask(void *arg);

/* Take ownership of a published payload (true once per payload). The receiver
 * accepts no new bytes until the payload is accepted or rejected. */
bool Uart_acquirePayload(UartPayload *out);
void Uart_payloadAccepted(void);                   /* receiver -> WAIT_MAGIC */
void Uart_payloadRejected(const char *errorText);  /* ERR_x line, then RECOVER; NULL = no line */

/* True while the receiver is between frames (used for IDLE after DONE). */
bool Uart_receiverIdle(void);

/* CRC-32/ISO-HDLC, matching zlib.crc32(). "123456789" -> 0xCBF43926. */
uint32_t Uart_crc32(const uint8_t *data, uint32_t length);

/* This module no longer writes to the UART. Every reply goes through the transmit
 * queue (uart_tx.h); UARTTxTask is the only writer. */

#endif /* UART_TASK_H */
