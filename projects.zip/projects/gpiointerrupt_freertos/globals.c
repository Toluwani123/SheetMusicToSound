/*
 * globals.c -- the single definition of the shared Globals object.
 *
 * Zero-initialised: every handle is NULL and every counter 0 until
 * Control_init() (control_task.c) creates the RTOS objects before the
 * scheduler starts.
 */
#include "globals.h"

Globals Glo = {0};
