/*
 * uart_tx.h -- UART0 transmit path: a bounded reply queue and the one task that
 * writes to the UART transmitter (uart_tx.c).
 *
 * OWNERSHIP RULE: UARTTxTask is the only application code that writes UART0 data.
 * Every other task submits a COMPLETE reply (one or more lines that must stay
 * together) with UartTx_send*(); the text is copied into the queue item, so the
 * caller's buffer is free as soon as the call returns.
 *
 * "Accepted" means the reply is stored in the queue. It does NOT mean a byte has
 * left the chip. Replies are transmitted in the order they were accepted.
 *
 * Task context only. Never call from an ISR, and never from a fault hook.
 */
#ifndef UART_TX_H
#define UART_TX_H

#include <stdint.h>
#include <stdbool.h>

/* Test-only configuration (saturation firmware). The release project has no
 * uart_tx_test.h; see test_tools/saturation/. */
#if defined(__has_include)
#  if __has_include("uart_tx_test.h")
#    include "uart_tx_test.h"
#  endif
#endif

/* Longest reply is "ACK_RECEIVED 16384 DEADBEEF\r\n" = 29 characters; the longest
 * grouped reply is "\r\nSMID v2 READY\r\nIDLE\r\n" = 23. 40 leaves room for growth.
 * A reply longer than this is REJECTED (counted), never truncated. */
#define UART_TX_MSG_MAX_CHARS      40U

/* Replies buffered between producers and UARTTxTask. A normal transfer produces at
 * most 4 replies close together (ACK_RECEIVED, ACK_VALID, PLAYING + a pending DONE),
 * and a reply of ~25 characters needs ~2.2 ms on the wire, so 8 absorbs any burst the
 * protocol can generate while one reply is in flight. Cost: see uart_tx.c. */
#define UART_TX_QUEUE_DEPTH        8U

/* How long a producer may wait for a free slot before the reply is declared lost.
 * A healthy transmitter frees a slot every few ms, so 250 ms means UARTTxTask is
 * broken or starved, not busy. */
#define UART_TX_SUBMIT_TIMEOUT_MS  250U

/* UARTTxTask gives up on a message if the UART FIFO accepts no byte for this long
 * (it needs ~87 us per byte, so this is a stuck peripheral, not a slow one). */
#define UART_TX_STALL_LIMIT_MS     50U

/* Create Glo.Bios.UARTTxQueue. Call before any producer can run (Control_init does,
 * before creating the tasks). Returns false if the allocation fails. */
bool UartTx_createQueue(void);

/* UARTTxTask entry (create with xTaskCreate). */
void UartTx_task(void *arg);

/* Submit one complete reply. 'text' must already contain its own "\r\n"s.
 * Waits up to UART_TX_SUBMIT_TIMEOUT_MS for a free slot. Returns true only if the
 * reply was accepted; false means it was NOT queued (counted in Glo.Diagnostics). */
bool UartTx_send(const char *text);

/* "<name> <decimal length> <8 hex digits CRC>\r\n" */
bool UartTx_sendAck(const char *name, uint32_t length, uint32_t crc);

/* "<text>\r\n" for the ERR_* names. */
bool UartTx_sendLine(const char *text);

/* Like UartTx_send but never waits: a full queue returns false at once. Used where a
 * producer must not block (receiver recovery retries, and inside the completion
 * critical section). */
bool UartTx_trySend(const char *text);

/* Free slots right now. A producer that is the only one able to enqueue (or that
 * holds the completion critical section) may rely on this for a guaranteed trySend. */
uint32_t UartTx_spacesAvailable(void);

/* Wait (bounded by UART_TX_SUBMIT_TIMEOUT_MS) until at least one slot is free.
 * Counts a queue-full event, and a submit timeout if the wait expires. */
bool UartTx_waitForSpace(void);

#endif /* UART_TX_H */
