/*
 * control_task.c -- protocol lifecycle (validate -> start -> STOP -> DONE),
 * RTOS object/task creation and the low-rate monitor.
 *
 * TASKS (FreeRTOS priority; higher number = more urgent)
 *   UARTTxTask     4  uart_tx.c   : sole writer of the UART transmitter (drains UARTTxQueue)
 *   UART0ReadTask  3  uart_task.c : receive framing, timeouts, recovery, STOP
 *   PayloadTask    2  here        : CRC, MIDI parse, start playback, DONE/IDLE
 *   MonitorTask    1  here        : 250 ms LED toggle + diagnostics snapshot
 *
 * SYNCHRONISATION (each object has a real producer and consumer)
 *   UARTReadSem  binary  uart0RxIsr (per byte batch) / Uart_payload* -> UART0ReadTask
 *   PayloadSem   binary  UART0ReadTask (payload published) and
 *                        Timer3 ISR via Control_playbackFinishedIsr -> PayloadTask
 *   UARTTxQueue  queue   UART0ReadTask and PayloadTask (whole replies) -> UARTTxTask
 *
 * REPLY ORDER. A reply is "published" when UartTx_send*() accepts it. The queue keeps
 * published replies in order; the rules below make the PUBLICATION order correct:
 *   - ACK_RECEIVED, ACK_VALID, PLAYING, and the ERR_ after them are all produced by
 *     PayloadTask, in protocol order, and the receiver is released only after PLAYING
 *     is queued, so UART0ReadTask produces nothing for that transfer in between.
 *   - DONE[+IDLE]: the "is completion ready / is the receiver idle" decision and the
 *     enqueue happen in one critical section (see Control_reportCompletion), so a STOP
 *     can never be published between that decision and the DONE it invalidated.
 *
 * PayloadSem only says "check for work". A binary semaphore coalesces gives, so after
 * every wake PayloadTask examines BOTH sources -- Uart_acquirePayload() and
 * Playback_takeCompletion() -- whose own state holds the real information.
 *
 * STOP is handled in UART0ReadTask context through the hook below (hard silence,
 * THEN the ACK_STOPPED/IDLE reply is queued) at the instant the STOP frame is
 * accepted. Cancellation never waits for the queue or the wire. It cannot race a
 * validation: the receiver ignores the ring while PayloadTask owns a payload, and
 * the payload is returned only AFTER playback has been started and PLAYING sent.
 * A STOP that follows therefore always finds a started song to cancel, and
 * Playback_stop() discards the song's pending completion so no stale DONE follows.
 *
 * EVENT ARRAY: s_melody (1,024 events) is owned here. Midi_parse() writes it only
 * from PayloadTask while no song is playing (ERR_BUSY refuses a transfer during
 * playback, and only PayloadTask starts playback); playback borrows it read-only
 * from Playback_start() until completion or Playback_stop().
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

#include <ti/drivers/GPIO.h>

#include "ti_drivers_config.h"
#include "globals.h"
#include "audio.h"
#include "midi.h"
#include "playback.h"
#include "uart_task.h"
#include "uart_tx.h"
#include "control_task.h"

/* Task priorities (FreeRTOS, not NVIC) and stack depths in WORDS (4 bytes each).
 *
 * UARTTxTask is the HIGHEST priority on purpose, although it is the least important
 * work: it is the only thing that frees queue slots, so it must never be starved by a
 * producer (a producer that outranks the drain could wait out its submit timeout while
 * the drain never runs). It stays cheap: it writes at most the 16 FIFO bytes that fit,
 * then sleeps one tick (uart_tx.c), so it takes a few microseconds per millisecond and
 * does not delay STOP, CRC or the monitor. UART0ReadTask stays above PayloadTask so a
 * STOP is never queued behind CRC work. */
#define PRIORITY_UART_TX         4U
#define PRIORITY_UART0_READ      3U
#define PRIORITY_PAYLOAD         2U
#define PRIORITY_MONITOR         1U
#define STACK_WORDS_UART_TX      256U     /* 1024 bytes: 41 B item + FIFO loop + kernel calls */
#define STACK_WORDS_UART0_READ   512U     /* 2048 bytes */
#define STACK_WORDS_PAYLOAD      768U     /* 3072 bytes: CRC, parser frame, reply formatting */
#define STACK_WORDS_MONITOR      256U     /* 1024 bytes */
#define MONITOR_PERIOD_MS        250U

/* When a DONE could not be queued, PayloadTask retries at this interval. */
#define COMPLETION_RETRY_MS      20U

static MelodyEvent s_melody[MAX_PARSED_NOTES];

/* ---------------------------------------------------------------- hooks */

/* Header time (UART0ReadTask): a transfer during playback is refused with ERR_BUSY. */
static bool Control_isBusy(void)
{
    return Playback_isActive();
}

/* STOP frame (UART0ReadTask): hard silence now; the transport sends ACK_STOPPED/IDLE.
 * Playback_stop() masks interrupts for the short, bounded audio quiesce, clears
 * Timer2/Timer3 and discards any pending completion report. */
static void Control_stopPlayback(void)
{
    Playback_stop();
}

static const UartHooks s_uartHooks =
{
    Control_isBusy,
    Control_stopPlayback
};

/* Timer3 ISR (priority 2, legal for FromISR): the melody ended and audio is silent.
 * Only wake PayloadTask; the UART output happens in task context. */
static void Control_playbackFinishedIsr(void)
{
    BaseType_t woken = pdFALSE;

    xSemaphoreGiveFromISR(Glo.Bios.PayloadSem, &woken);
    portYIELD_FROM_ISR(woken);
}

/* ------------------------------------------------------------ PayloadTask */

/* CRC -> ACK_RECEIVED -> parse -> ACK_VALID -> start -> PLAYING, exactly the
 * baseline order; a CRC failure is reported before ACK_RECEIVED. The receiver is
 * released (Uart_payloadAccepted) only after PLAYING, so nothing can interleave. */
static void Control_processPayload(void)
{
    UartPayload payload;
    MidiParseResult parsed;
    uint32_t actualCrc;
    uint32_t count = 0U;

    if (!Uart_acquirePayload(&payload))
    {
        return;
    }

    actualCrc = Uart_crc32(payload.data, payload.length);
    Glo.Diagnostics.LastCalculatedCrc32 = actualCrc;
    if (actualCrc != payload.expectedCrc32)
    {
        Uart_payloadRejected("ERR_CRC");
        return;
    }

    /* A reply that cannot be queued (UARTTxTask broken for UART_TX_SUBMIT_TIMEOUT_MS)
     * means the host would wait for something it was never told: give up on the
     * transfer quietly (NULL = no ERR_ line) and let receiver recovery announce IDLE. */
    if (!UartTx_sendAck("ACK_RECEIVED", payload.length, actualCrc))
    {
        Uart_payloadRejected(NULL);
        return;
    }
    parsed = Midi_parse(payload.data, payload.length, s_melody,
                        MAX_PARSED_NOTES, &count);
    if (parsed != MIDI_PARSE_OK)
    {
        /* Parsing is reached only after accepting a header while idle. */
        Playback_stop();
        Uart_payloadRejected((parsed == MIDI_PARSE_NOTE_CAPACITY) ?
                             "ERR_NOTE_CAPACITY" : "ERR_MIDI");
        return;
    }

    /* ACK_VALID is queued BEFORE playback starts, as in the baseline. */
    if (!UartTx_send("ACK_VALID\r\n"))
    {
        Uart_payloadRejected(NULL);
        return;
    }
    Glo.Diagnostics.TransferSuccessCount++;
    if (!Playback_start(s_melody, count))
    {
        /* Unreachable after a successful parse (it guarantees count >= 1), but never
         * leave the host waiting for PLAYING/DONE. */
        Uart_payloadRejected("ERR_MIDI");
        return;
    }
    /* PLAYING is queued AFTER the song started, so it is never claimed early. While
     * the payload is out the receiver is in VALIDATE and UART0ReadTask produces
     * nothing, so this task is the only producer and the slot ACK_VALID just freed
     * (or its own wait) is not taken by anyone else. */
    if (!UartTx_send("PLAYING\r\n"))
    {
        Playback_stop();            /* the host was not told: do not play on unannounced */
        Uart_payloadRejected(NULL);
        return;
    }
    Uart_payloadAccepted();
}

/* DONE only after real silence; IDLE only if the receiver is between frames.
 *
 * The decision ("completion is ready", "receiver is idle") and the enqueue are ONE
 * critical section. UART0ReadTask outranks this task, so without it a STOP could be
 * accepted after the decision but before the enqueue and the host would see
 * ACK_STOPPED, IDLE, DONE, IDLE: a DONE for a song the host had already cancelled.
 * Inside the section nothing can be published or cancelled; the enqueue is
 * non-blocking and its slot was checked first, so it cannot fail. Playback_stop()
 * discards the completion, so after a STOP no DONE is ever produced.
 *
 * Returns false if completion is still pending because the queue stayed full for
 * UART_TX_SUBMIT_TIMEOUT_MS (counted); the caller retries, nothing was consumed. */
static bool Control_reportCompletion(void)
{
    for (;;)
    {
        bool published = false;

        taskENTER_CRITICAL();
        if (!Playback_completionReady())
        {
            taskEXIT_CRITICAL();
            return true;
        }
        if (UartTx_spacesAvailable() != 0U)
        {
            published = UartTx_trySend(Uart_receiverIdle() ? "DONE\r\nIDLE\r\n" : "DONE\r\n");
            if (published)
            {
                (void)Playback_takeCompletion();
            }
        }
        taskEXIT_CRITICAL();

        if (published)
        {
            return true;
        }
        if (!UartTx_waitForSpace())
        {
            return false;
        }
    }
}

static void Control_payloadTask(void *arg)
{
    bool completionPending = false;

    (void)arg;

    for (;;)
    {
        /* Normally block until there is work. If a DONE could not be queued, wake
         * regularly to retry it (it is not signalled again). */
        xSemaphoreTake(Glo.Bios.PayloadSem,
                       completionPending ? pdMS_TO_TICKS(COMPLETION_RETRY_MS) : portMAX_DELAY);
        Glo.Diagnostics.PayloadWakeCount++;

        /* The semaphore coalesces: examine every source before blocking again. */
        Control_processPayload();
        completionPending = !Control_reportCompletion();
    }
}

/* ------------------------------------------------------------ MonitorTask */

static void Control_monitorTask(void *arg)
{
    (void)arg;

    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(MONITOR_PERIOD_MS));

        GPIO_toggle(CONFIG_GPIO_LED_0);
        Glo.Diagnostics.MonitorTicks++;

        /* Stack margins are in words (4 bytes); heap in bytes. */
        Glo.Diagnostics.StackFreeMinUartWords =
            uxTaskGetStackHighWaterMark(Glo.Bios.UART0ReadTask);
        Glo.Diagnostics.StackFreeMinPayloadWords =
            uxTaskGetStackHighWaterMark(Glo.Bios.PayloadTask);
        Glo.Diagnostics.StackFreeMinTxWords =
            uxTaskGetStackHighWaterMark(Glo.Bios.UARTTxTask);
        Glo.Diagnostics.TxQueueDepthNow =
            (uint32_t)uxQueueMessagesWaiting(Glo.Bios.UARTTxQueue);
        Glo.Diagnostics.StackFreeMinMonitorWords =
            uxTaskGetStackHighWaterMark(NULL);
        Glo.Diagnostics.StackFreeMinIdleWords =
            uxTaskGetStackHighWaterMark(xTaskGetIdleTaskHandle());
        Glo.Diagnostics.HeapFreeBytes = (uint32_t)xPortGetFreeHeapSize();
        Glo.Diagnostics.HeapMinFreeBytes = (uint32_t)xPortGetMinimumEverFreeHeapSize();
    }
}

/* ------------------------------------------------------------------ setup */

bool Control_init(void)
{
    bool created = true;

    Glo.Bios.UARTReadSem = xSemaphoreCreateBinary();
    Glo.Bios.PayloadSem = xSemaphoreCreateBinary();
    /* The reply queue exists before any task (producer or drain) is created. */
    if ((Glo.Bios.UARTReadSem == NULL) || (Glo.Bios.PayloadSem == NULL) ||
        !UartTx_createQueue())
    {
        Glo.Diagnostics.CreateFailCount++;
        return false;
    }

    Playback_init(Control_playbackFinishedIsr);
    Uart_init(&s_uartHooks);

    /* xTaskCreate() returns pdPASS (1) or errCOULD_NOT_ALLOCATE_REQUIRED_MEMORY (-1).
     * Nothing runs until vTaskStartScheduler(), so creation order is not run order. */
    created = created && (xTaskCreate(UartTx_task, "UART0Tx", STACK_WORDS_UART_TX, NULL,
                                      PRIORITY_UART_TX, &Glo.Bios.UARTTxTask) == pdPASS);
    created = created && (xTaskCreate(Uart_readTask, "UART0Rx", STACK_WORDS_UART0_READ, NULL,
                                      PRIORITY_UART0_READ, &Glo.Bios.UART0ReadTask) == pdPASS);
    created = created && (xTaskCreate(Control_payloadTask, "Payload", STACK_WORDS_PAYLOAD, NULL,
                                      PRIORITY_PAYLOAD, &Glo.Bios.PayloadTask) == pdPASS);
    created = created && (xTaskCreate(Control_monitorTask, "Monitor", STACK_WORDS_MONITOR, NULL,
                                      PRIORITY_MONITOR, &Glo.Bios.MonitorTask) == pdPASS);
    if (!created)
    {
        Glo.Diagnostics.CreateFailCount++;
        return false;
    }

    return true;
}
