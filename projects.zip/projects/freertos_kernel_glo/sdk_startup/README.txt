Linked SDK startup file (kernel/freertos/startup/startup_msp432e4_gcc.c) appears here in CCS.
