Linked SDK files (kernel/freertos/dpl/*.c) appear here in CCS; nothing is stored in this folder.
