# freertos_kernel_glo

FreeRTOS **V10.2.1** kernel library for the MSP432E401Y (Cortex-M4F, GCC port, `heap_4`),
built as a static library (`Debug/libfreertos_kernel_glo.a`) and referenced by
`gpiointerrupt_freertos`.

* `FreeRTOS/Source/` - unmodified kernel sources copied from the FreeRTOS-Kernel V10.2.1 tag
  (`tasks.c queue.c list.c timers.c event_groups.c stream_buffer.c`, `include/`,
  `portable/GCC/ARM_CM4F/`, `portable/MemMang/heap_4.c`). Hashes: `../../dependencies/DEPENDENCIES.md`.
* `FreeRTOSConfig.h` - the SDK 4.20.00.12 configuration with four marked project deltas.
* `dpl/*.c` and `sdk_startup/startup_msp432e4_gcc.c` - linked (not copied) from
  `${COM_TI_SIMPLELINK_MSP432E4_SDK_INSTALL_DIR}/kernel/freertos/`: the SDK's driver porting layer,
  Power policy hook and the vector table that already routes SVC/PendSV/SysTick to the kernel.
* The TI POSIX layer is not built: the application uses native FreeRTOS tasks and semaphores.
