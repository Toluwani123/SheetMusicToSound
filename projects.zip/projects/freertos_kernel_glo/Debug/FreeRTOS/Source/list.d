# FIXED

FreeRTOS/Source/list.o: ../FreeRTOS/Source/list.c \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/FreeRTOS.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOSConfig.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/projdefs.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/portable.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/deprecated_definitions.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/mpu_wrappers.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/list.h

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/FreeRTOS.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOSConfig.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/projdefs.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/portable.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/deprecated_definitions.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/mpu_wrappers.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/list.h:
