################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/startup/startup_msp432e4_gcc.c 

C_DEPS += \
./sdk_startup/startup_msp432e4_gcc.d 

OBJS += \
./sdk_startup/startup_msp432e4_gcc.o 

OBJS__QUOTED += \
"sdk_startup\startup_msp432e4_gcc.o" 

C_DEPS__QUOTED += \
"sdk_startup\startup_msp432e4_gcc.d" 

C_SRCS__QUOTED += \
"C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/startup/startup_msp432e4_gcc.c" 


