################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/ClockP_freertos.c \
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/DebugP_freertos.c \
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/HwiPMSP432E4_freertos.c \
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/MutexP_freertos.c \
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/PowerMSP432E4_freertos.c \
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/SemaphoreP_freertos.c \
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/SystemP_freertos.c 

C_DEPS += \
./dpl/ClockP_freertos.d \
./dpl/DebugP_freertos.d \
./dpl/HwiPMSP432E4_freertos.d \
./dpl/MutexP_freertos.d \
./dpl/PowerMSP432E4_freertos.d \
./dpl/SemaphoreP_freertos.d \
./dpl/SystemP_freertos.d 

OBJS += \
./dpl/ClockP_freertos.o \
./dpl/DebugP_freertos.o \
./dpl/HwiPMSP432E4_freertos.o \
./dpl/MutexP_freertos.o \
./dpl/PowerMSP432E4_freertos.o \
./dpl/SemaphoreP_freertos.o \
./dpl/SystemP_freertos.o 

OBJS__QUOTED += \
"dpl\ClockP_freertos.o" \
"dpl\DebugP_freertos.o" \
"dpl\HwiPMSP432E4_freertos.o" \
"dpl\MutexP_freertos.o" \
"dpl\PowerMSP432E4_freertos.o" \
"dpl\SemaphoreP_freertos.o" \
"dpl\SystemP_freertos.o" 

C_DEPS__QUOTED += \
"dpl\ClockP_freertos.d" \
"dpl\DebugP_freertos.d" \
"dpl\HwiPMSP432E4_freertos.d" \
"dpl\MutexP_freertos.d" \
"dpl\PowerMSP432E4_freertos.d" \
"dpl\SemaphoreP_freertos.d" \
"dpl\SystemP_freertos.d" 

C_SRCS__QUOTED += \
"C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/ClockP_freertos.c" \
"C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/DebugP_freertos.c" \
"C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/HwiPMSP432E4_freertos.c" \
"C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/MutexP_freertos.c" \
"C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/PowerMSP432E4_freertos.c" \
"C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/SemaphoreP_freertos.c" \
"C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/SystemP_freertos.c" 


