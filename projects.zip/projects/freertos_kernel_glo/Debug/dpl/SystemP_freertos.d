# FIXED

dpl/SystemP_freertos.o: \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/SystemP_freertos.c \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/dpl/SystemP.h

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/dpl/SystemP.h:
