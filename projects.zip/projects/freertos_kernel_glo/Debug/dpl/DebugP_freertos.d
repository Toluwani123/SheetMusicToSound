# FIXED

dpl/DebugP_freertos.o: \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/DebugP_freertos.c
