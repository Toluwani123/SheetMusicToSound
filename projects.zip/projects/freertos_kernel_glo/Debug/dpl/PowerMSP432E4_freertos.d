# FIXED

dpl/PowerMSP432E4_freertos.o: \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/PowerMSP432E4_freertos.c \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/Power.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/utils/List.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/FreeRTOS.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOSConfig.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/projdefs.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/portable.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/deprecated_definitions.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/mpu_wrappers.h

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/Power.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/utils/List.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/FreeRTOS.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOSConfig.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/projdefs.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/portable.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/deprecated_definitions.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/mpu_wrappers.h:
