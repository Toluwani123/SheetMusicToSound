# FIXED

dpl/ClockP_freertos.o: \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/kernel/freertos/dpl/ClockP_freertos.c \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/FreeRTOS.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOSConfig.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/projdefs.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/portable.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/deprecated_definitions.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/mpu_wrappers.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/timers.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/task.h \
 C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/list.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/dpl/ClockP.h \
 C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/dpl/HwiP.h

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/FreeRTOS.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOSConfig.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/projdefs.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/portable.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/deprecated_definitions.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/mpu_wrappers.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/timers.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/task.h:

C:/Users/iembi/workspace_ccstheia/uart_tx_queue_milestone/projects/freertos_kernel_glo/FreeRTOS/Source/include/list.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/dpl/ClockP.h:

C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/dpl/HwiP.h:
