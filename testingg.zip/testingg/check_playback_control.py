"""Deliverable 4 board checks. Run: python -u check_playback_control.py

Uses COM5 by default and the adjacent newmiditst.py/midi_tests folder.
This checks UART results; you must also listen for the stated sound/silence.
"""
import argparse
from pathlib import Path
import struct
import sys

import newmiditst as sender


def expect(reader, expected, timeout=5.0):
    line = reader.read_line(sender.time.monotonic() + timeout)
    print("MSP:", line, flush=True)
    if line != expected:
        raise sender.TransferError(f"Expected {expected!r}, received {line!r}")
    return line


def quiet(reader, seconds):
    """No delayed DONE or other response is allowed after a confirmed STOP."""
    try:
        line = reader.read_line(sender.time.monotonic() + seconds)
    except sender.ResponseTimeout:
        if reader.pending:
            raise sender.TransferError("Partial unexpected response during quiet check")
        return
    raise sender.TransferError("Unexpected response after STOP: " + line)


def start(port, data, legacy=False):
    reader = sender.LineReader(port)
    header, crc = sender.make_header(data)
    if legacy:
        header = struct.pack("<4sB3xII", b"SMID", 1, len(data), crc)
    sender.write_all(port, header)
    ack = sender.wait_response(reader, "ACK_READY")
    sender.verify_transfer_ack(ack, "ACK_READY", len(data), crc)
    sender.write_all(port, data)
    ack = sender.wait_response(reader, "ACK_RECEIVED")
    sender.verify_transfer_ack(ack, "ACK_RECEIVED", len(data), crc)
    expect(reader, "ACK_VALID")
    expect(reader, "PLAYING")
    return reader


def finish(reader):
    expect(reader, "DONE", timeout=20.0)
    expect(reader, "IDLE")


def run_checks(port, files):
    print("\nCHECK 1: STOP while idle, twice. Output should remain silent.", flush=True)
    sender.stop_playback(port)
    sender.stop_playback(port)
    print("PASS 1: idle STOP is repeatable.", flush=True)

    print("\nCHECK 2: reject another file during a sustained note.", flush=True)
    reader = start(port, files['d4_sustained.mid'])
    # Deliberately send only a header; ERR_BUSY means payload must not follow.
    sender.write_all(port, sender.make_header(files['musical_features.mid'])[0])
    expect(reader, "ERR_BUSY")
    expect(reader, "IDLE", sender.RECOVERY_TIMEOUT)
    print("LISTEN: the original low note should continue for the next 2 seconds.", flush=True)
    quiet(reader, 2.0)
    sender.stop_playback(port, reader)
    quiet(reader, 1.0)
    print("PASS 2: busy rejection followed by acknowledged STOP; verify original audio stayed unchanged.", flush=True)

    print("\nCHECK 3: STOP during a rest. Hear one short low note, then silence.", flush=True)
    reader = start(port, files['d4_rest.mid'])
    quiet(reader, 1.5)
    sender.stop_playback(port, reader)
    print("LISTEN: remain silent for 4 seconds; the later high note must never play.", flush=True)
    quiet(reader, 4.0)
    print("PASS 3: STOP during rest; no delayed DONE. Confirm no later high note.", flush=True)

    print("\nCHECK 4: malformed STOP must not cancel an active song.", flush=True)
    reader = start(port, files['d4_sustained.mid'])
    malformed = struct.pack("<4sBB2xII", b"SMID", 2, 1, 1, 0)
    sender.write_all(port, malformed)
    expect(reader, "ERR_HEADER")
    expect(reader, "IDLE", sender.RECOVERY_TIMEOUT)
    print("LISTEN: original note continues for 1 second after the rejected command.", flush=True)
    quiet(reader, 1.0)
    sender.stop_playback(port, reader)
    print("PASS 4: invalid STOP rejected; valid STOP still works.", flush=True)

    print("\nCHECK 5: full STOP header embedded inside MIDI metadata is ordinary payload.", flush=True)
    finish(start(port, files['d4_embedded_stop.mid']))
    print("PASS 5: three ascending notes reached natural DONE.", flush=True)

    print("\nCHECK 6: legacy SMID v1 MIDI transfer remains supported.", flush=True)
    finish(start(port, files['musical_features.mid'], legacy=True))
    print("PASS 6: v1 MIDI reached natural DONE.", flush=True)

    print("\nCHECK 7: three play/STOP cycles on the same connection, with no board reset.", flush=True)
    for cycle in range(1, 4):
        reader = start(port, files['d4_sustained.mid'])
        quiet(reader, 0.5)
        sender.stop_playback(port, reader)
        quiet(reader, 0.3)
        print(f"Cycle {cycle}/3 passed.", flush=True)
    print("PASS 7: repeated play/STOP cycles succeeded.", flush=True)

    print("\nCHECK 8: a fresh complete song after all STOP/error checks.", flush=True)
    finish(start(port, files['musical_features.mid']))
    print("PASS 8: new playback completed without a board reset.", flush=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", default="COM5")
    args = parser.parse_args(argv)
    if sender.serial is None:
        print("Install pySerial: python -m pip install pyserial", file=sys.stderr)
        return 2
    try:
        if sender.PROTOCOL_VERSION != 2 or not hasattr(sender, 'stop_playback'):
            raise ValueError("Replace newmiditst.py with the Deliverable 4 version first.")
        root = Path(__file__).resolve().parent / 'midi_tests'
        names = ('d4_sustained.mid', 'd4_rest.mid', 'd4_embedded_stop.mid', 'musical_features.mid')
        files = {name: (root/name).read_bytes() for name in names}
        print("Deliverable 4 checks on", args.port, "at 115200 baud.")
        print("Keep the board running. Close other serial monitors. Listen throughout.")
        print("Expected ERR_BUSY and ERR_HEADER messages below are intentional test results.")
        with sender.serial.Serial(args.port, sender.BAUD,
                                  bytesize=sender.serial.EIGHTBITS, parity=sender.serial.PARITY_NONE,
                                  stopbits=sender.serial.STOPBITS_ONE, timeout=0.05,
                                  write_timeout=sender.WRITE_TIMEOUT,
                                  xonxoff=False, rtscts=False, dsrdtr=False) as port:
            sender.synchronize(port)
            run_checks(port, files)
        print("\nPASS: all 8 Deliverable 4 protocol checks completed without resetting.")
        print("Record listening observations separately; UART responses cannot measure audio silence.")
        return 0
    except (OSError, ValueError, sender.TransferError, sender.serial.SerialException) as exc:
        print("FAIL:", exc, file=sys.stderr)
        print("No automatic retry. After receiver recovery, use python newmiditst.py --stop if needed.",
              file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nTest stopped on PC; to stop the song, run python newmiditst.py --stop.", file=sys.stderr)
        return 130


if __name__ == '__main__':
    sys.exit(main())
