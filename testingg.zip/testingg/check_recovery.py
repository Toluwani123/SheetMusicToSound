"""Run three intentional SMID transfer failures, each followed by good playback.

Run only after loading the Deliverable 3 firmware and finishing any playback:
    python check_recovery.py
Uses the updated newmiditst.py alongside this file. Defaults to COM5.
"""

import argparse
from pathlib import Path
import struct
import sys

import newmiditst as sender


def expect(reader, expected, timeout=5.0):
    deadline = sender.time.monotonic() + timeout
    line = reader.read_line(deadline)
    print("MSP:", line)
    if line.split()[0] != expected:
        raise sender.TransferError(f"Expected {expected}, received {line!r}.")
    return line


def begin_payload(port, reader, payload):
    header, crc = sender.make_header(payload)
    sender.write_all(port, header)
    ready = expect(reader, "ACK_READY")
    sender.verify_transfer_ack(ready, "ACK_READY", len(payload), crc)


def run_checks(port, large, good):
    if len(large) != 16384:
        raise ValueError("Expected the supplied 16,384-byte boundary MIDI.")
    if not 1 <= len(good) <= 1024:
        raise ValueError("Recovery playback must use the supplied small MIDI.")

    cases = (
        ("oversized header (16,385 bytes)", "ERR_SIZE"),
        ("corrupted 16 KiB payload with original CRC", "ERR_CRC"),
        ("truncated 16 KiB transfer", "ERR_TIMEOUT"),
    )
    for index, (name, error) in enumerate(cases):
        print(f"\nCHECK {index + 1}: {name}", flush=True)
        reader = sender.LineReader(port)
        if index == 0:
            # Intentionally bypass the ordinary sender's local size guard.
            header = struct.pack("<4sB3xII", b"SMID", sender.PROTOCOL_VERSION, 16385, 0)
            sender.write_all(port, header)
        else:
            begin_payload(port, reader, large)
            if index == 1:
                damaged = bytearray(large)
                damaged[len(damaged) // 2] ^= 1
                # The advertised CRC remains that of the unmodified file.
                sender.write_all(port, damaged)
            else:
                sender.write_all(port, large[:len(large) // 2])
                print("Sent only half; waiting for the board's inactivity timeout.")
        expect(reader, error)
        expect(reader, "IDLE", timeout=sender.RECOVERY_TIMEOUT)
        print("Expected rejection received. Checking good playback without a reset.")
        if not sender.transfer(port, good, wait_playback=True, playback_timeout=30.0):
            raise sender.TransferError("Good transfer after rejection failed.")
        # transfer() stops after DONE; consume IDLE before the next case.
        expect(sender.LineReader(port), "IDLE")
        print(f"PASS: {name}; good file reached DONE without resetting.", flush=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", default="COM5")
    args = parser.parse_args(argv)
    if sender.serial is None:
        print("Install pySerial: python -m pip install pyserial", file=sys.stderr)
        return 2
    root = Path(__file__).resolve().parent / "midi_tests"
    try:
        large = (root / "bytes_16384.mid").read_bytes()
        good = (root / "musical_features.mid").read_bytes()
        if sender.MAX_MIDI_FILE_SIZE != 16384:
            raise ValueError("Use the Deliverable 3 newmiditst.py from this package.")
        print("Intentional error checks: rejected payloads must not play.")
        print("A short musical_features.mid playback follows each rejection.")
        print("Keep CCS running; do not reset or pause the board during these checks.")
        with sender.serial.Serial(
            args.port, sender.BAUD,
            bytesize=sender.serial.EIGHTBITS, parity=sender.serial.PARITY_NONE,
            stopbits=sender.serial.STOPBITS_ONE,
            timeout=0.05, write_timeout=sender.WRITE_TIMEOUT,
            xonxoff=False, rtscts=False, dsrdtr=False,
        ) as port:
            sender.synchronize(port)
            run_checks(port, large, good)
        print("\nPASS: all three board error/recovery checks completed.")
        print("Record separately whether the expected good-file audio was heard.")
        return 0
    except (OSError, ValueError, sender.TransferError, sender.serial.SerialException) as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        print("No automatic retry. Wait for playback/recovery to finish before retrying.", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nCancelled. A partial payload will time out on the board.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
