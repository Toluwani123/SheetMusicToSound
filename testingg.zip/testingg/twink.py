from pathlib import Path


PPQN = 480

TEMPO_US_PER_QUARTER = 500_000   # 120 BPM


def vlq(value):
    """
    Encode an integer as a MIDI variable-length quantity.
    """

    output = [value & 0x7F]

    value >>= 7

    while value:
        output.append(
            (value & 0x7F) | 0x80
        )

        value >>= 7

    output.reverse()

    return bytes(output)


track = bytearray()


# --------------------------------------------------
# Tempo:
#
# delta = 0
# FF 51 03
# tempo = 500000 us/quarter
# --------------------------------------------------

track += vlq(0)

track += bytes([
    0xFF,
    0x51,
    0x03
])

track += TEMPO_US_PER_QUARTER.to_bytes(
    3,
    byteorder="big"
)


# --------------------------------------------------
# First phrase:
#
# Twinkle twinkle little star
#
# C4 C4 G4 G4 A4 A4 G4
#
# MIDI:
#
# 60 60 67 67 69 69 67
# --------------------------------------------------

notes = [
    # Twinkle, twinkle, little star
    60, 60, 67, 67, 69, 69, 67,

    # How I wonder what you are
    65, 65, 64, 64, 62, 62, 60,

    # Up above the world so high
    67, 67, 65, 65, 64, 64, 62,

    # Like a diamond in the sky
    67, 67, 65, 65, 64, 64, 62,

    # Twinkle, twinkle, little star
    60, 60, 67, 67, 69, 69, 67,

    # How I wonder what you are
    65, 65, 64, 64, 62, 62, 60
]


for i, note in enumerate(notes):

   
        # First note starts immediately.
    #
    # Every later note gets a 48-tick rest
    # after the previous note.

    # First note starts immediately.
    if i == 0:
        delta_before_note = 0

    # After every 7-note phrase, give a longer break.
    elif i % 7 == 0:
        delta_before_note = 480      # 500 ms line break

    # Normal small separation between repeated notes.
    else:
        delta_before_note = 48       # 50 ms normal gap


    # Note On
    track += vlq(delta_before_note)

    track += bytes([
        0x90,
        note,
        100
    ])


    # The final G is a half note.
    if i == len(notes) - 1:
        note_duration = 960
    else:
        # 432 ticks of sound
        # + 48 ticks of rest
        # = 480 ticks total
        # = one quarter note
        note_duration = 432


    # Note Off
    track += vlq(note_duration)

    track += bytes([
        0x80,
        note,
        64
    ])


# --------------------------------------------------
# End Of Track
# --------------------------------------------------

track += vlq(0)

track += bytes([
    0xFF,
    0x2F,
    0x00
])


# --------------------------------------------------
# MIDI header
# --------------------------------------------------

header = bytearray()

header += b"MThd"

header += (6).to_bytes(
    4,
    byteorder="big"
)

# Format 0
header += (0).to_bytes(
    2,
    byteorder="big"
)

# One track
header += (1).to_bytes(
    2,
    byteorder="big"
)

# 480 ticks / quarter note
header += PPQN.to_bytes(
    2,
    byteorder="big"
)


# --------------------------------------------------
# Track chunk
# --------------------------------------------------

track_chunk = bytearray()

track_chunk += b"MTrk"

track_chunk += len(track).to_bytes(
    4,
    byteorder="big"
)

track_chunk += track


# Complete Standard MIDI File
midi_file = header + track_chunk


output_path = (
    Path(__file__).resolve().parent
    /
    "twinkle_simple.mid"
)


with open(output_path, "wb") as f:
    f.write(midi_file)


print("Created:")
print(output_path)

print(
    "File size:",
    len(midi_file),
    "bytes"
)