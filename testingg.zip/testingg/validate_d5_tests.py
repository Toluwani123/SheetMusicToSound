"""Offline D5 fixture validation: raw SMF scan plus independent Mido reading.

Run: python validate_d5_tests.py
Optional dependency for this offline tool only: python -m pip install mido
Board tests do not need Mido. No serial port is opened here.
"""
import argparse
from fractions import Fraction
import hashlib
import io
import json
from pathlib import Path
import struct
import sys


class MidiValidationError(ValueError):
    pass


def scan(data):
    """Strict project-subset validator; does not use the generator's encoder."""
    if len(data)<22 or data[:4]!=b'MThd' or data[14:18]!=b'MTrk':
        raise MidiValidationError('Missing SMF header/track')
    header_size,fmt,tracks,ppqn=struct.unpack('>IHHH',data[4:14])
    if header_size!=6 or fmt!=0 or tracks!=1 or not 0<ppqn<32768:
        raise MidiValidationError('Requires standard Type 0 / one track / PPQN')
    if int.from_bytes(data[18:22],'big')!=len(data)-22:
        raise MidiValidationError('Track size must match complete file')
    pos=22;running=None;tempo=500000;now=Fraction(0);active=None;notes=[]
    counts={'running_status':0,'skipped_channel':0,'skipped_meta':0}
    fixed={0:2,0x20:1,0x21:1,0x2f:0,0x51:3,0x54:5,0x58:4,0x59:2}

    def take(n):
        nonlocal pos
        if n>len(data)-pos:raise MidiValidationError('Truncated event')
        value=data[pos:pos+n];pos+=n;return value
    def vlq():
        n=0
        for _ in range(4):
            byte=take(1)[0];n=n*128+(byte&127)
            if byte<128:return n
        raise MidiValidationError('VLQ exceeds four bytes')

    while pos<len(data):
        delta=vlq();now+=Fraction(delta*tempo,ppqn)
        if pos==len(data):raise MidiValidationError('Missing status/data')
        if data[pos]<128:
            if running is None:raise MidiValidationError('Running status without a channel status')
            status=running;counts['running_status']+=1
        else:
            status=take(1)[0];running=status if 0x80<=status<=0xef else None
        if status==0xff:
            kind=take(1)[0];length=vlq();body=take(length)
            if kind>=128 or (kind in fixed and length!=fixed[kind]):
                raise MidiValidationError('Invalid meta type/length')
            if kind==0x51:
                tempo=int.from_bytes(body,'big')
                if not tempo:raise MidiValidationError('Zero tempo')
            elif kind==0x2f:
                if active is not None or not notes or pos!=len(data):
                    raise MidiValidationError('Invalid end of track/note state')
                return {'notes':notes,'duration_us':float(now),**counts}
            else:
                if kind==0x20 and body[0]>15:raise MidiValidationError('Invalid channel prefix')
                if kind==0x21 and body[0]>127:raise MidiValidationError('Invalid MIDI port')
                counts['skipped_meta']+=1
            continue
        if not 0x80<=status<=0xef or status&15:
            raise MidiValidationError('Unsupported system event or nonzero channel')
        kind=status>>4
        body=take(1 if kind in (12,13) else 2)
        if any(b>=128 for b in body):raise MidiValidationError('Channel data byte has high bit set')
        if kind not in (8,9):counts['skipped_channel']+=1;continue
        note,velocity=body
        if kind==9 and velocity:
            if active is not None:raise MidiValidationError('Overlapping notes')
            if not 48<=note<=84:raise MidiValidationError('Unsupported pitch')
            active=(note,now)
        else:
            if active is None or active[0]!=note:raise MidiValidationError('Unmatched note ending')
            if len(notes)>=1024:raise MidiValidationError('Note capacity')
            start=active[1]
            if (now-start)>4294967295499:raise MidiValidationError('Note duration exceeds ms storage')
            if notes and start-Fraction(str(notes[-1]['off_us']))>4294967295499:
                raise MidiValidationError('Rest exceeds ms storage')
            notes.append({'note':note,'on_us':float(start),'off_us':float(now)})
            active=None
    raise MidiValidationError('Missing End Of Track')


def mido_notes(data):
    import mido
    midi=mido.MidiFile(file=io.BytesIO(data),clip=False)
    if midi.type!=0 or len(midi.tracks)!=1:raise MidiValidationError('Mido: unexpected layout')
    now=0.0;active=None;notes=[]
    for msg in midi:
        now+=msg.time*1_000_000
        if msg.type=='note_on' and msg.velocity:
            if active is not None:raise MidiValidationError('Mido: overlapping notes')
            active=(msg.note,now)
        elif msg.type=='note_off' or (msg.type=='note_on' and msg.velocity==0):
            if active is None or msg.note!=active[0]:raise MidiValidationError('Mido: unmatched ending')
            notes.append({'note':msg.note,'on_us':active[1],'off_us':now});active=None
    return notes,now


def check_notes(actual,expected,label):
    if len(actual)!=len(expected):raise MidiValidationError(label+': note-count mismatch')
    for a,e in zip(actual,expected):
        if a['note']!=e['note'] or abs(a['on_us']-e['on_us'])>0.01 or abs(a['off_us']-e['off_us'])>0.01:
            raise MidiValidationError(label+': note timeline mismatch')


def validate_directory(root):
    manifest=json.loads((root/'manifest.json').read_text())
    valid=invalid=0
    for case in manifest['cases']:
        data=(root/case['file']).read_bytes()
        if hashlib.sha256(data).hexdigest()!=case['sha256']:
            raise MidiValidationError(case['file']+': changed since generation')
        if case['expected']=='ERR_MIDI':
            try:scan(data)
            except MidiValidationError:invalid+=1
            else:raise MidiValidationError(case['file']+': negative fixture was accepted')
        else:
            info=scan(data);notes,duration=mido_notes(data)
            check_notes(info['notes'],case['notes'],case['file']+' raw scanner')
            check_notes(notes,case['notes'],case['file']+' Mido')
            if abs(duration-case['duration_seconds']*1e6)>0.01:
                raise MidiValidationError(case['file']+': Mido duration mismatch')
            for key in ('running_status','skipped_channel','skipped_meta'):
                if info[key]<case.get('minimum_'+key,0):
                    raise MidiValidationError(case['file']+': intended feature missing: '+key)
            valid+=1
        print('OK:',case['file'],case['expected'])
    print(f'PASS: {valid} valid fixtures checked with raw scanner + Mido; {invalid} negative fixtures rejected by the strict subset scanner.')
    print('Software validation only. Use check_midi_compatibility.py for board results.')
    return manifest


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory',type=Path,default=Path(__file__).resolve().parent/'midi_tests_d5')
    args=parser.parse_args()
    try:validate_directory(args.directory)
    except ImportError:
        print('Install Mido for offline validation: python -m pip install mido',file=sys.stderr);return 2
    except (OSError,ValueError,EOFError) as exc:
        print('FAIL:',exc,file=sys.stderr);return 1
    return 0

if __name__=='__main__':sys.exit(main())
