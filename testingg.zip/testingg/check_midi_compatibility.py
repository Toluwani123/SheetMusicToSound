"""Deliverable 5 board tests, using ready-made MIDI files beside this script.

python -u check_midi_compatibility.py              # quick compatibility/error/STOP suite
python -u check_midi_compatibility.py --suite long # Mido-written Twinkle + Ode to Joy
COM5 is the default. Requires existing pySerial; does not require Mido.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import newmiditst as sender


def expect(reader,expected,timeout=5.0):
    line=reader.read_line(sender.time.monotonic()+timeout)
    print('MSP:',line,flush=True)
    if line!=expected:raise sender.TransferError(f'Expected {expected!r}; received {line!r}')
    return line


def quiet(reader,seconds):
    try:line=reader.read_line(sender.time.monotonic()+seconds)
    except sender.ResponseTimeout:
        if reader.pending:raise sender.TransferError('Unexpected partial response during quiet check')
        return
    raise sender.TransferError('Unexpected response during quiet check: '+line)


def send_payload(port,data):
    reader=sender.LineReader(port)
    header,crc=sender.make_header(data)
    print(f'Payload: {len(data)} bytes; CRC32 {crc:08X}',flush=True)
    sender.write_all(port,header)
    line=reader.read_line(sender.time.monotonic()+sender.ACK_TIMEOUT)
    print('MSP:',line,flush=True)
    sender.verify_transfer_ack(line,'ACK_READY',len(data),crc)
    sender.write_all(port,data)
    line=reader.read_line(sender.time.monotonic()+sender.ACK_TIMEOUT)
    print('MSP:',line,flush=True)
    sender.verify_transfer_ack(line,'ACK_RECEIVED',len(data),crc)
    return reader


def start(port,data):
    reader=send_payload(port,data)
    expect(reader,'ACK_VALID')
    started=sender.time.monotonic()
    expect(reader,'PLAYING')
    return reader,started


def play_complete(port,data,seconds):
    reader,started=start(port,data)
    expect(reader,'DONE',timeout=max(10.0,seconds+5.0))
    elapsed=sender.time.monotonic()-started
    expect(reader,'IDLE')
    tolerance=max(0.25,seconds*0.02)
    print(f'Duration: host ACK_VALID-to-DONE {elapsed:.3f} s; MIDI reference {seconds:.3f} s; allowance {tolerance:.3f} s.')
    if abs(elapsed-seconds)>tolerance:
        raise sender.TransferError('Playback duration outside coarse host allowance; inspect timing/audio')
    return elapsed


def load_cases(root):
    manifest=json.loads((root/'manifest.json').read_text())
    if manifest.get('deliverable')!=5:raise ValueError('Expected D5 manifest')
    cases=manifest['cases'];files={}
    for case in cases:
        name=case['file']
        if Path(name).name!=name:raise ValueError('Fixture name must be a plain filename')
        data=(root/name).read_bytes()
        if hashlib.sha256(data).hexdigest()!=case['sha256']:
            raise ValueError(name+': contents do not match supplied manifest')
        if not 1<=len(data)<=sender.MAX_MIDI_FILE_SIZE:raise ValueError(name+': size outside sender limit')
        files[name]=data
    return cases,files


def run_checks(port,cases,files,suite='quick'):
    completed=0
    if suite in ('quick','all'):
        print('\nVALID FILES: first seven are the same four-note melody; last two are the same one-second C4.',flush=True)
        print('Listen for matching pitches, note lengths and rests. Program/controller effects are intentionally ignored.')
        for case in cases:
            if case['group']!='quick':continue
            name=case['file'];print('\nCHECK valid:',name,'--',case['description'],flush=True)
            play_complete(port,files[name],case['duration_seconds'])
            completed+=1;print('PASS:',name,flush=True)

        print('\nNEGATIVE FILES: each uses its own CORRECT transport CRC. ERR_MIDI is expected.',flush=True)
        print('Rejected data must be silent. A short C5 recovery beep follows each expected rejection.')
        for case in cases:
            if case['group']!='negative':continue
            name=case['file'];print('\nCHECK reject:',name,'--',case['description'],flush=True)
            reader=send_payload(port,files[name])
            expect(reader,'ERR_MIDI')
            expect(reader,'IDLE',sender.RECOVERY_TIMEOUT)
            quiet(reader,0.15)
            print('Rejection confirmed. Sending recovery beep now.',flush=True)
            play_complete(port,files['d5_recovery.mid'],0.25)
            completed+=1;print('PASS:',name,'rejected; recovery playback completed without reset.',flush=True)

        print('\nCHECK protection: running-status file, busy rejection, then STOP on this connection.',flush=True)
        reader,_=start(port,files['d5_running.mid'])
        sender.write_all(port,sender.make_header(files['d5_reference.mid'])[0])
        expect(reader,'ERR_BUSY');expect(reader,'IDLE',sender.RECOVERY_TIMEOUT)
        sender.stop_playback(port,reader)
        print('LISTEN: 3.5 seconds of silence; no later note may restart.',flush=True)
        quiet(reader,3.5)
        play_complete(port,files['d5_recovery.mid'],0.25)
        completed+=1;print('PASS: busy/STOP/replay with running-status input.',flush=True)

    if suite in ('long','all'):
        print('\nINDEPENDENT ENCODINGS: existing melodies written by Mido; these are not Chioma OMR exports.',flush=True)
        for case in cases:
            if case['group']!='long':continue
            name=case['file'];print('\nCHECK full melody:',name,flush=True)
            play_complete(port,files[name],case['duration_seconds'])
            completed+=1;print('PASS:',name,flush=True)
    print(f'\nPASS: Deliverable 5 {suite} suite completed: {completed} cases without a board reset.',flush=True)
    print('Record listening results separately. UART checks and coarse durations cannot prove individual note timing or audio quality.')
    return completed


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',default='COM5')
    parser.add_argument('--suite',choices=('quick','long','all'),default='quick')
    args=parser.parse_args(argv)
    if sender.serial is None:
        print('Install pySerial: python -m pip install pyserial',file=sys.stderr);return 2
    try:
        if sender.PROTOCOL_VERSION!=2 or sender.MAX_MIDI_FILE_SIZE!=16384:
            raise ValueError('Use the packaged SMID v2 sender')
        root=Path(__file__).resolve().parent/'midi_tests_d5'
        cases,files=load_cases(root)
        print('Deliverable 5',args.suite,'suite on',args.port,'at 115200 baud.')
        print('Keep CCS running; close other serial monitors; listen; do not reset during tests.')
        with sender.serial.Serial(args.port,sender.BAUD,
                                  bytesize=sender.serial.EIGHTBITS,parity=sender.serial.PARITY_NONE,
                                  stopbits=sender.serial.STOPBITS_ONE,timeout=0.05,
                                  write_timeout=sender.WRITE_TIMEOUT,
                                  xonxoff=False,rtscts=False,dsrdtr=False) as port:
            sender.synchronize(port)
            run_checks(port,cases,files,args.suite)
        return 0
    except (OSError,ValueError,sender.TransferError,sender.serial.SerialException) as exc:
        print('FAIL:',exc,file=sys.stderr)
        print('Keep this log. No automatic retry. If needed, after receiver recovery run python newmiditst.py --stop.',file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print('\nPC test cancelled; an active song continues until DONE or python newmiditst.py --stop.',file=sys.stderr)
        return 130

if __name__=='__main__':sys.exit(main())
