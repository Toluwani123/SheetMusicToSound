"""Send a complete MIDI file to the MSP432E401Y using SMID version 2 (Deliverable 5).

Requires: python -m pip install pyserial
Example:  python newmiditst.py twinkle_simple.mid --wait-playback

Firmware and this sender must be upgraded together. No automatic retries:
an acknowledgement can be lost after the board has already started playback.
"""

import argparse
import math
import struct
import sys
import time
import zlib
from pathlib import Path

try:
    import serial
except ImportError:
    serial = None


BAUD = 115200
MAX_MIDI_FILE_SIZE = 16384
PROTOCOL_VERSION = 2
COMMAND_MIDI = 0
COMMAND_STOP = 1
ACK_TIMEOUT = 5.0
WRITE_TIMEOUT = 5.0
RECOVERY_TIMEOUT = 4.0
# Firmware payload-idle timeout (2 s) plus quiet recovery (0.25 s), with margin.
STARTUP_QUIET_SECONDS = 2.6
MAX_RESPONSE_LINE = 256


class TransferError(Exception):
    pass


class ResponseTimeout(TransferError):
    pass


def make_header(payload):
    """Return a 16-byte header and payload CRC; do not modify MIDI bytes."""
    crc = zlib.crc32(payload) & 0xFFFFFFFF
    header = struct.pack("<4sBB2xII", b"SMID", PROTOCOL_VERSION, COMMAND_MIDI, len(payload), crc)
    return header, crc


def make_stop_header():
    return struct.pack("<4sBB2xII", b"SMID", PROTOCOL_VERSION, COMMAND_STOP, 0, 0)


class LineReader:
    """Accumulate fragmented UART lines across individual read timeouts."""

    def __init__(self, port):
        self.port = port
        self.pending = bytearray()

    def read_line(self, deadline):
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise ResponseTimeout("Timed out waiting for an MSP response.")
            self.port.timeout = min(0.05, remaining)
            byte = self.port.read(1)
            if not byte:
                continue
            if byte == b"\n":
                line = bytes(self.pending).rstrip(b"\r")
                self.pending.clear()
                try:
                    text = line.decode("ascii")
                except UnicodeDecodeError as exc:
                    raise TransferError("Non-ASCII data in MSP response.") from exc
                if text:
                    return text
                continue
            self.pending.extend(byte)
            if len(self.pending) > MAX_RESPONSE_LINE:
                raise TransferError("MSP response exceeded the line-length limit.")


def write_all(port, data):
    """Handle partial writes without an unbounded flush() wait."""
    deadline = time.monotonic() + WRITE_TIMEOUT
    offset = 0
    while offset < len(data):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TransferError("Timed out writing to the serial port.")
        port.write_timeout = remaining
        written = port.write(data[offset:])
        if written is None or written <= 0:
            raise TransferError("Serial write made no progress.")
        offset += written


def synchronize(port):
    """Let an abandoned earlier transfer time out before sending a new header.

    Opening this COM port is not assumed to reset the board. IDLE is not
    required at startup because its earlier announcement may have been missed.
    """
    print("Synchronizing with receiver (2.6 seconds)...")
    port.reset_input_buffer()
    deadline = time.monotonic() + STARTUP_QUIET_SECONDS
    while time.monotonic() < deadline:
        port.timeout = min(0.05, max(0.001, deadline - time.monotonic()))
        port.read(min(max(port.in_waiting, 1), 256))
    port.reset_input_buffer()


def wait_response(reader, expected, timeout=ACK_TIMEOUT):
    deadline = time.monotonic() + timeout
    while True:
        line = reader.read_line(deadline)
        print("MSP:", line)
        token = line.split()[0]
        if token.startswith("ERR_"):
            raise TransferError("MSP rejected the attempt: " + line)
        if token == expected:
            return line
        if token in {"IDLE", "DONE", "PLAYING"} or line in {"SMID v1 READY", "SMID v2 READY"}:
            # These asynchronous status lines do not acknowledge this request.
            continue
        raise TransferError("Unexpected response while waiting for " + expected + ": " + line)


def verify_transfer_ack(line, expected_name, length, crc):
    fields = line.split()
    if len(fields) != 3 or fields[0] != expected_name:
        raise TransferError("Malformed acknowledgement: " + line)
    try:
        actual_length = int(fields[1], 10)
        actual_crc = int(fields[2], 16)
    except ValueError as exc:
        raise TransferError("Invalid numbers in acknowledgement: " + line) from exc
    if actual_length != length or actual_crc != crc:
        raise TransferError("Acknowledged length/CRC does not match this file.")


def wait_for_recovery(port, reader):
    """Stop local pending writes; observe recovery but never resend."""
    port.reset_output_buffer()
    deadline = time.monotonic() + RECOVERY_TIMEOUT
    while True:
        try:
            line = reader.read_line(deadline)
        except TransferError:
            print("Receiver recovery was not confirmed. Check the board before retrying.")
            return
        print("MSP:", line)
        if line == "IDLE":
            print("Receiver accepts another header. Wait for any active playback to finish before retrying.")
            return


def stop_playback(port, reader=None):
    """STOP at a frame boundary. This does not abort a partial MIDI upload."""
    if reader is None:
        reader = LineReader(port)
    started = time.monotonic()
    print("Sending STOP...")
    write_all(port, make_stop_header())
    line = wait_response(reader, "ACK_STOPPED")
    if line != "ACK_STOPPED":
        raise TransferError("Malformed STOP acknowledgement: " + line)
    idle = wait_response(reader, "IDLE")
    if idle != "IDLE":
        raise TransferError("Malformed IDLE response: " + idle)
    elapsed = time.monotonic() - started
    print("STOP acknowledged; receiver ready. Host round trip: {:.3f} seconds.".format(elapsed))
    return elapsed


def wait_then_stop(port, reader, seconds):
    """Count from ACK_VALID; use the same port without another startup delay."""
    deadline = time.monotonic() + seconds
    print("STOP scheduled {:.3f} seconds after ACK_VALID.".format(seconds))
    while True:
        try:
            line = reader.read_line(deadline)
        except ResponseTimeout:
            stop_playback(port, reader)
            return
        print("MSP:", line)
        if line == "DONE":
            print("Playback finished naturally before the STOP deadline; no cancellation was tested.")
            return
        if line in {"PLAYING", "IDLE"}:
            continue
        raise TransferError("Unexpected response before scheduled STOP: " + line)


def transfer(port, payload, wait_playback=False, playback_timeout=180.0, stop_after=None):
    header, crc = make_header(payload)
    reader = LineReader(port)
    payload_started = False

    try:
        print("Sending header:", header.hex(" ").upper())
        transfer_started = time.monotonic()
        write_all(port, header)
        ready = wait_response(reader, "ACK_READY")
        verify_transfer_ack(ready, "ACK_READY", len(payload), crc)

        print("Sending", len(payload), "MIDI bytes...")
        payload_started = True
        write_all(port, payload)
        received = wait_response(reader, "ACK_RECEIVED")
        verify_transfer_ack(received, "ACK_RECEIVED", len(payload), crc)
        valid = wait_response(reader, "ACK_VALID")
        if valid != "ACK_VALID":
            raise TransferError("Malformed final acknowledgement: " + valid)

        transfer_seconds = time.monotonic() - transfer_started
        print("Transfer + validation: {:.3f} seconds (header to ACK_VALID).".format(transfer_seconds))
        print("SUCCESS: transfer CRC and MIDI parsing passed; playback starts automatically.")
        if stop_after is not None:
            wait_then_stop(port, reader, stop_after)
        elif wait_playback:
            wait_response(reader, "DONE", timeout=playback_timeout)
            print("MSP reported playback complete.")
        return True

    except TransferError as exc:
        print("ERROR:", exc, file=sys.stderr)
        if payload_started and isinstance(exc, ResponseTimeout):
            print("Final state is uncertain: the board may already be playing. No automatic retry.",
                  file=sys.stderr)
        wait_for_recovery(port, reader)
        return False


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("midi_file", nargs="?", type=Path,
                        help="MIDI path; defaults to twinkle_simple.mid beside this script")
    parser.add_argument("--port", default="COM5", help="COM5 on Windows; e.g. /dev/ttyUSB0 on Linux")
    parser.add_argument("--wait-playback", action="store_true", help="Keep reading until the MSP reports DONE")
    parser.add_argument("--playback-timeout", type=float, default=180.0,
                        help="Maximum seconds to wait for DONE (default: 180)")
    parser.add_argument("--version", action="version",
                        version="Deliverable 5 sender: SMID v2, 16384-byte MIDI limit")
    controls = parser.add_mutually_exclusive_group()
    controls.add_argument("--stop", action="store_true", help="Stop the current song; no MIDI filename")
    controls.add_argument("--stop-after", type=float, metavar="SECONDS",
                          help="Send a file, then STOP on the same connection after ACK_VALID")
    args = parser.parse_args(argv)
    if args.stop and (args.midi_file is not None or args.wait_playback):
        parser.error("--stop is used alone (optionally with --port)")
    if args.stop_after is not None and (not math.isfinite(args.stop_after) or args.stop_after < 0):
        parser.error("--stop-after must be a finite nonnegative number")

    if not math.isfinite(args.playback_timeout) or args.playback_timeout <= 0:
        parser.error("--playback-timeout must be positive")
    if serial is None:
        print("Install pySerial first: python -m pip install pyserial", file=sys.stderr)
        return 2
    payload = None
    if not args.stop:
        if args.midi_file is None:
            args.midi_file = Path(__file__).resolve().with_name("twinkle_simple.mid")
        try:
            payload = args.midi_file.read_bytes()
        except OSError as exc:
            print("Cannot read MIDI file:", exc, file=sys.stderr)
            return 2
        if not 1 <= len(payload) <= MAX_MIDI_FILE_SIZE:
            print(f"This firmware accepts 1..{MAX_MIDI_FILE_SIZE} payload bytes; "
                  f"file size is {len(payload)}", file=sys.stderr)
            return 2
    
        _, crc = make_header(payload)
        print("File:", args.midi_file.resolve())
        print("MIDI size:", len(payload), "bytes")
        print("CRC32: {:08X}".format(crc))
    print("Port:", args.port, "at 115200 baud, 8-N-1")

    try:
        with serial.Serial(args.port, BAUD, bytesize=serial.EIGHTBITS,
                           parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE,
                           timeout=0.05, write_timeout=WRITE_TIMEOUT,
                           xonxoff=False, rtscts=False, dsrdtr=False) as port:
            if args.stop:
                # Immediate command, for a playing/idle board at a frame boundary.
                port.reset_input_buffer()
                reader = LineReader(port)
                try:
                    stop_playback(port, reader)
                    return 0
                except TransferError as exc:
                    print("STOP failed:", exc, file=sys.stderr)
                    print("No STOP was confirmed. After an interrupted upload, wait for receiver recovery.",
                          file=sys.stderr)
                    wait_for_recovery(port, reader)
                    return 1
            synchronize(port)
            return 0 if transfer(port, payload, args.wait_playback, args.playback_timeout,
                                 args.stop_after) else 1
    except (serial.SerialException, OSError) as exc:
        print("Serial connection/write failed:", exc, file=sys.stderr)
        print("Transfer state is unknown. Stop this attempt and reconnect before a manual retry.",
              file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nSender closed. An incomplete transfer times out; an already playing song continues. Use --stop to stop it.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
