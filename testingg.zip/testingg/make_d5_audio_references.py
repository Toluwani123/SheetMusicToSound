"""Optional: rebuild the supplied PC reference WAVs from expected MIDI timelines.

Run: python make_d5_audio_references.py
Uses only Python's standard library. These are reference tones, not board recordings.
"""
from array import array
import json
import math
from pathlib import Path
import sys
import wave

ROOT=Path(__file__).resolve().parent
SAMPLE_RATE=24000


def render(case,path):
    samples=array('h',[0])*round(case['duration_seconds']*SAMPLE_RATE)
    fade=max(1,round(0.003*SAMPLE_RATE))
    for note in case['notes']:
        start=round(note['on_us']*SAMPLE_RATE/1e6)
        end=min(len(samples),round(note['off_us']*SAMPLE_RATE/1e6))
        frequency=440.0*2.0**((note['note']-69)/12)
        for i in range(start,end):
            relative=i-start
            gain=min(1.0,relative/fade,(end-1-i)/fade)
            samples[i]=round(0.22*32767*gain*math.sin(2*math.pi*frequency*relative/SAMPLE_RATE))
    if sys.byteorder!='little':samples.byteswap()
    with wave.open(str(path),'wb') as wav:
        wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(SAMPLE_RATE);wav.writeframes(samples.tobytes())


def main():
    manifest=json.loads((ROOT/'midi_tests_d5/manifest.json').read_text())
    cases={c['file']:c for c in manifest['cases']}
    output=ROOT/'audio_references_d5';output.mkdir(exist_ok=True)
    for midi,wav in [('d5_reference.mid','four_note_reference.wav'),
                     ('d5_twinkle_mido.mid','twinkle_reference.wav'),
                     ('d5_ode_mido.mid','ode_reference.wav')]:
        render(cases[midi],output/wav)
        print('Created',output/wav)
    print('Open the WAV files in your normal audio player; this script does not play them.')
    return 0

if __name__=='__main__':sys.exit(main())
