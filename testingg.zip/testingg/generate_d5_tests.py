"""Rebuild the supplied D5 MIDI fixtures (optional; files are already included).

Run: python generate_d5_tests.py
Requires Mido: python -m pip install mido
Creates files only; it neither sends MIDI nor plays audio.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import struct
import sys


def vlq(value):
    if not 0<=value<=0x0fffffff:raise ValueError('VLQ range')
    result=[value&127];value>>=7
    while value:result.insert(0,128|(value&127));value>>=7
    return bytes(result)


def smf(track,ppqn=480):
    return b'MThd'+struct.pack('>IHHH',6,0,1,ppqn)+b'MTrk'+struct.pack('>I',len(track))+track


def meta(kind,body):return bytes([255,kind])+vlq(len(body))+body


def encode(events,running=False,ppqn=480):
    """events are absolute tick/message pairs; simultaneous order is preserved."""
    out=bytearray();last_tick=0;previous=None
    for tick,msg in sorted(events,key=lambda x:x[0]):
        out.extend(vlq(tick-last_tick));last_tick=tick
        status=msg[0]
        if running and status==previous and status<240:out.extend(msg[1:])
        else:out.extend(msg)
        previous=status if status<240 else None
    return smf(bytes(out),ppqn)


MELODY=[(60,0,480),(64,720,1200),(67,1440,1920),(72,2160,3120)]


def melody_events(zero=False):
    out=[(0,meta(0x51,b'\x07\xa1\x20'))]
    for note,on,off in MELODY:
        out.extend([(on,bytes([0x90,note,80])),(off,bytes([0x90 if zero else 0x80,note,0]))])
    out.append((3120,meta(0x2f,b'')))
    return out


def expected_notes(melody=MELODY,ppqn=480):
    return [{'note':n,'on_us':on*500000/ppqn,'off_us':off*500000/ppqn} for n,on,off in melody]


def generate(root):
    import mido
    from validate_d5_tests import mido_notes,validate_directory
    root.mkdir(parents=True,exist_ok=True)
    cases=[]
    def put(name,data,description,notes=None,group='quick',minimum=None,expected='ACK_VALID'):
        (root/name).write_bytes(data)
        c={'file':name,'description':description,'expected':expected,'group':group,
           'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        if expected=='ACK_VALID':
            c['notes']=expected_notes() if notes is None else notes
            c['duration_seconds']=c['notes'][-1]['off_us']/1e6
        c.update({'minimum_'+k:v for k,v in (minimum or {}).items()})
        cases.append(c)

    put('d5_reference.mid',encode(melody_events()),'C4 E4 G4 C5 with three quarter-second rests; 3.25 seconds')
    put('d5_running.mid',encode(melody_events(True),True),'Same melody; running Note On and velocity-zero endings',minimum={'running_status':7})

    additions=[(120,b'\xc0\x05'),(240,b'\xc0\x06'),(600,b'\xd0\x20'),(660,b'\xd0\x30'),
               (840,b'\xa0\x40\x20'),(900,b'\xa0\x40\x30'),(960,b'\xb0\x01\x00'),
               (1080,b'\xb0\x07\x64'),(1260,b'\xe0\x00\x40'),(1320,b'\xe0\x00\x40')]
    put('d5_mixed_events.mid',encode(melody_events(True)+additions,True),
        'Same melody; running 1/2-byte channel events during notes and rests',minimum={'running_status':5,'skipped_channel':10})
    metadata=[(120,meta(3,b'D5 melody')),(600,meta(0x58,bytes([4,2,24,8]))),
              (900,meta(0x59,b'\x00\x00')),(1260,meta(1,b'gap')),
              (1500,meta(0x7f,b'\x00\xffSMID')),(1800,meta(0x20,b'\x00')),
              (1980,meta(0x21,b'\x00'))]
    put('d5_metadata.mid',encode(melody_events()+metadata),'Same melody; permitted metadata preserves elapsed time',minimum={'skipped_meta':7})
    put('d5_running_after_meta.mid',encode(melody_events(True)+[(960,meta(1,b'reset running status'))],True),
        'An explicit channel status resumes after metadata, then compression resumes',minimum={'running_status':6,'skipped_meta':1})
    switches=[(60,b'\xc0\x01'),(120,b'\xc0\x02'),(180,b'\xb0\x01\x00'),(240,b'\xb0\x07\x64'),
              (300,b'\xd0\x10'),(360,b'\xd0\x20'),(420,b'\xe0\x00\x40')]
    put('d5_switch_lengths.mid',encode(melody_events(True)+switches,True),
        'Repeated changes between one-byte and two-byte running-status messages',minimum={'running_status':3,'skipped_channel':7})

    # Independent writer: build Mido messages from musical intent, not raw bytes.
    mf=mido.MidiFile(type=0,ticks_per_beat=480);tr=mido.MidiTrack();mf.tracks.append(tr)
    tr.append(mido.MetaMessage('set_tempo',tempo=500000,time=0))
    last=0
    for note,on,off in MELODY:
        tr.append(mido.Message('note_on',note=note,velocity=80,time=on-last))
        tr.append(mido.Message('note_on',note=note,velocity=0,time=off-on));last=off
    tr.append(mido.MetaMessage('end_of_track',time=0))
    f=io.BytesIO();mf.save(file=f)
    put('d5_mido_reference.mid',f.getvalue(),'Same musical intent encoded by Mido '+str(mido.version_info),minimum={'running_status':7})

    fractional=[(0,b'\x90\x3c\x50'),(1994,b'\x80\x3c\x00'),(1994,meta(0x2f,b''))]
    one_note=expected_notes([(60,0,1994)],997)
    put('d5_fraction_reference.mid',encode(fractional,ppqn=997),'One-second C4 at 997 PPQN',notes=one_note)
    put('d5_split_deltas.mid',encode(fractional+[(i,b'\xb0\x01\x00') for i in range(1,1001)],True,997),
        'Same one-second C4 with 1000 timed controllers; fractional timing must be retained',notes=one_note,
        minimum={'running_status':999,'skipped_channel':1000})
    recovery=encode([(0,b'\x90\x48\x50'),(240,b'\x80\x48\x00'),(240,meta(0x2f,b''))])
    put('d5_recovery.mid',recovery,'Short C5 beep after each rejected file',notes=expected_notes([(72,0,240)]),group='recovery')

    base=encode(melody_events());track=base[22:];eot=b'\x00\xff\x2f\x00'
    negatives={
        'bad_running_start.mid':(b'\x00\x3c\x50'+eot,'Data bytes with no previous channel status'),
        'bad_running_after_meta.mid':(b'\x00\x90\x3c\x50\x00\xff\x01\x01x\x01\x3c\x00'+eot,'Running status illegally reused after metadata'),
        'bad_short_note.mid':(b'\x00\x90\x3c','Missing note velocity'),
        'bad_short_program.mid':(b'\x00\xc0','Missing one-byte Program Change data'),
        'bad_channel_data.mid':(b'\x00\x90\x3c\x80'+eot,'High bit set in channel data'),
        'bad_delta_vlq.mid':(b'\x81\x80\x80\x80\x00\x90\x3c\x50'+eot,'Delta VLQ exceeds four bytes'),
        'bad_meta_length.mid':(b'\x00\xff\x01\x7fabc','Declared meta payload extends past track'),
        'bad_meta_vlq.mid':(b'\x00\xff\x01\x81','Unterminated meta length'),
        'bad_tempo_length.mid':(b'\x00\xff\x51\x02\x07\xa1'+track,'Tempo has wrong payload length'),
        'bad_tempo_zero.mid':(b'\x00\xff\x51\x03\x00\x00\x00'+track,'Zero tempo'),
        'bad_signature_length.mid':(b'\x00\xff\x58\x03\x04\x02\x18'+track,'Time signature has wrong length'),
        'bad_eot_length.mid':(track[:-4]+b'\x00\xff\x2f\x01\x00','EOT has a payload'),
        'bad_missing_eot.mid':(track[:-4],'Notes completed but EOT absent'),
        'bad_bytes_after_eot.mid':(track+b'\x00\xc0\x01','Another event follows EOT'),
        'bad_overlap.mid':(b'\x00\x90\x3c\x50\x00\x90\x40\x50'+eot,'Two simultaneous notes exceed monophonic contract'),
        'bad_mismatched_off.mid':(b'\x00\x90\x3c\x50\x01\x80\x40\x00'+eot,'Note Off pitch does not match active note'),
        'bad_wrong_channel.mid':(b'\x00\x91\x3c\x50\x01\x81\x3c\x00'+eot,'Channel 1 byte value is outside channel-0 contract'),
        'bad_out_of_range.mid':(b'\x00\x90\x2f\x50\x01\x80\x2f\x00'+eot,'Pitch 47 is outside 48..84 contract'),
        'bad_sysex.mid':(b'\x00\xf0\x02\x7d\xf7'+track,'SysEx is outside current subset'),
        'bad_system_status.mid':(b'\x00\xf8'+track,'Raw realtime status is not an SMF channel event'),
        'bad_unended_note.mid':(b'\x00\x90\x3c\x50'+eot,'EOT while a note remains active'),
    }
    for name,(raw,reason) in negatives.items():put(name,smf(raw),reason,expected='ERR_MIDI',group='negative')
    for adjustment,suffix in ((-1,'short'),(1,'long')):
        bad=bytearray(base);bad[18:22]=struct.pack('>I',len(track)+adjustment)
        put('bad_track_length_'+suffix+'.mid',bytes(bad),'Declared track size disagrees with payload',expected='ERR_MIDI',group='negative')

    # Re-encode the user's existing melodies using Mido's own SMF writer.
    # These are independent encodings, not OMR exports or new compositions.
    for source,name in [('twinkle_simple.mid','d5_twinkle_mido.mid'),('ode_to_joy_msp.mid','d5_ode_mido.mid')]:
        data=(Path(__file__).resolve().parent/source).read_bytes()
        notes,duration=mido_notes(data);mf=mido.MidiFile(file=io.BytesIO(data))
        for tr in mf.tracks:
            for i,msg in enumerate(tr):
                if msg.type=='note_off':
                    tr[i]=mido.Message('note_on',channel=msg.channel,note=msg.note,velocity=0,time=msg.time)
        f=io.BytesIO();mf.save(file=f)
        put(name,f.getvalue(),'Existing '+source+' re-encoded by Mido with velocity-zero note endings',notes=notes,
            group='long',minimum={'running_status':1})
        cases[-1]['duration_seconds']=duration/1e6

    manifest={'deliverable':5,'protocol':'SMID v2 (unchanged)',
              'note':'Expected outcomes, not board measurements. Negative includes malformed and unsupported-subset files.',
              'independent_writer':'Mido '+str(mido.version_info),'cases':cases}
    (root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    validate_directory(root)
    print('Generated',len(cases),'fixtures in',root.resolve())


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory',type=Path,default=Path(__file__).resolve().parent/'midi_tests_d5')
    args=parser.parse_args()
    try:generate(args.directory)
    except ImportError:
        print('Install Mido for generation: python -m pip install mido',file=sys.stderr);return 2
    except (OSError,ValueError,EOFError) as exc:
        print('FAIL:',exc,file=sys.stderr);return 1
    return 0

if __name__=='__main__':sys.exit(main())
