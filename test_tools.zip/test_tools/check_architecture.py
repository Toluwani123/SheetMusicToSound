"""Static architecture checks for the globals + FreeRTOS monophonic firmware.

Evidence category: SOURCE INSPECTION by script (plus a real arm-none-eabi-gcc
-fsyntax-only compile of every header on its own). Nothing here runs the
firmware.

Usage: python check_architecture.py [<app project dir>] [<kernel project dir>]
"""
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "projects" / "gpiointerrupt_freertos"
KERNEL = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / "projects" / "freertos_kernel_glo"
GCC = r"C:\ti\gcc_arm_none_eabi_9_2_1\bin\arm-none-eabi-gcc-9.2.1.exe"
SDK = r"C:\ti\simplelink_msp432e4_sdk_4_20_00_12"

failures = 0


def check(name, ok, detail=""):
    global failures
    print(("PASS " if ok else "FAIL ") + name + (("  -- " + detail) if detail else ""))
    if not ok:
        failures += 1


def strip(text):
    text = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), text, flags=re.S)
    return re.sub(r"//[^\n]*", "", text)


def function_body(text, name):
    """Return the text of a top-level function definition, or ''."""
    m = re.search(r"^[A-Za-z_][\w\s\*]*\b" + re.escape(name) + r"\s*\([^;{]*\)\s*\{", text, re.M)
    if not m:
        return ""
    depth, i = 0, m.end() - 1
    while i < len(text):
        depth += text[i] == "{"
        depth -= text[i] == "}"
        if depth == 0:
            return text[m.start():i + 1]
        i += 1
    return ""


def main():
    files = {p.name: p.read_text() for p in sorted(APP.glob("*.[ch]"))}
    code = {n: strip(t) for n, t in files.items()}

    print("Project:", APP)
    print("\n-- required module files (and nothing monolithic) --")
    for base in ("audio", "midi", "playback", "uart_task", "uart_tx", "control_task"):
        check(f"{base}.c and {base}.h", f"{base}.c" in files and f"{base}.h" in files)
    check("main_freertos.c, globals.c, globals.h", all(n in files for n in ("main_freertos.c", "globals.c", "globals.h")))
    check("old gpiointerrupt.c and main_nortos.c are not in the project",
          "gpiointerrupt.c" not in files and "main_nortos.c" not in files)
    check("no stale build products in the project folder",
          not (APP / "Debug").exists() and not list(APP.glob("*.o")) and not list(APP.glob("*.out")))

    print("\n-- single definitions --")
    mains = [n for n, t in code.items() if n.endswith(".c") and re.search(r"\bint\s+main\s*\(", t)]
    check("exactly one main()", mains == ["main_freertos.c"], ", ".join(mains))
    glo_defs = [n for n, t in code.items() if re.search(r"^\s*Globals\s+Glo\b", t, re.M)]
    check("Globals Glo defined exactly once, in globals.c", glo_defs == ["globals.c"], ", ".join(glo_defs))
    check("globals.h declares 'extern Globals Glo;'", "extern Globals Glo;" in code["globals.h"])
    includes_c = [n for n, t in files.items() if re.search(r'#\s*include\s+["<][^">]+\.c[">]', t)]
    check("no #include of a .c file", not includes_c, ", ".join(includes_c))
    tables = [n for n, t in code.items() if re.search(r"\bsineTable\s*\[|midiFrequencyMilliHz\s*\[", t)]
    check("sine and frequency tables defined once, in audio.c", tables == ["audio.c"], ", ".join(tables))
    arrays = [n for n, t in code.items() if re.search(r"\bMelodyEvent\s+\w+\s*\[MAX_PARSED_NOTES\]", t)]
    check("the 1,024-event array has one owner (control_task.c)", arrays == ["control_task.c"], ", ".join(arrays))
    buffers = [n for n, t in code.items() if re.search(r"\buint8_t\s+fileBuffer\s*\[", t)]
    check("the 16 KB payload buffer has one owner (uart_task.c)", buffers == ["uart_task.c"], ", ".join(buffers))

    print("\n-- headers: guards and standalone compile --")
    for n, t in sorted(files.items()):
        if n.endswith(".h"):
            guard = n.upper().replace(".", "_")
            ok = re.search(r"#ifndef\s+" + guard + r"\b", t) and re.search(r"#define\s+" + guard + r"\b", t) \
                and t.rstrip().endswith("#endif /* " + guard + " */")
            check(f"{n} has include guard {guard}", bool(ok))
    flags = ["-fsyntax-only", "-std=c99", "-mcpu=cortex-m4", "-mthumb", "-mfloat-abi=hard", "-mfpu=fpv4-sp-d16",
             f"-I{APP}", f"-I{KERNEL}", f"-I{KERNEL}/FreeRTOS/Source/include",
             f"-I{KERNEL}/FreeRTOS/Source/portable/GCC/ARM_CM4F", f"-I{SDK}/source",
             f"-I{SDK}/source/third_party/CMSIS/Include", f"-I{SDK}/source/ti/posix/gcc",
             r"-IC:/ti/gcc_arm_none_eabi_9_2_1/arm-none-eabi/include"]
    with tempfile.TemporaryDirectory() as tmp:
        for n in sorted(f for f in files if f.endswith(".h")):
            probe = Path(tmp) / ("probe_" + n.replace(".h", ".c"))
            probe.write_text(f'#include "{n}"\nint main_probe_{n.replace(".", "_")}(void){{return 0;}}\n')
            r = subprocess.run([GCC] + flags + [str(probe)], capture_output=True, text=True)
            check(f"{n} compiles on its own (no reliance on include order)", r.returncode == 0,
                  r.stderr.strip().splitlines()[0] if r.returncode else "")

    print("\n-- module boundaries --")
    check("midi.c has no hardware, RTOS or globals dependency",
          not re.search(r'#include\s+[<"](?:.*driverlib|.*FreeRTOS|.*task\.h|.*semphr|globals\.h|uart_task|playback|audio)', files["midi.c"]))
    kernel_api = r"\b(?:x(?:Semaphore|Task|Queue)\w*|v(?:Task|Queue)\w*|portYIELD\w*|taskENTER\w*|taskEXIT\w*|ux?Task\w*)\s*\("
    check("audio.c makes no FreeRTOS calls (sample ISR stays kernel-independent)",
          not re.search(kernel_api, code["audio.c"]))
    check("playback.c makes no FreeRTOS calls (it only calls its completion hook)",
          not re.search(kernel_api, code["playback.c"]))
    check("playback.c does not parse MIDI or touch the UART",
          "Midi_parse" not in code["playback.c"] and "UART0_BASE" not in code["playback.c"])
    check("control_task.c does not touch raw receiver state or UART registers",
          not re.search(r"receiverState|UART0_BASE|s_rx|fileBuffer", code["control_task.c"]))
    check("audio.c does not include midi.h or uart_task.h",
          not re.search(r'#include\s+"(midi|uart_task|playback|control_task)\.h"', files["audio.c"]))
    check("uart_task.c does not call playback or audio (coordinated through hooks)",
          not re.search(r'#include\s+"(playback|audio|midi|control_task)\.h"', files["uart_task.c"]))

    print("\n-- ISR rules --")
    isrs = {
        "timer2ISR": "audio.c",              # priority 0: no kernel calls at all
        "transferTimer4ISR": "uart_task.c",  # priority 3: kernel-independent counter
        "timer3ISR": "playback.c",           # priority 2: only the completion hook
        "uart0RxIsr": "uart_task.c",         # priority 2: *FromISR only
        "Control_playbackFinishedIsr": "control_task.c",  # runs in Timer3 ISR: *FromISR only
    }
    for isr, fn in isrs.items():
        body = function_body(code[fn], isr)
        check(f"{isr} found in {fn}", bool(body))
        bad = re.findall(r"\b(xSemaphoreTake|xSemaphoreGive|xQueueSemaphoreTake|xSemaphoreTakeRecursive|vTaskDelay|xQueueSend|"
                         r"xQueueReceive|xTaskNotify\w*Wait|UartTx_\w+|Uart_(?:begin|end|send|put)\w*|UART0_write\w*|UARTChar\w*Put\w*)\s*\(", body)
        check(f"{isr} calls no blocking/mutex/UART-output function", not bad, ", ".join(bad))
    for isr in ("timer2ISR", "transferTimer4ISR", "timer3ISR"):
        body = function_body(code[isrs[isr]], isr)
        check(f"{isr} makes no FreeRTOS call itself", not re.search(kernel_api, body))
    for isr in ("uart0RxIsr", "Control_playbackFinishedIsr"):
        body = function_body(code[isrs[isr]], isr)
        calls = re.findall(r"\bx(?:Semaphore|Queue)\w*\s*\(", body)
        check(f"{isr}: every kernel call is a FromISR variant",
              bool(calls) and all("FromISR" in c for c in calls), ", ".join(calls))

    print("\n-- NVIC priorities --")
    plan = {"INT_TIMER2A": "IRQ_PRIO_AUDIO_SAMPLE", "INT_TIMER3A": "IRQ_PRIO_PLAYBACK",
            "INT_UART0": "IRQ_PRIO_UART_RX", "INT_TIMER4A": "IRQ_PRIO_TRANSFER_CLOCK"}
    all_code = "\n".join(code.values())
    for irq, macro in plan.items():
        m = re.search(r"IntPrioritySet\(\s*" + irq + r"\s*,\s*(\w+)\s*\)", all_code)
        check(f"{irq} priority set with {macro}", bool(m) and m.group(1) == macro, m.group(1) if m else "not set")
    check("globals.h proves audio priority 0 is above the FreeRTOS ceiling and FromISR users are not",
          "irqAudioIsAboveKernelCeiling" in code["globals.h"] and "irqKernelCallersAtOrBelowCeiling" in code["globals.h"])

    print("\n-- RTOS objects: every handle created, produced and consumed --")
    sites = {}
    for n, t in code.items():
        for ln, line in enumerate(t.split("\n"), 1):
            for obj in ("UART0ReadTask", "PayloadTask", "MonitorTask", "UARTTxTask", "UARTReadSem", "PayloadSem", "UARTTxQueue"):
                if "Glo.Bios." + obj in line:
                    sites.setdefault(obj, []).append((n, ln, line.strip()))
    for obj in ("UARTReadSem", "PayloadSem", "UARTTxQueue"):
        rows = sites.get(obj, [])
        creates = [r for r in rows if re.search(r"=\s*x(?:Semaphore|Queue)Create", r[2])]
        gives = [r for r in rows if re.search(r"xSemaphoreGive|xQueueSend", r[2])]
        if obj == "UARTTxQueue":   # uart_tx.c copies the handle into a local before xQueueSend(queue, ...)
            gives += [("uart_tx.c", ln, l.strip()) for ln, l in enumerate(code["uart_tx.c"].split("\n"), 1)
                      if re.search(r"\bxQueueSend\s*\(\s*queue\b", l)]
        takes = [r for r in rows if re.search(r"xSemaphoreTake|xQueueReceive", r[2])]
        check(f"{obj}: created {len(creates)}x, given {len(gives)}x, taken {len(takes)}x",
              len(creates) == 1 and len(gives) >= 1 and len(takes) >= 1)
        for kind, group in (("create", creates), ("give", gives), ("take", takes)):
            for n, ln, line in group:
                print(f"       {kind:6s} {n}:{ln}: {line}")
    for task in ("UART0ReadTask", "PayloadTask", "MonitorTask", "UARTTxTask"):
        rows = [r for r in sites.get(task, []) if "xTaskCreate" in r[2] or "&Glo.Bios." + task in r[2]]
        used = [r for r in sites.get(task, []) if "uxTaskGetStackHighWaterMark" in r[2]]
        check(f"{task}: handle stored by xTaskCreate and used by the monitor", bool(rows) or bool(sites.get(task)), "")
    for n, ln, line in [r for t in ("UART0ReadTask", "PayloadTask", "MonitorTask", "UARTTxTask") for r in sites.get(t, [])]:
        print(f"       handle {n}:{ln}: {line}")
    tasks_created = len(re.findall(r"xTaskCreate\s*\(", code["control_task.c"]))
    check("exactly four application tasks are created", tasks_created == 4, str(tasks_created))

    print("\n-- UART transmit ownership (queue + single owner task) --")
    writers = [n for n, t in code.items() if re.search(r"\bUARTChar(?:Put|PutNonBlocking)\s*\(|\bUARTCharPut\w*\s*\(", t)]
    check("only uart_tx.c writes UART0 data", writers == ["uart_tx.c"], ", ".join(writers))
    leftovers = [n for n, t in code.items() if re.search(r"UARTTxMutex|Uart_(?:begin|end)Reply|Uart_sendReply|Uart_putText|xSemaphoreCreateMutex|xSemaphoreCreateRecursiveMutex", t)]
    check("no UARTTxMutex / mutex-style reply API remains", not leftovers, ", ".join(leftovers))
    hooks = code["main_freertos.c"]
    check("fault hooks and Fault_halt make no UART or queue call",
          not re.search(r"UartTx_|UART\w*\(|xQueue\w*\(", hooks))
    check("UartTx_createQueue() runs before the first xTaskCreate in Control_init",
          code["control_task.c"].find("UartTx_createQueue") != -1 and
          code["control_task.c"].find("UartTx_createQueue") < code["control_task.c"].find("xTaskCreate"))
    check("UARTTxTask has the highest task priority",
          re.search(r"PRIORITY_UART_TX\s+4U", code["control_task.c"]) and
          all(int(m) < 4 for m in re.findall(r"#define\s+PRIORITY_(?:UART0_READ|PAYLOAD|MONITOR)\s+(\d+)U", code["control_task.c"])))
    check("test-only stall is not defined in the release project",
          not re.search(r"#\s*define\s+UART_TX_TEST_STALL_MS", "\n".join(code.values())) and
          not (APP / "uart_tx_test.h").exists())
    producers = [n for n, t in code.items() if n.endswith(".c") and re.search(r"\bUartTx_(?:send|sendAck|sendLine|trySend)\s*\(", t)]
    check("replies are produced only by uart_task.c, control_task.c (and defined in uart_tx.c)",
          sorted(producers) == ["control_task.c", "uart_task.c", "uart_tx.c"], ", ".join(sorted(producers)))

    print(f"\n{failures} failure(s).")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
