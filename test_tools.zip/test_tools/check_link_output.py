"""Inspect the linked firmware image: startup, kernel hookup, memory.

Evidence category: BUILD/LINK OUTPUT INSPECTION of a real arm-none-eabi-gcc
link (not a host build, not a run on the board).

Checks
  * exactly one main() and one reset handler; no NoRTOS startup or libraries
  * vector table (flash 0x0): initial stack pointer, reset, SVCall, PendSV and
    SysTick point to the symbols they should (the FreeRTOS port handlers)
  * the FreeRTOS kernel objects and the application modules were linked
  * Glo exists once, with its handle fields in .bss
  * RAM/flash use, heap array, ISR stack

Usage: python check_link_output.py <image.out> [<image.map>]
"""
import re
import subprocess
import sys
from pathlib import Path

TOOLS = Path(r"C:\ti\gcc_arm_none_eabi_9_2_1\bin")
NM = str(TOOLS / "arm-none-eabi-nm.exe")
OBJDUMP = str(TOOLS / "arm-none-eabi-objdump.exe")
SIZE = str(TOOLS / "arm-none-eabi-size.exe")

failures = 0


def check(name, ok, detail=""):
    global failures
    print(("PASS " if ok else "FAIL ") + name + (("  -- " + detail) if detail else ""))
    if not ok:
        failures += 1


def run(args):
    return subprocess.run(args, capture_output=True, text=True, check=True).stdout


def main():
    image = Path(sys.argv[1])
    mapfile = Path(sys.argv[2]) if len(sys.argv) > 2 else image.with_suffix(".map")

    nm = run([NM, "-C", "-S", str(image)]).splitlines()
    symbols = {}
    for line in nm:
        m = re.match(r"([0-9a-fA-F]{8})\s+(?:([0-9a-fA-F]{8})\s+)?(\w)\s+(.*)", line)
        if m:
            symbols.setdefault(m.group(4), []).append((int(m.group(1), 16), int(m.group(2) or "0", 16), m.group(3)))

    def addr(name):
        return symbols[name][0][0]

    print("Image:", image)
    print("\n-- one startup, one main, no NoRTOS --")
    mains = [s for s in symbols.get("main", []) if s[2] in "Tt"]
    check("exactly one definition of main()", len(mains) == 1, f"{len(mains)} found")
    check("exactly one resetISR (SDK FreeRTOS startup)", len([s for s in symbols.get("resetISR", []) if s[2] in "Tt"]) == 1)
    for banned in ("NoRTOS_start", "mainThread", "NoRTOS_stop", "nortos"):
        found = [n for n in symbols if banned.lower() in n.lower()]
        check(f"no symbol containing '{banned}'", not found, ", ".join(found[:3]))
    map_text = mapfile.read_text(errors="replace") if mapfile.exists() else ""
    check("map file: no NoRTOS library or object linked", "nortos" not in map_text.lower())
    check("map file: old monolithic gpiointerrupt.o / main_nortos.o absent",
          "gpiointerrupt.o" not in map_text and "main_nortos.o" not in map_text)

    print("\n-- vector table in flash --")
    dump = run([OBJDUMP, "-s", "-j", ".intvecs", str(image)])
    words = []
    for line in dump.splitlines():
        m = re.match(r"\s+[0-9a-f]{4}\s+((?:[0-9a-f]{8}\s?){1,4})", line)
        if m:
            for chunk in m.group(1).split():
                words.append(int.from_bytes(bytes.fromhex(chunk), "little"))
    check("vector table has at least 16 system entries", len(words) >= 16, f"{len(words)} words")
    expected = {
        0: ("initial stack pointer = _stack_end", addr("_stack_end") if "_stack_end" in symbols else None, False),
        1: ("reset = resetISR", addr("resetISR"), True),
        11: ("SVCall = vPortSVCHandler", addr("vPortSVCHandler"), True),
        14: ("PendSV = xPortPendSVHandler", addr("xPortPendSVHandler"), True),
        15: ("SysTick = xPortSysTickHandler", addr("xPortSysTickHandler"), True),
    }
    for index, (label, want, thumb) in expected.items():
        got = words[index] if index < len(words) else None
        want_value = (want | 1) if (thumb and want is not None) else want
        check(f"vector[{index:2d}] {label}", got is not None and got == want_value,
              f"0x{got:08X}" if got is not None else "missing")

    print("\n-- kernel and application objects linked --")
    for fn in ("vTaskStartScheduler", "xTaskCreate", "xQueueGenericCreate", "xQueueSemaphoreTake",
               "xQueueGiveFromISR", "xQueueGenericSend", "xQueueReceive", "pvPortMalloc", "xPortStartScheduler",
               "uxTaskGetStackHighWaterMark", "xPortGetMinimumEverFreeHeapSize"):
        check(f"kernel symbol {fn}", fn in symbols)
    for fn in ("Audio_init", "Audio_startNote", "Audio_stopNote", "Midi_parse", "Playback_start",
               "Playback_stop", "Playback_takeCompletion", "Uart_init", "Uart_readTask",
               "Uart_acquirePayload", "UartTx_createQueue", "UartTx_task", "UartTx_send", "UartTx_sendAck",
               "Playback_completionReady", "Control_init", "vAssertCalled",
               "vApplicationStackOverflowHook", "vApplicationMallocFailedHook"):
        check(f"application symbol {fn}", fn in symbols)
    check("no mutex in the image (xQueueCreateMutex / xQueueTakeMutexRecursive not linked)",
          "xQueueCreateMutex" not in symbols and "xQueueGiveMutexRecursive" not in symbols)
    check("UartTx_write is the only function calling UARTCharPutNonBlocking (symbol present once)",
          len([s for s in symbols.get("UartTx_write", []) if s[2] in "Tt"]) == 1)
    for static_name in ("timer2ISR", "timer3ISR", "uart0RxIsr", "transferTimer4ISR", "Control_payloadTask",
                        "Control_monitorTask"):
        check(f"function {static_name} present", any(static_name in n for n in symbols))

    print("\n-- Glo --")
    glo = symbols.get("Glo", [])
    check("Glo defined exactly once", len(glo) == 1, f"{len(glo)} found")
    if glo:
        print(f"INFO Glo at 0x{glo[0][0]:08X}, {glo[0][1]} bytes, section type '{glo[0][2]}'")
        check("Glo lives in .bss/.data (RAM address 0x2000xxxx)", 0x20000000 <= glo[0][0] < 0x20040000)

    print("\n-- memory --")
    size = run([SIZE, str(image)]).splitlines()[1].split()
    text, data, bss = int(size[0]), int(size[1]), int(size[2])
    print(f"INFO flash (text+data) = {text + data} bytes of 1,048,576 ({100.0 * (text + data) / 1048576:.1f} %)")
    print(f"INFO RAM static (data+bss) = {data + bss} bytes of 262,144 ({100.0 * (data + bss) / 262144:.1f} %)")
    heap = symbols.get("ucHeap", [(0, 0, "")])[0]
    print(f"INFO FreeRTOS heap array ucHeap = {heap[1]} bytes at 0x{heap[0]:08X}")
    check("heap array is the configured 32 KB", heap[1] == 0x8000, str(heap[1]))
    if "_stack_end" in symbols and "_stack" in symbols:
        print(f"INFO ISR/startup (MSP) stack = {addr('_stack_end') - addr('_stack')} bytes")
    check("RAM use leaves headroom (< 50 % of 256 KB)", (data + bss) < 131072)

    print(f"\n{failures} failure(s).")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
