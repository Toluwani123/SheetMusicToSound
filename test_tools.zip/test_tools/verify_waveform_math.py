"""Offline check of the audio-ISR integer arithmetic (no board, no COM port).

Mirrors sineTableInterpolate(), envelopeGainQ15(), audioConfigureEnvelope()
and the timer2ISR output stage bit-for-bit using Python integers with explicit
32-bit wrapping.  Evidence category: ARITHMETIC ON HOST (it does not run the
firmware and cannot hear anything).

Layout-aware: the sine table and audio constants are read from the modular
firmware's audio.c, and the core clock from FreeRTOSConfig.h, so nothing is a
stale copy.  The table and every constant are then compared with the baseline
gpiointerrupt.c to prove the waveform parameters did not change in the refactor.

Run:  python verify_waveform_math.py [<project dir with audio.c>] [<kernel project dir>] [<baseline gpiointerrupt.c>]
"""

import math
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DEFAULT_SOURCE = ROOT / "projects" / "gpiointerrupt_freertos"
DEFAULT_KERNEL = ROOT / "projects" / "freertos_kernel_glo"
DEFAULT_BASELINE = ROOT / "checkpoints" / "00_before_globals_rtos" / "gpiointerrupt" / "gpiointerrupt.c"
U32 = 0xFFFFFFFF


def load_firmware(path, kernel_dir=None):
    """path: a C file (baseline gpiointerrupt.c) or a project directory (audio.c)."""
    if path.is_dir():
        text = (path / "audio.c").read_text()
        cfg = (kernel_dir / "FreeRTOSConfig.h").read_text()
        m = re.search(r"#define\s+configCPU_CLOCK_HZ\s+\(\s*\(\s*unsigned long\s*\)\s*([0-9]+)\s*\)", cfg)
        if not m:
            raise SystemExit("Cannot find configCPU_CLOCK_HZ in FreeRTOSConfig.h")
        text += "\n#define SYSTEM_CLOCK_HZ {}U\n".format(m.group(1))
    else:
        text = path.read_text()

    def define(name):
        m = re.search(r"#define\s+" + name + r"\s+\(?([0-9]+)U?\)?", text)
        if not m:
            raise SystemExit("Cannot find #define " + name)
        return int(m.group(1))

    body = re.search(r"sineTable\[SINE_TABLE_SIZE\]\s*=\s*\{(.*?)\};", text, re.S).group(1)
    table = [int(v) for v in re.findall(r"\d+", body)]
    c = {n: define(n) for n in (
        "DAC_IDLE_CODE", "DAC_MAX_CODE", "AUDIO_SAMPLE_RATE_HZ", "AUDIO_TIMER_COUNTS",
        "SINE_TABLE_SIZE", "SINE_TABLE_BITS", "INTERP_FRACTION_BITS", "ENV_RAMP_MS",
        "ENV_END_GUARD_SAMPLES", "ENV_GAIN_ONE", "AUDIO_OUTPUT_GAIN", "SYSTEM_CLOCK_HZ")}
    c["ENV_RAMP_SAMPLES"] = (c["AUDIO_SAMPLE_RATE_HZ"] // 1000) * c["ENV_RAMP_MS"]
    assert len(table) == c["SINE_TABLE_SIZE"], "table length mismatch"
    return table, c


def c_div_trunc(a, b):
    """C99 signed division: truncates toward zero."""
    q = abs(a) // abs(b)
    return q if (a >= 0) == (b > 0) else -q


def to_i32(v):
    v &= U32
    return v - (1 << 32) if v & 0x80000000 else v


def interpolate(table, c, phase):
    bits, fb, size = c["SINE_TABLE_BITS"], c["INTERP_FRACTION_BITS"], c["SINE_TABLE_SIZE"]
    index = phase >> (32 - bits)
    nxt = (index + 1) & (size - 1)
    fraction = (phase >> (32 - bits - fb)) & ((1 << fb) - 1)
    first = table[index]
    difference = table[nxt] - first
    product = difference * fraction
    assert -(1 << 31) <= product < (1 << 31), "int32 product overflow"
    true_scaled = (first << fb) + product + (1 << (fb - 1))
    assert 0 <= true_scaled <= U32, "scaled sum outside uint32"
    scaled = ((first << fb) + (product & U32) + (1 << (fb - 1))) & U32  # C wraps mod 2^32
    assert scaled == true_scaled
    return scaled >> fb, index, nxt, fraction


def nearest(table, c, phase):
    return table[phase >> (32 - c["SINE_TABLE_BITS"])]


def configure_envelope(c, duration_ms):
    ms = duration_ms if duration_ms else 1
    counts = min((c["SYSTEM_CLOCK_HZ"] * ms) // 1000, U32)
    note_samples = counts // c["AUDIO_TIMER_COUNTS"]
    guard = c["ENV_END_GUARD_SAMPLES"]
    usable = note_samples - guard if note_samples > guard else 0
    ramp = c["ENV_RAMP_SAMPLES"]
    if 2 * ramp > usable:
        ramp = usable // 2
    return dict(note_samples=note_samples, attack=ramp, release=ramp,
                release_end=usable, release_start=usable - ramp)


def gain_q15(c, env, n):
    one = c["ENV_GAIN_ONE"]
    if n < env["attack"]:
        assert n * one <= U32
        return (n * one) // env["attack"]
    if n < env["release_start"]:
        return one
    if n < env["release_end"]:
        assert (env["release_end"] - n) * one <= U32
        return ((env["release_end"] - n) * one) // env["release"]
    return 0


def output_code(c, waveform, gain):
    centered = (waveform - c["DAC_IDLE_CODE"]) * c["AUDIO_OUTPUT_GAIN"]
    product = centered * gain
    assert -(1 << 31) <= product < (1 << 31), "gain product overflow"
    centered = c_div_trunc(product, c["ENV_GAIN_ONE"])
    out = c["DAC_IDLE_CODE"] + centered
    return min(max(out, 0), c["DAC_MAX_CODE"])


def old_firmware_code(table, c, phase):
    """Pre-milestone timer2ISR: nearest entry, x3, cast to uint16, &0x3FFF in DAC write."""
    centered = (table[phase >> 24] - c["DAC_IDLE_CODE"]) * 3
    return ((c["DAC_IDLE_CODE"] + centered) & 0xFFFF) & 0x3FFF


failures = 0


def check(name, ok, detail=""):
    global failures
    print(("PASS " if ok else "FAIL ") + name + (("  -- " + detail) if detail else ""))
    if not ok:
        failures += 1


def main():
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_SOURCE
    kernel = Path(sys.argv[2]) if len(sys.argv) > 2 else DEFAULT_KERNEL
    baseline = Path(sys.argv[3]) if len(sys.argv) > 3 else DEFAULT_BASELINE
    table, c = load_firmware(src, kernel)
    print("Source:", src)
    if baseline.exists():
        print("\n-- Unchanged against the baseline gpiointerrupt.c --")
        btable, bc = load_firmware(baseline)
        check("256-entry sine table identical to the baseline", table == btable)
        for name in sorted(c):
            check("constant {} = {} identical to the baseline".format(name, c[name]), c[name] == bc[name])
    print("Constants: table={} entries, DAC midpoint={}, table range {}..{}, sample rate={} Hz, "
          "ramp={} samples, guard={} samples".format(
              len(table), c["DAC_IDLE_CODE"], min(table), max(table), c["AUDIO_SAMPLE_RATE_HZ"],
              c["ENV_RAMP_SAMPLES"], c["ENV_END_GUARD_SAMPLES"]))
    fb = c["INTERP_FRACTION_BITS"]
    one_frac = 1 << (32 - c["SINE_TABLE_BITS"])  # phase distance between entries

    print("\n-- Interpolation boundary checks --")
    v, *_ = interpolate(table, c, 20 << 24)
    check("zero fraction returns first entry (index 20)", v == table[20], f"{v} vs {table[20]}")
    v, i, n, f = interpolate(table, c, (20 << 24) + one_frac // 2)
    exact = (table[20] + table[21]) / 2
    check("half fraction is midway (index 20->21)", abs(v - exact) <= 0.5,
          f"{table[20]} .. {table[21]} -> {v} (exact {exact})")
    v, *_ = interpolate(table, c, (20 << 24) + one_frac // 4)
    exact = table[20] + 0.25 * (table[21] - table[20])
    check("quarter fraction (rising)", abs(v - exact) <= 0.5, f"{v} vs {exact:.2f}")
    desc = 100  # table[100] > table[101]: falling section
    for frac in (0.25, 0.5, 0.75, 0.999):
        v, *_ = interpolate(table, c, (desc << 24) + int(frac * one_frac))
        lo, hi = sorted((table[desc], table[desc + 1]))
        exact = table[desc] + frac * (table[desc + 1] - table[desc])
        check(f"descending index {desc} fraction {frac}: stays between neighbours",
              lo <= v <= hi and abs(v - exact) <= 0.5, f"{table[desc]}->{table[desc+1]} gives {v}")
    for frac in (0.0, 0.5, 0.999):
        v, i, n, _ = interpolate(table, c, (255 << 24) + int(frac * one_frac))
        lo, hi = sorted((table[255], table[0]))
        check(f"last entry 255 fraction {frac} wraps to entry 0", n == 0 and lo <= v <= hi,
              f"{table[255]}->{table[0]} gives {v}")
    v_end, *_ = interpolate(table, c, U32)
    v_start, *_ = interpolate(table, c, 0)
    check("no discontinuity across phase wrap 0xFFFFFFFF -> 0", abs(v_end - v_start) <= 1,
          f"{v_end} then {v_start}")

    print("\n-- Sweep of 262,144 evenly spaced phases (all table entries and fractions) --")
    max_err_interp = max_err_near = 0.0
    lo_ok = True
    amp = (max(table) - min(table)) / 2
    step = 1 << 8
    for phase in range(0, 1 << 32, step * 64):
        v, i, n, f = interpolate(table, c, phase)
        lo, hi = sorted((table[i], table[n]))
        lo_ok &= lo <= v <= hi
        ideal = c["DAC_IDLE_CODE"] + amp * math.sin(2 * math.pi * phase / 2 ** 32)
        max_err_interp = max(max_err_interp, abs(v - ideal))
        max_err_near = max(max_err_near, abs(nearest(table, c, phase) - ideal))
    check("interpolated value always between the two neighbouring entries", lo_ok)
    print(f"INFO max deviation from an ideal sine (table units, before x3 gain): "
          f"nearest entry {max_err_near:.1f}, interpolated {max_err_interp:.2f}")

    print("\n-- Output stage --")
    one = c["ENV_GAIN_ONE"]
    ok = all(0 <= output_code(c, w, g) <= c["DAC_MAX_CODE"]
             for w in range(min(table), max(table) + 1, 7) for g in (0, 1, one // 3, one - 1, one))
    check("every output within DAC range 0..16383 for all waveform values and gains", ok)
    check("gain 0 gives exact midpoint", all(output_code(c, w, 0) == c["DAC_IDLE_CODE"] for w in table))
    check("full gain does not exceed existing amplitude",
          max(output_code(c, w, one) for w in table) == c["DAC_IDLE_CODE"] + (max(table) - c["DAC_IDLE_CODE"]) * 3)
    sym = all(output_code(c, c["DAC_IDLE_CODE"] + d, g) - c["DAC_IDLE_CODE"] ==
              -(output_code(c, c["DAC_IDLE_CODE"] - d, g) - c["DAC_IDLE_CODE"])
              for d in range(0, 2501, 13) for g in range(0, one + 1, 997))
    check("gain scaling symmetric about midpoint (no DC drift)", sym)
    same = all(output_code(c, nearest(table, c, p), one) == old_firmware_code(table, c, p)
               for p in range(0, 1 << 32, 1 << 20))
    check("options off (nearest entry, gain ONE) reproduces the pre-milestone DAC codes", same)

    print("\n-- Envelope (attack/release inside each note) --")
    for ms in (0, 1, 2, 5, 9, 10, 11, 25, 50, 125, 417, 1000, 4000, 40000):
        env = configure_envelope(c, ms)
        ns = env["note_samples"]
        gains = [gain_q15(c, env, n) for n in range(min(ns, 6000))]
        if ns > 6000:
            gains += [gain_q15(c, env, n) for n in range(ns - 6000, ns)]
        g_all = [gain_q15(c, env, n) for n in range(0, min(ns, 400))] + \
                [gain_q15(c, env, n) for n in range(max(0, ns - 400), ns + 3)]
        rises = all(gain_q15(c, env, n + 1) >= gain_q15(c, env, n) for n in range(env["attack"]))
        falls = all(gain_q15(c, env, n + 1) <= gain_q15(c, env, n)
                    for n in range(env["release_start"], env["release_end"] + 2))
        ends_zero = all(gain_q15(c, env, n) == 0 for n in range(env["release_end"], ns + 1))
        starts_zero = gain_q15(c, env, 0) == 0
        reaches_one = (env["attack"] < env["release_start"] and one in g_all) or \
                      (env["attack"] == env["release_start"] and max(g_all) <= one)
        inside = env["release_end"] <= max(ns - c["ENV_END_GUARD_SAMPLES"], 0) and \
                 env["attack"] + env["release"] <= env["release_end"]
        check(f"{ms:>5} ms note ({ns} samples): attack {env['attack']}, release {env['release']}, "
              f"silent from sample {env['release_end']}",
              starts_zero and rises and falls and ends_zero and reaches_one and inside and max(g_all) <= one)
    env = configure_envelope(c, 0)
    print(f"INFO 0 ms note policy: scheduled as 1 ms like the existing scheduler -> "
          f"{env['note_samples']} samples, ramps {env['attack']}/{env['release']}")

    print("\n{} failure(s).".format(failures))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
