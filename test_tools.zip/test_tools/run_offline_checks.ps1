<#
.SYNOPSIS
  Run every OFFLINE check (no board) and write the outputs to an evidence folder.

  Categories (kept separate on purpose):
    arithmetic on host ........ verify_waveform_math.py
    source text comparison .... check_code_moves.py
    source structure + header compile ... check_architecture.py
    UART transmit queue source checks ..... check_uart_tx.py
    link/build output inspection ......... check_link_output.py  (needs a built .out)
    host tooling model ........ board_tests\selftest_host_tooling.py (tests the test script only)

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File run_offline_checks.ps1 `
      -Image ..\build_output\gpiointerrupt_freertos.out -EvidenceDir ..\evidence
#>
param(
    [string]$Image = "",
    [string]$EvidenceDir = "..\evidence",
    [string]$Python = "python"
)
$ErrorActionPreference = "Continue"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $here
New-Item -ItemType Directory -Force -Path $EvidenceDir | Out-Null
$EvidenceDir = (Resolve-Path $EvidenceDir).Path
if ($Image -ne "") { $Image = (Resolve-Path $Image).Path }

function Run-Check($name, $outFile, [scriptblock]$cmd) {
    Write-Host "== $name"
    $target = Join-Path $EvidenceDir $outFile
    & $cmd 2>&1 | ForEach-Object { "$_" } | Out-File -FilePath $target -Encoding utf8
    Get-Content $target | Select-Object -Last 3
    Write-Host ""
}

Run-Check "waveform arithmetic (host)" "offline_waveform_math.txt" {
    & $Python "$here\verify_waveform_math.py" "$root\projects\gpiointerrupt_freertos" "$root\projects\freertos_kernel_glo" "$root\checkpoints\00_before_globals_rtos\gpiointerrupt\gpiointerrupt.c"
}
Run-Check "UART transmit queue: reply sizes, ownership, DONE critical section, diagnostics (source)" "offline_uart_tx.txt" {
    & $Python "$here\check_uart_tx.py"
}
Run-Check "moved-code comparison vs baseline (source text)" "offline_code_moves.txt" {
    & $Python "$here\check_code_moves.py" "$root\checkpoints\00_before_globals_rtos\gpiointerrupt\gpiointerrupt.c" "$root\projects\gpiointerrupt_freertos" --diffs
}
Run-Check "architecture / ISR rules / headers (source + header compile)" "offline_architecture.txt" {
    & $Python "$here\check_architecture.py"
}
if ($Image -ne "") {
    Run-Check "link output inspection" "offline_link_output.txt" {
        & $Python "$here\check_link_output.py" $Image
    }
}
Run-Check "host tooling self-test (protocol model; not firmware)" "offline_host_tooling_selftest.txt" {
    Push-Location "$here\board_tests"; & $Python -u selftest_host_tooling.py; Pop-Location
}
