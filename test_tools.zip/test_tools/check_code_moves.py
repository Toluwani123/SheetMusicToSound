"""Static move check: every function of the baseline gpiointerrupt.c must
reappear in the new modular sources either identically (after whitespace
normalisation and the documented rename map) or be listed with its diff.

This is a SOURCE-TEXT comparison. It proves that code was moved rather than
rewritten; it does not execute anything and says nothing about timing or sound.

Usage:  python check_code_moves.py <baseline gpiointerrupt.c> <src dir> [--diffs]
"""
import difflib
import re
import sys
from pathlib import Path

RENAMES = [  # (old, new): the documented identifier changes
    ("audioStopMidiNote", "Audio_stopNote"),
    ("audioStartMidiNote", "Audio_startNote"),
    ("playbackMsToTimerCounts", "Audio_msToCpuCounts"),
    ("playbackStop", "Playback_stop"),
    ("midiPayloadCrc32", "Uart_crc32"),
    ("UART0_writeTransferAck", "Uart_sendAck"),
    ("parseSimpleMidi", "Midi_parse"),
    ("MIDI_NOTE_MIN", "AUDIO_NOTE_MIN"),
    ("MIDI_NOTE_MAX", "AUDIO_NOTE_MAX"),
    ("MIDI_NOTE_NONE", "AUDIO_NOTE_NONE"),
]


# Baseline function -> new function name when the symbol itself was renamed.
FUNCTION_ALIASES = {
    "Audio_init": "Audio_hardwareInit",
    "AudioTimer_init": "Audio_timerInit",
    "playbackStartMelody": "Playback_start",
}


def strip_comments(text):
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    return re.sub(r"//[^\n]*", " ", text)


def norm(text):
    return re.sub(r"\s+", "", strip_comments(text))


def functions(text):
    """Yield (name, body) for top-level C functions (signature..closing brace)."""
    clean = strip_comments(text)
    pattern = re.compile(r"^(?:static\s+|inline\s+|volatile\s+)*[A-Za-z_][\w\s\*]*?\b([A-Za-z_]\w*)\s*\([^;{]*\)\s*\{", re.M)
    for m in pattern.finditer(clean):
        name = m.group(1)
        if name in ("if", "while", "for", "switch", "return"):
            continue
        depth, i = 0, m.end() - 1
        while i < len(clean):
            if clean[i] == "{":
                depth += 1
            elif clean[i] == "}":
                depth -= 1
                if depth == 0:
                    break
            i += 1
        yield name, clean[m.start():i + 1]


def main():
    base = Path(sys.argv[1]).read_text()
    srcdir = Path(sys.argv[2])
    show = "--diffs" in sys.argv
    new_text = "\n".join(p.read_text() for p in sorted(srcdir.glob("*.[ch]")))
    new_norm = norm(new_text)
    new_funcs = dict(functions(new_text))

    identical, changed, missing = [], [], []
    for name, body in functions(base):
        renamed = body
        for old, new in RENAMES:
            renamed = re.sub(r"\b" + old + r"\b", new, renamed)
        if norm(renamed) in new_norm:
            identical.append(name)
            continue
        target = FUNCTION_ALIASES.get(name)
        for old, new in RENAMES:
            if name == old:
                target = new
        target = target or name
        if target in new_funcs:
            changed.append((name, target, renamed, new_funcs[target]))
        else:
            missing.append(name)

    print(f"functions in baseline: {len(identical) + len(changed) + len(missing)}")
    print(f"  identical after rename map : {len(identical)}")
    print(f"  moved with edits           : {len(changed)}")
    for name, target, _, _ in changed:
        print(f"      {name} -> {target}")
    print(f"  not found by name          : {len(missing)}")
    for name in missing:
        print(f"      {name}  (expected: replaced by the new task/ISR design)")
    if show:
        for name, target, old, new in changed:
            print("\n=== diff:", name, "->", target)
            for line in difflib.unified_diff(
                    [l.strip() for l in old.split("\n") if l.strip()],
                    [l.strip() for l in new.split("\n") if l.strip()], lineterm="", n=1):
                print(line)


if __name__ == "__main__":
    main()
