/*
 * uart_tx_test.h -- TEST-ONLY: builds the SATURATION firmware.
 *
 * Copy this file into projects\gpiointerrupt_freertos\ (next to uart_tx.h) and rebuild.
 * uart_tx.h includes it automatically when it exists. UARTTxTask then sleeps this many
 * milliseconds after taking each reply from the queue, so the 8-slot queue fills and the
 * queue-full policy (250 ms submit timeout, receiver recovery) can be exercised on the
 * board with a PC sender. DELETE the file and rebuild to return to the release firmware.
 * The release project does not contain this file; check_architecture.py verifies that.
 */
#ifndef UART_TX_TEST_H
#define UART_TX_TEST_H

#define UART_TX_TEST_STALL_MS   400U

#endif /* UART_TX_TEST_H */
