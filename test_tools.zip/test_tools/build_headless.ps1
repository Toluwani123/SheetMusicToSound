<#
.SYNOPSIS
  Import the two CCS projects into a scratch workspace and build them with the
  headless CCS 21 build (the same GNU make + arm-none-eabi-gcc 9.2.1 + SysConfig
  1.4.0 chain the CCS GUI uses). No board is needed.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File build_headless.ps1 `
      -Workspace C:\temp\ws_glo `
      -KernelProject ..\projects\freertos_kernel_glo `
      -AppProject    ..\projects\gpiointerrupt_freertos `
      -LogFile       C:\temp\build_log.txt

  Output: <AppProject>\Debug\gpiointerrupt_freertos.out and .map
#>
param(
    [Parameter(Mandatory = $true)][string]$Workspace,
    [Parameter(Mandatory = $true)][string]$KernelProject,
    [Parameter(Mandatory = $true)][string]$AppProject,
    [string]$LogFile = "",
    [string]$Cli = "C:\ti\ccs2101\ccs\eclipse\ccs-server-cli.bat"
)

$ErrorActionPreference = "Stop"
$KernelProject = (Resolve-Path $KernelProject).Path
$AppProject = (Resolve-Path $AppProject).Path
$appName = Split-Path $AppProject -Leaf

# The CLI is a .bat; run it through cmd.exe so the dotted -ccs.* options reach it intact.
function Invoke-Ccs([string]$arguments) {
    cmd.exe /c "`"$Cli`" -workspace `"$Workspace`" $arguments"
}

foreach ($p in @($KernelProject, $AppProject)) {
    Write-Host "Importing $p"
    Invoke-Ccs "-application projectImport -ccs.location `"$p`""
}

Write-Host "Building $appName (Debug); the kernel library project is built as a reference"
if ($LogFile -ne "") {
    # Save as UTF-8 (PowerShell 5.1 Tee-Object would write UTF-16) and show the end of the log.
    Invoke-Ccs "-application projectBuild -ccs.projects $appName -ccs.configuration Debug" 2>&1 |
        ForEach-Object { "$_" } | Out-File -FilePath $LogFile -Encoding utf8
    Get-Content $LogFile | Select-Object -Last 8
} else {
    Invoke-Ccs "-application projectBuild -ccs.projects $appName -ccs.configuration Debug"
}
