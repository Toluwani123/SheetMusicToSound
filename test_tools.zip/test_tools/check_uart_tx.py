"""Static checks specific to the UART transmit queue (SOURCE INSPECTION, not a run).

  * every reply the firmware can queue is measured and must fit one queue item
    (UART_TX_MSG_MAX_CHARS); the worst case of each formatted reply is computed from
    the protocol limits, not from one example
  * queue item size, queue storage, and heap cost
  * every producer call site checks the returned status (a lost reply is never ignored
    silently, except the documented best-effort startup banner)
  * the 'critical section' that publishes DONE contains no blocking call
  * Fault hooks and ISRs do not reach the queue

Usage: python check_uart_tx.py [<app project dir>]
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "projects" / "gpiointerrupt_freertos"
failures = 0


def check(name, ok, detail=""):
    global failures
    print(("PASS " if ok else "FAIL ") + name + (("  -- " + detail) if detail else ""))
    if not ok:
        failures += 1


def strip(text):
    text = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), text, flags=re.S)
    return re.sub(r"//[^\n]*", "", text)


def c_len(literal):
    """Length of a C string literal body in characters (handles \\r \\n \\\\ \\")."""
    return len(re.sub(r"\\(?:[rn\\\"t]|x[0-9a-fA-F]{2}|[0-7]{1,3})", "x", literal))


def main():
    hdr = strip((APP / "uart_tx.h").read_text())
    tx = strip((APP / "uart_tx.c").read_text())
    files = {p.name: strip(p.read_text()) for p in APP.glob("*.c")}
    uart_h = strip((APP / "uart_task.h").read_text())

    item_chars = int(re.search(r"#define\s+UART_TX_MSG_MAX_CHARS\s+(\d+)U", hdr).group(1))
    depth = int(re.search(r"#define\s+UART_TX_QUEUE_DEPTH\s+(\d+)U", hdr).group(1))
    max_file = int(re.search(r"#define\s+MAX_MIDI_FILE_SIZE\s+(\d+)U", uart_h).group(1))
    digits = len(str(max_file))

    print("-- reply length (characters, including CR LF) vs the queue item --")
    replies = {}
    for name in ("ACK_READY", "ACK_RECEIVED"):          # sendAck: name SP decimal SP 8hex CRLF
        replies[name + " <len> <crc>  (worst case)"] = len(name) + 1 + digits + 1 + 8 + 2
    for src, text in files.items():
        for m in re.finditer(r'UartTx_(?:send|trySend)\s*\(\s*"((?:[^"\\]|\\.)*)"\s*\)', text):
            replies[f'{src}: "{m.group(1)}"'] = c_len(m.group(1))
        for m in re.finditer(r'(?:UARTReceiver_fail|Uart_payloadRejected)\s*\(\s*"([A-Z_]+)"', text):
            replies[f'{src}: {m.group(1)} line'] = len(m.group(1)) + 2
        for m in re.finditer(r'\?\s*"([A-Z_]+)"\s*:\s*"([A-Z_]+)"', text):     # (cond) ? "ERR_A" : "ERR_B"
            for g in (m.group(1), m.group(2)):
                if g.startswith("ERR_"):
                    replies[f'{src}: {g} line'] = len(g) + 2
        for m in re.finditer(r'\?\s*"((?:[^"\\]|\\.)*)"\s*:\s*"((?:[^"\\]|\\.)*)"', text):
            for g in (m.group(1), m.group(2)):
                if "DONE" in g:
                    replies[f'{src}: "{g}"'] = c_len(g)
    longest = max(replies.values())
    for label, n in sorted(replies.items(), key=lambda kv: -kv[1]):
        print(f"       {n:3d}  {label}")
    check(f"{len(replies)} distinct replies measured; longest is {longest} chars", len(replies) >= 12)
    check(f"longest reply ({longest}) fits UART_TX_MSG_MAX_CHARS ({item_chars})", longest <= item_chars)
    check("the sizes all derive from MAX_MIDI_FILE_SIZE", digits == 5, f"{max_file} -> {digits} digits")

    print("\n-- storage --")
    item_bytes = 1 + item_chars
    print(f"       item = 1 length byte + {item_chars} chars = {item_bytes} B;  queue = {depth} x {item_bytes} = {depth * item_bytes} B"
          " (+ kernel queue header, + 1024 B task stack + TCB)")
    check("queue item is length + characters by value (no pointer member)",
          re.search(r"typedef struct\s*\{\s*uint8_t length;\s*char\s+text\[UART_TX_MSG_MAX_CHARS\];\s*\}\s*UartTxMsg;", tx) is not None)
    check("queue is created with sizeof(UartTxMsg) items", "xQueueCreate(UART_TX_QUEUE_DEPTH, sizeof(UartTxMsg))" in tx)
    check("no per-reply dynamic allocation in uart_tx.c", not re.search(r"\b(?:pvPortMalloc|malloc|calloc)\b", tx))
    check("xQueueSend is given the address of a message copy, never a char pointer",
          all(re.search(r"xQueueSend\(\s*queue\s*,\s*msg\s*,", l) for l in tx.splitlines() if "xQueueSend(" in l))
    check("formatting appends are bounds-checked (refuse rather than truncate)",
          tx.count("if (msg->length >= UART_TX_MSG_MAX_CHARS)") >= 3)

    print("\n-- producers check the result --")
    for src in ("uart_task.c", "control_task.c"):
        text = files[src]
        calls = [(m.start(), m.group(0)) for m in re.finditer(r"[^\n]*\bUartTx_(?:send|sendAck|sendLine|trySend)\s*\([^\n]*", text)]
        bad = []
        for _, line in calls:
            ok = ("if (" in line or "(void)" in line or "published =" in line or "return" in line)
            if not ok:
                bad.append(line.strip())
        check(f"{src}: all {len(calls)} UartTx_send* calls test or deliberately discard the result", not bad, "; ".join(bad))
    voids = [l.strip() for l in files["uart_task.c"].splitlines() + files["control_task.c"].splitlines()
             if "(void)UartTx_" in l]
    check("only best-effort discards: startup banner and ERR_ line after the receiver already recovers",
          len(voids) == 2, str(voids))

    print("\n-- DONE publication is one non-blocking critical section --")
    m = re.search(r"static bool Control_reportCompletion\(void\)\s*\{(.*?)\n\}\n", files["control_task.c"], re.S)
    body = m.group(1) if m else ""
    section = re.search(r"taskENTER_CRITICAL\(\);(.*?)taskEXIT_CRITICAL\(\);\s*\n\s*if \(published\)", body, re.S)
    inner = section.group(1) if section else ""
    check("critical section found in Control_reportCompletion", bool(inner))
    check("section decides (completion ready, receiver idle) and enqueues together",
          all(k in inner for k in ("Playback_completionReady", "Uart_receiverIdle", "UartTx_trySend", "Playback_takeCompletion")))
    check("section never blocks (no vTaskDelay, no waiting send, no semaphore take)",
          not re.search(r"vTaskDelay|UartTx_send\(|UartTx_waitForSpace|xSemaphoreTake|xQueueReceive", inner))
    check("slot is verified before the completion is consumed",
          inner.find("UartTx_spacesAvailable") < inner.find("Playback_takeCompletion") and
          inner.find("UartTx_trySend") < inner.find("Playback_takeCompletion"))

    print("\n-- STOP cancels audio before touching the queue --")
    acc = re.search(r"s_hooks->stopPlayback\(\);(.*?)return;", files["uart_task.c"], re.S)
    check("stopPlayback hook runs first in the STOP branch; the queue is touched after it",
          bool(acc) and acc.group(1).find("UartTx_send") > -1 and files["uart_task.c"].find("s_hooks->stopPlayback();") <
          files["uart_task.c"].find('UartTx_send("ACK_STOPPED\\r\\nIDLE\\r\\n")'))
    check("ACK_STOPPED and IDLE are ONE queue item", 'UartTx_send("ACK_STOPPED\\r\\nIDLE\\r\\n")' in files["uart_task.c"])
    check("DONE and IDLE are ONE queue item", '"DONE\\r\\nIDLE\\r\\n"' in files["control_task.c"])

    print("\n-- nothing time-critical reaches the queue --")
    for isr_file in ("audio.c", "playback.c"):
        check(f"{isr_file} has no UartTx_ call", "UartTx_" not in files[isr_file])
    check("fault hooks (main_freertos.c) have no UartTx_ call", "UartTx_" not in files["main_freertos.c"])
    rx_isr = re.search(r"static void uart0RxIsr\(void\)\s*\{(.*?)\n\}\n", files["uart_task.c"], re.S).group(1)
    check("uart0RxIsr has no UartTx_ call", "UartTx_" not in rx_isr)

    print("\n-- diagnostics fields exist and have a stated writer --")
    glob = (APP / "globals.h").read_text()
    for field in ("TxMsgsQueued", "TxMsgsTransmitted", "TxBytesTransmitted", "TxQueueFullCount", "TxSubmitTimeoutCount",
                  "TxFormatErrorCount", "TxNotReadyCount", "TxFaultCount", "TxMaxQueueDepth", "TxQueueDepthNow",
                  "TxInFlight", "StackFreeMinTxWords"):
        line = next((l for l in glob.splitlines() if re.search(r"\b" + field + r"\s*;", l)), "")
        check(f"{field} declared volatile with a writer comment", "volatile uint32_t" in line and "/*" in line)
    check("multi-writer counters use atomic adds",
          all(re.search(r"UartTx_count\(&Glo\.Diagnostics\." + f + r"\)", tx) for f in
              ("TxMsgsQueued", "TxQueueFullCount", "TxSubmitTimeoutCount", "TxFormatErrorCount", "TxNotReadyCount")))

    print(f"\n{failures} failure(s).")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
