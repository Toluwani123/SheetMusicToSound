"""Board checks for the queue-based UART transmit path (UARTTxQueue + UARTTxTask).

python -u check_tx_queue.py                    # Q1, Q2, Q4 on the RELEASE firmware
python -u check_tx_queue.py --test Q3          # Q3 only on the SATURATION firmware
python -u check_tx_queue.py --port COM7 --test Q2 --count 120

Uses only the PC sender protocol (newmiditst.py beside this script; SMID v2 unchanged).
Nothing here needs the Raspberry Pi sender.

Q1  reply burst. N STOP frames in ONE write (N = --burst, default 6, fits the queue).
    Each STOP is answered by one queue item "ACK_STOPPED\\r\\nIDLE\\r\\n". PASS = exactly
    N x (ACK_STOPPED, IDLE), in order, nothing else, then a normal song to DONE + IDLE.
    Whole lines only: an interleaved or truncated reply cannot parse as a line.
Q2  queue pressure on the release firmware. --count STOP frames (default 120) arrive
    faster than their 19-character replies can be sent (16 bytes in vs 19 bytes out
    per frame), so the 8-slot queue fills and UART0ReadTask must wait for space.
    PASS = every reply arrives, in order, nothing lost. Then read CCS:
    TxQueueFullCount > 0, TxMaxQueueDepth == 8, TxSubmitTimeoutCount == 0.
Q3  queue-full policy. ONLY on the saturation firmware (UARTTxTask delays 400 ms per
    reply, test_tools/saturation). --burst STOP frames (default 16) overrun the queue
    and the 250 ms submit timeout. PASS = complete (ACK_STOPPED, IDLE) pairs for the
    replies that were accepted, then a single recovery IDLE, no partial line, no stray
    DONE, and a normal song still plays afterwards. Read CCS: TxSubmitTimeoutCount >= 1.
Q4  natural completion racing STOP. STOP is sent at offsets around the moment the song
    ends (measured on a calibration run). Allowed outcomes only:
      A  ACK_STOPPED, IDLE                    (STOP won; completion discarded)
      B  DONE, IDLE, ACK_STOPPED, IDLE        (completion published first, then STOP)
      C  DONE, ACK_STOPPED, IDLE              (STOP header was mid-receive at completion)
    A DONE after ACK_STOPPED is a stale completion and FAILS. Each cycle ends by
    starting the next song immediately (restart straight after a cancel).

UART lines prove ordering, not sound. LISTEN during Q4: every STOP silences the tone.
"""
import argparse
import re
import sys
import time

import check_rtos_extra as extra
import newmiditst as sender

SONG = "d5_reference.mid"
PAIR = ["ACK_STOPPED", "IDLE"]


def stop_frames(count):
    return sender.make_stop_header() * count


def drain(reader, quiet_seconds, limit=5000):
    """Read lines until nothing arrives for quiet_seconds. A partial line fails."""
    lines = []
    while len(lines) < limit:
        try:
            line = reader.read_line(sender.time.monotonic() + quiet_seconds)
        except sender.ResponseTimeout:
            if reader.pending:
                raise sender.TransferError("Partial line left on the wire (truncated reply): "
                                           + bytes(reader.pending).decode("ascii", "replace"))
            return lines
        lines.append(line)
    raise sender.TransferError("More lines than expected; the board keeps talking.")


def normal_song(port, reader, why):
    print(f"\n{why}: a normal song must still play", flush=True)
    extra.start(port, reader, extra.load(SONG))
    extra.expect(reader, "DONE", timeout=10.0)
    extra.expect(reader, "IDLE")


def q1_burst(port, burst):
    print(f"\n=== Q1: {burst} STOP frames in one write; replies must be {burst} x (ACK_STOPPED, IDLE) ===")
    reader = sender.LineReader(port)
    sender.write_all(port, stop_frames(burst))
    lines = drain(reader, 0.6)
    print("lines:", len(lines), flush=True)
    if lines != PAIR * burst:
        raise sender.TransferError(f"Burst replies wrong or out of order: {lines}")
    normal_song(port, reader, "after the burst")
    print("PASS Q1: every reply arrived whole and in order.")


def q2_pressure(port, count):
    print(f"\n=== Q2: {count} STOP frames in one write (queue pressure, release firmware) ===")
    reader = sender.LineReader(port)
    started = sender.time.monotonic()
    sender.write_all(port, stop_frames(count))
    lines = drain(reader, 0.8, limit=count * 2 + 10)
    seconds = sender.time.monotonic() - started - 0.8
    print(f"lines: {len(lines)} in about {seconds:.2f} s", flush=True)
    if lines != PAIR * count:
        pairs = sum(1 for i in range(0, len(lines) - 1, 2) if lines[i:i + 2] == PAIR)
        raise sender.TransferError(f"Replies lost, reordered or interleaved: {pairs} clean pairs of {count}; "
                                   f"first lines {lines[:6]} ... last {lines[-4:]}")
    normal_song(port, reader, "after the flood")
    print("PASS Q2: no reply lost or interleaved. NOW READ CCS: TxQueueFullCount > 0, "
          "TxMaxQueueDepth == 8, TxSubmitTimeoutCount == 0, RxOverflowCount == 0.")


def q3_queue_full(port, burst):
    print(f"\n=== Q3: {burst} STOP frames against the SATURATION firmware (400 ms per reply) ===")
    reader = sender.LineReader(port)
    sender.write_all(port, stop_frames(burst))
    lines = drain(reader, 2.5, limit=burst * 2 + 10)
    print("lines:", lines, flush=True)
    text = " ".join(lines)
    if not re.fullmatch(r"(?:ACK_STOPPED IDLE ?)*(?:IDLE)?", text):
        raise sender.TransferError(f"Unexpected, partial or interleaved replies: {lines}")
    pairs = text.count("ACK_STOPPED")
    lone_idle = (len(lines) - 2 * pairs) == 1
    if pairs >= burst:
        raise sender.TransferError("The queue never overflowed: this is not the saturation firmware, "
                                   "or --burst is too small (needs more than 9 replies).")
    if pairs < 1 or not lone_idle:
        raise sender.TransferError(f"Expected accepted replies then one recovery IDLE; got {pairs} pairs, "
                                   f"lone IDLE: {lone_idle}")
    print(f"{pairs} replies were accepted and sent whole; the rest were refused (counted) and the "
          "receiver recovered with one IDLE.")
    normal_song(port, reader, "after queue-full recovery")
    print("PASS Q3. NOW READ CCS: TxSubmitTimeoutCount >= 1, TxQueueFullCount >= 1; after the song, "
          "TxMsgsQueued == TxMsgsTransmitted.")


def q4_completion_vs_stop(port, cycles):
    print(f"\n=== Q4: STOP around natural completion, {cycles} cycles ===")
    data = extra.load(SONG)
    reader = sender.LineReader(port)

    extra.start(port, reader, data)
    t_playing = sender.time.monotonic()
    extra.expect(reader, "DONE", timeout=10.0)
    song = sender.time.monotonic() - t_playing
    extra.expect(reader, "IDLE")
    print(f"calibration: PLAYING -> DONE took {song:.3f} s")

    offsets = (-0.10, -0.05, -0.02, -0.005, 0.0, 0.005, 0.02, 0.05, 0.10)
    allowed = ([ "ACK_STOPPED", "IDLE"], ["DONE", "IDLE", "ACK_STOPPED", "IDLE"], ["DONE", "ACK_STOPPED", "IDLE"])
    seen = {"A": 0, "B": 0, "C": 0}
    for cycle in range(cycles):
        offset = offsets[cycle % len(offsets)]
        extra.start(port, reader, data)
        t_playing = sender.time.monotonic()
        wait = max(0.0, song + offset - (sender.time.monotonic() - t_playing))
        sender.time.sleep(wait)
        sender.write_all(port, sender.make_stop_header())
        lines = drain(reader, 0.5)
        outcome = [k for k, v in zip("ABC", allowed) if lines == v]
        print(f"cycle {cycle + 1}/{cycles}  STOP at song{offset:+.3f} s -> {lines}"
              f"  [{outcome[0] if outcome else 'NOT ALLOWED'}]", flush=True)
        if not outcome:
            raise sender.TransferError(f"Stale or malformed completion/STOP sequence: {lines}")
        seen[outcome[0]] += 1
        # next iteration restarts immediately, with no pause after the cancel
    print(f"outcomes: A={seen['A']} B={seen['B']} C={seen['C']} (all allowed; B/C show the race window was hit)")
    normal_song(port, reader, "after the sweep")
    print("PASS Q4: no DONE ever followed an ACK_STOPPED; restart after each cancel worked.")


TESTS = {"Q1": q1_burst, "Q2": q2_pressure, "Q3": q3_queue_full, "Q4": q4_completion_vs_stop}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--port", default="COM5")
    parser.add_argument("--test", choices=sorted(TESTS), action="append",
                        help="run only this check (repeatable). Default: Q1 Q2 Q4 (Q3 needs the saturation image)")
    parser.add_argument("--burst", type=int, default=None, help="Q1 default 6, Q3 default 16")
    parser.add_argument("--count", type=int, default=120, help="Q2 STOP frames (default 120)")
    parser.add_argument("--cycles", type=int, default=18, help="Q4 cycles (default 18)")
    args = parser.parse_args(argv)
    if sender.serial is None:
        print("Install pySerial: python -m pip install pyserial", file=sys.stderr)
        return 2
    selected = args.test or ["Q1", "Q2", "Q4"]
    try:
        with sender.serial.Serial(args.port, sender.BAUD, bytesize=sender.serial.EIGHTBITS,
                                  parity=sender.serial.PARITY_NONE, stopbits=sender.serial.STOPBITS_ONE,
                                  timeout=0.05, write_timeout=sender.WRITE_TIMEOUT,
                                  xonxoff=False, rtscts=False, dsrdtr=False) as port:
            sender.synchronize(port)
            for key in selected:
                if key == "Q1":
                    q1_burst(port, args.burst or 6)
                elif key == "Q2":
                    q2_pressure(port, args.count)
                elif key == "Q3":
                    q3_queue_full(port, args.burst or 16)
                else:
                    q4_completion_vs_stop(port, args.cycles)
        print(f"\nPASS: queue checks {', '.join(selected)} completed without a board reset.")
        print("Now read the Glo.Diagnostics Tx* counters in CCS (see HARDWARE_TEST_GUIDE.md).")
        return 0
    except (OSError, ValueError, sender.TransferError, sender.serial.SerialException) as exc:
        print("FAIL:", exc, file=sys.stderr)
        print("Keep this log. If a song is still playing: python newmiditst.py --stop", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nCancelled; use python newmiditst.py --stop if a song is playing.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
