"""Milestone board tests A-E for interpolation + note ramps (SMID v2, unchanged protocol).

python -u check_milestone_playback.py            # all tests, A..E
python -u check_milestone_playback.py --test D   # one test (A, B, C, D or E)
python -u check_milestone_playback.py --port COM7

Uses newmiditst.py beside this script and the MIDI files in this folder.
UART lines prove transfer/scheduling/STOP behaviour only. YOU must listen for
pitch, buzz, clicks, rests and silence and write them in MILESTONE_TEST_RECORD.txt.
"""
import argparse
from pathlib import Path
import sys

import newmiditst as sender

ROOT = Path(__file__).resolve().parent


def expect(reader, expected, timeout=5.0):
    line = reader.read_line(sender.time.monotonic() + timeout)
    print("MSP:", line, flush=True)
    if line != expected:
        raise sender.TransferError(f"Expected {expected!r}; received {line!r}")
    return line


def quiet(reader, seconds):
    """No response may arrive during this interval (e.g. no DONE after STOP)."""
    try:
        line = reader.read_line(sender.time.monotonic() + seconds)
    except sender.ResponseTimeout:
        if reader.pending:
            raise sender.TransferError("Unexpected partial response during quiet check")
        return
    raise sender.TransferError("Unexpected response during quiet check: " + line)


def midi_seconds(data):
    """Last Note Off time for this project's Type 0 subset (tempo-aware)."""
    def vlq(i):
        value = 0
        while True:
            b = data[i]
            i += 1
            value = (value << 7) | (b & 0x7F)
            if b < 0x80:
                return value, i
    division = int.from_bytes(data[12:14], "big")
    i, us, tempo, running, last_off = 22, 0.0, 500000, 0, 0.0
    while i < len(data):
        delta, i = vlq(i)
        us += delta * tempo / division
        status = data[i]
        if status < 0x80:
            status = running
        else:
            i += 1
        if status == 0xFF:
            kind = data[i]
            length, i = vlq(i + 1)
            if kind == 0x51:
                tempo = int.from_bytes(data[i:i + 3], "big")
            if kind == 0x2F:
                break
            i += length
            running = 0
            continue
        running = status
        kind = status & 0xF0
        size = 1 if kind in (0xC0, 0xD0) else 2
        if kind == 0x80 or (kind == 0x90 and data[i + 1] == 0):
            last_off = us
        i += size
    return last_off / 1e6


def load(name):
    for folder in (ROOT / "midi_tests_milestone", ROOT / "reference_midi", ROOT):
        if (folder / name).is_file():
            return (folder / name).read_bytes()
    raise FileNotFoundError(name + " not found beside this script")


def start(port, data):
    reader = sender.LineReader(port)
    header, crc = sender.make_header(data)
    print(f"Payload: {len(data)} bytes; CRC32 {crc:08X}", flush=True)
    sender.write_all(port, header)
    sender.verify_transfer_ack(sender.wait_response(reader, "ACK_READY"), "ACK_READY", len(data), crc)
    sender.write_all(port, data)
    sender.verify_transfer_ack(sender.wait_response(reader, "ACK_RECEIVED"), "ACK_RECEIVED", len(data), crc)
    expect(reader, "ACK_VALID")
    started = sender.time.monotonic()
    expect(reader, "PLAYING")
    return reader, started


def play_complete(port, name):
    data = load(name)
    seconds = midi_seconds(data)
    print(f"\n>> {name}: expected about {seconds:.3f} s", flush=True)
    reader, started = start(port, data)
    expect(reader, "DONE", timeout=max(10.0, seconds + 5.0))
    elapsed = sender.time.monotonic() - started
    expect(reader, "IDLE")
    allowance = max(0.25, seconds * 0.02)
    print(f"Duration: host ACK_VALID-to-DONE {elapsed:.3f} s; MIDI {seconds:.3f} s; allowance {allowance:.3f} s")
    if abs(elapsed - seconds) > allowance:
        raise sender.TransferError("Playback duration outside coarse allowance: ramps must not lengthen the track")
    return elapsed


def stop_during(port, name, after, where):
    print(f"\n>> {name}: STOP {after:.3f} s after ACK_VALID ({where})", flush=True)
    reader, started = start(port, load(name))
    quiet(reader, max(0.0, after - (sender.time.monotonic() - started)))
    sender.stop_playback(port, reader)
    print("LISTEN: sound must cut off at once and stay silent for 2 s (no restart, no stuck tone).", flush=True)
    quiet(reader, 2.0)


def test_a(port):
    print("\n=== TEST A: low / middle / high pitches ===")
    print("LISTEN: four steady tones C3 (MIDI 48), C4 (60), A4 (69 = 440 Hz), C6 (84), each 2 s, 0.5 s silence between.")
    print("        No buzz, wobble or interruptions; each tone starts and ends softly (5 ms ramps). A tuner app on A4 should read ~440 Hz.")
    play_complete(port, "m6_pitch_range.mid")
    print("PASS A (UART/duration). Record what you heard.")


def test_b(port):
    print("\n=== TEST B: repeated, adjacent and short notes ===")
    print("LISTEN: 8 separate A4 pulses (each attack audible), a smooth fast C-major scale, then six C5 blips that get")
    print("        shorter (50 -> 1 ms; the last ones are faint ticks), a near-silent 0 ms note, 2.5 s silence, final G4.")
    play_complete(port, "m6_envelope_edges.mid")
    print("LISTEN: repeated C4 / repeated C3 pairs stay distinct, short rests audible, C3 and C6 extremes present.")
    play_complete(port, "musical_features.mid")
    print("PASS B (UART/duration: ramps did not lengthen either track). Record what you heard.")


def test_c(port):
    print("\n=== TEST C: familiar melodies with rests ===")
    print("LISTEN: Twinkle Twinkle - correct notes, rhythm, and silent rests between phrases.")
    play_complete(port, "twinkle_simple.mid")
    print("LISTEN: Ode to Joy - back-to-back notes with no gaps; repeated notes still separate.")
    play_complete(port, "ode_to_joy_msp.mid")
    print("PASS C (UART/duration). Record what you heard.")


def test_d(port):
    print("\n=== TEST D: STOP during playback, then a new transfer ===")
    # 20 ms notes are ~5 ms attack, ~8 ms sustain, ~5 ms release: these STOPs land in or near a ramp.
    for after in (1.003, 2.509, 4.015):
        stop_during(port, "m6_stop_ramps.mid", after, "inside a 20 ms note: attack/sustain/release region")
        play_complete(port, "d5_reference.mid")
    stop_during(port, "d4_sustained.mid", 2.0, "middle of a 4 s sustained C4")
    play_complete(port, "d5_reference.mid")
    print("PASS D (UART): STOP acknowledged, no delayed DONE, next file played to DONE each time.")


def test_e(port, runs=5):
    print(f"\n=== TEST E: normal completion, {runs} consecutive runs ===")
    print("LISTEN: C4 E4 G4 C5 each run; complete silence after every DONE (no stuck or hum tone).")
    for run in range(1, runs + 1):
        print(f"\nRun {run} of {runs}")
        play_complete(port, "d5_reference.mid")
    print(f"PASS E (UART/duration): {runs} runs finished and returned to IDLE.")


TESTS = {"A": test_a, "B": test_b, "C": test_c, "D": test_d, "E": test_e}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--port", default="COM5", help="serial port (default COM5)")
    parser.add_argument("--test", choices=sorted(TESTS), action="append",
                        help="run only this test; repeat for several (default: all)")
    args = parser.parse_args(argv)
    if sender.serial is None:
        print("Install pySerial: python -m pip install pyserial", file=sys.stderr)
        return 2
    selected = args.test or sorted(TESTS)
    try:
        print("Milestone tests", ", ".join(selected), "on", args.port, "at 115200 baud.")
        print("Keep CCS running (no breakpoints); close other serial monitors; keep the same volume throughout.")
        with sender.serial.Serial(args.port, sender.BAUD, bytesize=sender.serial.EIGHTBITS,
                                  parity=sender.serial.PARITY_NONE, stopbits=sender.serial.STOPBITS_ONE,
                                  timeout=0.05, write_timeout=sender.WRITE_TIMEOUT,
                                  xonxoff=False, rtscts=False, dsrdtr=False) as port:
            sender.synchronize(port)
            for key in selected:
                TESTS[key](port)
        print(f"\nPASS: milestone tests {', '.join(selected)} completed without a board reset.")
        print("UART checks cannot judge audio quality: fill in your listening observations.")
        return 0
    except (OSError, ValueError, sender.TransferError, sender.serial.SerialException) as exc:
        print("FAIL:", exc, file=sys.stderr)
        print("Keep this log. If a song is still playing: python newmiditst.py --stop", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nCancelled; an active song continues until DONE or python newmiditst.py --stop.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
