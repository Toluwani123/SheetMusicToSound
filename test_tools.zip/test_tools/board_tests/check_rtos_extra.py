"""Extra board checks for the FreeRTOS build: races the older suites do not target.

python -u check_rtos_extra.py                 # all three checks
python -u check_rtos_extra.py --test R1       # one check (R1, R2 or R3)
python -u check_rtos_extra.py --port COM7 --cycles 40

R1  rapid STOP / restart: STOP at varied points after ACK_VALID (including
    immediately), then require ACK_STOPPED + IDLE, then 0.4 s of NOTHING (a stale
    DONE / PLAYING from the cancelled song is a failure); every 4th cycle starts the
    next song straight away. Ends with one normal song played to DONE + IDLE.
R2  truncated header: send 9 of 16 header bytes and then NOTHING. The firmware
    must time out by itself (ERR_TIMEOUT about 1 s, then IDLE about 0.25 s later).
R3  extra data at the payload handoff: after ACK_READY send the payload plus a
    complete STOP frame in one write. Either outcome is acceptable, silence is not:
      A) ERR_SIZE, IDLE            (extra input seen at the handoff)
      B) ACK_RECEIVED, ACK_VALID, PLAYING, ACK_STOPPED, IDLE
                                   (the queued STOP was honoured in order)
    Anything else, or the song playing on with no ACK_STOPPED, fails.

UART lines prove sequencing only. LISTEN during R1: sound must cut off at each STOP
and nothing may restart. Uses newmiditst.py beside this script (SMID v2, unchanged).
"""
import argparse
from pathlib import Path
import sys
import time

import newmiditst as sender

ROOT = Path(__file__).resolve().parent


def load(name):
    for folder in (ROOT / "reference_midi", ROOT / "midi_tests_milestone", ROOT):
        if (folder / name).is_file():
            return (folder / name).read_bytes()
    raise FileNotFoundError(name)


def expect(reader, expected, timeout=5.0):
    line = reader.read_line(sender.time.monotonic() + timeout)
    print("MSP:", line, flush=True)
    if line != expected:
        raise sender.TransferError(f"Expected {expected!r}; received {line!r}")
    return line


def quiet(reader, seconds, what):
    """Nothing at all may arrive for 'seconds'."""
    try:
        line = reader.read_line(sender.time.monotonic() + seconds)
    except sender.ResponseTimeout:
        if reader.pending:
            raise sender.TransferError("Partial unexpected response during quiet check: " + what)
        return
    raise sender.TransferError(f"Unexpected response during quiet check ({what}): {line}")


def start(port, reader, data):
    header, crc = sender.make_header(data)
    sender.write_all(port, header)
    sender.verify_transfer_ack(sender.wait_response(reader, "ACK_READY"), "ACK_READY", len(data), crc)
    sender.write_all(port, data)
    sender.verify_transfer_ack(sender.wait_response(reader, "ACK_RECEIVED"), "ACK_RECEIVED", len(data), crc)
    expect(reader, "ACK_VALID")
    expect(reader, "PLAYING")


def r1_rapid_stop_restart(port, cycles):
    print(f"\n=== R1: {cycles} rapid STOP/restart cycles (stale DONE / resurrected start check) ===")
    print("LISTEN: every start is C4 E4 G4 C5; each STOP must cut it off at once; no tone may restart.")
    data = load("d5_reference.mid")
    delays = (0.0, 0.01, 0.05, 0.2, 0.7)
    reader = sender.LineReader(port)
    for cycle in range(1, cycles + 1):
        delay = delays[cycle % len(delays)]
        print(f"\ncycle {cycle}/{cycles}: STOP {delay:.2f} s after PLAYING", flush=True)
        start(port, reader, data)
        if delay > 0.0:
            quiet(reader, delay, "between PLAYING and STOP")
        sender.stop_playback(port, reader)
        if cycle % 4 != 0:
            quiet(reader, 0.4, "after STOP: no DONE / PLAYING / ACK may follow")
        else:
            print("(this cycle restarts immediately)")
    # The last STOP left the receiver idle; a normal song must still run to DONE + IDLE.
    print("\nfinal check: a normal song after all the cancellations")
    quiet(reader, 0.4, "after the last STOP")
    start(port, reader, data)
    expect(reader, "DONE", timeout=8.0)
    expect(reader, "IDLE")
    print("PASS R1: no stale completion or restart; normal playback still works.")


def r2_truncated_header(port):
    print("\n=== R2: truncated header must time out by itself ===")
    reader = sender.LineReader(port)
    header, _ = sender.make_header(load("d5_reference.mid"))
    sender.write_all(port, header[:9])
    sent = sender.time.monotonic()
    print("sent 9 of 16 header bytes; sending nothing more ...", flush=True)
    line = reader.read_line(sent + 4.0)
    waited = sender.time.monotonic() - sent
    print(f"MSP: {line}   ({waited:.2f} s after the partial header)", flush=True)
    if line != "ERR_TIMEOUT":
        raise sender.TransferError(f"Expected ERR_TIMEOUT, received {line!r}")
    if not 0.8 <= waited <= 2.5:
        raise sender.TransferError(f"ERR_TIMEOUT arrived after {waited:.2f} s; expected about 1.0 s")
    idle_wait = sender.time.monotonic()
    expect(reader, "IDLE", timeout=3.0)
    print(f"IDLE {sender.time.monotonic() - idle_wait:.2f} s later (quiet interval 0.25 s)")
    data = load("d5_reference.mid")
    start(port, reader, data)
    expect(reader, "DONE", timeout=8.0)
    expect(reader, "IDLE")
    print("PASS R2: timeout without further input, recovery, then a normal song.")


def r3_extra_data_at_handoff(port):
    print("\n=== R3: STOP frame glued to the end of the payload ===")
    data = load("d5_reference.mid")
    reader = sender.LineReader(port)
    header, crc = sender.make_header(data)
    sender.write_all(port, header)
    sender.verify_transfer_ack(sender.wait_response(reader, "ACK_READY"), "ACK_READY", len(data), crc)
    sender.write_all(port, data + sender.make_stop_header())
    lines = []
    deadline = sender.time.monotonic() + 4.0
    try:
        while sender.time.monotonic() < deadline:
            line = reader.read_line(deadline)
            print("MSP:", line, flush=True)
            lines.append(line.split()[0])
            if lines[-2:] == ["ACK_STOPPED", "IDLE"] or lines[-2:] == ["ERR_SIZE", "IDLE"]:
                break
    except sender.ResponseTimeout:
        pass
    outcome_a = lines == ["ERR_SIZE", "IDLE"]
    outcome_b = lines == ["ACK_RECEIVED", "ACK_VALID", "PLAYING", "ACK_STOPPED", "IDLE"]
    if not (outcome_a or outcome_b):
        print("FAIL R3: unexpected sequence, sending STOP to clean up:", lines, flush=True)
        try:
            sender.stop_playback(port, reader)
        except sender.TransferError:
            pass
        raise sender.TransferError(f"Extra data at the handoff was neither rejected nor honoured: {lines}")
    print("outcome", "A (ERR_SIZE: extra input caught at the handoff)" if outcome_a
          else "B (STOP honoured after playback started)")
    quiet(reader, 1.0, "after the glued STOP: silence expected, no DONE")
    start(port, reader, data)
    expect(reader, "DONE", timeout=8.0)
    expect(reader, "IDLE")
    print("PASS R3: the glued frame was not silently lost; the next song plays normally.")


TESTS = {"R1": None, "R2": r2_truncated_header, "R3": r3_extra_data_at_handoff}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--port", default="COM5")
    parser.add_argument("--test", choices=sorted(TESTS), action="append", help="run only this check (repeatable)")
    parser.add_argument("--cycles", type=int, default=20, help="R1 STOP/restart cycles (default 20)")
    args = parser.parse_args(argv)
    if sender.serial is None:
        print("Install pySerial: python -m pip install pyserial", file=sys.stderr)
        return 2
    selected = args.test or sorted(TESTS)
    try:
        with sender.serial.Serial(args.port, sender.BAUD, bytesize=sender.serial.EIGHTBITS,
                                  parity=sender.serial.PARITY_NONE, stopbits=sender.serial.STOPBITS_ONE,
                                  timeout=0.05, write_timeout=sender.WRITE_TIMEOUT,
                                  xonxoff=False, rtscts=False, dsrdtr=False) as port:
            sender.synchronize(port)
            for key in selected:
                if key == "R1":
                    r1_rapid_stop_restart(port, args.cycles)
                else:
                    TESTS[key](port)
        print(f"\nPASS: RTOS extra checks {', '.join(selected)} completed without a board reset.")
        print("UART lines cannot judge audio: record what you heard during R1.")
        return 0
    except (OSError, ValueError, sender.TransferError, sender.serial.SerialException) as exc:
        print("FAIL:", exc, file=sys.stderr)
        print("Keep this log. If a song is still playing: python newmiditst.py --stop", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nCancelled; use python newmiditst.py --stop if a song is playing.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
