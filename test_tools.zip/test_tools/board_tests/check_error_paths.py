"""Board checks for the error replies that now travel through the transmit queue.

python -u check_error_paths.py                # E1 E2 E3 E4
python -u check_error_paths.py --test E1 --port COM7

E1  CRC rejection:   header with a wrong CRC, correct payload.
      expect ACK_READY, ERR_CRC, IDLE            then a normal song plays to DONE + IDLE
E2  invalid MIDI:    payload that is not MIDI, correct CRC.
      expect ACK_READY, ACK_RECEIVED, ERR_MIDI, IDLE   then a normal song
E3  size limits:     length 0, then length 16385 (MAX_MIDI_FILE_SIZE + 1), header only.
      each: ERR_SIZE, IDLE                       then a normal song
E4  two producers:   while a song plays, a second header is refused (UART0ReadTask
      produces ERR_BUSY and the recovery IDLE) and the song then finishes (PayloadTask
      produces DONE). Allowed orders:
        ERR_BUSY, IDLE, DONE, IDLE
        ERR_BUSY, DONE, IDLE        (completion landed while the receiver was recovering)
      The song must keep playing through the refusal (listen: no cut-off).

UART lines prove sequencing only. Uses newmiditst.py beside this script (SMID v2, unchanged).
"""
import argparse
import struct
import sys
import zlib

import check_rtos_extra as extra
import check_tx_queue as txq
import newmiditst as sender

SONG = "d5_reference.mid"


def header(length, crc):
    return struct.pack("<4sBB2xII", b"SMID", sender.PROTOCOL_VERSION, sender.COMMAND_MIDI, length, crc)


def recover_and_play(port, reader, why):
    txq.normal_song(port, reader, why)


def e1_bad_crc(port):
    print("\n=== E1: wrong CRC must give ERR_CRC then IDLE, then normal playback ===")
    reader = sender.LineReader(port)
    data = extra.load(SONG)
    good = zlib.crc32(data) & 0xFFFFFFFF
    bad = good ^ 0x00000001
    sender.write_all(port, header(len(data), bad))
    sender.verify_transfer_ack(_expect_ack(reader, "ACK_READY"), "ACK_READY", len(data), bad)
    sender.write_all(port, data)
    extra.expect(reader, "ERR_CRC", timeout=5.0)
    extra.expect(reader, "IDLE", timeout=3.0)
    recover_and_play(port, reader, "after the CRC rejection")
    print("PASS E1")


def _expect_ack(reader, name):
    line = reader.read_line(sender.time.monotonic() + 5.0)
    print("MSP:", line, flush=True)
    if line.split()[0] != name:
        raise sender.TransferError(f"Expected {name}; received {line!r}")
    return line


def e2_invalid_midi(port):
    print("\n=== E2: not-MIDI payload with a correct CRC must give ERR_MIDI then IDLE ===")
    reader = sender.LineReader(port)
    data = b"THIS IS NOT A MIDI FILE " * 4
    head, crc = sender.make_header(data)
    sender.write_all(port, head)
    sender.verify_transfer_ack(_expect_ack(reader, "ACK_READY"), "ACK_READY", len(data), crc)
    sender.write_all(port, data)
    sender.verify_transfer_ack(_expect_ack(reader, "ACK_RECEIVED"), "ACK_RECEIVED", len(data), crc)
    extra.expect(reader, "ERR_MIDI", timeout=5.0)
    extra.expect(reader, "IDLE", timeout=3.0)
    recover_and_play(port, reader, "after the invalid MIDI")
    print("PASS E2")


def e3_size_limits(port):
    print("\n=== E3: size limits (0 and MAX+1) must give ERR_SIZE then IDLE ===")
    reader = sender.LineReader(port)
    for length in (0, sender.MAX_MIDI_FILE_SIZE + 1):
        print(f"\nheader length {length}", flush=True)
        sender.write_all(port, header(length, 0))
        extra.expect(reader, "ERR_SIZE", timeout=3.0)
        extra.expect(reader, "IDLE", timeout=3.0)
    recover_and_play(port, reader, "after the size rejections")
    print("PASS E3")


def e4_two_producers(port):
    print("\n=== E4: ERR_BUSY + recovery IDLE (receive task) racing DONE (payload task) ===")
    print("LISTEN: the song must play to its end without a cut-off.")
    reader = sender.LineReader(port)
    data = extra.load(SONG)
    extra.start(port, reader, data)
    extra.quiet(reader, 1.0, "song playing, nothing should be sent")
    head, _ = sender.make_header(data)
    sender.write_all(port, head)
    # ERR_BUSY at once, recovery IDLE 0.25 s later, DONE when the song ends (~2.3 s after
    # the header); 4 s of silence afterwards closes the capture.
    lines = txq.drain(reader, 4.0)
    print("lines:", lines, flush=True)
    if lines not in (["ERR_BUSY", "IDLE", "DONE", "IDLE"], ["ERR_BUSY", "DONE", "IDLE"]):
        raise sender.TransferError(f"Unexpected sequence: {lines}")
    recover_and_play(port, reader, "after the refused header")
    print("PASS E4")


TESTS = {"E1": e1_bad_crc, "E2": e2_invalid_midi, "E3": e3_size_limits, "E4": e4_two_producers}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--port", default="COM5")
    parser.add_argument("--test", choices=sorted(TESTS), action="append")
    args = parser.parse_args(argv)
    if sender.serial is None:
        print("Install pySerial: python -m pip install pyserial", file=sys.stderr)
        return 2
    selected = args.test or sorted(TESTS)
    try:
        with sender.serial.Serial(args.port, sender.BAUD, bytesize=sender.serial.EIGHTBITS,
                                  parity=sender.serial.PARITY_NONE, stopbits=sender.serial.STOPBITS_ONE,
                                  timeout=0.05, write_timeout=sender.WRITE_TIMEOUT,
                                  xonxoff=False, rtscts=False, dsrdtr=False) as port:
            sender.synchronize(port)
            for key in selected:
                TESTS[key](port)
        print(f"\nPASS: error-path checks {', '.join(selected)} completed without a board reset.")
        return 0
    except (OSError, ValueError, sender.TransferError, sender.serial.SerialException) as exc:
        print("FAIL:", exc, file=sys.stderr)
        print("Keep this log. If a song is still playing: python newmiditst.py --stop", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nCancelled; use python newmiditst.py --stop if a song is playing.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
