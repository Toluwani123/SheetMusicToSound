"""Generate the three small extra MIDI files for the interpolation/ramp milestone.

Standard library only. All files follow the existing contract: Type 0, one
track, channel 1 (status byte channel 0), monophonic, notes 48..84.
PPQN 1000 with tempo 1,000,000 us/quarter, so 1 tick = exactly 1 ms.

Run:  python generate_milestone_tests.py
Output: midi_tests_milestone\\*.mid and midi_tests_milestone\\manifest.txt
"""

from pathlib import Path

OUT = Path(__file__).resolve().parent / "midi_tests_milestone"
PPQN = 1000
TEMPO_US = 1_000_000


def vlq(value):
    out = [value & 0x7F]
    value >>= 7
    while value:
        out.append(0x80 | (value & 0x7F))
        value >>= 7
    return bytes(reversed(out))


def build(timeline):
    """timeline: list of (note or None, milliseconds). None = rest."""
    track = bytearray()
    track += vlq(0) + b"\xFF\x51\x03" + TEMPO_US.to_bytes(3, "big")
    pending = 0
    for note, ms in timeline:
        if note is None:
            pending += ms
            continue
        track += vlq(pending) + bytes([0x90, note, 100])
        track += vlq(ms) + bytes([0x80, note, 0])
        pending = 0
    # Trailing silence is not part of this contract: EOT follows the last Note Off.
    track += vlq(0) + b"\xFF\x2F\x00"
    header = b"MThd" + (6).to_bytes(4, "big") + (0).to_bytes(2, "big") + \
        (1).to_bytes(2, "big") + PPQN.to_bytes(2, "big")
    return header + b"MTrk" + len(track).to_bytes(4, "big") + bytes(track)


def describe(timeline):
    notes = [n for n, _ in timeline if n is not None]
    total = sum(ms for _, ms in timeline)
    return len(notes), total


FILES = {}

# Test A: steady low / middle / high tones (MIDI 48 C3, 60 C4, 69 A4 = 440 Hz, 84 C6).
FILES["m6_pitch_range.mid"] = (
    "Test A. Four 2-second tones: MIDI 48 (130.81 Hz), 60 (261.63 Hz), 69 (440.00 Hz), "
    "84 (1046.50 Hz), 0.5 s rest between.",
    [(48, 2000), (None, 500), (60, 2000), (None, 500), (69, 2000), (None, 500), (84, 2000)])

# Test B: repeated / adjacent / short / zero-length notes, plus a long rest.
edges = []
edges += [(69, 125)] * 8                                   # 8 repeated A4, no rests: 1.000 s
edges += [(None, 750)]
edges += [(n, 125) for n in (60, 62, 64, 65, 67, 69, 71, 72)]  # adjacent scale, no rests
edges += [(None, 750)]
for ms in (50, 20, 10, 5, 2, 1):                           # short notes, 250 ms rest after each
    edges += [(72, ms), (None, 250)]
edges += [(72, 0), (None, 500)]                            # zero-length note (plays as 1 ms)
edges += [(None, 2000)]                                    # long rest: total 2.5 s silence
edges += [(67, 500)]
FILES["m6_envelope_edges.mid"] = (
    "Test B. 8 repeated A4 x 125 ms (no gaps); 0.75 s rest; C-major scale 8 x 125 ms (no gaps); "
    "0.75 s rest; C5 for 50, 20, 10, 5, 2, 1 ms each with 0.25 s rest; a 0 ms C5; 2.5 s silence; "
    "G4 0.5 s.", edges)

# Test D helper: 20 ms notes are almost all ramp, so a STOP lands in attack/sustain/release.
FILES["m6_stop_ramps.mid"] = (
    "Test D. 400 adjacent 20 ms notes alternating C4/G4 (8.0 s). Every note is "
    "5 ms attack + ~8 ms sustain + 5 ms release, so STOP usually lands inside a ramp.",
    [(60 if i % 2 == 0 else 67, 20) for i in range(400)])


def main():
    OUT.mkdir(exist_ok=True)
    lines = ["Milestone test MIDI files (Type 0, channel 1, PPQN 1000, 1 tick = 1 ms)", ""]
    for name, (purpose, timeline) in FILES.items():
        data = build(timeline)
        (OUT / name).write_bytes(data)
        count, total = describe(timeline)
        lines.append(f"{name}: {len(data)} bytes, {count} notes, {total / 1000:.3f} s")
        lines.append("    " + purpose)
        print(lines[-2])
    (OUT / "manifest.txt").write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
